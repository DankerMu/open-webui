---
name: invoice-builder
description: Invoice builder, uploaded and deleted by the slash menu e2e case.
---
No instructions.
