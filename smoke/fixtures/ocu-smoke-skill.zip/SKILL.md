---
name: harness-smoke-skill
description: Harness smoke skill, uploaded and deleted by make smoke.
---
No instructions.
