## Review round1 — fix pass1

Reviewed head `c4a579d8064d2d65d442512a97a254c81db1f655`.

The correctness+test-evidence seat found one **confirmed P1 wrapper defect in the new browser test**, not in the two production map entries: its listing interceptor unconditionally parses JSON after `route.fetch()`. The existing 3-second visible poll sends `If-None-Match`, and the static stub legitimately returns an empty `304`. A test that remains active through that poll can reject inside the route handler. The initial successful2.4s case did not cover it.

One fix pass is active. Strengthen the same browser case to observe a real bounded conditional poll and record RED before adding a non-200 pass-through using the already-fetched response. No fixed sleep, repeated upstream fetch, ETag removal, polling disablement, error suppression or timeout increase. Then rerun the real UI gate and obtain a fresh correctness+test-evidence rereview.

The classifier's semantic RED/GREEN, independent per-map omission controls and preserved capability boundary remain valid. Fixture acceptance is unchanged; merge is blocked pending the fix and fresh proof.
