import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time

root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
label, *argv = sys.argv[1:]
output = Path('/tmp') / f'issue-239-{label}.command.json'
if output.exists():
    raise SystemExit('Refusing to overwrite prior evidence')
paths = [
    'src/lib/components/chat/workspace-file-rows.ts',
    'src/lib/components/chat/workspace-file-rows.test.ts',
    'src/lib/components/chat/WorkspaceArtifact.svelte',
    'e2e/ocu-tree.e2e.ts',
    'docs/decisions/implemented/architecture/2026-10-04-ocu-workspace-file-tree.md',
    'Makefile', 'package-lock.json',
]
def identities():
    items = [root / name for name in paths]
    items += sorted((root / 'openspec/changes/workspace-tsv-kind').rglob('*'))
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in items if path.is_file()}
env = os.environ.copy()
env['PATH'] = str(root / '.venv/bin') + ':/Users/danker/.nvm/versions/node/v22.23.2/bin:' + env['PATH']
record = {'argv': argv, 'cwd': str(root), 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'platform': platform.platform(), 'inputs_before': identities()}
begin = time.time()
child = subprocess.Popen(argv, cwd=root, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
interrupted = False
try:
    stdout, stderr = child.communicate(timeout=1800)
except (subprocess.TimeoutExpired, KeyboardInterrupt):
    interrupted = True
    os.killpg(child.pid, signal.SIGINT)
    try:
        stdout, stderr = child.communicate(timeout=30)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGKILL)
        stdout, stderr = child.communicate()
record.update(exit=child.returncode, elapsed=time.time()-begin, interrupted=interrupted, stdout=stdout, stderr=stderr, inputs_after=identities())
record['inputs_unchanged'] = record['inputs_before'] == record['inputs_after']
output.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({key:value for key,value in record.items() if key not in ('inputs_before','inputs_after','stdout','stderr')}))
print(stdout[-7000:])
print(stderr[-5000:])
raise SystemExit(child.returncode if not interrupted else 124)
