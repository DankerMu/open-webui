const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const root = '/Users/danker/Documents/31308/open-webui-ocu-plan2';
const load = createRequire(`${root}/package.json`);
const ts = load('typescript');
const before = fs.readFileSync('/tmp/issue-239-e2e-before-format.txt', 'utf8');
const expected = fs.readFileSync('/tmp/issue-239-e2e-formatted.txt', 'utf8');
const after = fs.readFileSync(`${root}/e2e/ocu-tree.e2e.ts`, 'utf8');
const hash = (value) => crypto.createHash('sha256').update(value).digest('hex');
assert.equal(after, expected);
function syntax(text) {
  const source = ts.createSourceFile('ocu-tree.e2e.ts', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  assert.deepEqual(source.parseDiagnostics, []);
  function visit(node) {
    const children = node.getChildren(source);
    return children.length ? [node.kind, children.map(visit)] : [node.kind, node.getText(source)];
  }
  return visit(source);
}
const first = syntax(before);
const last = syntax(after);
assert.deepEqual(last, first);
const result = {
  before_sha256: hash(before),
  after_sha256: hash(after),
  syntax_tree_sha256: hash(JSON.stringify(first)),
  identical_typescript_syntax_and_token_text: true,
  final_bytes_equal_prettier_output: true,
  typescript_version: ts.version,
  change: 'Only line wrapping of the new browser test callback destructured parameter; no token, literal, assertion or runtime change.',
  evidence: 'ui.command.json exercised before_sha256; this exact syntax/token equivalence bridges to the final formatted test. Production module and paired unit test are unchanged.'
};
fs.writeFileSync('/tmp/issue-239-format-identity.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
