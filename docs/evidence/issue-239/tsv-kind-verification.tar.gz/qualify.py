import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile
import time

root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
module_name = 'src/lib/components/chat/workspace-file-rows.ts'
test_name = 'src/lib/components/chat/workspace-file-rows.test.ts'
paths = [module_name, test_name, 'e2e/ocu-tree.e2e.ts']
def hashes(base):
    return {name: hashlib.sha256((base/name).read_bytes()).hexdigest() for name in paths}
result = {'inputs_before': hashes(root), 'cases': [], 'scope': 'Disposable tracked-source snapshot, reused installed dependencies and copied generated Kit metadata; canonical make test-frontend. No live source mutation.'}
try:
    with tempfile.TemporaryDirectory(prefix='issue-239-qualification-') as temporary:
        scratch = Path(temporary)
        snapshot = scratch/'source.tar'
        with snapshot.open('wb') as output:
            subprocess.run(['git','archive','HEAD'],cwd=root,stdout=output,check=True,timeout=120)
        copy = scratch/'repo'
        copy.mkdir()
        with tarfile.open(snapshot) as archive:
            archive.extractall(copy, filter='data')
        for name in paths:
            shutil.copyfile(root/name,copy/name)
        (copy/'node_modules').symlink_to(root/'node_modules', target_is_directory=True)
        shutil.copytree(root/'.svelte-kit',copy/'.svelte-kit')
        assert hashes(copy)==result['inputs_before']
        module = copy/module_name
        candidate = module.read_text()
        type_entry = "\tspreadsheet: 'sheet',\n"
        mime_entry = "\t'text/tab-separated-values': 'sheet',\n"
        assert candidate.count(type_entry)==1 and candidate.count(mime_entry)==1
        env=os.environ.copy()
        env['PATH']='/Users/danker/.nvm/versions/node/v22.23.2/bin:'+env['PATH']
        def run(label, expected):
            started=time.time()
            process=subprocess.run(['make','test-frontend'],cwd=copy,env=env,capture_output=True,text=True,timeout=180)
            row={'label':label,'argv':['make','test-frontend'],'exit':process.returncode,'elapsed':time.time()-started,'inputs':hashes(copy),'stdout':process.stdout,'stderr':process.stderr}
            result['cases'].append(row)
            print(label,process.returncode,process.stdout[-1800:],process.stderr[-3000:])
            assert process.returncode==expected, 'Unexpected qualification exit'
            if expected:
                assert "expected 'other' to be 'sheet'" in process.stdout+process.stderr, 'Mutant did not fail for the semantic classification error'
            return row
        run('candidate-baseline',0)
        module.write_text(candidate.replace(type_entry,'',1))
        run('missing-spreadsheet-type',2)
        module.write_text(candidate.replace(mime_entry,'',1))
        run('missing-tsv-mime',2)
        module.write_text(candidate)
        run('restored-candidate',0)
    result['owned_snapshot_removed']=not Path(temporary).exists()
finally:
    result['inputs_after']=hashes(root)
    result['live_inputs_unchanged']=result['inputs_before']==result['inputs_after']
    Path('/tmp/issue-239-qualification-result.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['owned_snapshot_removed'] and result['live_inputs_unchanged']
