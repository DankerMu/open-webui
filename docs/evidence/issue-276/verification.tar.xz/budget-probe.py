"""Parent probe: successful private retirement must not be stranded by publication budget checks."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile

root, output = map(Path, sys.argv[1:])
assert not output.exists()
for key in ('ALL_PROXY','HTTP_PROXY','HTTPS_PROXY','all_proxy','http_proxy','https_proxy'):
    os.environ.pop(key,None)
os.environ['NO_PROXY']=os.environ['no_proxy']='*'
sys.path[:0]=[str(root),str(root/'computer-use-server')]
import pytest
from tests.orchestrator.test_office_sessions import office_world, _outputs, _state
from tests.orchestrator.test_office_callback_publish import _opened, _surviving
from tests.orchestrator.test_office_callback_processing import CHANGED, _content_origin, _bind_internal
from tests.orchestrator.test_office_save_as import _kill_worker_at, _RETIREMENT_WORKER, _office, SERVER_DIR

WORKER = r'''
import json, os, sys, time
from pathlib import Path
from types import SimpleNamespace
os.environ['BASE_DATA_DIR']=os.environ['OCU_BASE']
import docker_manager
container=SimpleNamespace(id='retirement-budget-sandbox',status='running',attrs={'State':{'Paused':False}})
def pause():
    container.status,container.attrs['State']['Paused']='paused',True
def unpause():
    container.status,container.attrs['State']['Paused']='running',False
container.pause,container.unpause,container.reload=pause,unpause,lambda:None
docker_manager._docker_client=SimpleNamespace(containers=SimpleNamespace(get=lambda identity:container))
from office import publish
from office.store import OfficeStore
chat=os.environ['OCU_CHAT']
private=Path(os.environ['OCU_BASE'])/chat/'.ocu/office/staging'
private_identity=(private.stat().st_dev,private.stat().st_ino)
real_sync,real_monotonic=os.fsync,time.monotonic
elapsed=[0.0]
slow=[False]
armed=[False]
syncs=[0]
def sync(fd):
    result=real_sync(fd)
    info=os.fstat(fd)
    if (info.st_dev,info.st_ino)==private_identity:
        syncs[0]+=1
        if slow[0] and armed[0]:
            elapsed[0]+=6.0
            armed[0]=False
    return result
os.fsync=sync
time.monotonic=lambda:real_monotonic()+elapsed[0]
observations=[]
for mode in ('slow','slow','ordinary'):
    slow[0]=mode=='slow'
    armed[0]=True
    before_syncs=syncs[0]
    error=None
    try:
        publish.recover_publications(chat,now=time.time()+10.0)
    except Exception as exc:
        error={'type':type(exc).__name__,'message':str(exc)}
    state=OfficeStore().read(chat)
    session=state['sessions'][os.environ['COPY_SESSION']]
    observations.append({'mode':mode,'error':error,'pending':len(state['journal']),
                         'private_names':sorted(p.name for p in private.iterdir()),
                         'reason':session['reason'],'private_sync_calls':syncs[0]-before_syncs,
                         'injected_budget_seconds':elapsed[0], 'container_paused':container.attrs['State']['Paused']})
print(json.dumps({'budget_observations':observations}),flush=True)
'''

with tempfile.TemporaryDirectory(prefix='issue-276-budget-') as temporary, pytest.MonkeyPatch.context() as patch:
    fixture=office_world.__wrapped__(Path(temporary),patch)
    world=next(fixture)
    try:
        http,data,origin,manager,broker,baseline,session=_opened(world)
        (_outputs(data)/'report.docx').unlink()
        with _content_origin({'/save.docx':CHANGED}) as server,_bind_internal(patch,server.url):
            _surviving(http,data,session,patch,server,final=True)
        environment=_kill_worker_at(data,_RETIREMENT_WORKER,'retained-intent',session,RETIRE_PRECLAIM_TIMEOUT='1')
        before=json.loads(_state(data).read_bytes())
        assert next(iter(before['journal'].values()))['copy']['retained_reason']=='publish_timeout'
        _outputs(data).rmdir()
        child=subprocess.run([sys.executable,'-c',WORKER],cwd=SERVER_DIR,env={**environment,'COPY_CUT':'','RETIRE_PRECLAIM_TIMEOUT':''},capture_output=True,text=True,timeout=20)
        assert child.returncode==0,(child.stdout,child.stderr)
        payloads=[json.loads(line) for line in child.stdout.splitlines() if line.startswith('{"budget_observations":')]
        assert len(payloads)==1
        rows=payloads[0]['budget_observations']
        after=json.loads(_state(data).read_bytes())
        assert after['documents']==before['documents'] and after['receipts']==before['receipts']
        assert not _outputs(data).exists()
        accepted=all(row['error'] is None and row['pending']==0 and row['private_names']==[] and row['reason']=='publish_timeout' and not row['container_paused'] for row in rows)
        result={'source_root':str(root),'owner_sha256':hashlib.sha256((root/'computer-use-server/office/save_as.py').read_bytes()).hexdigest(),
                'oracle_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'accepted':accepted,
                'child_stdout':child.stdout,'child_stderr':child.stderr,'documents_receipts_conserved':True,'outputs_recreated':False,
                'boundary':'Actual fresh recovery/filesystem/fsync with controlled monotonic budget advance after successful private-directory sync; not a wall-clock performance measurement.'}
    finally:
        fixture.close()
assert not Path(temporary).exists()
result['temporary_directory_removed']=True
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'accepted':accepted,'rows':rows},indent=2),flush=True)
raise SystemExit(0 if accepted else 1)
