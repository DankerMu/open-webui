"""Parent-owned retained-intent/root-removal probe using real HTTP and native workers."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import tempfile

root, output = map(Path, sys.argv[1:])
assert not output.exists()
for name in ('ALL_PROXY','HTTP_PROXY','HTTPS_PROXY','all_proxy','http_proxy','https_proxy'):
    os.environ.pop(name, None)
os.environ['NO_PROXY'] = os.environ['no_proxy'] = '*'
sys.path[:0] = [str(root), str(root/'computer-use-server')]
import pytest
from tests.orchestrator.test_office_sessions import office_world, _outputs, _state, _versions
from tests.orchestrator.test_office_callback_publish import _opened, _surviving
from tests.orchestrator.test_office_callback_processing import CHANGED, _content_origin, _bind_internal
from tests.orchestrator.test_office_save_as import _kill_worker_at, _RETIREMENT_WORKER, _office, SERVER_DIR
from tests.orchestrator.test_outputs_endpoint import CHAT

identities = {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in (
    'computer-use-server/office/save_as.py','computer-use-server/office/publish.py',
    'tests/orchestrator/test_office_save_as.py')}
rows = []
for remove_root in (False, True):
    with tempfile.TemporaryDirectory(prefix='issue-276-retirement-') as directory, pytest.MonkeyPatch.context() as patch:
        fixture = office_world.__wrapped__(Path(directory),patch)
        world = next(fixture)
        try:
            http,data,origin,manager,broker,baseline,session = _opened(world)
            (_outputs(data)/'report.docx').unlink()
            with _content_origin({'/save.docx':CHANGED}) as server, _bind_internal(patch,server.url):
                _surviving(http,data,session,patch,server,final=True)
            environment = _kill_worker_at(data,_RETIREMENT_WORKER,'retained-intent',session,RETIRE_PRECLAIM_TIMEOUT='1')
            assert Path(environment['COPY_MARKER']).read_text() == 'retained-intent'
            before = json.loads(_state(data).read_bytes())
            entry = next(iter(before['journal'].values()))
            assert entry['copy']['retained_reason']=='publish_timeout'
            names = [_office(data)/'staging'/entry['staging'][key] for key in ('anchor_name','witness_name')]
            assert all(path.read_bytes()==CHANGED for path in names)
            assert not list(_outputs(data).iterdir())
            index = data/CHAT/'.ocu/index.json'
            index_before = index.read_bytes()
            selected = _versions(data)/hashlib.sha256(CHANGED).hexdigest()
            assert selected.read_bytes()==CHANGED
            if remove_root:
                _outputs(data).rmdir()
            started = json.loads((_office(data)/'fence.json').read_bytes())['pause_started_at']
            argv = [sys.executable,'-c',_RETIREMENT_WORKER]
            fresh_env = {**environment,'COPY_CUT':'','RETIRE_PRECLAIM_TIMEOUT':'','OCU_RECOVER_NOW':str(started+5.001)}
            fresh = subprocess.run(argv,cwd=SERVER_DIR,env=fresh_env,capture_output=True,text=True,timeout=20)
            assert fresh.returncode==0,(fresh.stdout,fresh.stderr)
            after = json.loads(_state(data).read_bytes())
            record = after['sessions'][session['session_id']]
            row = {'removed_root':remove_root,'cut':'retained-intent','killed_worker_marker_observed':True,
                   'fresh_exit':fresh.returncode,'fresh_stdout':fresh.stdout,'fresh_stderr':fresh.stderr,
                   'state':record['state'],'reason':record['reason'],'saved_as':record['saved_as'],
                   'pending':len(after['journal']),'private_names_remaining':sum(path.exists() for path in names),
                   'outputs_exists':_outputs(data).exists(),'documents_conserved':after['documents']==before['documents'],
                   'receipts_conserved':after['receipts']==before['receipts'],'selected_blob_conserved':selected.read_bytes()==CHANGED,
                   'index_conserved':index.read_bytes()==index_before,'session_identity_conserved':record['file_id']==session['file_id'] and record['document_key']==session['document_key']}
            row['accepted'] = (row['state']=='error' and row['reason']=='publish_timeout' and row['saved_as'] is None and row['pending']==0 and row['private_names_remaining']==0 and row['outputs_exists']==(not remove_root) and all(row[key] for key in ('documents_conserved','receipts_conserved','selected_blob_conserved','index_conserved','session_identity_conserved')))
            frozen = _state(data).read_bytes()
            replay = subprocess.run(argv,cwd=SERVER_DIR,env=fresh_env,capture_output=True,text=True,timeout=20)
            assert replay.returncode==0,(replay.stdout,replay.stderr)
            row['completed_replay_state_unchanged'] = _state(data).read_bytes()==frozen
            row['accepted'] = row['accepted'] and row['completed_replay_state_unchanged']
            rows.append(row)
        finally:
            fixture.close()
    assert not Path(directory).exists()
assert rows[0]['accepted'], 'present-root positive control failed'
assert identities == {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in identities}
result = {'source_root':str(root),'source_identities':identities,'oracle_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'rows':rows,'accepted':all(row['accepted'] for row in rows),'owned_temporary_directories_removed':True,
          'environment':{'python':sys.version,'platform':platform.platform(),'packages':{name:importlib.metadata.version(name) for name in ('pytest','pytest-asyncio','fastapi','starlette','aiohttp','httpx','docker','mcp','PyYAML')}},
          'limits':'Actual fixture HTTP, native SIGKILL and fresh Python filesystem recovery; controlled Docker state, not deployment/power-loss certification.'}
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'accepted':result['accepted'],'rows':[{k:v for k,v in row.items() if k not in ('fresh_stdout','fresh_stderr')} for row in rows]},indent=2),flush=True)
raise SystemExit(0 if result['accepted'] else 1)
