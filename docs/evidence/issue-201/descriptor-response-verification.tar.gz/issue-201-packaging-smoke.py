"""Import the app from exactly the server Dockerfile COPY source closure."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = Path('/Users/danker/Documents/31308/open-computer-use/computer-use-server')
dockerfile = root / 'Dockerfile'
report = {'dockerfile_sha256': hashlib.sha256(dockerfile.read_bytes()).hexdigest(),
          'boundary': 'isolated declared COPY materialization, actual app import; not image build',
          'copies': [], 'exit': None}
if args.output.exists():
    raise SystemExit('Refusing to overwrite evidence')
with tempfile.TemporaryDirectory(prefix='issue-201-package-', dir='/tmp') as directory:
    temporary = Path(directory)
    appdir = temporary / 'app'
    appdir.mkdir()
    for line in dockerfile.read_text().splitlines():
        if not line.lstrip().upper().startswith('COPY '):
            continue
        fields = shlex.split(line, comments=True)
        if len(fields) != 3 or fields[1].startswith('--'):
            raise RuntimeError('Unsupported COPY syntax; do not guess packaging inputs')
        source = root / fields[1]
        destination = appdir / fields[2]
        if fields[2] == '.':
            destination = appdir / source.name
        if source.is_symlink() or not source.exists():
            raise RuntimeError('COPY input must exist and not be symlink')
        if source.is_dir():
            shutil.copytree(source, destination, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
        report['copies'].append({'source': fields[1], 'destination': fields[2]})
    identity = {p.relative_to(appdir).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in appdir.rglob('*.py')}
    report['python_inputs'] = identity
    code = """import json, pathlib, app, file_response, uploads
root = pathlib.Path.cwd()
for module in (app, file_response, uploads):
    assert pathlib.Path(module.__file__).parent == root
assert any(getattr(route, 'path', '') == '/files/{chat_id}/{filename:path}' for route in app.app.routes)
print(json.dumps({'app':app.__file__,'response':file_response.__file__,'reader':uploads.__file__,'route_present':True}))
"""
    env = {'PATH': os.defpath, 'HOME': str(temporary), 'PYTHONDONTWRITEBYTECODE': '1',
           'BASE_DATA_DIR': str(temporary / 'data'),
           'OCU_INTERNAL_TOKEN': 'issue-201-packaging-only-token',
           'MCP_API_KEY': 'issue-201-packaging-only-mcp-token',
           'PUBLIC_BASE_URL': 'http://ocu.example', 'OCU_WEBUI_ORIGIN': 'https://webui.example',
           'OCU_SANDBOX_SUBNET': '10.90.0.0/24', 'SINGLE_USER_MODE': 'true',
           'DOCKER_HOST': 'unix://' + str(temporary / 'no-docker.sock')}
    command = [sys.executable, '-B', '-c', code]
    result = subprocess.run(command, cwd=appdir, env=env, capture_output=True, text=True, timeout=30)
    report.update(argv=command, exit=result.returncode, stdout=result.stdout, stderr=result.stderr)
    report['inputs_unchanged'] = identity == {
        p.relative_to(appdir).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in appdir.rglob('*.py')}
report['owned_tree_removed'] = not temporary.exists()
args.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key:report[key] for key in ('exit','stdout','stderr','inputs_unchanged','owned_tree_removed')}, indent=2))
raise SystemExit(report['exit'] if report['inputs_unchanged'] and report['owned_tree_removed'] else 2)
