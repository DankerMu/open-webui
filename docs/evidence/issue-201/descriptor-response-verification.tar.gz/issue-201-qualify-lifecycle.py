"""Disposable single-defect qualification of unchanged response ownership tests."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

SOURCE = Path('/Users/danker/Documents/31308/open-computer-use')
parser = argparse.ArgumentParser()
parser.add_argument('--case', choices=('restore', 'leak', 'doubleclose', 'abandon'), required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
if args.output.exists() or args.output.with_suffix('.log').exists():
    raise SystemExit('Refusing to overwrite evidence')
paths = sorted((SOURCE / 'computer-use-server').rglob('*.py'))
paths = [p for p in paths if '__pycache__' not in p.parts]
paths += [SOURCE / 'tests/test_file_response.py', SOURCE / 'computer-use-server/requirements.txt']
identity = {p.relative_to(SOURCE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
report = {'case': args.case, 'source_before': identity,
          'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'qualification': 'late semantic sensitivity, not original pre-fix chronology'}
with tempfile.TemporaryDirectory(prefix='issue-201-negative-', dir='/tmp') as directory:
    root = Path(directory)
    for path in paths:
        target = root / path.relative_to(SOURCE)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
    (root / 'computer-use-server/static').mkdir()
    (root / 'computer-use-server/static/drawio').mkdir()
    target = root / 'computer-use-server/file_response.py'
    text = target.read_text()
    mutations = {
        'leak': ('            close_fd(file_fd)', '            pass  # qualification: omit owned close'),
        'doubleclose': ('            close_fd(file_fd)', '            close_fd(file_fd)\n            close_fd(file_fd)'),
        'abandon': ('anyio.to_thread.run_sync(os.read, file_fd, self.chunk_size)',
                    'anyio.to_thread.run_sync(os.read, file_fd, self.chunk_size, abandon_on_cancel=True)'),
    }
    if args.case != 'restore':
        old, new = mutations[args.case]
        assert text.count(old) == 1
        target.write_text(text.replace(old, new))
        report['mutation'] = {'from': old, 'to': new}
    selected = {
        'leak': 'completed_file_response or read_failure or send_failure',
        'doubleclose': 'read_failure or send_failure',
        'abandon': 'termination_waits_for_real_read',
        'restore': '',
    }[args.case]
    command = [sys.executable, '-m', 'pytest', 'tests/test_file_response.py', '-vv', '--import-mode=importlib',
               '--junitxml=' + str(args.output.with_suffix('.xml'))]
    if selected:
        command += ['-k', selected]
    report.update(argv=command, candidate_response_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                  test_sha256=hashlib.sha256((root / 'tests/test_file_response.py').read_bytes()).hexdigest())
    started = time.monotonic()
    with args.output.with_suffix('.log').open('x') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT,
                                env={k:v for k,v in os.environ.items() if k.lower() not in {'http_proxy','https_proxy','all_proxy'}},
                                timeout=90)
    report.update(exit=result.returncode, elapsed_seconds=time.monotonic()-started)
report['owned_tree_removed'] = not root.exists()
report['source_after'] = {p.relative_to(SOURCE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
report['source_unchanged'] = report['source_before'] == report['source_after']
args.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k:v for k,v in report.items() if k not in {'source_before','source_after'}}, indent=2))
raise SystemExit(report['exit'] if report['source_unchanged'] and report['owned_tree_removed'] else 2)
