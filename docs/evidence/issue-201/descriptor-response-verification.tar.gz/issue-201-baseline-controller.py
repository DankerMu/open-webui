"""Bounded parent-owned checks; exclusive evidence files and stable tracked inputs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path('/Users/danker/Documents/31308/open-computer-use')
parser = argparse.ArgumentParser()
parser.add_argument('--run-id', required=True)
parser.add_argument('--expected-sha', required=True)
parser.add_argument('--timeout', type=int, default=300)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
if not args.run_id.isalnum() or not command or not 1 <= args.timeout <= 3600:
    raise SystemExit('Invalid run identity, command or bound')
env = {k: v for k, v in os.environ.items() if k.lower() not in {'all_proxy', 'http_proxy', 'https_proxy'}}
base = Path('/tmp/issue-201-' + args.run_id)
log_path, result_path, launch_path = [Path(str(base) + suffix) for suffix in ('.log', '.json', '-launch.json')]
for path in (log_path, result_path, launch_path):
    if path.exists():
        raise SystemExit(f'Refusing to overwrite {path}')

def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()

def identity():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
            for name in paths if name and (name.endswith('.py') or name.endswith('requirements.txt'))}

def interrupted(signum, frame):
    raise KeyboardInterrupt(f'Interrupted by {signum}')

if head() != args.expected_sha:
    raise SystemExit('Unexpected source HEAD')
state = {'argv': command, 'cwd': str(ROOT), 'source_head': head(),
         'input_sha256_before': identity(), 'exit': None,
         'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'timeout_seconds': args.timeout}
started = time.monotonic()
process = None
for number in (signal.SIGINT, signal.SIGTERM):
    signal.signal(number, interrupted)
try:
    with log_path.open('x') as output:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=output,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        state.update(runner_pid=os.getpid(), child_pid=process.pid, child_pgid=process.pid)
        launch_path.write_text(json.dumps(state, indent=2) + '\n')
        state['exit'] = process.wait(timeout=args.timeout)
except (subprocess.TimeoutExpired, KeyboardInterrupt) as exc:
    state['interruption'] = type(exc).__name__
finally:
    for number in (signal.SIGINT, signal.SIGTERM):
        signal.signal(number, signal.SIG_IGN)
    if process is not None and process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)
    state.update(elapsed_seconds=time.monotonic()-started,
                 source_head_after=head(), input_sha256_after=identity(),
                 child_reaped=process is None or process.poll() is not None)
    state['inputs_unchanged'] = state['input_sha256_before'] == state['input_sha256_after']
    result_path.write_text(json.dumps(state, indent=2) + '\n')
    print(json.dumps({k:v for k,v in state.items() if not k.startswith('input_sha256')}, indent=2))
if not state['inputs_unchanged'] or state['source_head_after'] != args.expected_sha:
    raise SystemExit(2)
raise SystemExit(state['exit'] if state['exit'] is not None else 2)
