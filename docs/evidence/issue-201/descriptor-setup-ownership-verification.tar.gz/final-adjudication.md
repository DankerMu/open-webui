# Issue201 final adjudication

Source candidate `3280d24a14d6240b1ad4edcb5d45e40bb515f6f7`; base `8b4d81847c3cc1388e78b078fde817888514cf6b`. Gate352 round2 clean;1/2 fix passes used.

Round1: correctness/integration and test-evidence/spec seats found no actionable defect; security/invariant proposed SECINV-R1-1 native setup-worker ownership. Parent confirmed its missing coverage and reproduced the direct response defect before the fix: four direct-response native cancellation failures, four full-app controls passing. Acquisition lost the real descriptor after worker return; response-level fstat outlived close/reuse and observed the sentinel inode. The evidence does not establish an ordinary disconnect or default Uvicorn request-path leak.

Fix: an outer AnyIO group owns the entire response child, so native caller cancellation becomes child-scope cancellation and group exit joins setup. The child's finally owns release; the existing inner stream/disconnect group joins reads. Starlette collapse_excgroups preserves singleton pre-header403/404 instead of converting them to grouped500s.

Round2: fresh correctness/test-evidence full-diff review reports no findings and closes SECINV-R1-1. Independent verifier marks that exact candidate REFUTED at the repaired head, while retaining its historical confirmed direct-response defect and middleware reachability limit. Parent gap sweep finds no additional blocking defect.

## Current-candidate evidence

- Same native regression input before/after:4 direct failures+4 full-app controls →8 passes. Combined owning cases88pass.
- Eleven affected test modules667pass,0skip,3subtests,99.12s;49/49 response statements covered (line, not branch coverage).
- Actual Uvicorn40 cases+6 protocol comparisons pass; exact original bytes/metadata through response-start path replacement, pre-header403/404, safe aliases and MIME/disposition/isolation/no-store retained. Bounded client abandonment and later liveness are separate from ASGI descriptor ownership proof.
- Final disposable missing-close/double-close/abandoned-read controls:10/6/4 semantic failures;30 restored passes. Late sensitivity qualification is not original pre-fix chronology.
- Declared Dockerfile COPY closure imports the actual app/response/reader; no image build claimed.
- Fresh reviewer reconciles every matrix/HTTP/packaging/negative-control fingerprint with frozen candidate blobs. Historical Git-head labels in pre-commit runs are not used as candidate identity.

## Limits retained

The original tracked-only runner missed the new lifecycle test's pre-run fingerprint; raw execution and post-baseline hash remain, with no invented historical hash. New setup regressions have complete matching RED/GREEN input records. Bash matrix and eval qualification package versions differ and are separately recorded. Static/doc command pass indexes are parent observations, not independent raw transcripts.

No full-suite, image/Linux/LAN certification, same-inode content snapshot or hard-link/bind-mount provenance claim. Filesystem work may delay cancellation until the non-abandoned worker finishes; there is no latency bound. Private framework helper and task-group semantics require requalification on dependency updates. Post-header faults abort rather than send a second response.
