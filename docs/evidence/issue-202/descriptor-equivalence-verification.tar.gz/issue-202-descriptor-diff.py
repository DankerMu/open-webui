import json
import sys

def diff(a, b, path=''):
    if type(a) is not type(b):
        print(path, repr(a), repr(b))
    elif isinstance(a, dict):
        for key in sorted(a.keys() | b.keys()):
            diff(a.get(key), b.get(key), path + '/' + key)
    elif isinstance(a, list):
        if len(a) != len(b):
            print(path, 'length', len(a), len(b))
        for i, (x, y) in enumerate(zip(a, b)):
            diff(x, y, path + '/' + str(i))
    elif a != b:
        print(path, repr(a), repr(b))
a = json.load(open(sys.argv[1]))['cases']
b = json.load(open(sys.argv[2]))['cases']
diff(a, b)
