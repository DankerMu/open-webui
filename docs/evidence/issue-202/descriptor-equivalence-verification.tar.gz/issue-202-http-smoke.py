"""Actual app consumer smoke for shared descriptor extraction; benign owned data only."""
import argparse
import hashlib
import http.client
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import zipfile

SUPPORT = Path('/tmp/issue-200-http-smoke.py')
spec = importlib.util.spec_from_file_location('archive_smoke_support', SUPPORT)
support = importlib.util.module_from_spec(spec)
spec.loader.exec_module(support)
ROOT = Path('/Users/danker/Documents/31308/open-computer-use')
CHAT = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890'
UNSAFE = 'a1b2c3d4-e5f6-7890-abcd-ef1234567891'
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
if args.output.exists():
    raise SystemExit('Refusing to overwrite evidence')
report = {'source_before': support.source_identity(ROOT), 'requests': [], 'exit': None,
          'script_sha256': support.sha(Path(__file__).read_bytes()),
          'support_sha256': support.sha(SUPPORT.read_bytes()), 'toolchain': support.toolchain()}
process = bound = None
with tempfile.TemporaryDirectory(prefix='issue-202-http-', dir='/tmp') as directory:
    root = Path(directory)
    data = root / 'data'
    outputs = data / CHAT / 'outputs'
    outputs.mkdir(parents=True)
    (outputs / 'ordinary.txt').write_bytes(b'ordinary preserved bytes')
    canary = root / 'benign-canary.txt'
    canary.write_bytes(b'outside-shared-primitive-canary')
    (data / UNSAFE).mkdir()
    (data / UNSAFE / 'outputs').symlink_to(outputs, target_is_directory=True)
    env = {'PATH': os.defpath, 'HOME': str(root), 'PYTHONDONTWRITEBYTECODE': '1',
           'BASE_DATA_DIR': str(data), 'OCU_INTERNAL_TOKEN': support.TOKEN,
           'MCP_API_KEY': 'issue-202-http-only-mcp-token',
           'DOCKER_HOST': 'unix://' + str(root / 'no-docker.sock'),
           'PUBLIC_BASE_URL': 'http://ocu.example', 'OCU_WEBUI_ORIGIN': 'https://webui.example',
           'OCU_SANDBOX_SUBNET': '10.90.0.0/24', 'SINGLE_USER_MODE': 'true',
           'SKILLS_CACHE_DIR': str(root / 'skills'), 'SKILLS_CACHE_HOST_PATH': str(root / 'skills')}
    bound = socket.socket()
    bound.bind(('127.0.0.1', 0)); bound.listen(128)
    port = bound.getsockname()[1]
    command = [sys.executable, '-B', str(SUPPORT), '_serve', str(ROOT), str(bound.fileno()), str(root / 'metadata.json')]
    report['server_argv'] = command
    def request(method, path, body=None, extra=None):
        headers = {'Authorization': 'Bearer ' + support.TOKEN, 'Connection': 'close'}
        headers.update(extra or {})
        connection = http.client.HTTPConnection('127.0.0.1', port, timeout=5)
        try:
            connection.request(method, path, body=body, headers=headers)
            response = connection.getresponse()
            content = response.read(2 * 1024 * 1024)
            row = {'method': method, 'path': path, 'status': response.status,
                   'headers': response.getheaders(), 'body_sha256': support.sha(content),
                   'body_size': len(content)}
            if response.getheader('Content-Type', '').startswith('application/json'):
                row['json'] = json.loads(content)
            report['requests'].append(row)
            return row, content
        finally:
            connection.close()
    with (root / 'server.log').open('w+b') as log:
        try:
            process = subprocess.Popen(command, cwd=root, env=env, pass_fds=(bound.fileno(),),
                                       start_new_session=True, stdout=log, stderr=subprocess.STDOUT)
            bound.close(); bound = None
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise RuntimeError('Owned app exited before readiness')
                try:
                    row, content = request('GET', '/health')
                    if row['status'] == 200:
                        break
                except (OSError, http.client.HTTPException):
                    pass
                time.sleep(.05)
            else:
                raise TimeoutError('Owned app readiness deadline')
            expected = {'ordinary.txt': b'ordinary preserved bytes'}
            for seq, payload in enumerate((b'first committed upload', b'second collision upload')):
                boundary = 'issue202benignboundary'
                body = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="report.txt"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()
                        + payload + f'\r\n--{boundary}--\r\n'.encode())
                row, _ = request('POST', f'/api/uploads/{CHAT}/report.txt', body,
                                 {'Content-Type': 'multipart/form-data; boundary=' + boundary,
                                  'X-OCU-Attachment-Id': 'issue202-' + str(seq)})
                stored = 'report.txt' if seq == 0 else 'report (2).txt'
                assert row['status'] == 200 and row['json']['filename'] == stored, row
                assert row['json']['size'] == len(payload)
                assert row['json']['md5'] == hashlib.md5(payload, usedforsecurity=False).hexdigest()
                expected[stored] = payload
            row, _ = request('GET', f'/api/uploads/{CHAT}/imports')
            assert row['status'] == 200 and set(row['json']['ids']) == {'issue202-0','issue202-1'}, row
            row, _ = request('GET', f'/api/outputs/{CHAT}')
            assert row['status'] == 200 and row['json']['total'] == 3, row
            files = {item['path']: item for item in row['json']['files']}
            assert set(files) == set(expected)
            assert len({item['file_id'] for item in files.values()}) == 3
            for name, payload in expected.items():
                assert files[name]['hash'] == support.sha(payload)
                assert files[name]['size'] == len(payload)
            etag = dict(row['headers'])['etag']
            row, content = request('GET', f'/api/outputs/{CHAT}', extra={'If-None-Match': etag})
            assert row['status'] == 304 and content == b'', row
            row, content = request('GET', f'/files/{CHAT}/ordinary.txt')
            assert row['status'] == 200 and content == expected['ordinary.txt']
            row, content = request('GET', f'/files/{CHAT}/archive')
            assert row['status'] == 200
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                assert {name:archive.read(name) for name in archive.namelist()} == expected
            (outputs / 'outside-link.txt').symlink_to(canary)
            for path in (f'/files/{CHAT}/outside-link.txt', f'/files/{CHAT}/archive'):
                row, content = request('GET', path)
                assert row['status'] in (403,404) and canary.read_bytes() not in content, row
            row, content = request('GET', f'/api/outputs/{UNSAFE}')
            assert row['status'] == 500 and row['json'] == {'detail':'outputs listing failed'}, row
            assert str(root).encode() not in content and canary.read_bytes() not in content
            assert {name:(outputs/name).read_bytes() for name in expected} == expected
            assert canary.read_bytes() == b'outside-shared-primitive-canary'
            report['observed_outputs'] = {name:support.sha(payload) for name,payload in expected.items()}
            report['outside_canary_unchanged'] = True
            report['exit'] = 0
        except BaseException as exc:
            report['exit'] = 1
            report['failure'] = repr(exc)
        finally:
            if process is not None:
                report['process_cleanup'] = support.stop_owned(process)
            if bound is not None:
                bound.close()
            log.flush(); log.seek(0)
            report['server_log'] = log.read().decode(errors='replace')
            probe = socket.socket(); probe.settimeout(.5)
            try:
                report['port_closed'] = probe.connect_ex(('127.0.0.1', port)) != 0
            finally:
                probe.close()
report['owned_tree_removed'] = not root.exists()
report['source_after'] = support.source_identity(ROOT)
report['source_unchanged'] = report['source_before'] == report['source_after']
if not report['source_unchanged'] or not report['owned_tree_removed'] or not report['port_closed']:
    report['exit'] = 2
args.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k:report[k] for k in ('exit','source_unchanged','owned_tree_removed','port_closed')}, indent=2))
if 'failure' in report:
    print(report['failure'])
raise SystemExit(report['exit'])
