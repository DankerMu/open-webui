"""Probe constructor policy when required OS flags are unavailable before import."""
import argparse
import importlib
import json
import os
from pathlib import Path
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--server', type=Path, required=True)
parser.add_argument('--missing', choices=('O_NOFOLLOW','O_DIRECTORY','O_NONBLOCK','none'), required=True)
args = parser.parse_args()
with tempfile.TemporaryDirectory(prefix='issue-202-platform-', dir='/tmp') as directory:
    os.environ['BASE_DATA_DIR'] = directory
    os.environ['PUBLIC_BASE_URL'] = 'http://localhost:20200'
    os.environ['DOCKER_SOCKET'] = 'unix://' + directory + '/no-docker.sock'
    sys.path.insert(0, str(args.server))
    original = getattr(os, args.missing) if args.missing != 'none' else None
    if args.missing != 'none':
        delattr(os, args.missing)
    try:
        module = importlib.import_module('outputs_broker')
        try:
            module.OutputsBroker()
            outcome = {'result':'constructed'}
        except Exception as exc:
            outcome = {'class':type(exc).__name__,'message':str(exc)}
    finally:
        if args.missing != 'none':
            setattr(os, args.missing, original)
expected = {'result':'constructed'} if args.missing == 'none' else {
    'class':'RuntimeError','message':'outputs broker requires O_NOFOLLOW, O_DIRECTORY and O_NONBLOCK support'}
print(json.dumps({'missing':args.missing,'outcome':outcome,'expected':expected,'passed':outcome==expected}))
raise SystemExit(0 if outcome==expected else 1)
