"""Use the existing installed coverage tool without resolving new dependencies."""
import argparse
import json
from pathlib import Path
import sys

installed = '/Users/danker/Documents/31308/open-webui-ocu-plan2/.venv/lib/python3.12/site-packages'
sys.path.insert(0, installed)
import coverage
sys.path.remove(installed)
import pytest

print(json.dumps({'coverage_version': coverage.__version__, 'coverage_file': coverage.__file__,
                  'pytest_version': pytest.__version__, 'pytest_file': pytest.__file__}))
parser = argparse.ArgumentParser(add_help=False)
parser.add_argument('--run-id', required=True)
args, pytest_args = parser.parse_known_args()
if not args.run_id.isalnum():
    raise SystemExit('Invalid coverage run identity')
result_path = Path('/tmp/issue-202-coverage-' + args.run_id + '.json')
data_path = Path('/tmp/issue-202-coverage-data-' + args.run_id)
if result_path.exists() or data_path.exists():
    raise SystemExit('Refusing to overwrite coverage evidence')
collector = coverage.Coverage(source=['descriptor_io'], data_file=str(data_path))
collector.start()
try:
    status = pytest.main(pytest_args)
finally:
    collector.stop()
    collector.save()
    collector.json_report(outfile=str(result_path))
    collector.report(show_missing=True)
raise SystemExit(status)
