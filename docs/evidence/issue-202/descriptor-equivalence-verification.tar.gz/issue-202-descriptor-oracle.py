#!/usr/bin/env python3
"""Issue 202 equivalence/security oracle; copies source, never imports original modules."""
import argparse
import errno
import fcntl
import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import socket
import stat
import sys
import tempfile
import traceback
import uuid

REAL_OPEN, REAL_FSTAT, REAL_DUP, REAL_CLOSE = os.open, os.fstat, os.dup, os.close
CANARY = b"OUTSIDE-CHAT-CANARY-202\n"
GOOD = b"owned workspace bytes\n"
STAMP = 1700000000000000000


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalize(value, root):
    if isinstance(value, str):
        return value.replace(str(root), "<OWNED_TMP>")
    if isinstance(value, list):
        return [normalize(item, root) for item in value]
    if isinstance(value, dict):
        return {key: normalize(item, root) for key, item in value.items()}
    return value


def exception(exc):
    result = {"class": type(exc).__module__ + "." + type(exc).__qualname__,
              "message": str(exc), "errno": getattr(exc, "errno", None),
              "status_code": getattr(exc, "status_code", None),
              "detail": getattr(exc, "detail", None),
              "filename": getattr(exc, "filename", None),
              "filename2": getattr(exc, "filename2", None),
              "reason": getattr(exc, "reason", None)}
    if exc.__cause__ is not None:
        result["cause"] = exception(exc.__cause__)
    elif exc.__context__ is not None and not exc.__suppress_context__:
        result["context"] = exception(exc.__context__)
    return result


def fd_set():
    # The child process lowers its soft limit before imports, so this complete
    # census is cheap even on hosts whose default soft limit is one million.
    maximum = resource.getrlimit(resource.RLIMIT_NOFILE)[0]
    return {fd for fd in range(maximum) if fd_is_open(fd)}


def fd_is_open(fd):
    try:
        fcntl.fcntl(fd, fcntl.F_GETFD)
        return True
    except OSError as exc:
        if exc.errno != errno.EBADF:
            raise
        return False


class Calls:
    """Fault only a named real acquisition; do not patch project collaborators."""
    def __init__(self, target=None, phase=None, number=None, mode=None):
        self.target, self.phase, self.number, self.mode = target, phase, number, mode
        self.fired = False
        self.active = {}
        self.acquired = []
        self.events = []

    def fail(self, path):
        self.fired = True
        raise OSError(self.number, "oracle injected " + errno.errorcode[self.number], path)

    def open(self, path, flags, *args, **kwargs):
        name = os.fsdecode(path)
        target = Path(name).name == self.target
        self.events.append({"operation": "open", "path": name, "flags": flags,
                            "relative": kwargs.get("dir_fd") is not None,
                            "fault_target": target})
        if target and self.phase == "open" and not self.fired:
            self.fail(name)
        fd = REAL_OPEN(path, flags, *args, **kwargs)
        item = {"fd": fd, "path": name, "target": target, "closed": False}
        self.active[fd] = item
        self.acquired.append(item)
        return fd

    def dup(self, fd):
        result = REAL_DUP(fd)
        item = {"fd": result, "path": "<dup>", "target": False, "closed": False}
        self.active[result] = item
        self.acquired.append(item)
        return result

    def close(self, fd):
        REAL_CLOSE(fd)
        if fd in self.active:
            self.active.pop(fd)["closed"] = True

    def fstat(self, fd):
        item = self.active.get(fd)
        if item and item["target"] and not self.fired:
            if self.phase == "fstat":
                self.fail(item["path"])
            if self.phase == "type":
                self.fired = True
                actual = list(REAL_FSTAT(fd))
                actual[0] = self.mode
                return os.stat_result(actual)
        return REAL_FSTAT(fd)

    def __enter__(self):
        os.open, os.fstat, os.dup, os.close = self.open, self.fstat, self.dup, self.close
        return self

    def __exit__(self, *args):
        os.open, os.fstat, os.dup, os.close = REAL_OPEN, REAL_FSTAT, REAL_DUP, REAL_CLOSE


def directory_result(fd):
    try:
        return {"kind": "directory", "verified_directory": stat.S_ISDIR(REAL_FSTAT(fd).st_mode),
                "entries": sorted(os.listdir(fd))}
    finally:
        os.close(fd)


def file_result(fd):
    try:
        return {"kind": "regular", "verified_regular": stat.S_ISREG(REAL_FSTAT(fd).st_mode),
                "bytes_hex": os.read(fd, 4096).hex()}
    finally:
        os.close(fd)


def make_tree(data, chat, outside):
    out = data / chat / "outputs"
    out.mkdir(parents=True)
    (out / "good.txt").write_bytes(GOOD)
    (out / "directory").mkdir()
    (out / "directory" / "nested.txt").write_bytes(b"nested\n")
    (out / ".hidden.txt").write_bytes(b"hidden\n")
    os.mkfifo(out / "fifo")
    (out / "link.txt").symlink_to(outside / "canary.txt")
    (out / "linkdir").symlink_to(outside, target_is_directory=True)
    for path in (out / "good.txt", out / "directory" / "nested.txt", out / ".hidden.txt"):
        os.utime(path, ns=(STAMP, STAMP))
    return out


def suite(root, modules):
    uploads, broker_module = modules
    broker = broker_module.OutputsBroker()
    data = root / "data"
    outside = root / "outside"
    outside.mkdir()
    (outside / "canary.txt").write_bytes(CANARY)
    out = make_tree(data, "oracle", outside)
    borrowed = REAL_OPEN(out, os.O_RDONLY | os.O_DIRECTORY)
    borrowed_identity = REAL_FSTAT(borrowed)
    cases, violations = [], []

    def observe(name, boundary, operation, recovery, *, target=None, phase=None,
                number=None, mode=None, require_rejection=False, expected=None):
        before = fd_set()
        calls = Calls(target, phase, number, mode)
        with calls:
            try:
                outcome = {"success": operation()}
            except Exception as exc:
                outcome = {"error": exception(exc)}
        after = fd_set()
        leaks = after - before
        alive = [item for item in calls.acquired if not item["closed"] and fd_is_open(item["fd"])]
        ownership_ok = not leaks and not alive
        same = REAL_FSTAT(borrowed)
        borrowed_ok = (same.st_dev, same.st_ino) == (borrowed_identity.st_dev, borrowed_identity.st_ino)
        borrowed_ok = borrowed_ok and "good.txt" in os.listdir(borrowed)
        # Leak checks precede harness cleanup; do not let cleanup mask defects.
        for fd in leaks:
            REAL_CLOSE(fd)
        try:
            recovered = {"success": recovery()}
        except Exception as exc:
            recovered = {"error": exception(exc)}
        if fd_set() != before:
            ownership_ok = False
            for fd in fd_set() - before:
                REAL_CLOSE(fd)
        judgement = {"owned_descriptors_released": ownership_ok,
                     "borrowed_root_usable": borrowed_ok,
                     "valid_recovery": "success" in recovered,
                     "fault_triggered": calls.fired if phase else None}
        if require_rejection:
            judgement["unsafe_input_rejected"] = "error" in outcome
        if expected is not None:
            judgement["independent_expected_result"] = outcome == {"success": expected}
        for label, result in (("outcome", outcome), ("recovery", recovered)):
            value = result.get("success")
            if isinstance(value, dict) and "entries" in value and "revision" in value:
                judgement[label + "_public_discovery_paths"] = [
                    entry["path"] for entry in value["entries"]
                ] == ["directory/nested.txt", "good.txt"]
        record = {"name": name, "boundary": boundary,
                  "input": {"target": target, "fault_phase": phase,
                            "fault_errno": number, "fault_errno_name": errno.errorcode.get(number),
                            "substituted_type": mode},
                  "outcome": outcome, "ownership": judgement,
                  "recovery": recovered, "syscalls": calls.events}
        cases.append(normalize(record, root))
        for key, value in judgement.items():
            if value is False:
                violations.append({"case": name, "judgement": key,
                                   "outcome": normalize(outcome, root)})

    def upload_read(leaf):
        value, mime = uploads.read_chat_upload("oracle", leaf)
        return {"bytes_hex": value.hex(), "mime": mime}
    upload_good = lambda: upload_read("good.txt")
    broker_good = lambda: file_result(broker._open_regular("good.txt", dir_fd=borrowed, label="output leaf"))
    dir_good = lambda: directory_result(uploads.open_directory_path(out / "directory"))
    for leaf in ("good.txt", "missing", "link.txt", "directory", "fifo", "linkdir/canary.txt"):
        observe("uploads.read." + leaf, "public uploads.read_chat_upload", lambda leaf=leaf: upload_read(leaf),
                upload_good, require_rejection=leaf != "good.txt",
                expected={"bytes_hex": GOOD.hex(), "mime": "text/plain"} if leaf == "good.txt" else None)
    for leaf in ("directory", "missing", "good.txt", "fifo", "linkdir"):
        observe("uploads.directory." + leaf, "public uploads.open_directory_path",
                lambda leaf=leaf: directory_result(uploads.open_directory_path(out / leaf)),
                dir_good, require_rejection=leaf != "directory")
    for scan in (False, True):
        for wrapper in ("root", "child"):
            for leaf in ("directory", "missing", "good.txt", "fifo", "linkdir"):
                def operation(leaf=leaf, scan=scan, wrapper=wrapper):
                    if wrapper == "root":
                        return directory_result(broker._open_directory_path(out / leaf, "output directory", scan=scan))
                    return directory_result(broker._open_child_directory(borrowed, leaf, scan=scan))
                observe(f"broker.{wrapper}.scan-{scan}.{leaf}", "owning broker directory wrapper; borrowed parent for child",
                        operation, broker_good, require_rejection=leaf != "directory")
    for leaf in ("good.txt", "missing", "link.txt", "directory", "fifo"):
        observe("broker.regular." + leaf,
                "private owning broker._open_regular planted-leaf boundary; public discovery excludes static links",
                lambda leaf=leaf: file_result(broker._open_regular(leaf, dir_fd=borrowed, label="output leaf")),
                broker_good, require_rejection=leaf != "good.txt",
                expected={"kind": "regular", "verified_regular": True, "bytes_hex": GOOD.hex()} if leaf == "good.txt" else None)

    # Public consumer results are captured separately and in full. Stable fixtures,
    # timestamps and external UUID generation avoid output normalization shortcuts.
    make_tree(data, "consumer", outside)
    consumer_good = lambda: broker.reconcile("consumer")
    observe("broker.public.reconcile", "public OutputsBroker.reconcile", consumer_good, consumer_good)
    for leaf in ("link.txt", "directory", "fifo", "missing"):
        observe("broker.public.register." + leaf, "public OutputsBroker.register_host_write",
                lambda leaf=leaf: broker.register_host_write("consumer", leaf), consumer_good,
                require_rejection=True)
    observe("broker.public.register.good", "public OutputsBroker.register_host_write",
            lambda: broker.register_host_write("consumer", "good.txt"), consumer_good)

    seams = [
        ("uploads.read", "public uploads.read_chat_upload leaf", "good.txt", upload_good, upload_good),
        ("uploads.read.chat-root", "public uploads reader chat-root acquisition", "oracle", upload_good, upload_good),
        ("uploads.read.outputs-root", "public uploads reader outputs-root acquisition", "outputs", upload_good, upload_good),
        ("uploads.read.ancestor", "public uploads reader child-directory acquisition", "directory",
         lambda: upload_read("directory/nested.txt"), upload_good),
        ("broker.public.index", "public OutputsBroker.current_revision persisted index acquisition", "index.json",
         lambda: broker.current_revision("consumer"), consumer_good),
        ("broker.public.registration-leaf", "public register_host_write leaf hashing acquisition", "good.txt",
         lambda: broker.register_host_write("consumer", "good.txt"), consumer_good),
        ("uploads.directory", "public uploads.open_directory_path", "directory", dir_good, dir_good),
        ("broker.regular", "private owning broker._open_regular", "good.txt", broker_good, broker_good),
    ]
    for scan in (False, True):
        seams.extend([
            (f"broker.root.scan-{scan}", "owning broker directory root wrapper", "directory",
             lambda scan=scan: directory_result(broker._open_directory_path(out / "directory", "output directory", scan=scan)), broker_good),
            (f"broker.child.scan-{scan}", "owning broker child wrapper with borrowed parent", "directory",
             lambda scan=scan: directory_result(broker._open_child_directory(borrowed, "directory", scan=scan)), broker_good),
        ])
        seams.append((f"broker.public.{'scan' if scan else 'registration'}", "public reconcile vs registration root acquisition", "outputs",
                      consumer_good if scan else lambda: broker.register_host_write("consumer", "good.txt"), consumer_good))
    for name, boundary, target, operation, recovery in seams:
        for phase in ("open", "fstat"):
            for number in (errno.EIO, errno.ENOENT, errno.ENOTDIR, errno.ELOOP, errno.EMFILE, errno.ENFILE):
                observe(f"{name}.{phase}.{errno.errorcode[number]}", boundary,
                        operation, recovery, target=target, phase=phase, number=number)
        wrong_mode = stat.S_IFDIR if target in ("good.txt", "index.json") else stat.S_IFREG
        observe(name + ".type-mismatch", boundary, operation, recovery,
                target=target, phase="type", mode=wrong_mode, require_rejection=True)
    REAL_CLOSE(borrowed)
    return cases, violations


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path, help="repository root or server directory")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--compare", type=Path)
    parser.add_argument("--mutation", choices=("uploads-nofollow", "broker-nofollow"))
    args = parser.parse_args()
    source = args.source.resolve()
    if (source / "computer-use-server").is_dir():
        source = source / "computer-use-server"
    output = args.output.resolve()
    if (output == Path(__file__).resolve() or output.is_relative_to(source)
            or (args.compare and output == args.compare.resolve())):
        parser.error("--output must not overwrite the oracle, source tree, or comparison baseline")
    report = {"schema": "issue-202-descriptor-oracle/1", "provenance": {
        "source": str(source), "source_hashes": {}, "oracle_sha256": digest(Path(__file__)),
        "python": sys.version, "executable": sys.executable, "platform": platform.platform(),
        "machine": platform.machine(), "mutation": args.mutation,
        "arguments": vars(args) | {"source": str(args.source), "output": str(args.output), "compare": str(args.compare) if args.compare else None},
        "dependencies": {}, "source_import_isolated": False}, "cases": [], "violations": []}
    exit_code = 2
    owned = None
    original_limits = resource.getrlimit(resource.RLIMIT_NOFILE)
    resource.setrlimit(resource.RLIMIT_NOFILE, (min(original_limits[0], 1024), original_limits[1]))
    report["provenance"]["descriptor_soft_limit"] = resource.getrlimit(resource.RLIMIT_NOFILE)[0]
    initial = fd_set()
    try:
        with tempfile.TemporaryDirectory(prefix="issue-202-oracle-", dir="/tmp") as temporary:
            owned = Path(temporary)
            copied = owned / "server"
            copied.mkdir()
            for path in sorted(source.rglob("*.py")):
                if "__pycache__" in path.parts:
                    continue
                relative = path.relative_to(source)
                report["provenance"]["source_hashes"][str(relative)] = digest(path)
                destination = copied / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path, destination)
            if args.mutation:
                destination = copied / ("uploads.py" if args.mutation == "uploads-nofollow" else "outputs_broker.py")
                text = destination.read_text()
                old = "_FILE_FLAGS = os.O_RDONLY | _NO_FOLLOW | _NONBLOCK | _CLOSE_ON_EXEC"
                if text.count(old) != 1:
                    raise RuntimeError("mutation requires exactly one baseline leaf-read flag definition")
                destination.write_text(text.replace(old, "_FILE_FLAGS = os.O_RDONLY | _NONBLOCK | _CLOSE_ON_EXEC"))
                report["provenance"]["mutated_copy_sha256"] = digest(destination)
            # No inherited credentials/config, no .env loading. Only temporary paths.
            os.environ.clear()
            os.environ.update({"HOME": str(owned / "home"), "TMPDIR": str(owned),
                               "BASE_DATA_DIR": str(owned / "data"),
                               "SKILLS_CACHE_DIR": str(owned / "skills"),
                               "SKILLS_CACHE_HOST_PATH": str(owned / "skills"),
                               "DOCKER_SOCKET": "unix://" + str(owned / "forbidden-docker.sock"),
                               "ENABLE_NETWORK": "false", "PUBLIC_BASE_URL": "http://localhost:20200"})
            sys.dont_write_bytecode = True
            sys.path = [str(copied)] + [entry for entry in sys.path
                       if entry and Path(entry).resolve() not in (source, source.parent, Path.cwd())]
            # Fail closed even if an import unexpectedly attempts transport activity.
            def no_transport(*unused, **kwargs):
                raise RuntimeError("oracle forbids network and Docker transport")
            socket.socket.connect = no_transport
            socket.socket.connect_ex = no_transport
            socket.create_connection = no_transport
            for dependency in ("fastapi", "docker", "aiohttp"):
                report["provenance"]["dependencies"][dependency] = importlib.metadata.version(dependency)
            uploads = importlib.import_module("uploads")
            broker = importlib.import_module("outputs_broker")
            for name, module in list(sys.modules.items()):
                filename = getattr(module, "__file__", None)
                if filename and Path(filename).resolve().is_relative_to(source):
                    raise RuntimeError("module imported from original source: " + name)
            report["provenance"]["source_import_isolated"] = True
            # Deterministic external identifier generator; never replace project functions.
            counter = iter(range(1, 100000))
            uuid.uuid4 = lambda: uuid.UUID(int=next(counter), version=4)
            os.getpid = lambda: 202
            report["provenance"]["deterministic_fixture"] = {
                "mtime_ns": STAMP, "uuid4": "ascending integer payload, version=4",
                "getpid": 202, "note": "external PID fixed for exact staging filename observations"}
            report["cases"], report["violations"] = suite(owned, (uploads, broker))
            if args.compare:
                baseline = json.loads(args.compare.read_text())
                if baseline["schema"] != report["schema"] or baseline.get("violations") or baseline.get("setup_error"):
                    raise RuntimeError("comparison input is not a passing oracle baseline")
                expected = {item["name"]: item for item in baseline["cases"]}
                actual = {item["name"]: item for item in report["cases"]}
                changed = [name for name in sorted(expected.keys() | actual.keys()) if expected.get(name) != actual.get(name)]
                report["comparison"] = {"baseline_sha256": digest(args.compare), "changed_cases": changed,
                                        "exact_case_equality": not changed}
            exit_code = 1 if report["violations"] or report.get("comparison", {}).get("changed_cases") else 0
    except Exception as exc:
        report["setup_error"] = exception(exc)
        report["setup_traceback"] = traceback.format_exc()
        report["emergency_cleanup_fd_count"] = len(fd_set() - initial)
        for fd in fd_set() - initial:
            REAL_CLOSE(fd)
    report["cleanup"] = {"owned_temp_tree_removed": owned is not None and not owned.exists(),
                         "fd_set_restored": fd_set() == initial,
                         "repository_write_operations": 0,
                         "source_import_isolation_verified": report["provenance"]["source_import_isolated"]}
    if not all(report["cleanup"][key] for key in ("owned_temp_tree_removed", "fd_set_restored")):
        exit_code = 2
    report["exit_code"] = exit_code
    args.output.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"output": str(args.output), "exit_code": exit_code,
                      "cases": len(report["cases"]), "violations": report["violations"],
                      "comparison": report.get("comparison"), "setup_error": report.get("setup_error"),
                      "cleanup": report["cleanup"]}, sort_keys=True))
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
