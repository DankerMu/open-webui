"""Observe caller error chains for type rejection followed by real close failure."""
import argparse
import importlib
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
from unittest.mock import patch

parser = argparse.ArgumentParser()
parser.add_argument('--server', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.server))
import outputs_broker
import uploads

real_fstat, real_close = os.fstat, os.close

def record(error, root):
    value = {'class': type(error).__name__, 'message': str(error).replace(str(root), '<ROOT>')}
    if error.__cause__ is not None:
        value['cause'] = record(error.__cause__, root)
    elif error.__context__ is not None and not error.__suppress_context__:
        value['context'] = record(error.__context__, root)
    return value

results = []
with tempfile.TemporaryDirectory(prefix='issue-202-compound-', dir='/tmp') as directory:
    root = Path(directory)
    (root / 'child').mkdir(); (root / 'leaf').write_bytes(b'benign')
    borrowed = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
    broker = outputs_broker.OutputsBroker()
    operations = {
        'broker-root': lambda: broker._open_directory_path(root / 'child', 'root'),
        'broker-child': lambda: broker._open_child_directory(borrowed, 'child'),
        'broker-regular': lambda: broker._open_regular('leaf', dir_fd=borrowed, label='leaf'),
        'uploads-directory': lambda: uploads.open_directory_path(root / 'child'),
    }
    try:
        for name, operation in operations.items():
            closed = []
            def wrong_type(fd):
                actual = list(real_fstat(fd))
                actual[0] = stat.S_IFDIR if name == 'broker-regular' else stat.S_IFREG
                return os.stat_result(actual)
            def close_then_fail(fd):
                real_close(fd); closed.append(fd)
                raise OSError(5, 'controlled close failure')
            with patch.object(os, 'fstat', wrong_type), patch.object(os, 'close', close_then_fail):
                try:
                    operation()
                    outcome = {'unexpected':'success'}
                except Exception as error:
                    outcome = record(error, root)
            results.append({'case':name, 'outcome':outcome,'owned_closes':len(closed),
                            'borrowed_usable':stat.S_ISDIR(real_fstat(borrowed).st_mode)})
    finally:
        real_close(borrowed)
print(json.dumps(results))
