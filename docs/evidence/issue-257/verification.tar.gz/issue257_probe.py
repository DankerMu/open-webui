"""Parent-owned actual pytest-call observer; intentional test failure is expected."""
import json
import os
from pathlib import Path
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace

import pytest

CASE = os.environ['ISSUE257_CASE']
OUTPUT = Path(os.environ['ISSUE257_OUTPUT'])
observations = {'case': CASE}


@pytest.hookimpl(wrapper=True)
def pytest_runtest_call(item):
    if item.module.__name__ != 'tests.orchestrator.test_office_control_plane_concurrency':
        return (yield)
    module = item.module
    docker = item.funcargs['office_world'][3]
    original_lock = docker._combined_lock
    import fcntl
    original_flock = fcntl.flock
    injected = OSError('issue257 controlled ' + CASE)
    patch = pytest.MonkeyPatch()
    children, watches, unstarted_joins = [], [], []
    futures, releases, result_calls, rescue_used = [], [], [], []
    owner_thread = threading.get_ident()
    finished = threading.Event()
    rescuers = []
    actual_error = None
    cleanup_release = []

    class Watch(threading.Thread):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            watches.append(self)

        def join(self, *args, **kwargs):
            if self.ident is None:
                unstarted_joins.append(True)
            return super().join(*args, **kwargs)

    def popen(*args, **kwargs):
        if CASE == 'popen':
            raise injected
        child = subprocess.Popen(*args, **kwargs)
        children.append(child)
        return child

    if CASE in ('popen', 'marker'):
        patch.setattr(module, 'subprocess', SimpleNamespace(Popen=popen, PIPE=subprocess.PIPE))
        patch.setattr(module, 'threading', SimpleNamespace(Event=threading.Event, Thread=Watch))
        if CASE == 'marker':
            from tests.orchestrator import _office_store
            wait_marker = _office_store._wait_marker

            def marker(path, child, label):
                wait_marker(path, child, label)
                observations['real_child_marker'] = path.read_text() == 'held'
                raise injected

            patch.setattr(_office_store, '_wait_marker', marker)
    else:
        class Pool(ThreadPoolExecutor):
            def submit(self, function, docker, chat, held, release, expired):
                wait = held.wait
                set_release = release.set
                cleanup_release.append(set_release)

                def observed_set():
                    if threading.get_ident() == owner_thread:
                        releases.append(True)
                    return set_release()

                def failed_wait(timeout=None):
                    assert wait(timeout), 'probe could not acquire real thread holder'
                    observations['real_thread_holder_ready'] = True

                    def rescue():
                        if not finished.wait(2):
                            rescue_used.append(True)
                            set_release()

                    rescuer = threading.Thread(target=rescue)
                    rescuers.append(rescuer)
                    rescuer.start()
                    raise injected

                patch.setattr(release, 'set', observed_set)
                patch.setattr(held, 'wait', failed_wait)
                future = super().submit(function, docker, chat, held, release, expired)
                futures.append(future)
                result = future.result

                def observed_result(*args, **kwargs):
                    if threading.get_ident() == owner_thread:
                        result_calls.append(True)
                    return result(*args, **kwargs)

                patch.setattr(future, 'result', observed_result)
                return future

        patch.setattr(module, 'ThreadPoolExecutor', Pool)
    try:
        try:
            return (yield)
        except BaseException as error:
            actual_error = error
            raise
        finally:
            finished.set()
            observations.update(
                top_level_is_injected=actual_error is injected,
                top_level_type=type(actual_error).__name__,
                top_level_message=str(actual_error),
                lock_restored=docker._combined_lock is original_lock,
                flock_restored=fcntl.flock is original_flock,
                unstarted_join_calls=len(unstarted_joins),
                child_count=len(children),
                children_reaped=all(child.poll() is not None for child in children),
                child_pipes_closed=all(child.stdout.closed and child.stderr.closed for child in children),
                explicit_owner_release=bool(releases),
                explicit_future_result=bool(result_calls),
                futures_completed=all(future.done() for future in futures),
                emergency_rescue_used=bool(rescue_used),
            )
    finally:
        for release in cleanup_release:
            release()
        for child in children:
            if child.poll() is None:
                child.kill()
            child.communicate(timeout=5)
        for rescuer in rescuers:
            rescuer.join(timeout=5)
            assert not rescuer.is_alive()
        docker._combined_lock = original_lock
        fcntl.flock = original_flock
        patch.undo()
        OUTPUT.write_text(json.dumps(observations, indent=2) + '\n')


def pytest_sessionfinish(session, exitstatus):
    if OUTPUT.exists():
        data = json.loads(OUTPUT.read_text())
        data['pytest_exit'] = int(exitstatus)
        OUTPUT.write_text(json.dumps(data, indent=2) + '\n')
