import json
from pathlib import Path
import sys

case, phase = sys.argv[1:]
path = Path('/tmp/issue-257-evidence') / f'{case}-{phase}-observations.json'
data = json.loads(path.read_text())
checks = {
    'intentional_test_failure': data['pytest_exit'] == 1,
    'initiating_exception_is_primary': data['top_level_is_injected'],
    'lock_restored_before_fixture_teardown': data['lock_restored'],
    'flock_unchanged_or_restored': data['flock_restored'],
    'never_join_unstarted_watchdog': data['unstarted_join_calls'] == 0,
    'no_rescue_as_owner_cleanup': not data['emergency_rescue_used'],
}
if case == 'popen':
    checks['no_child_acquired'] = data['child_count'] == 0
elif case == 'marker':
    checks.update(real_child_acquired=data['child_count'] == 1 and data.get('real_child_marker') is True,
                  child_reaped=data['children_reaped'], pipes_closed=data['child_pipes_closed'])
else:
    checks.update(real_thread_acquired=data.get('real_thread_holder_ready') is True,
                  explicit_owner_release=data['explicit_owner_release'],
                  explicit_future_observation=data['explicit_future_result'],
                  future_completed=data['futures_completed'])
result = {'case': case, 'phase': phase, 'checks': checks, 'accepted': all(checks.values())}
Path('/tmp/issue-257-evidence', f'{case}-{phase}-verdict.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['accepted'] else 1)
