import ast
import hashlib
import json
from pathlib import Path
import sys
import types

root = Path('/Users/danker/Documents/31308/open-computer-use')
baseline = Path('/tmp/issue-252-stage-c')

def normalized_code(code):
    constants = tuple(normalized_code(value) if isinstance(value, types.CodeType) else value for value in code.co_consts)
    return code.replace(co_consts=constants, co_filename='<same-input>', co_firstlineno=1, co_linetable=b'')

records = []
for name in ('test_office_control_plane.py', 'test_office_callback_body_budget.py'):
    before = (baseline/name).read_bytes()
    after = (root/'tests/orchestrator'/name).read_bytes()
    before_tree = ast.parse(before)
    after_tree = ast.parse(after)
    changes = []
    for node in ast.walk(after_tree):
        if isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name == alias.asname == 'office_world':
                    changes.append((node.module, alias.name))
                    alias.asname = None
    assert changes == [('tests.orchestrator.test_office_sessions', 'office_world')], changes
    assert ast.dump(before_tree, include_attributes=False) == ast.dump(after_tree, include_attributes=False)
    left = normalized_code(compile(before, '<same-input>', 'exec'))
    right = normalized_code(compile(after, '<same-input>', 'exec'))
    assert left == right, name
    records.append({'file':name,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'only_change':'explicit same-name office_world fixture export','AST_equivalent_after_removing_redundant_alias':True,'compiled_code_equal_excluding_debug_locations':True})
result={'python':sys.version,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'records':records,'limits':'Only the two test fixture import annotations are normalized. Executable code, constants, exception tables, globals and closure metadata remain compared; file/line/column debug locations are excluded. Production is not transformed.'}
Path('/tmp/issue-252-oracle-identity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
