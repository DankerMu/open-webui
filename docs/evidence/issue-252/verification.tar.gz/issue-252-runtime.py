import asyncio
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time

for name in ('ALL_PROXY','HTTP_PROXY','HTTPS_PROXY','all_proxy','http_proxy','https_proxy'):
    os.environ.pop(name, None)
os.environ['NO_PROXY'] = '*'
os.environ['no_proxy'] = '*'
sys.path.insert(0, '/Users/danker/Documents/31308/open-computer-use')
import httpx
import pytest
import uvicorn
from tests.orchestrator.test_office_sessions import office_world, _snapshot
from tests.orchestrator.test_office_control_plane import _open_session, _body_jwt, _header_jwt, _callback_path
from tests.orchestrator.test_outputs_endpoint import CHAT

LIMIT = 1048576
records = []
label = sys.argv[1]
out = Path('/tmp') / f'issue-252-runtime-{label}.json'
assert not out.exists()

def padded(token, size):
    prefix = json.dumps({'token': token, 'ignored': '界'}, ensure_ascii=False, separators=(',', ':')).encode()
    assert len(prefix) < size
    return prefix + b' ' * (size - len(prefix))


async def raw(app, path, headers, chunks, forbid=False):
    sent=[]
    received=0
    attempts=0
    async def receive():
        nonlocal received, attempts
        attempts+=1
        if forbid:
            raise AssertionError('callback received body with authoritative header')
        if received >= len(chunks):
            raise AssertionError('callback read beyond supplied terminal body')
        chunk=chunks[received]
        received+=1
        return {'type':'http.request','body':chunk,'more_body':received<len(chunks)}
    async def send(message):
        sent.append(message)
    scope={'type':'http','asgi':{'version':'3.0','spec_version':'2.3'},'http_version':'1.1','method':'POST','scheme':'http','path':path,'raw_path':path.encode(),'query_string':b'','headers':headers,'client':('testclient',50000),'server':('testserver',80),'root_path':''}
    try:
        await app(scope,receive,send)
    except Exception as exc:
        return {'raised':str(exc),'receive_calls':attempts,'chunks_delivered':received}
    start=next(m for m in sent if m['type']=='http.response.start')
    body=b''.join(m.get('body',b'') for m in sent if m['type']=='http.response.body')
    return {'status':start['status'],'body':json.loads(body),'receive_calls':attempts,'chunks_delivered':received}
with tempfile.TemporaryDirectory(prefix='callback-budget-runtime-') as directory, pytest.MonkeyPatch.context() as patch:
    worldgen=office_world.__wrapped__(Path(directory),patch)
    world=next(worldgen)
    sock=None
    server=None
    thread=None
    try:
        http,data,origin,docker,broker=world
        sock=socket.socket()
        sock.bind(('127.0.0.1',0))
        port=sock.getsockname()[1]
        config=uvicorn.Config(http.app,host='127.0.0.1',port=port,log_level='error',access_log=False,lifespan='off')
        server=uvicorn.Server(config)
        thread=threading.Thread(target=server.run,kwargs={'sockets':[sock]},daemon=False)
        thread.start()
        deadline=time.monotonic()+10
        while not server.started:
            if not thread.is_alive() or time.monotonic()>deadline:
                raise RuntimeError('owned HTTP server failed startup')
            time.sleep(.01)
        with httpx.Client(base_url=f'http://127.0.0.1:{port}',trust_env=False,timeout=10) as client:
            for size in (LIMIT,LIMIT+1):
                *_,session=_open_session(world,name=f'http-{size}.docx')
                body=padded(_body_jwt(session),size)
                before=_snapshot(data)
                hits=origin.hits
                response=client.post(_callback_path(session),content=body)
                from office.store import OfficeStore
                state=OfficeStore().read(CHAT)['sessions'][session['session_id']]['state']
                record={'seam':'HTTP','bytes':size,'status':response.status_code,'body':response.json(),'session_state':state,'files_unchanged':_snapshot(data)==before,'download_hits_delta':origin.hits-hits}
                record['accepted']= response.status_code==200 and response.json()=={'error':0} and state=='editing' if size==LIMIT else response.status_code==413 and response.json()=={'error':1,'reason':'callback_body_too_large'} and record['files_unchanged'] and record['download_hits_delta']==0
                records.append(record)
        for headerkind in ('valid','invalid'):
            *_,session=_open_session(world,name=f'header-{headerkind}.docx')
            header=('Bearer '+_header_jwt(session)).encode() if headerkind=='valid' else b'Bearer invalid-runtime-canary'
            before=_snapshot(data)
            result=asyncio.run(raw(http.app,_callback_path(session),[(b'authorization',header),(b'content-length',b'999999999')],[],forbid=True))
            result.update(seam='ASGI',case=headerkind,files_unchanged=_snapshot(data)==before)
            expected=200 if headerkind=='valid' else 401
            result['accepted']=result.get('status')==expected and result['receive_calls']==0 and (headerkind=='valid' or result['files_unchanged'])
            records.append(result)
        for length in (None,b'1'):
            *_,session=_open_session(world,name='stream-'+('missing' if length is None else 'forged')+'.docx')
            body=padded(_body_jwt(session),LIMIT+1)
            chunks=[body[:524288],body[524288:LIMIT],body[LIMIT:],b'not-consumed']
            before=_snapshot(data)
            hits=origin.hits
            headers=[] if length is None else [(b'content-length',length)]
            result=asyncio.run(raw(http.app,_callback_path(session),headers,chunks))
            result.update(seam='ASGI',case='missing-length' if length is None else 'forged-small-length',files_unchanged=_snapshot(data)==before,download_hits_delta=origin.hits-hits)
            result['accepted']=result.get('status')==413 and result.get('body')=={'error':1,'reason':'callback_body_too_large'} and result['receive_calls']==3 and result['files_unchanged'] and result['download_hits_delta']==0
            records.append(result)
    finally:
        if server is not None:
            server.should_exit=True
        if thread is not None:
            thread.join(10)
            if thread.is_alive():
                raise RuntimeError('owned HTTP server failed teardown')
        if sock is not None:
            sock.close()
        worldgen.close()
report={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':records,'all_accepted':all(r['accepted'] for r in records),'owned_server_stopped':True,'temporary_root_removed':not Path(directory).exists(),'limits':'Local actual FastAPI/uvicorn plus ASGI receive control; fake Docker and callback origin only, not LAN or full DocumentServer certification.'}
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['all_accepted'] else 2)
