"""Parent-owned bounded workflow-contract replay; not a hosted Actions runner."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
BASELINE = Path('/tmp/issue-262-evidence/ci-baseline.yml')
CONSTRAINTS = Path('/tmp/issue-262-evidence/constraints-baseline.yaml')
NODE = '/Users/danker/.nvm/versions/node/v22.23.2/bin/node'
GIT = str(Path(shutil.which('git')).resolve())
BASH = '/bin/bash'
DEFAULT_PR = {'opened', 'synchronize', 'reopened'}
GUARDS = ('lockfile-consistency', 'layer6-diff-size-guard')
AGGREGATE = 'all-checks-passed'
workflow_path, output_name = map(Path, sys.argv[1:])
assert not output_name.exists()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def execute(argv, cwd, environment, expected=None):
    result = subprocess.run(argv, cwd=cwd, env=environment, text=True, capture_output=True, timeout=15)
    if expected is not None:
        assert result.returncode == expected, (argv, result.returncode, result.stdout, result.stderr)
    return {'argv': argv, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}

def load_workflow(path, environment):
    script = "const fs=require('node:fs'),yaml=require('yaml');process.stdout.write(JSON.stringify(yaml.parse(fs.readFileSync(process.argv[1],'utf8'))));"
    result = execute([NODE, '-e', script, str(path)], ROOT, environment, 0)
    return json.loads(result['stdout'])

def run_step(job):
    steps = [step for step in job['steps'] if 'run' in step]
    assert len(steps) == 1
    return steps[0]

def unwrap(expression):
    if not isinstance(expression, str):
        return expression
    expression = expression.strip()
    if expression.startswith('${{') and expression.endswith('}}'):
        return expression[3:-2].strip()
    return expression

def lookup(value, path):
    if not path:
        return value
    name, *rest = path
    if name == '*':
        assert isinstance(value, list)
        return [lookup(item, rest) for item in value]
    if not isinstance(value, dict):
        return None
    return lookup(value.get(name), rest)

def condition(expression, context, needs=None):
    expression = unwrap(expression)
    if expression is None:
        return needs is None or all(item['result'] == 'success' for item in needs.values())
    if isinstance(expression, bool):
        return expression
    if expression == 'always()':
        return True
    match = re.fullmatch(r"(!?)contains\(([a-zA-Z0-9_.*]+),\s*'([^']*)'\)", expression)
    if match:
        value = lookup(context, match[2].split('.'))
        needle = match[3].casefold()
        present = any(str(item).casefold() == needle for item in value) if isinstance(value, list) else needle in str(value or '').casefold()
        return not present if match[1] else present
    match = re.fullmatch(r"([a-zA-Z0-9_.]+)\s*==\s*'([^']*)'", expression)
    if match:
        return str(lookup(context, match[1].split('.'))).casefold() == match[2].casefold()
    raise AssertionError('Unsupported expression is not accepted evidence: '+str(expression))

def subscribed(workflow, event_name, action=None, branch='main'):
    triggers = workflow['on']
    if event_name not in triggers:
        return False
    settings = triggers[event_name]
    if event_name == 'pull_request':
        kinds = DEFAULT_PR if settings is None or 'types' not in settings else set(settings['types'])
        return action in kinds
    assert event_name == 'push'
    return settings is None or branch in settings.get('branches', [branch])

def environment_for(step, context, needs, environment):
    result = dict(environment)
    for name, template in step.get('env', {}).items():
        expression = unwrap(template)
        result[name] = json.dumps(needs, indent=2) if expression == 'toJSON(needs)' else str(lookup(context, expression.split('.')))
    return result

def evaluate(workflow, repo, steps, environment, base, head, *, action, labels, changed_label=None, event_name='pull_request', branch='main', other_results=None):
    payload = {'action': action, 'pull_request': {'labels': [{'name': name} for name in labels], 'base': {'sha': base}, 'head': {'sha': head}}}
    if changed_label is not None:
        payload['label'] = {'name': changed_label}
    row = {'event_name': event_name, 'action': action, 'payload': payload, 'head': head,
           'subscribed': subscribed(workflow, event_name, action, branch), 'hosted_execution': False}
    if not row['subscribed']:
        row.update(guards={}, aggregate=None)
        return row
    context = {'github': {'event_name': event_name, 'event': payload}}
    jobs = workflow['jobs']
    states = {name: 'success' for name in jobs if name != AGGREGATE}
    states.update(other_results or {})
    observations = {}
    for name in GUARDS:
        job = jobs[name]
        step = run_step(job)
        if not condition(job.get('if'), context):
            states[name] = 'skipped'
            observations[name] = {'job': 'skipped', 'step': 'not_entered'}
        elif not condition(step.get('if'), context):
            # Checkout is an explicit successful dependency input, not executed here.
            states[name] = 'success'
            observations[name] = {'job': 'success', 'step': 'skipped'}
        else:
            result = execute([BASH, '--noprofile', '--norc', '-e', '-o', 'pipefail', str(steps[name])], repo,
                             environment_for(step, context, {}, environment))
            assert result['exit'] in (0, 1), result
            if result['exit'] == 1:
                marker = 'changed but' if name == 'lockfile-consistency' else 'PR exceeds'
                assert marker in result['stdout'], result
            states[name] = 'success' if result['exit'] == 0 else 'failure'
            observations[name] = {'job': states[name], 'step': 'executed', **result}
    needed = {name: {'result': states[name], 'outputs': {}} for name in jobs[AGGREGATE]['needs']}
    if condition(jobs[AGGREGATE].get('if'), context, needed):
        step = run_step(jobs[AGGREGATE])
        result = execute([BASH, '--noprofile', '--norc', '-e', '-o', 'pipefail', str(steps[AGGREGATE])], repo,
                         environment_for(step, context, needed, environment))
        assert result['exit'] in (0, 1), result
        if result['exit'] == 1:
            assert '::error::A required job' in result['stdout'], result
        aggregate = {'job': 'success' if result['exit'] == 0 else 'failure', **result}
    else:
        aggregate = {'job': 'skipped', 'exit': None}
    row.update(guards=observations, needs=needed, aggregate=aggregate)
    assert execute([GIT, 'rev-parse', 'HEAD'], repo, environment, 0)['stdout'].strip() == head
    return row

before = {'workflow': digest(workflow_path), 'baseline': digest(BASELINE), 'constraints': digest(CONSTRAINTS),
          'current_constraints': digest(ROOT/'constraints.yaml'), 'oracle': digest(Path(__file__))}
assert before['constraints'] == before['current_constraints']
with tempfile.TemporaryDirectory(prefix='issue-262-guards-') as temporary:
    home = Path(temporary)/'home'; home.mkdir()
    environment = {'PATH': str(Path(GIT).parent)+':/usr/bin:/bin:/usr/sbin:/sbin', 'HOME': str(home),
                   'TMPDIR': temporary, 'LANG': 'C', 'LC_ALL': 'C',
                   'GIT_AUTHOR_DATE': '2000-01-01T00:00:00Z', 'GIT_COMMITTER_DATE': '2000-01-01T00:00:00Z'}
    workflow = load_workflow(workflow_path, environment)
    reference = load_workflow(BASELINE, environment)
    step_files = {}
    for name in (*GUARDS, AGGREGATE):
        program = run_step(workflow['jobs'][name])['run']
        assert program == run_step(reference['jobs'][name])['run'], 'Guard program mutation is outside executable scope'
        path = Path(temporary)/(name+'.sh'); path.write_text(program); step_files[name] = path
    repo = Path(temporary)/'repo'; repo.mkdir()
    execute([GIT, 'init', '--quiet', '--initial-branch=omp/ci-fixture'], repo, environment, 0)
    for key, value in [('user.name','CI guard fixture'),('user.email','ci-fixture@example.invalid'),('commit.gpgsign','false'),('core.hooksPath',str(repo/'.git/hooks'))]:
        execute([GIT, 'config', key, value], repo, environment, 0)
    (repo/'constraints.yaml').write_bytes(CONSTRAINTS.read_bytes())
    execute([GIT,'add','constraints.yaml'],repo,environment,0)
    execute([GIT,'commit','--quiet','-m','test(ci): establish guarded diff base'],repo,environment,0)
    base = execute([GIT,'rev-parse','HEAD'],repo,environment,0)['stdout'].strip()
    (repo/'change.txt').write_text(''.join(f'changed line {index}\n' for index in range(401)))
    execute([GIT,'add','change.txt'],repo,environment,0)
    execute([GIT,'commit','--quiet','-m','test(ci): create oversized change'],repo,environment,0)
    head = execute([GIT,'rev-parse','HEAD'],repo,environment,0)['stdout'].strip()
    opened = evaluate(workflow,repo,step_files,environment,base,head,action='opened',labels=[])
    added = evaluate(workflow,repo,step_files,environment,base,head,action='labeled',labels=['diff-limit-exempt'],changed_label='diff-limit-exempt')
    baseline_good = opened['subscribed'] and opened['aggregate']['exit'] == 1 and opened['guards']['layer6-diff-size-guard']['exit'] == 1
    observed_fresh = added['subscribed'] and added['guards']['layer6-diff-size-guard']['step'] == 'skipped' and added['aggregate']['exit'] == 0
    result = {'mode':'construction tracer','workflow':str(workflow_path),'identities_before':before,
              'platform_contract':'https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#pull_request',
              'rows':[opened,added],'known_good_oversize_refusal':baseline_good,'same_head':opened['head']==added['head'],
              'fresh_label_evaluation':observed_fresh,'accepted':baseline_good and observed_fresh,
              'failures':[] if observed_fresh else ['labeled activity did not produce the required fresh local evaluation'],
              'environment_keys':sorted(environment),'node':execute([NODE,'--version'],ROOT,environment,0)['stdout'].strip(),
              'git':execute([GIT,'--version'],repo,environment,0)['stdout'].strip(),
              'limits':'Documented subscription/used-expression model plus actual guard/aggregate programs; no hosted dispatch, checkout or unrelated-job execution claim.'}
result['temporary_fixture_removed'] = not Path(temporary).exists()
result['identities_after'] = {'workflow':digest(workflow_path),'baseline':digest(BASELINE),'constraints':digest(CONSTRAINTS),
                              'current_constraints':digest(ROOT/'constraints.yaml'),'oracle':digest(Path(__file__))}
assert result['identities_before'] == result['identities_after']
output_name.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result[key] for key in ('known_good_oversize_refusal','same_head','fresh_label_evaluation','accepted','failures','temporary_fixture_removed')},indent=2))
raise SystemExit(0 if result['accepted'] else 1)
