## Source

- Discovered during: read-only follow-up while scoping issue #262; this is separate from #262’s pull-request label-trigger freshness.
- Evidence:
  - `.github/workflows/ci.yml:231-232` uses `git diff --diff-filter=ACMR` and counts changed hunk lines. A complete file deletion has status `D`, which this filter omits.
  - Historical repository commit `7229fac0c4111350db52d387ab6cbcfa2148c43c` deleted `src/lib/components/admin/Settings.svelte`, which had 497 lines. Isolating that path under the guard’s `--ignore-all-space` and hunk-line counting behavior produced 0 lines with `ACMR`, versus 470 countable hunk lines with `ACDMR`; this path is not covered by the exclusions at `ci.yml:232`.
  - `AGENTS.md:186` states a 400-line diff limit excluding lockfiles/snapshots/i18n; `constraints.yaml:118-122` sets the 400-line threshold and names the exemption label; `.github/PULL_REQUEST_TEMPLATE.md:28` repeats the limit. None documents an exemption for whole-file deletions.
  - `git blame` traces the `ACMR` filter to `ba10495e4d2ca696389889de13819dae83723516`, which introduced the guard; its commit message does not state a deletion-exemption policy.

## Problem

A PR that deletes more than 400 countable lines by removing whole files can have those lines omitted from the layer6 counter and therefore avoid the documented size threshold. This is a policy/code mismatch; the historical 497-line deletion demonstrates 470 omitted countable hunk lines. The consequence for a PR is inferred from the counter behavior, not from a CI run.

## Boundary

- In scope: count deleted lines from complete, non-excluded files in the existing layer6 diff-size guard.
- Out of scope: #262’s label-trigger freshness, changing the 400-line threshold, changing the exclusion list, or changing the exemption-label policy.
- Affected surface: `.github/workflows/ci.yml` layer6; existing policy statements are in `AGENTS.md`, `constraints.yaml`, and `.github/PULL_REQUEST_TEMPLATE.md`.

## Solution direction

- Recommended: include deletion status `D` in the diff filter while preserving the current threshold, whitespace handling, path exclusions, comparison base, and exemption label.
- Alternative: explicitly document and encode whole-file deletions as exempt; this preserves current counting behavior but deliberately leaves large deletion-only diffs outside the stated limit.

## Acceptance criteria

- [ ] A focused regression proof shows an unexempted deletion-only change with more than 400 countable lines fails the guard, while one at or below 400 does not.
- [ ] Whole-file deletions are counted in mixed diffs; deleted lines in modified files remain counted.
- [ ] Lockfile, snapshot, and i18n exclusions and the `diff-limit-exempt` label retain their current behavior.

## Metadata

- Suggested priority: P2 — a reproducible bypass of the documented PR-size guard can admit an oversized review diff.
- Estimated size: S
- Dependencies: none
- Readiness: implementation-ready — bounded counter change with focused regression coverage; independent of #262.
