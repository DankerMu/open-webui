import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess

root = Path('/Users/danker/Documents/31308/open-computer-use')
readme = root/'tests/README.md'
blocks = re.findall(r'```bash\n(.*?)\n```', readme.read_text(), re.S)
commands = [block for block in blocks if block.startswith('uv run ')]
assert len(commands) == 1
argv = shlex.split(commands[0].replace('\\\n', ' '))
assert argv[:7] == ['uv','run','--no-project','--with','pytest','--with-requirements','computer-use-server/requirements.txt']
assert argv[7:11] == ['--','python','-m','pytest']
expected = json.loads(Path('/tmp/issue-255-current-canonical.json').read_text())
expression = expected['argv'][expected['argv'].index('-k')+1]
assert argv[11:] == ['tests/','-q','--import-mode=importlib','--ignore=tests/integration','-k',expression]
env = os.environ.copy()
env['UV_OFFLINE'] = '1'
env['UV_PYTHON'] = '3.13'
for name in ('ALL_PROXY','HTTP_PROXY','HTTPS_PROXY','all_proxy','http_proxy','https_proxy'):
    env.pop(name,None)
env['NO_PROXY'] = '*'
env['no_proxy'] = '*'
version = subprocess.run(argv[:11]+['--version'],cwd=root,env=env,text=True,capture_output=True,timeout=60)
assert version.returncode == 0, version.stderr
assert version.stdout.strip() == 'pytest 9.1.1', version.stdout
command = argv + ['--collect-only','-p','no:cacheprovider']
run = subprocess.run(command,cwd=root,env=env,text=True,capture_output=True,timeout=120)
nodes = [line for line in run.stdout.splitlines() if line.startswith('tests/') and '::' in line]
result = {'readme_sha256':hashlib.sha256(readme.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'documented_argv':argv,'exercised_argv':command,'environment':'Existing offline cache, UV_PYTHON3.13, proxies disabled; no repository dependency change or pytest pin.','pytest_version':version.stdout.strip(),'exit':run.returncode,'stdout':run.stdout,'stderr':run.stderr,'selected_nodes':nodes,'selected_count':len(nodes),'equal_to_current_qualified_selection':set(nodes)==set(expected['selected_nodes']) and len(nodes)==len(set(nodes)),'qualification':'Actual documented uv/python-m-pytest command plus collection-only/cache-disabled observation flags. This is CLI collection smoke, not current950 execution.'}
Path('/tmp/issue-255-doc-cli.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ('stdout','stderr','selected_nodes')},indent=2))
assert run.returncode == 0 and result['equal_to_current_qualified_selection']
