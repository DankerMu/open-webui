import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import time

import pytest

parser = argparse.ArgumentParser()
parser.add_argument('--root', required=True)
parser.add_argument('--mode', choices=('explicit', 'canonical', 'execute'), required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
root = Path(args.root).resolve()
out = Path(args.output)
assert not out.exists(), out
assert pytest.__version__ == '9.1.1', pytest.__version__
modules = [
    'tests/orchestrator/test_office_control_plane.py',
    'tests/orchestrator/test_office_router.py',
    'tests/orchestrator/test_office_versions.py',
    'tests/test_auth_guard.py',
    'tests/orchestrator/test_lifecycle.py',
    'tests/orchestrator/test_office_sessions.py',
    'tests/orchestrator/test_office_session_lifecycle.py',
    'tests/orchestrator/test_office_save_close.py',
    'tests/orchestrator/test_office_notice.py',
    'tests/orchestrator/test_office_sweep.py',
    'tests/orchestrator/test_office_store.py',
    'tests/orchestrator/test_office_tokens.py',
    'tests/orchestrator/test_office_config.py',
    'tests/orchestrator/test_outputs_endpoint.py',
    'tests/orchestrator/test_preview_prefix.py',
    'tests/orchestrator/test_server_package.py',
]
for path in modules:
    assert (root/path).is_file(), path
expression = ' or '.join(Path(path).name for path in modules)
removed = []
for name in ('ALL_PROXY','HTTP_PROXY','HTTPS_PROXY','all_proxy','http_proxy','https_proxy'):
    if name in os.environ:
        removed.append(name)
        os.environ.pop(name)
os.environ['NO_PROXY'] = '*'
os.environ['no_proxy'] = '*'
os.chdir(root)
sys.path.insert(0, str(root))

class Observer:
    def __init__(self):
        self.nodes = []
        self.world = []
        self.reports = []
        self.rootpath = None

    def pytest_collection_finish(self, session):
        self.nodes = [item.nodeid for item in session.items]
        self.rootpath = str(session.config.rootpath)
        if args.mode == 'explicit':
            return
        for item in session.items:
            if 'world' not in item.fixturenames:
                continue
            definitions = session._fixturemanager.getfixturedefs('world', item)
            parents = list(item.iter_parents())
            self.world.append({
                'nodeid': item.nodeid,
                'available': bool(definitions),
                'matching_owner_nodes': [definition.node.nodeid for definition in definitions or () if definition.node is not None and definition.node in parents],
            })

    def pytest_runtest_logreport(self, report):
        self.reports.append({'nodeid':report.nodeid,'when':report.when,'outcome':report.outcome})

observer = Observer()
selection = modules if args.mode == 'explicit' else ['tests/', '-k', expression]
argv = selection + ['-q', '--import-mode=importlib', '--ignore=tests/integration', '-p', 'no:cacheprovider', '--tb=short']
if args.mode != 'execute':
    argv.append('--collect-only')
started = time.time()
code = pytest.main(argv, plugins=[observer])
missing = [row['nodeid'] for row in observer.world if not row['available']]
result = {
    'root':str(root), 'pytest_root':observer.rootpath, 'mode':args.mode,
    'python':sys.version, 'pytest':pytest.__version__,
    'packages':{name:importlib.metadata.version(name) for name in ('fastapi','starlette','aiohttp','httpx','docker','mcp','PyYAML')},
    'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'argv':argv, 'pytest_exit':int(code), 'elapsed':time.time()-started,
    'removed_proxy_names':removed, 'no_proxy_all':True,
    'selected_nodes':observer.nodes, 'selected_count':len(observer.nodes),
    'world_resolution':observer.world, 'missing_world':missing,
    'reports':observer.reports,
    'source_inputs':{path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in modules},
    'qualification':'Explicit mode only records node IDs, not the already-reported failing fixture lookup. Canonical/execute modes observe actual selected-node world definitions without changing fixtures or collection. Collection success is not a test pass.',
}
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ('selected_nodes','world_resolution','reports','source_inputs')},indent=2))
raise SystemExit(int(code) if code else (2 if missing else 0))
