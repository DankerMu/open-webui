import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

source = Path('/Users/danker/Documents/31308/open-computer-use')
control = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
snapshot = Path(json.loads(Path('/tmp/issue-255-snapshot.json').read_text())['snapshot_root'])
label, location, *argv = sys.argv[1:]
root = {'source': source, 'control': control, 'historical': snapshot}[location]
out = Path('/tmp') / f'issue-255-{label}.command.json'
assert not out.exists(), out

def identities():
    result = {}
    for scope in (source, snapshot):
        for subdir in ('computer-use-server', 'tests'):
            for file in sorted((scope/subdir).rglob('*.py')):
                result[scope.name+'/'+str(file.relative_to(scope))] = hashlib.sha256(file.read_bytes()).hexdigest()
    for file in [source/'computer-use-server/requirements.txt', snapshot/'computer-use-server/requirements.txt', Path('/tmp/issue-255-selection.py')]:
        result[str(file)] = hashlib.sha256(file.read_bytes()).hexdigest()
    return result

env = os.environ.copy()
env['PATH'] = str(control/'.venv/bin') + ':/Users/danker/.nvm/versions/node/v22.23.2/bin:' + env['PATH']
record = {'argv':argv,'cwd':str(root),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'inputs_before':identities()}
started = time.time()
child = subprocess.Popen(argv,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
interrupted = False
try:
    stdout,stderr=child.communicate(timeout=1200)
except (subprocess.TimeoutExpired,KeyboardInterrupt):
    interrupted=True
    os.killpg(child.pid,signal.SIGINT)
    try:
        stdout,stderr=child.communicate(timeout=30)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid,signal.SIGKILL)
        stdout,stderr=child.communicate()
record.update(exit=child.returncode,interrupted=interrupted,elapsed=time.time()-started,stdout=stdout,stderr=stderr,inputs_after=identities())
record['inputs_unchanged']=record['inputs_before']==record['inputs_after']
out.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:value for key,value in record.items() if key not in ('inputs_before','inputs_after','stdout','stderr')}))
print(stdout[-8000:]);print(stderr[-4000:])
raise SystemExit(124 if interrupted else child.returncode)
