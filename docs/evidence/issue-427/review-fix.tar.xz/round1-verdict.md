# Round 1 — request changes

Source head: `48e8a8ae49eaa8c96246b2b2cfc8b694923bb9fe`. Companion head: `737bb77d2707716aad06dccc2629b1c499eaa72b`.

Expanded hybrid, high risk. Seats: correctness; test-evidence+spec-compliance; invariant-state. Correctness and invariant-state found no introduced production defect. Parent gap sweep and evidence-seat follow-up found one blocking coverage class.

## E1 — CONFIRMED P1 `test-evidence`

Invariant: a committed save covers only its dispatch generation; a foreign watermark cannot cover an unrelated local modification. The fixture explicitly requires later edits to remain dirty both before and after native delivery.

The new `deliveredModification < modification` dirty disjunct masks the binding assertions when every later edit remains undelivered. Three existing tests use only pending later/local edits: dispatch-generation coverage, timeout/cumulative coverage, and another-tab watermark coverage.

Independent parent controls, without modifying repository source/tests:

- Reply-time capture instead of dispatch capture: all nine cases in those three functions still pass (exit 0). Evidence: `masked-existing-reply-capture.json`.
- Commit-time capture instead of recorded generation: the same nine cases still pass (exit 0). Evidence: `masked-existing-commit-capture.json`.
- Broad watermark credit: five pass/four fail; existing timeout intermediate assertions catch that broad defect, but the foreign-watermark case itself passes. Evidence: `masked-existing-watermark-credit.json`. No claim that the whole suite misses this mutant.

Source/test hashes are recorded before and after every control and unchanged. These are semantic test-oracle defects, not evidence of a production defect in the reviewed implementation.

Fix group: preserve pending/no-later-edit cases and add delivered-later variants to dispatch and cumulative coverage tests; preserve pending foreign-watermark case and add its delivered variant. Assert the same user-visible dirty state and no extra save. Qualify each with the parent-owned controls, then run/reconcile the updated owning inventory. Production code and frozen fixture remain unchanged. Fresh correctness+test-evidence review follows.

## Non-blocking notes

- Public screenshot names differ from archived private-runtime names; parent can provide an explicit mapping in the evidence update. No missing runtime assertion.
- Correlated retry re-enters the already tested delivery-gated save owner; exact new-edit-at-retry combination is not separately exercised. Source trace plus shared-boundary coverage supports this path; no contradictory execution found.
- Real content proof remains XLSX-only, deliberately not #172 or LAN acceptance.

## CI

Source identity-email check succeeded. Companion has no exact-head run/check after opened/reopened and a 15-minute monitor; Actions enabled and CI active. Required `All checks passed` remains unsatisfied. No merge authorization until satisfied.
