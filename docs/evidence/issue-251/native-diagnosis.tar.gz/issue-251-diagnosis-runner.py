import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
label, *argv = sys.argv[1:]
out = Path('/tmp') / f'issue-251-{label}.command.json'
if out.exists():
    raise SystemExit('Refusing to replace diagnostic evidence')
paths = ['vite.config.ts', 'svelte.config.js', 'package.json', 'package-lock.json',
         'scripts/dev-bg.sh', 'scripts/dev-env.sh', 'scripts/verify-ui-ocu.py',
         'e2e/smoke.e2e.ts', 'playwright.config.ts', 'Makefile']

def identities():
    return [{'path': name, 'sha256': hashlib.sha256((root/name).read_bytes()).hexdigest()}
            for name in paths]

def optimizer():
    path = root/'node_modules/.vite/deps/_metadata.json'
    return json.loads(path.read_text()) if path.is_file() else None

env = os.environ.copy()
env['PATH'] = str(root/'.venv/bin') + ':/Users/danker/.nvm/versions/node/v22.23.2/bin:' + env['PATH']
env['UV_NO_SYNC'] = '1'
record = {'argv': argv, 'cwd': str(root),
          'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
          'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'inputs_before': identities(), 'optimizer_before': optimizer()}
started = time.time()
child = subprocess.Popen(argv, cwd=root, env=env, text=True,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
try:
    stdout, stderr = child.communicate(timeout=600)
except (subprocess.TimeoutExpired, KeyboardInterrupt):
    os.killpg(child.pid, signal.SIGINT)
    try:
        stdout, stderr = child.communicate(timeout=30)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGKILL)
        stdout, stderr = child.communicate()
record.update(exit=child.returncode, elapsed=time.time()-started, stdout=stdout, stderr=stderr,
              inputs_after=identities(), optimizer_after=optimizer())
record['inputs_unchanged'] = record['inputs_before'] == record['inputs_after']
out.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('stdout','stderr','inputs_before','inputs_after','optimizer_before','optimizer_after')}))
print(stdout[-12000:])
print(stderr[-8000:])
raise SystemExit(child.returncode)
