const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const root = '/Users/danker/Documents/31308/open-webui-ocu-plan2';
const load = createRequire(`${root}/package.json`);
const ts = load('typescript');
const before = fs.readFileSync('/tmp/issue-251-configured-red-inputs/vite-cache.e2e.ts', 'utf8');
const after = fs.readFileSync(`${root}/e2e/vite-cache.e2e.ts`, 'utf8');
const title = 'owned UI optimizer cache preserves dependency evaluation in a reused default frontend';
function parse(text) {
  const source = ts.createSourceFile('vite-cache.e2e.ts', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  assert.deepEqual(source.parseDiagnostics, []);
  const candidates = source.statements.filter(statement => ts.isExpressionStatement(statement) && ts.isCallExpression(statement.expression) && statement.expression.arguments[0]?.text === title);
  assert.equal(candidates.length, 1);
  const main = candidates[0];
  const callback = main.expression.arguments.at(-1);
  const tries = callback.body.statements.filter(ts.isTryStatement);
  assert.equal(tries.length, 1);
  return { protectedBody: tries[0].tryBlock.getText(source), siblings: source.statements.filter(statement => statement !== main).map(statement => statement.getText(source)) };
}
const original = parse(before);
const current = parse(after);
assert.equal(current.protectedBody, original.protectedBody);
assert.deepEqual(current.siblings, original.siblings);
const hash = text => crypto.createHash('sha256').update(text).digest('hex');
const result = {
  before_sha256: hash(before), after_sha256: hash(after),
  protected_scenario_body_sha256: hash(original.protectedBody),
  identical_main_scenario_and_assertion_body: true,
  identical_imports_helpers_and_prerequisite_cases: true,
  change: 'Only main-fixture failure collection and cleanup propagation change: primary error retained, cleanup attempted, sole error rethrown unchanged or multiple errors aggregated outside finally.',
  limit: 'This is not whole-program equivalence: exceptional teardown reporting intentionally changes. Final E2E/lint/type validation is required; production configuration/harness bytes are unchanged.',
  typescript_version: ts.version
};
fs.writeFileSync('/tmp/issue-251-oracle-identity.json', JSON.stringify(result, null, 2)+'\n');
console.log(JSON.stringify(result, null, 2));
