状态纠正：#251 尚未完成，重新打开。

GitHub GraphQL 的 ClosedEvent 确认本 issue 在 2026-10-12T11:32:32Z 被 PR #386 关闭（closer = PullRequest 386），不是 #251 的实现或验收完成。该 PR 风险段落写了否定句 `not a root-cause fix: #251 remains open`，但其中的 closing-keyword 形式仍把本 issue 关联到合并关闭。已把该段改成不会触发关闭的独立表述。

#248 的实现与归档仍然完成；#251 一直在执行队列中保持未完成。目前 #251 的配置驱动回归、完整浏览器和缓存所有权证据已通过，仍在完成静态检查、交叉审查及独立合并流程。不会把这次误关闭计作完成。
