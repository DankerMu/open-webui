import assert from 'node:assert/strict';
import { loadConfigFromFile } from '/Users/danker/Documents/31308/open-webui-ocu-plan2/node_modules/vite/dist/node/index.js';
const root = '/Users/danker/Documents/31308/open-webui-ocu-plan2';
const saved = Object.fromEntries(['OCU_UI_PROXY_HARNESS','OCU_UI_VITE_CACHE_DIR','OCU_UI_SVELTEKIT_OUT_DIR'].map(key => [key, process.env[key]]));
try {
  for (const harness of [false, true]) {
    if (harness) {
      process.env.OCU_UI_PROXY_HARNESS = 'true';
      process.env.OCU_UI_VITE_CACHE_DIR = '/tmp/issue-251-seam/vite-cache';
      process.env.OCU_UI_SVELTEKIT_OUT_DIR = '/tmp/issue-251-seam/svelte-kit';
    } else {
      delete process.env.OCU_UI_PROXY_HARNESS;
      delete process.env.OCU_UI_VITE_CACHE_DIR;
      delete process.env.OCU_UI_SVELTEKIT_OUT_DIR;
    }
    const loaded = await loadConfigFromFile({ command: 'serve', mode: 'development' }, root+'/vite.config.ts', root);
    assert(loaded);
    console.log(JSON.stringify({harness, cacheDir: loaded.config.cacheDir ?? null}));
  }
} finally {
  for (const [key,value] of Object.entries(saved)) {
    if (value === undefined) delete process.env[key]; else process.env[key] = value;
  }
}
