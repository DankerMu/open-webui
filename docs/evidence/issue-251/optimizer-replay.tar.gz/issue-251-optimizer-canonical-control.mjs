import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import net from 'node:net';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const repo = '/Users/danker/Documents/31308/open-webui-ocu-plan2';
const load = createRequire(`${repo}/package.json`);
const { chromium } = load('playwright');
const { createServer } = await import(pathToFileURL(`${repo}/node_modules/vite/dist/node/index.js`));
const label = process.argv[2];
assert(label && /^[a-z0-9-]+$/.test(label));
const output = `/tmp/issue-251-${label}.json`;
try { await fs.access(output); throw new Error('Refusing to overwrite evidence'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
const root = await fs.realpath(await fs.mkdtemp(path.join(os.tmpdir(), 'issue-251-optimizer-')));
const cache = path.join(root, 'optimizer');
const record = { root, cache, experiment: 'Two real Vite5 servers, installed real Tiptap/ProseMirror modules, shared disposable optimizer cache; initial lazy discovery versus preincluded generation. No repository/dependency/config edits.', observations: [], resolutions: [], logs: [] };
record.probeSha256 = crypto.createHash('sha256').update(await fs.readFile(new URL(import.meta.url))).digest('hex');
let first;
let second;
let browser;
const deps = ['@tiptap/extension-bubble-menu', '@tiptap/extension-table', 'prosemirror-state'];
const entry = deps.map((dep, index) => `import * as dependency${index} from '${dep}';`).join('\n') + '\nwindow.probeLoaded = true;\n';
await fs.writeFile(path.join(root, 'package.json'), JSON.stringify({ name: 'selection-provenance-probe', type: 'module' }));
await fs.symlink(path.join(repo, 'node_modules'), path.join(root, 'node_modules'));
await fs.writeFile(path.join(root, 'index.html'), '<!doctype html><html><body><script type="module" src="/entry.js"></script></body></html>');
await fs.writeFile(path.join(root, 'entry.js'), entry);
const logger = {
  info: message => record.logs.push(String(message)),
  warn: message => record.logs.push(String(message)),
  warnOnce: message => record.logs.push(String(message)),
  error: message => record.logs.push(String(message)),
  clearScreen() {}, hasErrorLogged() { return false; }, hasWarned: false
};
function observer(name) {
  return { name: 'selection-probe-observer', configResolved(config) {
    const resolver = config.plugins.find(plugin => plugin.name === 'vite:resolve');
    const original = resolver.resolveId;
    resolver.resolveId = async function (...args) {
      const result = await original.apply(this, args);
      const text = typeof result === 'string' ? result : result?.id;
      if (text?.includes('/optimizer/') && (args[0].includes('chunk-') || deps.includes(args[0]))) {
        record.resolutions.push({ server: name, specifier: args[0], importer: args[1], resolved: text });
      }
      return result;
    };
  }};
}
async function freePort() {
  const socket = net.createServer();
  await new Promise((resolve, reject) => socket.once('error', reject).listen(0, '127.0.0.1', resolve));
  const port = socket.address().port;
  await new Promise(resolve => socket.close(resolve));
  return port;
}
async function start(name, include) {
  const server = await createServer({ root, configFile: false, cacheDir: cache, customLogger: logger,
    optimizeDeps: { entries: [], ...(include ? { include, force: true } : {}) },
    server: { host: '127.0.0.1', port: await freePort(), strictPort: true }, plugins: [observer(name)] });
  try {
    await server.listen();
    return server;
  } catch (error) {
    await server.close();
    throw error;
  }
}
async function visit(server, name) {
  const page = await browser.newPage();
  const events = [];
  const errors = [];
  const modules = [];
  await page.exposeFunction('__recordSelection', event => events.push(event));
  page.on('pageerror', error => {
    errors.push(String(error));
    void page.evaluate(() => { document.body.dataset.probeFailed = 'true'; }).catch(() => {});
  });
  await page.route(/\/optimizer\/deps\/.*\.js(?:\?.*)?$/, async route => {
    const response = await route.fetch();
    if (response.status() !== 200) { await route.fulfill({ response }); return; }
    const body = await response.text();
    const opener = 'static jsonID(id, selectionClass) {';
    const address = route.request().url();
    if (body.includes('Selection.jsonID("cell"') || body.includes(opener)) {
      modules.push({ url: address, sha256: crypto.createHash('sha256').update(body).digest('hex'), imports: [...body.matchAll(/from\s+["']([^"']+)["']/g)].map(match => match[1]) });
    }
    if (!body.includes(opener)) { await route.fulfill({ response }); return; }
    assert.equal(body.split(opener).length, 2);
    const altered = body.replace(opener, `${opener}\n    globalThis.__recordSelection({id, registry: import.meta.url, existed: id in classesById, sameClass: classesById[id] === selectionClass, stack: new Error('selection-registration').stack});`);
    await route.fulfill({ response, body: altered });
  });
  const origin = server.resolvedUrls.local[0];
  await page.goto(origin);
  await page.waitForFunction(() => window.probeLoaded || document.body.dataset.probeFailed, undefined, { timeout: 10000 }).catch(error => errors.push(String(error)));
  const loaded = await page.evaluate(() => Boolean(window.probeLoaded));
  record.observations.push({ name, origin, loaded, errors, events, modules });
  await page.close();
}
try {
  browser = await chromium.launch({ headless: true });
  first = await start('first', null);
  await visit(first, 'first-cold');
  record.metadataFirst = JSON.parse(await fs.readFile(path.join(cache, 'deps/_metadata.json'), 'utf8'));
  second = await start('second', [...deps].reverse());
  await visit(second, 'second-cold');
  record.metadataSecond = JSON.parse(await fs.readFile(path.join(cache, 'deps/_metadata.json'), 'utf8'));
  await second.close(); second = null;
  await visit(first, 'first-reused');
  first.moduleGraph.invalidateAll();
  await visit(first, 'first-reused-invalidated');
} catch (error) {
  record.error = String(error.stack || error);
  process.exitCode = 3;
} finally {
  await second?.close();
  await first?.close();
  await browser?.close();
  await fs.rm(root, { recursive: true, force: true });
  record.ownedRootRemoved = true;
  await fs.writeFile(output, JSON.stringify(record, null, 2) + '\n');
  console.log(JSON.stringify({ observations: record.observations.map(({ name, loaded, errors, events }) => ({ name, loaded, errors, cell: events.filter(event => event.id === 'cell') })), error: record.error, ownedRootRemoved: record.ownedRootRemoved }, null, 2));
}
