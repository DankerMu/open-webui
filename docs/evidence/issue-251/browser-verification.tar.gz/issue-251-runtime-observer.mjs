import assert from 'node:assert/strict';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
const root = '/Users/danker/Documents/31308/open-webui-ocu-plan2';
const [label, command, ...args] = process.argv.slice(2);
assert(label && command && /^[a-z0-9-]+$/.test(label));
const destination = `/tmp/issue-251-${label}.runtime.json`;
assert(!fs.existsSync(destination));
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
async function inventory(directory, relative = '') {
  if (!fs.existsSync(directory)) return [];
  const rows = [];
  for (const entry of (await fsp.readdir(directory, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    const name = path.join(relative, entry.name);
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) rows.push(...await inventory(full, name));
    else if (entry.isSymbolicLink()) rows.push({ path: name, symlink: await fsp.readlink(full) });
    else if (entry.isFile()) rows.push({ path: name, sha256: hash(await fsp.readFile(full)) });
  }
  return rows;
}
const defaultCache = path.join(root, 'node_modules/.vite');
const runs = new Map();
const pending = [];
const observationErrors = [];
const watcher = fs.watch(path.join(root, '.run'), { recursive: true }, (_event, filename) => {
  if (!filename) return;
  const normalized = String(filename).split(path.sep).join('/');
  const match = /^(workspace-ui-[^/]+)(?:\/|$)/.exec(normalized);
  if (!match) return;
  const runName = match[1];
  if (!runs.has(runName)) {
    const row = { run: runName, cacheMetadata: [], before: null };
    runs.set(runName, row);
    const job = inventory(defaultCache).then(before => { row.before = before; }).catch(error => observationErrors.push(String(error)));
    pending.push(job);
  }
  const metadataPath = `${runName}/vite-cache/deps/_metadata.json`;
  if (![`${runName}/vite-cache`, `${runName}/vite-cache/deps`, metadataPath].includes(normalized)) return;
  const full = path.join(root, '.run', metadataPath);
  const job = fsp.readFile(full).then(bytes => {
    const metadata = JSON.parse(bytes);
    runs.get(runName).cacheMetadata.push({ path: metadataPath, sha256: hash(bytes), browserHash: metadata.browserHash });
  }).catch(error => {
    // Cache publication/removal can race this filesystem notification; later stable publication is required below.
    if (error.code !== 'ENOENT') observationErrors.push(String(error));
  });
  pending.push(job);
});
watcher.on('error', error => observationErrors.push(String(error)));
let child;
let stdout = '';
let stderr = '';
let exit;
try {
  child = spawn(command, args, { cwd: root, env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.on('data', bytes => { stdout += bytes; process.stdout.write(bytes); });
  child.stderr.on('data', bytes => { stderr += bytes; process.stderr.write(bytes); });
  exit = await new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('close', (code, signal) => resolve({ code, signal }));
  });
} finally {
  watcher.close();
  await Promise.all(pending);
  const after = await inventory(defaultCache);
  const observations = [...runs.values()].map(row => ({ ...row,
    defaultUnchanged: JSON.stringify(row.before) === JSON.stringify(after),
    ownedRootRemoved: !fs.existsSync(path.join(root, '.run', row.run)),
    privateCacheRemoved: !fs.existsSync(path.join(root, '.run', row.run, 'vite-cache'))
  }));
  const valid = observations.length > 0 && observations.every(row => row.cacheMetadata.length > 0 && row.defaultUnchanged && row.ownedRootRemoved && row.privateCacheRemoved) && observationErrors.length === 0;
  const record = { argv: [command, ...args], exit, observations, observationErrors, valid,
    defaultAfter: after, stdout, stderr, observerSha256: hash(await fsp.readFile(new URL(import.meta.url))) };
  await fsp.writeFile(destination, JSON.stringify(record, null, 2)+'\n');
  console.log(JSON.stringify({ exit, valid, runs: observations.map(({ run, cacheMetadata, defaultUnchanged, ownedRootRemoved, privateCacheRemoved }) => ({ run, cacheMetadata, defaultUnchanged, ownedRootRemoved, privateCacheRemoved })), observationErrors }, null, 2));
  process.exitCode = exit?.code === 0 && valid ? 0 : (exit?.code || 2);
}
