const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const root = '/Users/danker/Documents/31308/open-webui-ocu-plan2';
const load = createRequire(`${root}/package.json`);
const { chromium } = load('playwright');
const label = process.argv[2];
const instrument = process.argv[3] === 'instrument';
assert(label && /^[a-z0-9-]+$/.test(label));
const destination = `/tmp/issue-251-${label}.json`;
assert(!fs.existsSync(destination));
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  const errors = [];
  const rewritten = [];
  const registrations = [];
  page.on('pageerror', error => errors.push(String(error)));
  page.on('console', message => {
    if (message.type() === 'error') errors.push(message.text());
  });
  await page.exposeFunction('__captureSelectionRegistration', event => registrations.push(event));
  if (instrument) {
    await page.route(/\/node_modules\/\.vite\/deps\/[^/?]+\.js(?:\?.*)?$/, async route => {
      const response = await route.fetch();
      if (response.status() !== 200) {
        await route.fulfill({ response });
        return;
      }
      const body = await response.text();
      const opener = 'static jsonID(id, selectionClass) {';
      if (!body.includes(opener)) {
        await route.fulfill({ response });
        return;
      }
      assert.equal(body.split(opener).length, 2);
      assert(body.includes('throw new RangeError("Duplicate use of selection JSON ID " + id)'));
      const extra = `${opener}\n    globalThis.__captureSelectionRegistration({id, registry: import.meta.url, existed: id in classesById, sameClass: classesById[id] === selectionClass, stack: new Error('selection-registration-probe').stack});`;
      const modified = body.replace(opener, extra);
      const address = new URL(route.request().url());
      rewritten.push({path: address.pathname + address.search,
        original_sha256: crypto.createHash('sha256').update(body).digest('hex'),
        instrumented_sha256: crypto.createHash('sha256').update(modified).digest('hex')});
      await route.fulfill({ response, body: modified });
    });
  }
  let shell = false;
  let routeError = false;
  try {
    await page.goto('http://localhost:5173/auth');
    await page.locator('input[type="email"], input[name="email"]').first().fill(process.env.SEED_EMAIL || 'admin@harness.local');
    await page.locator('input[type="password"]').first().fill(process.env.SEED_PASSWORD || 'harness-admin-pw');
    await page.locator('button[type="submit"]').first().click();
    await page.waitForURL(/\/$|\/c\//, { timeout: 20000 });
    await page.waitForFunction(() => Boolean(document.querySelector('#chat-container, #chat-input, textarea')) || document.body.innerText.includes('500: Internal Error'), undefined, { timeout: 20000 });
    shell = await page.locator('#chat-container, #chat-input, textarea').first().isVisible();
    routeError = await page.getByText('500: Internal Error', { exact: true }).isVisible();
    if (process.argv.includes('--dismiss-changelog') && shell) {
      const acknowledge = page.getByRole('button', { name: "Okay, Let's Go!", exact: true });
      if (await acknowledge.isVisible()) await acknowledge.click();
    }
    await page.screenshot({ path: `/tmp/issue-251-${label}.png`, fullPage: true });
    await page.evaluate(() => Promise.resolve());
  } catch (error) {
    errors.push(String(error));
  } finally {
    const record = { instrument, shell, routeError, errors, rewritten, registrations,
      probe_sha256: crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex'),
      limit: instrument
        ? 'Test-only observer inserted before the existing registration guard; guard and imports remain unchanged. Routing disables browser HTTP cache. No authentication headers, requests or responses retained.'
        : 'Plain browser navigation and user interaction; no route interception or library instrumentation. No authentication headers, requests or responses retained.' };
    fs.writeFileSync(destination, JSON.stringify(record, null, 2) + '\n');
    await browser.close();
    console.log(JSON.stringify(record, null, 2));
    process.exitCode = shell && !routeError && errors.length === 0 ? 0 : 2;
  }
})().catch(error => { console.error(String(error)); process.exitCode = 3; });
