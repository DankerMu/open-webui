import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

name, cwd, *argv = sys.argv[1:]
root = Path(cwd)
output = Path('/tmp') / f'issue-221-{name}.command.json'
if output.exists():
    raise SystemExit(f'Refusing overwrite: {output}')
env = os.environ.copy()
env['PATH'] = '/Users/danker/.nvm/versions/node/v22.23.2/bin:/Users/danker/Documents/31308/open-webui-ocu-plan2/.venv/bin:' + env['PATH']
env['UV_NO_SYNC'] = '1'
state = root / '.review-gate.json'
before = hashlib.sha256(state.read_bytes()).hexdigest() if state.exists() else None
started = time.time()
p = subprocess.run(argv, cwd=root, env=env, capture_output=True, text=True, timeout=1800)
after = hashlib.sha256(state.read_bytes()).hexdigest() if state.exists() else None
record = {'cwd': cwd, 'argv': argv, 'exit': p.returncode, 'elapsed': time.time()-started, 'state_sha256_before': before, 'state_sha256_after': after, 'ignore_sha256': hashlib.sha256((root / '.prettierignore').read_bytes()).hexdigest(), 'stdout': p.stdout, 'stderr': p.stderr}
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('stdout','stderr')}))
print(p.stdout[-4000:])
print(p.stderr[-4000:])
raise SystemExit(p.returncode)
