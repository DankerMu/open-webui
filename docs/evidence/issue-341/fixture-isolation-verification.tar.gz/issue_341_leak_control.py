"""Disposable process-state leak; only the throwaway qualification child loads this."""
from contextlib import contextmanager
import os
import sys
import types

import pytest

TARGET = 'tests/security/test_path_traversal_app.py::TestNormalOperations::test_outputs_normal'

@pytest.hookimpl(tryfirst=True)
def pytest_collection_modifyitems(items):
    canonical = sys.modules['tests.orchestrator.test_outputs_endpoint']
    original = canonical._isolated_app
    selected = [item for item in items if item.nodeid == TARGET]
    if len(selected) != 1:
        raise pytest.UsageError('negative control target missing')

    @contextmanager
    def leaking_context(*args, **kwargs):
        with original(*args, **kwargs) as result:
            yield result
        # An intentionally defective restoration, after the real request/lifetime.
        os.environ['ISSUE341_DISPOSABLE_LEAK'] = 'present'
        sys.modules['docker_manager'] = types.ModuleType('docker_manager')

    canonical._isolated_app = leaking_context
    selected[0].module._isolated_app = leaking_context
