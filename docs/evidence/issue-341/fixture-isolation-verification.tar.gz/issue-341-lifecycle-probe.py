#!/usr/bin/env python3
"""Static-authored #341 lifecycle qualification; parent owns execution/deadlines.

Run from open-computer-use, once per mode in a fresh Python interpreter:
  uv run --offline --python 3.12 --no-project --with pytest --with pytest-asyncio --with-requirements computer-use-server/requirements.txt -- python /tmp/issue-341-lifecycle-probe.py --mode normal --json /tmp/issue-341-lifecycle-normal.json
  uv run --offline --python 3.12 --no-project --with pytest --with pytest-asyncio --with-requirements computer-use-server/requirements.txt -- python /tmp/issue-341-lifecycle-probe.py --mode intentional-failure --json /tmp/issue-341-lifecycle-intentional-failure.json

Required binding interface: the collected security test module's global
_isolated_app must be the exact callable from the already-collected canonical
outputs test module. Only that binding is wrapped. The wrapper delegates entry,
yield and exit to the existing helper, and never isolates or restores app state.
The security fixture still owns its actual client and seeded workspace.

The original selected test runs unchanged. A target-frame trace observes only
its real response's numeric status. Failure mode injects one identifiable
AssertionError only after that original test passes with the real HTTP200.

Exit 0 means qualified normal completion. Exit 1 means qualified intentional
failure (pytest itself returned 1); it is deliberately not normalized to zero.
Exit 2 means invalid qualification, including unrelated pytest failures. JSON
also retains pytest's actual exit code. No subprocesses, deadlines, retries,
application substitutions or recovery substitutions are implemented here.
Raw pytest/app stdout and stderr are suppressed; the output channel is safe
JSON only. Environment values, exception messages, locals and credentials are
never serialized. Complete environment and module objects are kept in memory
only for equality/identity comparisons at the canonical context's boundary.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager, redirect_stderr, redirect_stdout
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path.cwd()))

import pytest

TARGET = "tests/security/test_path_traversal_app.py::TestNormalOperations::test_outputs_normal"
HELPER_PATH = Path("tests/orchestrator/test_outputs_endpoint.py").resolve()


class LifecycleProbe:
    def __init__(self, mode):
        self.mode = mode
        self.client = None
        self.security_module = None
        self.original_helper = None
        self.observed_helper = None
        self.intentional_error = AssertionError()
        self.invalid_reasons = []
        self.data = {
            "schema_version": 1,
            "mode": mode,
            "selected_nodes": [],
            "executed_nodes": [],
            "selection_valid": False,
            "binding_valid": False,
            "context_entries": 0,
            "context_yields": 0,
            "context_exits": 0,
            "lifecycle_observations": [],
            "phase_outcomes": [],
            "target": {
                "response_observed": False,
                "response_status": None,
                "original_test_passed": False,
                "intentional_assertion_injected": False,
            },
            "pytest_exit_code": None,
            "probe_exit_code": None,
            "qualified": False,
            "classification": "invalid",
            "invalid_reasons": self.invalid_reasons,
        }

    def invalidate(self, reason):
        if reason not in self.invalid_reasons:
            self.invalid_reasons.append(reason)

    def client_state(self):
        client = self.client
        if client is None:
            return {
                "client_observed": False,
                "client_is_closed": False,
                "portal_attribute_observed": False,
                "portal_is_none": False,
                "exit_stack_observed": False,
                "exit_stack_callback_count": None,
                "no_surviving_portal_context": False,
            }
        closed = getattr(client, "is_closed", None) is True
        portal_observed = hasattr(client, "portal")
        portal_is_none = portal_observed and client.portal is None
        stack = getattr(client, "exit_stack", None)
        callbacks = getattr(stack, "_exit_callbacks", None)
        count = None if callbacks is None else len(callbacks)
        return {
            "client_observed": True,
            "client_is_closed": closed,
            "portal_attribute_observed": portal_observed,
            "portal_is_none": portal_is_none,
            "exit_stack_observed": stack is not None,
            "exit_stack_callback_count": count,
            "no_surviving_portal_context": portal_is_none and (
                stack is None or count == 0
            ),
        }

    @pytest.hookimpl(trylast=True)
    def pytest_collection_modifyitems(self, items):
        self.data["selected_nodes"] = [item.nodeid for item in items]
        if self.data["selected_nodes"] != [TARGET]:
            self.invalidate("unexpected_selected_nodes")
            raise pytest.UsageError("lifecycle probe requires the exact target node")
        self.data["selection_valid"] = True
        item = items[0]
        modules = [
            module for module in tuple(sys.modules.values())
            if module is not None
            and isinstance(getattr(module, "__file__", None), str)
            and Path(module.__file__).resolve() == HELPER_PATH
        ]
        if len(modules) != 1:
            self.invalidate("canonical_helper_module_not_unique")
            raise pytest.UsageError("lifecycle probe requires one collected helper module")
        canonical = modules[0]
        original = getattr(canonical, "_isolated_app", None)
        inventory = getattr(canonical, "_APP_MODULES", None)
        security = item.module
        if (
            not callable(original)
            or getattr(security, "_isolated_app", None) is not original
            or not isinstance(inventory, tuple)
            or not all(isinstance(name, str) for name in inventory)
        ):
            self.invalidate("canonical_binding_interface_missing")
            raise pytest.UsageError("security module must bind the canonical _isolated_app")
        self.data["binding_valid"] = True
        self.security_module = security
        self.original_helper = original

        def relevant_modules():
            # Same membership rule as the sole lifetime owner; no copied inventory.
            return {
                name: module for name, module in tuple(sys.modules.items())
                if name in inventory or name.startswith("mcp_resources")
            }

        @contextmanager
        def observed_helper(*args, **kwargs):
            self.data["context_entries"] += 1
            environment_before = os.environ.copy()
            modules_before = relevant_modules()
            observation = {
                "environment_before_count": len(environment_before),
                "modules_before_count": len(modules_before),
                "before_canonical_restore": None,
                "after_canonical_restore": None,
            }
            self.data["lifecycle_observations"].append(observation)
            try:
                with original(*args, **kwargs) as result:
                    self.data["context_yields"] += 1
                    try:
                        yield result
                    finally:
                        # Fixture closure must already have happened at this point.
                        observation["before_canonical_restore"] = self.client_state()
            finally:
                # The real helper has completed its own exit, even if it raised.
                self.data["context_exits"] += 1
                environment_after = os.environ.copy()
                modules_after = relevant_modules()
                same_names = modules_before.keys() == modules_after.keys()
                same_objects = same_names and all(
                    modules_after[name] is module
                    for name, module in modules_before.items()
                )
                observation.update({
                    "environment_after_count": len(environment_after),
                    "environment_exactly_restored": environment_before == environment_after,
                    "modules_after_count": len(modules_after),
                    "module_name_set_exactly_restored": same_names,
                    "prior_module_objects_exactly_restored": same_objects,
                    "module_object_mismatch_count": sum(
                        name not in modules_after or modules_after[name] is not module
                        for name, module in modules_before.items()
                    ),
                    "added_module_count": len(modules_after.keys() - modules_before.keys()),
                    "missing_module_count": len(modules_before.keys() - modules_after.keys()),
                    "after_canonical_restore": self.client_state(),
                })

        self.observed_helper = observed_helper
        security._isolated_app = observed_helper

    def pytest_runtest_logstart(self, nodeid):
        self.data["executed_nodes"].append(nodeid)

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_setup(self, item):
        yield
        if item.nodeid == TARGET:
            self.client = item.funcargs.get("client")

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_call(self, item):
        if item.nodeid != TARGET:
            yield
            return
        previous = sys.gettrace()
        if previous is not None:
            self.invalidate("existing_python_tracer")
            raise pytest.UsageError("lifecycle probe requires no existing tracer")
        code = item.obj.__code__

        def trace_target(frame, event, arg):
            if frame.f_code is not code:
                return None
            if event in ("line", "return"):
                # Do not emit frame locals: read only the unchanged test's response.
                response = frame.f_locals.get("resp")
                if response is not None:
                    status = getattr(response, "status_code", None)
                    if type(status) is int:
                        self.data["target"]["response_observed"] = True
                        self.data["target"]["response_status"] = status
            return trace_target

        sys.settrace(trace_target)
        try:
            outcome = yield
        finally:
            sys.settrace(previous)
        target = self.data["target"]
        target["original_test_passed"] = outcome.excinfo is None
        if (
            self.mode == "intentional-failure"
            and target["original_test_passed"]
            and target["response_observed"]
            and target["response_status"] == 200
        ):
            target["intentional_assertion_injected"] = True
            outcome.force_exception(self.intentional_error)

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_makereport(self, item, call):
        outcome = yield
        report = outcome.get_result()
        self.data["phase_outcomes"].append({
            "nodeid": report.nodeid,
            "phase": report.when,
            "outcome": report.outcome,
            "intentional_assertion": (
                call.excinfo is not None
                and call.excinfo.value is self.intentional_error
                and call.excinfo.type is AssertionError
            ),
        })

    def release_observation_binding(self):
        if self.security_module is not None:
            if self.security_module._isolated_app is self.observed_helper:
                self.security_module._isolated_app = self.original_helper
            else:
                self.invalidate("observation_binding_changed")

    def qualify(self, pytest_exit_code):
        self.data["pytest_exit_code"] = pytest_exit_code
        if not self.data["selection_valid"] or not self.data["binding_valid"]:
            self.invalidate("selection_or_binding_invalid")
        if self.data["executed_nodes"] != [TARGET]:
            self.invalidate("unexpected_executed_nodes")
        if any(self.data[key] != 1 for key in (
            "context_entries", "context_yields", "context_exits"
        )):
            self.invalidate("canonical_context_not_exercised_exactly_once")
        observations = self.data["lifecycle_observations"]
        if len(observations) != 1:
            self.invalidate("lifecycle_observation_count_invalid")
        for observation in observations:
            if not all(observation.get(key) is True for key in (
                "environment_exactly_restored",
                "module_name_set_exactly_restored",
                "prior_module_objects_exactly_restored",
            )):
                self.invalidate("process_state_not_exactly_restored")
            for boundary in ("before_canonical_restore", "after_canonical_restore"):
                state = observation.get(boundary)
                if state is None or not all(state.get(key) is True for key in (
                    "client_observed", "client_is_closed", "no_surviving_portal_context"
                )):
                    self.invalidate("client_lifetime_not_closed_at_restoration_boundary")
        target = self.data["target"]
        if not (
            target["response_observed"]
            and target["response_status"] == 200
            and target["original_test_passed"]
        ):
            self.invalidate("original_target_did_not_pass_with_real_http200")
        expected_failure = self.mode == "intentional-failure"
        expected_outcomes = [
            {"nodeid": TARGET, "phase": "setup", "outcome": "passed", "intentional_assertion": False},
            {"nodeid": TARGET, "phase": "call", "outcome": "failed" if expected_failure else "passed", "intentional_assertion": expected_failure},
            {"nodeid": TARGET, "phase": "teardown", "outcome": "passed", "intentional_assertion": False},
        ]
        if self.data["phase_outcomes"] != expected_outcomes:
            self.invalidate("unexpected_setup_call_or_teardown_outcome")
        if target["intentional_assertion_injected"] is not expected_failure:
            self.invalidate("intentional_assertion_provenance_invalid")
        expected_exit = 1 if expected_failure else 0
        if pytest_exit_code != expected_exit:
            self.invalidate("unexpected_pytest_exit_code")
        qualified = not self.invalid_reasons
        self.data["qualified"] = qualified
        self.data["classification"] = (
            "qualified_intentional_assertion_failure" if expected_failure
            else "qualified_normal_completion"
        ) if qualified else "invalid"
        exit_code = expected_exit if qualified else 2
        self.data["probe_exit_code"] = exit_code
        return exit_code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("normal", "intentional-failure"), required=True)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    if not Path("tests/security/test_path_traversal_app.py").is_file():
        parser.error("run from the open-computer-use repository root")
    if args.json.resolve().parent != Path("/tmp").resolve():
        parser.error("qualification JSON must be written directly under /tmp")
    probe = LifecycleProbe(args.mode)
    argv = [
        "tests/", "--import-mode=importlib", "--ignore=tests/integration",
        "-p", "no:cacheprovider", "-p", "no:terminal",
        "-k", "test_path_traversal_app and test_outputs_normal",
    ]
    pytest_exit_code = None
    # No raw exception/warning/locals/app output enters the evidence channel.
    # Parent subprocess timeout covers collection, execution and teardown together.
    with open(os.devnull, "w", encoding="utf-8") as suppressed:
        with redirect_stdout(suppressed), redirect_stderr(suppressed):
            try:
                pytest_exit_code = int(pytest.main(argv, plugins=[probe]))
            except BaseException:
                probe.invalidate("runner_exception")
            finally:
                probe.release_observation_binding()
    exit_code = probe.qualify(pytest_exit_code)
    payload = json.dumps(probe.data, sort_keys=True, indent=2) + "\n"
    args.json.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
