#!/usr/bin/env python3
"""Read-only #341 diagnostic; run from the source repository, never import app here.

Example (parent execution only):
  uv run --no-project --with pytest --with-requirements computer-use-server/requirements.txt -- python /tmp/issue-341-isolation-probe.py --mode ordered --collect-only --json /tmp/issue-341-ordered-collection.json
  uv run --no-project --with pytest --with-requirements computer-use-server/requirements.txt -- python /tmp/issue-341-isolation-probe.py --mode ordered --json /tmp/issue-341-ordered.json

Use --mode alone and --mode reversed in fresh interpreters for controls. Each
execution still runs its entire selected sequence in one pytest process. This
probe does not isolate modules, set app settings, replace functions, or recover
failures. Existing test fixtures own all application state changes.

JSON excludes headers, credentials, environment, bodies, locals, exception
messages, and pytest longrepr. Only allowlisted identities, data roots, chat
existence, outcomes, and the numeric response status are recorded. Object IDs
and temporary roots naturally differ between runs; schema and ordering do not.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys

# Prevent diagnostic runs from leaving bytecode in the repository.
sys.dont_write_bytecode = True
# Match python -m pytest's repository import path despite this runner living in /tmp.
sys.path.insert(0, str(Path.cwd()))

import pytest

PUBLISH = "tests/orchestrator/test_office_publish.py::test_missing_chat_is_not_recreated"
STORE = "tests/orchestrator/test_office_store.py::test_missing_state_reads_empty_schema_without_creating_state_file"
TARGET = "tests/security/test_path_traversal_app.py::TestNormalOperations::test_outputs_normal"
ORDER = [PUBLISH, STORE, TARGET]
SELECTION = (
    "test_missing_chat_is_not_recreated or "
    "test_missing_state_reads_empty_schema_without_creating_state_file or "
    "test_outputs_normal"
)
CHAT = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
ERRORS = ("StateCorruptError", "StateDurabilityError")


def identity(obj):
    return None if obj is None else hex(id(obj))


def namespace(obj):
    return {} if obj is None else vars(obj)


def class_info(cls):
    if cls is None:
        return None
    return {"identity": identity(cls), "module": cls.__module__, "name": cls.__name__}


def function_info(fn):
    if fn is None:
        return None
    return {
        "identity": identity(fn),
        "name": fn.__name__,
        "globals_identity": identity(fn.__globals__),
    }


def redacted_path(path):
    # Data roots normally contain no credentials. Defend against accidental
    # credential-shaped configured roots without inspecting any environment.
    text = str(path)
    text = re.sub(r"(://)[^/@\s]+@", r"\1[REDACTED]@", text)
    return re.sub(
        r"(?i)((?:token|password|secret|api[_-]?key)[=:])[^/\s&?#]+",
        r"\1[REDACTED]", text,
    )


def root_info(path):
    if path is None:
        return None
    root = Path(path)
    try:
        chat_exists = (root / CHAT).is_dir()
        outputs_exists = (root / CHAT / "outputs").is_dir()
        inspection_error = None
    except OSError as exc:
        chat_exists = outputs_exists = None
        inspection_error = class_info(type(exc))
    return {
        "path": redacted_path(root),
        "chat_is_directory": chat_exists,
        "outputs_is_directory": outputs_exists,
        "inspection_error": inspection_error,
    }


def module_info(module):
    if module is None:
        return None
    return {
        "identity": identity(module),
        "root": root_info(namespace(module).get("BASE_DATA_DIR")),
    }


def endpoint_globals(client):
    """Locate the real client ASGI endpoint without importing or calling it."""
    asgi_app = namespace(client).get("app")
    router = namespace(asgi_app).get("router")
    for route in namespace(router).get("routes", ()):
        data = namespace(route)
        if data.get("path") == "/api/outputs/{chat_id}":
            endpoint = data.get("endpoint")
            return asgi_app, endpoint, endpoint.__globals__
    return asgi_app, None, {}


def snapshot(item):
    cached_app = sys.modules.get("app")
    cached_manager = sys.modules.get("docker_manager")
    publish = sys.modules.get("office.publish")
    store = sys.modules.get("office.store")
    client = item.funcargs.get("client")
    asgi_app, endpoint, active = endpoint_globals(client)
    # Prefer the actual client's endpoint graph; lifecycle snapshots without
    # a client instead inspect the cached module graph, explicitly labelled.
    app_globals = active if endpoint is not None else namespace(cached_app)
    recovery = app_globals.get("recover_publications")
    recovery_globals = getattr(recovery, "__globals__", {})
    publish_globals = namespace(publish)
    lock = app_globals.get("_combined_lock")
    lock_globals = getattr(lock, "__globals__", {})
    publication_manager = publish_globals.get("docker_manager")
    recovery_manager = recovery_globals.get("docker_manager")
    store_manager = namespace(store).get("docker_manager")
    app_class_sets = {name: app_globals.get(name) for name in ERRORS}
    publication_class_sets = {name: publish_globals.get(name) for name in ERRORS}
    recovery_class_sets = {name: recovery_globals.get(name) for name in ERRORS}
    current_class_sets = {name: namespace(store).get(name) for name in ERRORS}
    return {
        "graph_source": "client_endpoint" if endpoint is not None else "cached_modules",
        "cached_app": module_info(cached_app),
        "client_asgi_app_identity": identity(asgi_app),
        "cached_asgi_app_identity": identity(namespace(cached_app).get("app")),
        "client_uses_cached_asgi_app": None if client is None else asgi_app is namespace(cached_app).get("app"),
        "active_endpoint": function_info(endpoint),
        "active_app_globals_identity": identity(app_globals),
        "active_app_root": root_info(app_globals.get("BASE_DATA_DIR")),
        "cached_manager": module_info(cached_manager),
        "publication_module_identity": identity(publish),
        "publication_manager": module_info(publication_manager),
        "active_recovery": function_info(recovery),
        "cached_publication_recovery": function_info(publish_globals.get("recover_publications")),
        "active_recovery_manager": module_info(recovery_manager),
        "active_lock": function_info(lock),
        "active_lock_globals_root": root_info(lock_globals.get("BASE_DATA_DIR")),
        "current_store_module_identity": identity(store),
        "current_store_manager": module_info(store_manager),
        "manager_equalities": {
            "publication_is_cached": None if publication_manager is None else publication_manager is cached_manager,
            "recovery_is_cached": None if recovery_manager is None else recovery_manager is cached_manager,
            "store_is_cached": None if store_manager is None else store_manager is cached_manager,
            "lock_globals_are_cached_manager_globals": None if lock is None or cached_manager is None else lock_globals is vars(cached_manager),
            "publication_root_equals_active_app_root": None if publication_manager is None or not app_globals else namespace(publication_manager).get("BASE_DATA_DIR") == app_globals.get("BASE_DATA_DIR"),
        },
        "exceptions": {
            name: {
                "active_app": class_info(app_class_sets[name]),
                "publication": class_info(publication_class_sets[name]),
                "active_recovery": class_info(recovery_class_sets[name]),
                "current_store": class_info(current_class_sets[name]),
                "publication_is_app": None if publication_class_sets[name] is None or app_class_sets[name] is None else publication_class_sets[name] is app_class_sets[name],
                "publication_is_store": None if publication_class_sets[name] is None or current_class_sets[name] is None else publication_class_sets[name] is current_class_sets[name],
            }
            for name in ERRORS
        },
    }


class Probe:
    def __init__(self, mode, collect_only):
        self.mode = mode
        self.data = {
            "schema_version": 1,
            "mode": mode,
            "collect_only": collect_only,
            "selected_natural_order": [],
            "planned_execution_order": [],
            "executed_order": [],
            "selection_valid": False,
            "snapshots": [],
            "phase_outcomes": [],
            "target": {
                "pre_get_captured": False,
                "response_status": None,
                "exception_events": [],
            },
            "pytest_exit_code": None,
        }

    @pytest.hookimpl(trylast=True)
    def pytest_collection_modifyitems(self, items):
        selected = [item.nodeid for item in items]
        self.data["selected_natural_order"] = selected
        expected = [TARGET] if self.mode == "alone" else ORDER
        if selected != expected:
            raise pytest.UsageError("#341 probe requires exactly the documented nodes in canonical natural order; inspect diagnostic JSON")
        self.data["selection_valid"] = True
        if self.mode == "reversed":
            items.reverse()
        self.data["planned_execution_order"] = [item.nodeid for item in items]

    def capture(self, item, stage):
        self.data["snapshots"].append({"nodeid": item.nodeid, "stage": stage, "state": snapshot(item)})

    def pytest_runtest_logstart(self, nodeid):
        self.data["executed_order"].append(nodeid)

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_setup(self, item):
        self.capture(item, "before_setup")
        yield
        self.capture(item, "after_setup")

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_teardown(self, item):
        self.capture(item, "before_teardown")
        yield
        self.capture(item, "after_teardown")

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_call(self, item):
        if item.nodeid != TARGET:
            yield
            return
        code = item.obj.__code__
        previous = sys.gettrace()
        # Never silently disable another tracer (coverage/debugger would alter
        # the observation contract). The parent command uses neither.
        if previous is not None:
            raise pytest.UsageError("#341 probe requires no existing Python tracer")

        def trace_target(frame, event, arg):
            if frame.f_code is not code:
                return None
            if event == "line":
                if not self.data["target"]["pre_get_captured"]:
                    # The existing test's first executable statement is GET.
                    self.capture(item, "immediately_before_outputs_get")
                    self.data["target"]["pre_get_captured"] = True
                response = frame.f_locals.get("resp")
                if response is not None:
                    self.data["target"]["response_status"] = response.status_code
            elif event == "exception":
                cls = arg[0]
                _, _, active = endpoint_globals(item.funcargs.get("client"))
                recovery = active.get("recover_publications")
                recovery_globals = getattr(recovery, "__globals__", {})
                self.data["target"]["exception_events"].append({
                    "class": class_info(cls),
                    "matches": {
                        name: {
                            "active_app": cls is active.get(name),
                            "active_recovery": cls is recovery_globals.get(name),
                            "current_store": cls is namespace(sys.modules.get("office.store")).get(name),
                        }
                        for name in ERRORS
                    },
                })
            return trace_target

        sys.settrace(trace_target)
        try:
            yield
        finally:
            sys.settrace(previous)

    def pytest_runtest_logreport(self, report):
        self.data["phase_outcomes"].append({
            "nodeid": report.nodeid,
            "phase": report.when,
            "outcome": report.outcome,
        })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("ordered", "alone", "reversed"), required=True)
    parser.add_argument("--collect-only", action="store_true")
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    if not Path("tests/security/test_path_traversal_app.py").is_file():
        parser.error("run from the open-computer-use repository root")
    if args.json.resolve().parent != Path("/tmp").resolve():
        parser.error("diagnostic JSON must be written directly under /tmp")
    plugin = Probe(args.mode, args.collect_only)
    argv = [
        "tests/", "-q", "--import-mode=importlib", "--ignore=tests/integration",
        "-p", "no:cacheprovider", "-k", "test_outputs_normal" if args.mode == "alone" else SELECTION,
        "--tb=no", "--show-capture=no",
    ]
    if args.collect_only:
        argv.append("--collect-only")
    exit_code = 3
    try:
        exit_code = int(pytest.main(argv, plugins=[plugin]))
    finally:
        plugin.data["pytest_exit_code"] = exit_code
        args.json.write_text(json.dumps(plugin.data, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
