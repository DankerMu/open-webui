## Diagnosis and approved prerequisite scope

The user explicitly authorized this test-isolation repair as a prerequisite for #199. No Office, broker, authorization or discovery production change is authorized by this repair.

Fresh Python 3.12 runs used the unchanged security fixture at source baseline `8a5f046465436ee2e05db76ba1b4ce90a66a3de5`. The diagnostic runs existing tests without replacing recovery, records the actual client's endpoint globals immediately before GET, and retains object/class identities. Command prefix:

```sh
uv run --offline --python 3.12 --no-project --with pytest --with pytest-asyncio --with-requirements computer-use-server/requirements.txt -- python /tmp/issue-341-isolation-probe.py
```

Each mode first ran `--collect-only`; all three validated exact node selection. Then each mode ran in a fresh interpreter with `--mode MODE --json /tmp/issue-341-MODE.json`:

| Mode | Observed result |
| --- | --- |
| ordered: publish predecessor, store predecessor, security target | exit 1; 2 passed, target failed in 0.66 s; escaped `StateCorruptError` |
| alone: canonical `tests/` collection, only target executed | exit 1; target returned HTTP 500 in 0.64 s |
| reversed: target, store predecessor, publish predecessor | exit 1; 2 passed, target returned HTTP 500 in 0.66 s |

The immediate pre-GET graph in all modes proves that the active app/new manager uses the seeded temporary root, while the actual recovery function's bound manager is a different module object using `/data`, where the seeded chat is absent. In ordered mode, the propagated exception class equals the recovery function's `StateCorruptError`, but is not the class caught by the active app or currently exported by `office.store`.

**Correction to the initial hypothesis:** predecessor execution is not necessary for the stale-root failure: canonical collection already leaves the cached Office graph in the target-alone and reversed controls. Those controls are not green and must not be reported as evidence that only one execution order fails. The ordered sequence additionally establishes the escaped exception-class mismatch seen in the full run. No claim is made that this is the full run's exact historical predecessor sequence.

The implementation boundary is now actionable: reuse `tests/orchestrator/test_outputs_endpoint.py::_isolated_app` for the security fixture's complete app/Office/environment lifetime, seed and consume its single data root, retain all security assertions, and restore prior module objects/environment even on failure. Keep this separate from #255 collection routing. #340 remains the preceding serial implementation.

Raw evidence retained locally for the eventual durable evidence bundle: `/tmp/issue-341-isolation-probe.py`, `/tmp/issue-341-{ordered,alone,reversed}{,-collection}.{json,log}`. These are diagnosis results, not a repaired-suite or merge claim.
