## Exact-head local verification

Head: `e49c9cb856c306a962f887a1ccfc7cc3620271f4`.

Owner-approved policy: https://github.com/DankerMu/open-webui/pull/293#issuecomment-6095627934 . GitHub Actions admission query for this head returned zero workflow runs. This is a scoped macOS local equivalent, not a remote Actions/Linux claim.

- `make test-backend` with owning selection: 57 passed / 434 deselected; exact collected and executed node sets agree. One inherited Starlette deprecation warning.
- `make smoke-proxy`: exit0, six Hurl files, Office7/24/5 and real grant issuance/resource/expiry matrix. Normal witness and eight qualified fault boundaries additionally check argv/public containment, precise pin bytes and independent cleanup.
- BrowserHarness narrow renderer proof: five distinct ports, three occupied service reservations, both real nginx listeners return expected internal404; owned scratch/data removed. No browser acceptance claim.
- `make lint-scoped`: 109 files conform; `make anti-drift`: 2.84% duplicate lines, dead-code/export checks pass.
- Ruff format: ten Python files; affected Markdown Prettier and whitespace checks pass. Commit hooks pass.
- `make doc-gate`; `make decisions-verify`: 49 records; strict `ocu-resource-grants` validation pass.
- Hashes of all15 verification input files match committed blobs. Remote feature head matches local head; current main is its ancestor. OCU pin's seven overlapping proof files match the #298 native evidence byte-for-byte.
- No production backend/frontend files changed: no unrelated full-suite or aggregate coverage sweep. Source OCU, production auth, dependencies and CI are unchanged.

Native platform: macOS26.6.2 arm64; Python3.12.12, nginx1.31.6, Hurl8.0.1. Raw synthetic credentials remain private. Parent-owned dev services stopped; ports8080/5173 free. Cross-review remains a separate merge gate.
