## Fresh group5 baseline and RED

- #298 source/control merged；selected reviewed OCU pin is `276e00aceddb332974a0390e01d69d9430065816`。本阶段只改 WebUI harness/pin，不改 OCU 实现。
- 旧 pin `a53731df95a3b92acb2dcb5980f969b4f8b4ee52` 的 `make smoke-proxy` 基线通过全部6个Hurl文件及 Office7owner/24auth-guard/5unlisted；拥有的服务已停止。
- 新增一个 canonical `download=1&%64ownload=0` issuer302 tracer，保留原文件断言。`make smoke-proxy` 实际失败为 **HTTP200 vs302**，不是语法或依赖错误；原始输出保留于本地证据。新 pin/实现尚未因此计入完成。
- 独立短会话可行性探针复用真实 `create_token` 与 canonical dev-env：fresh issuer302/verifier200；约3.99秒后 issuer401/verifier403；owner资源清理和sentinel通过。它是直接WebUI可行性，不替代本issue的新网关联调。
- expanded group5 fixture reviewPASS、strict/docs/49decision gatesPASS，checkpoint `e63d2855e955fd015c6a1f76b3116b8a8fcbaf56`。原子 cutover 正在实现；required renderer inputs覆盖继承的BrowserHarness窄端口兼容，不宣称#300浏览器验收。

继承 harness dotenv-policy 漂移已独立记录 #419，不自动加入队列；本阶段新增 mint 和父级运行显式禁用 dotenv，不读取 `.env`/secret store。
