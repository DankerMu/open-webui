## Summary

Closes #299.

- Atomically pin OCU to reviewed `276e00aceddb332974a0390e01d69d9430065816` and migrate native file assertions to real WebUI resource-grant issuance/following.
- Prove canonical and grant GET/HEAD, exact encoded query, null-origin CORS/isolation, identity/header containment, per-request no-contact refusals and real short-session expiry.
- Share the existing private Hurl-variable lifetime with Office, distinguish private request metadata from public response evidence, and redact transport failures. Retain Office 7 owner / 24 auth-guard / 5 unlisted assertions.
- Supply required Office renderer inputs and allocate all inherited browser-harness ports together. Browser resource acceptance remains #300; real-editor acceptance remains #172.

Atomic diff exception: the pin changes canonical file responses; pin, stub fixtures, request assertions and private response-evidence parsing must cut over together. Coherent resource-judge extraction and existing nested-fixture ownership keep both large harness files under 800 lines. No production auth, frontend, source OCU, dependency or CI changes.

## Test plan

- [x] Old-pin `make smoke-proxy` green; tests-only canonical302 tracer red (actual200).
- [x] Exact owning discovery/execution reconciliation: 57 tests; 57 passed, 434 deselected, one inherited Starlette deprecation warning.
- [x] `make lint-scoped`: 109 files; `make anti-drift`: 2.84% duplication, dead-code/export checks passed.
- [x] Ten touched Python files pass Ruff format; affected Markdown passes Prettier; whitespace check passes.
- [x] `make doc-gate`, `make decisions-verify`: 49 records; strict shared OpenSpec validation passes.
- [x] Commit hooks: naming, merge markers, large files, private keys, Ruff, secret scan and Conventional Commits pass.

## Runtime evidence

Frozen head: `e49c9cb856c306a962f887a1ccfc7cc3620271f4`.

- Final unwrapped `make smoke-proxy`: exit0; all six Hurl files, full Office matrix and real resource matrix pass. The encoded `download=1&%64ownload=0` row reaches the exact upstream query inline with sandbox/nosniff.
- Parent witness verifies all eight staged gateway files byte-for-byte against the reviewed git revision; observes actual credential-free Hurl argv and mode0600 variable files; independently queries owned DB rows, sentinel preservation, process-group retirement and closed ports.
- Eight qualified counterexamples fail at concrete oracles: encoded-query nosniff loss, actual upstream credential echo, forwarded Cookie, real OCU arrival during a preserved404 denial, invalid fresh session, skipped expiry wait with independently observed still-valid200, stopped owned gateway, and unsafe argv rejected before launch. Public-output scans find no managed credential or credential pattern.
- Narrow inherited BrowserHarness proof executes actual allocation/materialization/rendering, reserves its three service ports and starts both real nginx listeners; internal-only routes refuse404. Owned scratch/data removed. This is not #300 browser/UI evidence.
- Parent-owned dev services stopped; ports8080/5173 free.

Evidence: `/tmp/issue-299-evidence/` (command outputs, source hashes, exact nodes, witness reports, fault adjudication). Raw credential captures remain private and are excluded from publication.

## Risk

- macOS native local evidence, not Linux/Actions or deployment certification. Use the owner-approved exact-head local required-status path from PR293 comment6095627934.
- Before-verifier download refusal is composed from #298's native zero-auth proof and exact pinned generator/template bytes; real-auth smoke independently proves zero OCU contact. No invented verifier telemetry.
- Inherited dotenv policy drift is separately tracked in #419. Parent runs and the new short-session mint explicitly disable dotenv; broad harness policy is unchanged.
- Shared `ocu-resource-grants` fixture stays active and its decision stays proposed through #300.

## Canonicality check

- [x] No parallel implementation, compatibility shim, forbidden suffix or dependency change.
- [x] Existing Office private-variable behavior reused; existing stub fixture owner extended; all consumers of shared helpers migrated.
- [x] Cleanup ownership and Office interruption controls preserved.

## 偏离记录

- Initial verification migrated two backend403/409 assertions from canonical auth rows to grant-file rows; status/header assertions remain intact.
- Parent corrected its own probe assumptions: header writer returnsNone, public health and Office fallback require upstream services. Those failed probes are retained but excluded from qualification; corrected concrete probes passed.
- Parent accidentally formatted constraints.yaml with Prettier; restored hash-verified baseline bytes with only the approved pin change. No threshold/parser change.
- Skipping expiry wait is rejected by the implementation's stronger explicit wall-clock-crossing guard after the protected probe independently observes the still-valid grant200; no production clock changes.

## Agent Review

Expanded three-seat round1 is clean on `e49c9cb856c306a962f887a1ccfc7cc3620271f4`: correctness; test-evidence+spec-compliance; invariant-state. No findings or required evidence gaps; zero review fix passes. Full reports and parent adjudication are in `/tmp/issue-299-evidence/review-*.json` and `adjudication-round1.json`. Selected risk packs: protocol, setup, file/credential IO, auth/secrets, ordering, resource limits, compatibility, errors, release pin and documentation; no application-schema change.
