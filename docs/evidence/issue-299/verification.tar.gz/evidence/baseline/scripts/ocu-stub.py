#!/usr/bin/env python3
"""Deterministic OCU HTTP stub for harness smoke. No Docker, no real OCU."""

from __future__ import annotations

import ast
import base64
import hashlib
import json
import logging
import mimetypes
import os
import re
import secrets
import threading
from email import policy
from email.parser import BytesParser
from functools import lru_cache
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from typing import Optional
from urllib.parse import parse_qs, quote, unquote, urlparse

from ocu_stub_nested import nested_listing_entry, nested_names, nested_payload
from ocu_stub_office import OFFICE_SCENARIOS, OfficeStore
from ocu_stub_office_page import office_host_page

log = logging.getLogger('ocu-stub')

PREFIX = os.environ.get('OCU_PUBLIC_PREFIX', '').rstrip('/')
EXPECTED_TOKEN = os.environ.get('OCU_INTERNAL_TOKEN', '')
RECORD_PATH = os.environ.get('OCU_STUB_RECORD', '')
FIXTURE_PATH = os.environ.get('OCU_STUB_FIXTURES', '')
ASSET_ROOT = Path(os.environ.get('OCU_STUB_ASSETS', ''))
VALID_OFFICE = Path(os.environ.get('OCU_STUB_DOCX', ''))
WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
# Upstream generated fixtures use a weaker CSP so the proxy's forced
# sandbox CSP is observable. Binary/download keep this upstream policy.
WEAK_CSP = "default-src 'self'"
FILES = {
    'page.html': (
        'text/html; charset=utf-8',
        b"""<!doctype html><html><head><title>ocu-stub page</title>
<link rel="stylesheet" href="style.css"><style>#inline{color:rgb(0,128,0)}</style></head><body>
<p id="inline">ocu-stub page</p><img id="image" src="data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=">
<button id="run" onclick="document.querySelector('#clicked').textContent='clicked'">Run</button>
<span id="clicked"></span><span id="proof"></span>
<script>
let storage='blocked', parentAccess='blocked', cookie='blocked';
try { localStorage.getItem('token'); storage='leaked' } catch {}
try { window.parent.localStorage.getItem('token'); parentAccess='leaked' } catch {}
try { cookie=document.cookie || 'blocked' } catch {}
document.querySelector('#proof').textContent=[self.origin,storage,parentAccess,cookie].join('|');
window.parent.postMessage({type:'fixture-opaque',storage,parentAccess,cookie},'*');
</script></body></html>""",
    ),
    'report.html': ('text/html; charset=utf-8', b'<!doctype html><html><body>ocu-stub report</body></html>'),
    'final.html': ('text/html; charset=utf-8', b'<!doctype html><html><body>ocu-stub final report</body></html>'),
    'diagram.svg': (
        'image/svg+xml',
        b"""<svg xmlns="http://www.w3.org/2000/svg" width="120" height="40">
<text id="proof" y="20">waiting</text><script><![CDATA[
let storage='blocked', parentAccess='blocked', cookie='blocked';
try { localStorage.getItem('token'); storage='leaked' } catch {}
try { window.parent.localStorage.getItem('token'); parentAccess='leaked' } catch {}
try { cookie=document.cookie || 'blocked' } catch {}
document.getElementById('proof').textContent=[self.origin,storage,parentAccess,cookie].join('|');
window.parent.postMessage({type:'fixture-svg',storage,parentAccess,cookie},'*');
]]></script></svg>""",
    ),
    'report.svg': ('image/svg+xml', b'<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"></svg>'),
    'data.xml': ('application/xml', b'<?xml version="1.0"?><root>ocu-stub</root>'),
    'report.xml': ('application/xml', b'<?xml version="1.0"?><root>ocu-stub-report</root>'),
    'plain.xml': ('text/xml; charset=utf-8', b'<?xml version="1.0"?><root>plain-xml</root>'),
    'page.xhtml': (
        'application/xhtml+xml; charset=UTF-8',
        b'<?xml version="1.0"?><html xmlns="http://www.w3.org/1999/xhtml"><body>x</body></html>',
    ),
    'report.xhtml': (
        'application/xhtml+xml; charset=UTF-8',
        b'<?xml version="1.0"?><html xmlns="http://www.w3.org/1999/xhtml"><body>r</body></html>',
    ),
    'blob.bin': ('application/octet-stream', b'\x00\x01\x02\x03'),
    'report.bin': ('application/octet-stream', b'\x00\x01\x02\x03'),
    'sub/report.bin': ('application/octet-stream', b'nested-bin'),
    'sub/space hash#plus+percent%.html': (
        'text/html; charset=utf-8',
        b'<!doctype html><html><body>encoded</body></html>',
    ),
    'sub/report.html': ('text/html; charset=utf-8', b'<!doctype html><html><body>nested</body></html>'),
    'backend-html403.html': ('TEXT/HTML; charset=utf-8', b'upstream error'),
    'diagram.drawio': (
        'application/xml',
        b"""<mxfile>
<diagram id="combined" name="Combined">
<mxGraphModel math="1">
<root>
<mxCell id="0"/>
<mxCell id="1" parent="0"/>
<mxCell id="ordinary" value="Page one" style="whiteSpace=wrap;" vertex="1" parent="1">
<mxGeometry x="40" y="40" width="120" height="60" as="geometry"/>
</mxCell>
<mxCell id="and" value="AND"
style="shape=mxgraph.electrical.logic_gates.and;whiteSpace=wrap;"
vertex="1" parent="1">
<mxGeometry x="200" y="40" width="100" height="60" as="geometry"/>
</mxCell>
<mxCell id="phone" value=""
style="shape=image;image=img/telecommunication/Cellphone_128x128.png;aspect=fixed;"
vertex="1" parent="1">
<mxGeometry x="40" y="140" width="80" height="80" as="geometry"/>
</mxCell>
<mxCell id="math" value="$$E=mc^2$$" style="html=1;" vertex="1" parent="1">
<mxGeometry x="160" y="140" width="120" height="40" as="geometry"/>
</mxCell>
</root>
</mxGraphModel>
</diagram>
</mxfile>""",
    ),
}
STATIC = {
    'preview.js': ('text/javascript; charset=utf-8', b'export const ocuStub = true;\n'),
    'deep/preview.js': ('text/javascript; charset=utf-8', b'export const ocuStubDeep = true;\n'),
}

_LOCK = threading.RLock()
_SEQ = 0
_states: dict[str, str] = {
    'running': 'running',
    'stopped': 'stopped',
    'never_created': 'never_created',
}
_uploads: dict[str, dict[str, tuple[bytes, dict]]] = {}
_OFFICE = OfficeStore(
    lock=_LOCK,
    scenario_of=lambda chat_id: _scenario(chat_id),
    prefix=PREFIX,
    fixture_file=lambda chat_id, name, revision=1: _fixture_file(chat_id, name, revision),
    fixture_outputs=lambda chat_id: _fixture_outputs(chat_id),
    occupied_names=lambda chat_id: (set(FILES) | {'backend403', 'backend409'}).union(
        {entry['path'] for entry in _fixture_outputs(chat_id)['files']}, _uploads.get(chat_id, {})
    ),
    files=FILES,
    uploads=_uploads,
    valid_office=VALID_OFFICE,
    scenario_file=lambda chat_id, name: _scenario_file(chat_id, name, {}),
)

DESCRIBE_RE = re.compile(r'^/internal/describe/([^/]+)$')
LAUNCH_RE = re.compile(r'^/internal/launch/([^/]+)$')
OUTPUTS_RE = re.compile(r'^/api/outputs/([^/]+)$')
ARCHIVE_RE = re.compile(r'^/files/([^/]+)/archive$')
FILES_RE = re.compile(r'^/files/([^/]+)/(.+)$')
PREVIEW_RE = re.compile(r'^/preview/([^/]+)$')
UPLOAD_POST_RE = re.compile(r'^/api/uploads/([^/]+)/(.+)$')
BROWSER_STATUS_RE = re.compile(r'^/browser/([^/]+)/status$')
BROWSER_JSON_VERSION_RE = re.compile(r'^/browser/([^/]+)/json/version$')
BROWSER_JSON_RE = re.compile(r'^/browser/([^/]+)/json$')
TERM_STATUS_RE = re.compile(r'^/terminal/([^/]+)/status$')
HEARTBEAT_RE = re.compile(r'^/terminal/([^/]+)/heartbeat$')
TERM_SESSIONS_RE = re.compile(r'^/terminal/([^/]+)/sessions$')
TERM_PROCESSES_RE = re.compile(r'^/terminal/([^/]+)/processes$')
TERM_ACTION_RE = re.compile(r'^/terminal/([^/]+)/(start-ttyd|stop-ttyd|restart-container|resurrect-container)$')
TERM_KILL_RE = re.compile(r'^/terminal/([^/]+)/processes/([0-9]+)/kill$')
TERM_WS_RE = re.compile(r'^/terminal/([^/]+)/ws$')
BROWSER_WS_RE = re.compile(r'^/browser/([^/]+)/devtools/page/([^/]+)$')
STATIC_RE = re.compile('^' + re.escape(PREFIX) + r'/static/(.+)$') if PREFIX else re.compile(r'^/static/(.+)$')


def _scenario(chat_id: str) -> str | None:
    if not FIXTURE_PATH:
        return None
    return json.loads(Path(FIXTURE_PATH).read_text(encoding='utf-8')).get(chat_id)


def _backend_error(name: str) -> tuple[int, bytes, str, dict] | None:
    if name == 'backend403':
        return 403, b'backend 403', 'text/plain; charset=utf-8', {}
    if name == 'backend409':
        return 409, b'backend 409', 'text/plain; charset=utf-8', {}
    if name == 'backend-html403.html':
        extra = {'Content-Security-Policy': WEAK_CSP, 'X-Content-Type-Options': 'other'}
        return 403, b'upstream error', 'TEXT/HTML; charset=utf-8', extra
    return None


def _scenario_file(chat_id: str, name: str, query: dict) -> tuple[int, bytes, str, dict] | None:
    scenario = _scenario(chat_id)
    mime = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    if scenario in ('deleted_after', 'partial_after') and name == 'report.html':
        return 404, b'not found', 'text/plain; charset=utf-8', {}
    if scenario == 'corrupt' and name == 'corrupt.docx':
        return 200, b'not a ZIP document', mime, _file_headers(name, query)
    if scenario == 'valid' and name == 'valid.docx':
        return 200, VALID_OFFICE.read_bytes(), mime, _file_headers(name, query)
    if scenario is not None and re.fullmatch(r'item-[0-9]{3}\.txt', name):
        return 200, name.encode(), 'text/plain; charset=utf-8', _file_headers(name, query)
    nested = nested_payload(name) if scenario == 'nested' else None
    if nested is not None:
        return 200, nested[0], nested[1], _file_headers(name, query)
    return None


def _fixture_file(chat_id: str, name: str, revision: int = 1) -> dict:
    kind, mime = (
        ('docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
        if name.endswith('.docx')
        else (
            ('drawio', 'application/xml')
            if name.endswith('.drawio')
            else (
                ('html', 'text/html')
                if name.endswith('.html')
                else ('image', 'image/svg+xml')
                if name.endswith('.svg')
                else ('text', 'text/plain')
            )
        )
    )
    file_id = 'fixture-report' if name in ('report.html', 'final.html') else f'fixture-{name}'
    return {
        'file_id': file_id,
        'path': name,
        'name': name,
        'url': f'{PREFIX}/files/{chat_id}/{name}',
        'type': kind,
        'mime': mime,
        'revision': revision,
        'size': 128,
        'mtime_ns': 1,
        'hash': 'fixture',
        'modified': False,
    }


def _state_of(chat_id: str) -> str:
    scenario = _scenario(chat_id)
    with _LOCK:
        state = _states.get(chat_id)
    if scenario is not None:
        return 'running' if state == 'running' else 'stopped' if scenario == 'stopped' else 'running'
    return state or 'never_created'


def _launch(chat_id: str) -> tuple[int, dict]:
    scenario = _scenario(chat_id)
    with _LOCK:
        if scenario is None and _states.get(chat_id, 'never_created') == 'never_created':
            return 409, {'reason': 'never_created'}
        _states[chat_id] = 'running'
    return 200, {'state': 'running'}


def _fixture_outputs(chat_id: str) -> dict:
    scenario = _scenario(chat_id)
    if scenario is None:
        names = ('page.html', 'diagram.svg', 'data.xml', 'blob.bin')
        return {
            'revision': 1,
            'files': [
                {'path': name, 'url': f'{PREFIX}/files/{chat_id}/{name}', 'file_id': f'fixture-{name}', 'revision': 1}
                for name in names
            ],
        }
    revision = 2 if scenario in ('deleted_after', 'renamed', 'partial_after') else 1
    names = {
        'empty': [],
        'valid': ['page.html', 'valid.docx'],
        'corrupt': ['page.html', 'corrupt.docx'],
        'deleted': ['report.html', 'page.html'],
        'deleted_after': ['page.html'],
        'renamed': ['final.html', 'page.html'],
        'partial': ['report.html'] + [f'item-{index:03d}.txt' for index in range(100)],
        'partial_after': [f'item-{index:03d}.txt' for index in range(101)],
        'large': ['page.html'] + [f'item-{index:03d}.txt' for index in range(100)],
        'drawio': ['diagram.drawio'],
        'drawio_embedded': ['diagram.drawio'],
        **{name: ['report.docx'] for name in OFFICE_SCENARIOS - {'office_save_as'}},
        'office_save_as': [],
        'nested': nested_names(),
    }.get(scenario, ['page.html', 'diagram.svg', 'report.html'])
    files = (
        [nested_listing_entry(chat_id, name, PREFIX, revision, _fixture_file) for name in names]
        if scenario == 'nested'
        else [_fixture_file(chat_id, name, revision) for name in names]
    )
    return {
        'chat_id': chat_id,
        'revision': revision,
        'files': files,
        'total': len(names),
        'timestamp': 1,
        'next_cursor': None,
    }


def _outputs(chat_id: str, query: dict | None = None) -> dict:
    body = _fixture_outputs(chat_id)
    with _LOCK:
        uploaded = _uploads.get(chat_id, {})
        body['files'].extend(entry for _, entry in uploaded.values())
        body['revision'] += len(uploaded)
        _OFFICE.overlay_listing(chat_id, body)
    if 'total' in body:
        offset = int((query or {}).get('cursor', ['0'])[0])
        if _scenario(chat_id) == 'partial_after' and offset > 0:
            raise ValueError('fixture later page is inaccessible')
        body['total'] = len(body['files'])
        body['next_cursor'] = str(offset + 100) if offset + 100 < body['total'] else None
        body['files'] = body['files'][offset : offset + 100]
    return body


def _store_upload(chat_id: str, name: str, payload: bytes) -> dict:
    with _LOCK:
        fixture = _fixture_outputs(chat_id)
        uploaded = _uploads.setdefault(chat_id, {})
        occupied = _OFFICE.occupied_names(chat_id)
        path = PurePosixPath(name)
        stored = name
        counter = 2
        while stored in occupied:
            stored = str(path.with_name(f'{path.stem} ({counter}){path.suffix}'))
            counter += 1
        entry = _fixture_file(chat_id, stored, fixture['revision'] + len(uploaded) + 1)
        entry.update(
            file_id=f'upload-{hashlib.sha256(stored.encode()).hexdigest()}',
            url=f'{PREFIX}/files/{chat_id}/{quote(stored)}',
            size=len(payload),
            hash=hashlib.sha256(payload).hexdigest(),
        )
        uploaded[stored] = (payload, entry)
    return {'status': 'success', 'filename': stored, 'size': len(payload), 'md5': hashlib.md5(payload).hexdigest()}


def _listing_etag(body: dict, query: dict) -> str:
    representation = {key: value for key, value in body.items() if key != 'timestamp'}
    representation['limit'] = int(query.get('limit', ['100'])[0])
    digest = hashlib.sha256(json.dumps(representation, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    return f'W/"{digest}"'


def _file_headers(name: str, query: dict) -> dict[str, str]:
    extra: dict[str, str] = {
        'Content-Security-Policy': WEAK_CSP,
        'X-Content-Type-Options': 'other',
    }
    download = query.get('download') == ['1']
    if download:
        extra['Content-Disposition'] = f'attachment; filename="{name.rsplit("/", 1)[-1]}"'
        return extra
    extra['Content-Disposition'] = f'inline; filename="{name.rsplit("/", 1)[-1]}"'
    return extra


@lru_cache(maxsize=1)
def _preview_generator():
    source_path = ASSET_ROOT.parent / 'app.py'
    definition = next(
        node
        for node in ast.parse(source_path.read_text(encoding='utf-8')).body
        if isinstance(node, ast.FunctionDef) and node.name == '_generate_preview_html'
    )
    namespace = {'OCU_PUBLIC_PREFIX': PREFIX, 'json': json, 'Optional': Optional}
    exec(compile(ast.Module(body=[definition], type_ignores=[]), str(source_path), 'exec'), namespace)
    return namespace['_generate_preview_html']


def _preview_html(chat_id: str, embed: str = '') -> tuple[bytes, dict[str, str]]:
    if embed == 'office':
        return office_host_page(chat_id, PREFIX)
    if ASSET_ROOT.is_dir() and FIXTURE_PATH:
        nonce = secrets.token_urlsafe(24) if embed in ('browser', 'terminal') else None
        headers = {'Cache-Control': 'no-cache, no-store, must-revalidate'}
        if nonce:
            headers['Content-Security-Policy'] = (
                "default-src 'none'; "
                f"script-src 'self' 'nonce-{nonce}'; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: blob:; "
                "font-src 'self' data:; "
                "connect-src 'self'; "
                "frame-src 'none'; "
                "base-uri 'none'; "
                "object-src 'none'; "
                "form-action 'none'; "
                "frame-ancestors 'self'"
            )
        return _preview_generator()(
            chat_id, f'{PREFIX}/api/outputs/{chat_id}', f'{PREFIX}/files/{chat_id}', nonce
        ).encode(), headers
    return (
        '<!doctype html><html><head>'
        f'<script type="module" src="{PREFIX}/static/preview.js"></script>'
        '</head><body>'
        f'<div id="ocu-stub-preview" data-chat-id="{chat_id}"'
        f' data-api-url="{PREFIX}/api/outputs/{chat_id}"'
        f' data-files-base="{PREFIX}/files/{chat_id}"'
        f' data-describe-url="/api/v1/ocu/workspaces/{chat_id}"></div>'
        f'<script>fetch("{PREFIX}/terminal/{chat_id}/heartbeat")</script>'
        '</body></html>'
    ).encode(), {'Content-Security-Policy': WEAK_CSP}


def _observe(handler: BaseHTTPRequestHandler, extra: dict | None = None) -> None:
    if not RECORD_PATH:
        return
    global _SEQ
    auth = handler.headers.get('Authorization', '')
    expected = f'Bearer {EXPECTED_TOKEN}' if EXPECTED_TOKEN else ''
    entry = {
        'id': None,
        'record_type': 'arrival',
        'method': handler.command,
        'target': handler.path,
        'identity': {
            'x-user-id': handler.headers.get('X-User-Id', ''),
            'x-user-email': handler.headers.get('X-User-Email', ''),
            'x-chat-id': handler.headers.get('X-Chat-Id', ''),
        },
        'token_ok': bool(expected) and auth == expected,
        'upgrade': handler.headers.get('Upgrade', ''),
    }
    if extra:
        entry.update(extra)
    with _LOCK:
        _SEQ += 1
        entry['id'] = _SEQ
        fd = os.open(RECORD_PATH, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        with os.fdopen(fd, 'a', encoding='utf-8') as stream:
            stream.write(json.dumps(entry) + '\n')


def _masked_ws_frame(stream) -> tuple[int, bytes] | None:
    header = stream.read(2)
    if len(header) != 2:
        return None
    opcode, length = header
    if not length & 0x80:
        return None
    size = length & 0x7F
    if size == 126:
        size = int.from_bytes(stream.read(2), 'big')
    elif size == 127:
        size = int.from_bytes(stream.read(8), 'big')
    if size > 65536:
        return None
    mask = stream.read(4)
    payload = stream.read(size)
    if len(mask) != 4 or len(payload) != size:
        return None
    return opcode & 0x0F, bytes(byte ^ mask[index % 4] for index, byte in enumerate(payload))


class StubHandler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def _ws_without_upgrade(self, _match: re.Match[str], _query: dict) -> None:
        self._not_found()

    def log_message(self, fmt: str, *args) -> None:
        log.info('%s - %s', self.address_string(), fmt % args)

    def _internal(self) -> bool:
        return urlparse(self.path).path.startswith('/internal/')

    def _echo_headers(self) -> None:
        if not self._internal():
            return
        auth = self.headers.get('Authorization')
        if auth is not None:
            self.send_header('X-Echo-Authorization', auth)
        requested = self.headers.get('X-Requested-With')
        if requested is not None:
            self.send_header('X-Echo-X-Requested-With', requested)

    def _write(self, status: int, body: bytes, content_type: str, extra: dict[str, str] | None = None) -> None:
        self.close_connection = True
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Connection', 'close')
        self._echo_headers()
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(body)

    def _json(self, status: int, payload: dict) -> None:
        self._write(status, json.dumps(payload).encode(), 'application/json; charset=utf-8')

    def _ok(self, match: re.Match[str], _query: dict) -> None:
        self._json(200, {'ok': True, 'chat': match.group(1)})

    def _not_found(self) -> None:
        self._write(404, b'not found', 'text/plain; charset=utf-8')

    def _describe(self, match: re.Match[str], _query: dict) -> None:
        if _scenario(match.group(1)) == 'unreachable':
            self.close_connection = True
            return
        state = _state_of(match.group(1))
        views = ['files', 'browser', 'terminal'] if state == 'running' else ['files']
        self._json(200, {'state': state, 'revision': 1, 'views': views})

    def _launch_route(self, match: re.Match[str], _query: dict) -> None:
        self._json(*_launch(match.group(1)))

    def _outputs_route(self, match: re.Match[str], query: dict) -> None:
        try:
            body = _outputs(match.group(1), query)
            etag = _listing_etag(body, query)
            headers = {'ETag': etag, 'Cache-Control': 'no-cache, no-store, must-revalidate'}
            if self.headers.get('If-None-Match') == etag:
                self._write(304, b'', 'application/json; charset=utf-8', headers)
            else:
                self._write(200, json.dumps(body).encode(), 'application/json; charset=utf-8', headers)
        except ValueError:
            self._json(503, {'reason': 'listing_incomplete'})

    def _archive(self, match: re.Match[str], _query: dict) -> None:
        self._json(200, {'chat': match.group(1), 'archive': True})

    def _serve_file(self, match: re.Match[str], query: dict) -> None:
        name = unquote(match.group(2))
        office = _OFFICE.file_bytes(match.group(1), name)
        if office is not None:
            self._write(200, office[0], office[1]['mime'], _file_headers(name, query))
            return
        with _LOCK:
            uploaded = _uploads.get(match.group(1), {}).get(name)
        if uploaded is not None:
            self._write(200, uploaded[0], uploaded[1]['mime'], _file_headers(name, query))
            return
        error = _backend_error(name) or _scenario_file(match.group(1), name, query)
        if error is not None:
            status, body, mime, extra = error
            self._write(status, body, mime, extra) if status != 404 else self._not_found()
            return
        fixture = FILES.get(name)
        if fixture is None:
            self._not_found()
            return
        self._write(200, fixture[1], fixture[0], _file_headers(name, query))

    def _preview(self, match: re.Match[str], query: dict) -> None:
        modes = query.get('embed', [])
        html, headers = _preview_html(match.group(1), modes[0] if len(modes) == 1 else '')
        self._write(200, html, 'text/html; charset=utf-8', headers)

    def _heartbeat(self, match: re.Match[str], _query: dict) -> None:
        self._write(200, b'', 'text/plain; charset=utf-8')

    def _browser_status(self, match: re.Match[str], _query: dict) -> None:
        active = _state_of(match.group(1)) == 'running'
        self._json(
            200,
            {
                'active': active,
                'pages': [{'id': 'stub-page', 'title': 'OCU fixture browser', 'url': 'about:blank'}] if active else [],
            },
        )

    def _browser_pages(self, match: re.Match[str], _query: dict) -> None:
        chat_id = match.group(1)
        self._write(
            200,
            json.dumps(
                [
                    {
                        'id': 'stub-page',
                        'type': 'page',
                        'title': 'OCU fixture browser',
                        'url': 'about:blank',
                        'webSocketDebuggerUrl': f'{PREFIX}/browser/{chat_id}/devtools/page/stub-page',
                    }
                ]
            ).encode(),
            'application/json; charset=utf-8',
        )

    def _terminal_status(self, match: re.Match[str], _query: dict) -> None:
        self._json(200, {'active': _state_of(match.group(1)) == 'running'})

    def _terminal_sessions(self, _match: re.Match[str], _query: dict) -> None:
        self._json(200, {'sessions': []})

    def _terminal_processes(self, _match: re.Match[str], _query: dict) -> None:
        self._json(200, {'processes': []})

    def _terminal_action(self, match: re.Match[str], _query: dict) -> None:
        self._json(200, {'success': True, 'chat': match.group(1)})

    def _upload_post(self, match: re.Match[str], _query: dict) -> None:
        name = unquote(match.group(2))
        if any(part in ('', '.', '..') for part in name.split('/')) or re.search(r'[\x00-\x1f\x7f]', name):
            self._json(400, {'detail': 'Invalid filename'})
            return
        content_type = self.headers.get('Content-Type', '')
        message = BytesParser(policy=policy.default).parsebytes(
            f'Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n'.encode() + self._request_body
        )
        parts = [
            part
            for part in message.iter_parts()
            if part.get_content_disposition() == 'form-data'
            and part.get_param('name', header='content-disposition') == 'file'
            and part.get_filename() is not None
            and not part.is_multipart()
        ]
        if (
            message.get_content_type() != 'multipart/form-data'
            or any(part.defects for part in message.walk())
            or len(parts) != 1
        ):
            self._json(422, {'detail': 'Expected multipart file field'})
            return
        self._json(200, _store_upload(match.group(1), name, parts[0].get_payload(decode=True)))

    def _serve_static(self, match: re.Match[str], _query: dict) -> None:
        if ASSET_ROOT.is_dir() and FIXTURE_PATH:
            target = ASSET_ROOT / unquote(match.group(1))
            if target.is_file() and target.resolve().is_relative_to(ASSET_ROOT.resolve()):
                mime = mimetypes.guess_type(target.name)[0] or 'application/octet-stream'
                self._write(200, target.read_bytes(), mime)
                return
        fixture = STATIC.get(unquote(match.group(1)))
        if fixture is None:
            self._not_found()
            return
        content_type, body = fixture
        self._write(200, body, content_type)

    def _websocket(self, match: re.Match[str], _query: dict) -> None:
        key = self.headers.get('Sec-WebSocket-Key', '')
        self.close_connection = True
        digest = base64.b64encode(hashlib.sha1((key + WS_GUID).encode('ascii')).digest()).decode('ascii')
        self.send_response(101, 'Switching Protocols')
        self.send_header('Upgrade', 'websocket')
        self.send_header('Connection', 'Upgrade')
        self.send_header('Sec-WebSocket-Accept', digest)
        requested_protocols = self.headers.get('Sec-WebSocket-Protocol', '').split(',')
        if TERM_WS_RE.match(urlparse(self.path).path) and 'tty' in requested_protocols:
            self.send_header('Sec-WebSocket-Protocol', 'tty')
        self.end_headers()
        self.wfile.write(
            b'\x81\x14{"id":0,"result":{}}' if BROWSER_WS_RE.match(urlparse(self.path).path) else b'\x81\x02ok'
        )
        self.wfile.flush()
        _observe(
            self,
            {
                'record_type': 'ws_lifecycle',
                'ws_event': 'open',
                'request_target': self.path,
                'target': f'/ws-events{self.path}',
            },
        )
        try:
            while True:
                frame = _masked_ws_frame(self.rfile)
                if frame is None:
                    return
                kind, decoded = frame
                if kind == 8:
                    self.wfile.write(b'\x88\x00')
                    self.wfile.flush()
                    return
                if kind == 9:
                    kind = 10
                elif kind not in (1, 2):
                    continue
                # Preserve proxy smoke's echo, but keep real client sockets alive until teardown.
                prefix = bytes((0x80 | kind,))
                length = bytes((len(decoded),)) if len(decoded) < 126 else b'\x7e' + len(decoded).to_bytes(2, 'big')
                self.wfile.write(prefix + length + decoded)
                self.wfile.flush()
        except OSError:
            return
        finally:
            _observe(
                self,
                {
                    'record_type': 'ws_lifecycle',
                    'ws_event': 'close',
                    'request_target': self.path,
                    'target': f'/ws-events{self.path}',
                },
            )

    def _read_body(self) -> bytes:
        length = int(self.headers.get('Content-Length', '0') or '0')
        return self.rfile.read(length) if length else b''

    def _serve_http(self, method: str) -> None:
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        if _OFFICE.dispatch(self, method, parsed.path, getattr(self, '_request_body', b'')):
            return
        for verb, regex, fn in _ROUTES:
            if verb != method:
                continue
            match = regex.match(parsed.path)
            if match:
                fn(self, match, query)
                return
        self._not_found()

    def _dispatch(self, method: str) -> None:
        extra: dict = {}
        self._request_body = b''
        if self.headers.get('Content-Length'):
            payload = self._read_body()
            self._request_body = payload
            extra['body_sha256'] = hashlib.sha256(payload).hexdigest()
            extra['body_length'] = len(payload)
        _observe(self, extra or None)
        try:
            if self.headers.get('Upgrade', '').lower() == 'websocket':
                parsed = urlparse(self.path)
                for regex in (TERM_WS_RE, BROWSER_WS_RE):
                    match = regex.match(parsed.path)
                    if match:
                        self._websocket(match, {})
                        return
                self._not_found()
                return
            self._serve_http(method)
        except Exception:
            log.exception('stub handler failed for %s %s', method, self.path)
            if not self.wfile.closed:
                try:
                    self._write(500, b'stub error', 'text/plain; charset=utf-8')
                except Exception:
                    pass

    def do_GET(self) -> None:
        self._dispatch('GET')

    def do_HEAD(self) -> None:
        self._dispatch('HEAD')

    def do_POST(self) -> None:
        self._dispatch(self.command)

    do_PUT = do_PATCH = do_DELETE = do_OPTIONS = do_POST


_ROUTES = (
    ('GET', DESCRIBE_RE, StubHandler._describe),
    ('POST', LAUNCH_RE, StubHandler._launch_route),
    ('GET', OUTPUTS_RE, StubHandler._outputs_route),
    ('GET', ARCHIVE_RE, StubHandler._archive),
    ('GET', FILES_RE, StubHandler._serve_file),
    ('GET', PREVIEW_RE, StubHandler._preview),
    ('POST', UPLOAD_POST_RE, StubHandler._upload_post),
    ('GET', BROWSER_JSON_VERSION_RE, StubHandler._ok),
    ('GET', BROWSER_JSON_RE, StubHandler._browser_pages),
    ('GET', BROWSER_STATUS_RE, StubHandler._browser_status),
    ('GET', TERM_STATUS_RE, StubHandler._terminal_status),
    ('GET', HEARTBEAT_RE, StubHandler._heartbeat),
    ('GET', TERM_SESSIONS_RE, StubHandler._terminal_sessions),
    ('GET', TERM_PROCESSES_RE, StubHandler._terminal_processes),
    ('POST', TERM_ACTION_RE, StubHandler._terminal_action),
    ('POST', TERM_KILL_RE, StubHandler._ok),
    ('GET', TERM_WS_RE, StubHandler._ws_without_upgrade),
    ('GET', BROWSER_WS_RE, StubHandler._ws_without_upgrade),
    ('GET', STATIC_RE, StubHandler._serve_static),
    ('HEAD', STATIC_RE, StubHandler._serve_static),
)


class StubServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def main() -> int:
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    raw_port = os.environ.get('OCU_STUB_PORT', '8090')
    try:
        port = int(raw_port)
    except ValueError:
        log.error('OCU_STUB_PORT must be an integer, got %r', raw_port)
        return 2
    server = StubServer(('127.0.0.1', port), StubHandler)
    log.info('ocu-stub listening on http://127.0.0.1:%s', server.server_address[1])
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
