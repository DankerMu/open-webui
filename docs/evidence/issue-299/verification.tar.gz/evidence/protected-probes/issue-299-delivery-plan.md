# #299 execution contract

Mode: Construction, Critical; verifier construction also needs known-good/known-bad judge qualification. Approved direction is shared resource-grants D6/group5, not a new architecture choice. Scope: exact reviewed OCU pin plus WebUI native smoke/stub/Hurl ownership. No OCU source, production auth, frontend, CI/dependency changes, real-editor172 or browser300 acceptance.

## Existing owners and baseline

Control base470168e2a542d6e46b4a01092e26fa6425edeaa7; new branch omp/issue-299-real-auth-grant-smoke. Reviewed OCU merge276e00aceddb332974a0390e01d69d9430065816 contains295-dependent gateway,296HEAD and297preview; pin is currentlya53731df95a3b92acb2dcb5980f969b4f8b4ee52. Existing8PINNED_FILES cover the gateway; no new pinned filename needed.

Fresh old-pin make smoke-proxy passed all6Hurl files, including Office7owner/24auth-guard/5unlisted. Parent devservices stopped. Source-bound native proof298:32methods plus qualification, reviewed production bytes. Direct WebUI feasibility (not gateway acceptance) reused create_token with5second expiry through canonical dev-env environment: freshissuer302/verifier200, waited3.9855s, expiredissuer401/verifier403, ownedcleanup+sentinel passed. No production clock/globalTTL change; no dotenv loading in that probe.

Read maps /tmp/issue-299-evidence/{lifecycle-scout,matrix-scout,research-adjudication}.json. Correct scout mistakes: sub/archive is ordinary; client X-Ocu-Grant cannot select authority on a valid grant URL; http.client HEAD drops bytes; historic229 evidence is not edited; private Hurl requests legitimately contain credentials and are not browser-response leaks.

## Files and shared contracts

- scripts/smoke-proxy.py (782lines): keep lifecycle thin; pin materialization, owner provisioning, cleanup/sentinel semantics preserved.
- scripts/smoke_proxy_support.py: one Hurl argv/redaction/report/private-variable owner. A mechanical extraction of the existing Office private-variable block may be shared; no copied second implementation or changed229behavior.
- scripts/smoke_proxy_office.py and its pairedtest: only necessary mechanical shared-helper callsite change; preserve assertions and effective variable precedence/failure/interruption cleanup.
- scripts/ocu-stub.py (800lines): ordinary-fileHEAD, deterministic resource responses and names-only forwarded-credential observations. If space requires extraction, move one coherent existing owner, no formatting tricks, duplicate implementation or unrelated refactor. New source module requires paired behavioral tests.
- smoke/proxy/*.hurl: preserve final legacy assertions while moving non-download file reads through grants; per-request denial and arrival attribution, not an aggregate count-only judge.
- constraints.yaml: onlyocu_checkout.sha changes; no gate thresholds or unrelated config.
- scripts/verify-ui-ocu.py: narrow required reverse caller update only. BrowserHarness inheritsSmoke.render and already reserves4ports; allocate its fifth Office listener alongside them. No lazy newport collision, UIcomponent or browseroracle edits. Parent exercises renderer compatibility without claiming300.
- New resource-smoke helper plus pairedtests is permitted when it gives the grant matrix one coherent owner and keeps800-line limits. Reuse existing HTTP/Hurl/cleanup helpers, not a parallel harness.

## Phases

1. Parent expanded group5 fixture review+strict; checkpoint. Single implementer no-check brief, parent owns all execution.
2. Tests-only vertical tracer: add a canonical real-owner encoded-duplicate query issuer302 expectation to existing Hurl ownership, retaining all old file assertions. Parent runs make smoke-proxy againstoldpin and observesactual200-versus302 RED. No pin or production/harness implementation in this stage.
3. Atomic cutover: reviewed pin, required Office inputs/ports at both renderer callers, explicit no-follow issuance/following, stub ordinaryHEAD and names-only arrival metadata, migrated existingfinalfile assertions. Add grant matrix incrementally, keeping oldauth/mutation/static/upload/WS/Office coverage. No newproductionauth or signing implementation.
4. Credential/expiry boundary: use existing create_token helper in backend interpreter with canonical scripts/dev-env.sh signing environment; inherit explicit matchingWEBUI_SECRET_KEY whenprovided, setPYTHON_DOTENV_DISABLED=1 and harness-onlyDATA_DIR/FRONTEND_BUILD_DIR, whitelist childenv. Backend helper import may initialize normal harness DB/config; no DB outside.run/data and no secret-store reads. Token/exp only on captured private stdout, never argv/publiclogs. Prove realissuer admission before waitingpastactualexp. Newmodule pairedtests focus real parser/containment/ownership/error boundaries, not wiring/mock echoes.
5. Parent verification: make smoke-proxy, owning backendharness tests, scopedlint/anti-drift/format/docs/strict as dictatedbyscope. No fullsuite default. Raw-wireHEAD and exactquery/inline/CSP+single-nosniff are required. Qualify wrongtarget/auth admission, omittedno-contact check, credentialecho, failure-output/argv leakage, earlyexpiry/skipwait, brokenisolation; restorecandidateandfinalsmoke. Observecleanupandprivatefile/process retirement. Runtime publicreports nevercontaincredentialvalues.
6. Durable source-bound bundle, commit/PR, three-seat review, max2fixpasses. Approvedexact-head localWebUIstatus; beforemergeclosingrefs exactly{WebUI#299}. Sharedfixture/decisionremainactiveuntil300. Rollback matchedpin+expectations atomically, no shim.

## Decisive boundaries

- Real owner canonical302 with relative same-chat/encodedpath/rawquery Location, emptybody,no-store/no-referrer; register everyobservedgrant before any failure diagnostic or follow request. Never urllibauto-follow withCookie. Exact download=1&%64ownload=0 must complete realissuer/newgateway/OCUstub, rawqueryexact, inline, exactsandbox andsinglenosniff.
- Raw socket HEAD for canonical302 andfinalgrant; compare GETmetadata andobserveemptywirebody. StubfileHEAD sharesGETresponseowner; archiveHEADstilldenied.
- Each grantarrival has correctinternal credential/currentidentity/ordinarytarget/query; presenceflags proveCookie/grant/auth-mode/resourceheaders/Referer absent withoutrecordingvalues. Forged holdercredentials cannotselectauthority; sessionJWT-as-routecredential andgrant-as-WebUIsession refuse.
- Everydenial has its ownzeroOCUarrivalwindow: anonymous401, foreign404, tamper/wrongchat/expiry404, exactarchive/invalidroute/unsupportedmethod/download404. Do notinventordinaryfilenameblacklists. Before-verifierdownloadguard relies additionallyon298nativezeroauthproof boundtoexactpinbytes; do notinventrealverifiertelemetry.
- CORSonlyvalidatedexactOrigin:null; nocredentials/wildcard/SetCookie; cache/referrer andfinalMIMEpolicy retained includingerrors. Downloadsremaincanonicalsessionpath.
- Privatevars/reportrequestmetadata maycarrycredentials; browserresponsefields/bodies mustnot exceptintentional successfulissuerLocation. All publicfailure paths, including http_raw transport exceptions and partialHurlreports, mustredactrawgrantURLs/knowncanaries withoutsuppressingnonzero failure.
- ExistingOffice229privatevars and76best-effortexactownedcleanup remain. No newcleanupframework, no repair of inherited294interruptiongap. Inheriteddev-envdotenvpolicy observation is separateissue-scribe work, not a broader299fix.

Open design decisions: none in authority/acceptance. Implementer chooses minimal coherent helper extraction under existing size/canonicality constraints; parent rejects duplicated transport/judges or unqualified evidence shortcuts.
