"""Parent-owned execution witness; credentials stay in its private output only."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import logging
import os
import re
import secrets
import subprocess
import sys
import socket
import sqlite3
import time
import tempfile
from unittest.mock import patch

ROOT = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
EXPECTED_PIN = '276e00aceddb332974a0390e01d69d9430065816'
sys.path.insert(0, str(ROOT / 'scripts'))
import smoke_proxy_support as support

parser = argparse.ArgumentParser()
parser.add_argument('--mode', choices=['normal', 'echo', 'forwarded-cookie', 'nosniff', 'argv', 'denial-contact', 'transport', 'fresh-session', 'expiry-wait'], default='normal')
parser.add_argument('--report', type=Path, required=True)
parser.add_argument('--private-root', type=Path, required=True)
args = parser.parse_args()
os.umask(0o077)
args.private_root.mkdir(mode=0o700, parents=True, exist_ok=True)
private = Path(tempfile.mkdtemp(prefix='witness-', dir=args.private_root)).resolve()
spec = importlib.util.spec_from_file_location('protected_resource_smoke', ROOT / 'scripts/smoke-proxy.py')
smoke_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke_module)
original_run = subprocess.run
canaries = set()
argv_records = []
vars_records = []
source_records = []
mode_applied = False
native_validated = False
process_ids = []
cleanup_world = {}
fault_observations = {}
TOKEN_PATTERN = re.compile(r'(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{24,}(?:\.[A-Za-z0-9_-]{24,}){1,2}(?![A-Za-z0-9_-])')
GRANT_PATTERN = re.compile(r'/ocu/f/([^/\s\"\x27?#]+)')


def harvest(text):
    canaries.update(TOKEN_PATTERN.findall(text))
    canaries.update(value for value in GRANT_PATTERN.findall(text) if len(value) >= 24)


def current_secrets(smoke):
    values = [*getattr(smoke, 'secrets', []), getattr(smoke, 'token', ''),
              os.environ.get('WEBUI_SECRET_KEY', '')]
    canaries.update(value for value in values if isinstance(value, str) and len(value) >= 8)
    return canaries


def guard_argv(command, values):
    if any(value in str(argument) for value in values for argument in command):
        raise support.Fail('private credential appeared in child arguments')


def once(text, old, new):
    if text.count(old) != 1:
        raise support.Fail('qualification configuration anchor differs')
    return text.replace(old, new, 1)


class WitnessSmoke(smoke_module.Smoke):
    def stage_copy(self, checkout):
        destination = super().stage_copy(checkout)
        if self.pin_sha != EXPECTED_PIN:
            raise support.Fail('real-auth qualification pin differs from reviewed source')
        for relative in smoke_module.PINNED_FILES:
            expected = original_run(['git', '-C', str(checkout), 'show', EXPECTED_PIN + ':' + relative],
                                    capture_output=True, check=True).stdout
            actual = destination / relative
            if actual.is_symlink() or actual.read_bytes() != expected:
                raise support.Fail('staged source differs from reviewed git blob')
            source_records.append({'path': relative, 'sha256': hashlib.sha256(expected).hexdigest()})
        return destination

    def render(self, nginx):
        global mode_applied, native_validated
        super().render(nginx)
        if args.mode not in {'forwarded-cookie', 'nosniff'}:
            return
        config = self.stage / 'deploy/proxy/nginx.conf'
        text = config.read_text()
        start = text.index('        location ~ ^/ocu/f/')
        end = text.find('        location ', start + 1)
        if end < 0:
            raise support.Fail('grant location boundary differs')
        block = text[start:end]
        if args.mode == 'forwarded-cookie':
            block = once(block, '            proxy_pass_request_headers off;',
                         '            proxy_pass_request_headers off;\n            proxy_set_header Cookie $http_cookie;')
        else:
            block = once(block, '            add_header X-Content-Type-Options $ocu_nosniff always;',
                         '            add_header X-Content-Type-Options $ocu_qualified_nosniff always;')
        text = text[:start] + block + text[end:]
        if args.mode == 'nosniff':
            text = once(text, '    map $ocu_force_isolation $ocu_nosniff {',
                        '    map $args $ocu_qualified_nosniff {\n'
                        '        default $ocu_nosniff;\n'
                        '        "~^download=1&%64ownload=0$" $upstream_http_x_content_type_options;\n'
                        '    }\n    map $ocu_force_isolation $ocu_nosniff {')
        config.write_text(text)
        checked = original_run([nginx, '-t', '-c', str(config)], capture_output=True)
        if checked.returncode:
            (private / 'validation.stderr').write_bytes(checked.stderr)
            raise support.Fail('qualification configuration is not valid nginx')
        native_validated = True
        mode_applied = True

    def start_owned(self, argv, env, ready, log_path=None, timeout=8.0):
        global mode_applied
        if args.mode == 'echo' and any(str(value).endswith('/scripts/ocu-stub.py') for value in argv):
            argv = [str(value) if not str(value).endswith('/scripts/ocu-stub.py')
                    else '/tmp/issue-299-stub-echo.py' for value in argv]
            mode_applied = True
        guard_argv(argv, current_secrets(self))
        pid = super().start_owned(argv, env, ready, log_path, timeout)
        process_ids.append(pid)
        if any(str(value).endswith('/scripts/proxy-dev.sh') for value in argv) and env.get('OCU_CHECKOUT') == str(self.stage):
            self.primary_proxy_pid = pid
        return pid

    def cleanup_data(self):
        rows = {'user': [self.created[k] for k in ('owner', 'foreign') if k in self.created],
                'chat': [self.created[k] for k in ('chat', 'foreign_chat', 'office_chat') if k in self.created]}
        super().cleanup_data()
        with sqlite3.connect(f'file:{ROOT}/.run/data/webui.db?mode=ro', uri=True) as db:
            cleanup_world['owned_rows_absent'] = all(
                db.execute(f'SELECT COUNT(*) FROM "{table}" WHERE id=?', (key,)).fetchone()[0] == 0
                for table, keys in rows.items() for key in keys)
            cleanup_world['sentinel_preserved'] = bool(self.sentinel_id and db.execute(
                'SELECT COUNT(*) FROM user WHERE id=?', (self.sentinel_id,)).fetchone()[0] == 1)
        cleanup_world['owned_row_count'] = sum(map(len, rows.values()))


smoke = WitnessSmoke()


def witnessed_run(command, *positional, **options):
    global mode_applied
    command = list(command) if isinstance(command, (list, tuple)) else [command]
    is_hurl = bool(command) and Path(str(command[0])).name == 'hurl'
    if is_hurl:
        for index, value in enumerate(command):
            if value != '--variables-file':
                continue
            path = Path(command[index + 1])
            if path.is_symlink() or path.stat().st_mode & 0o777 != 0o600:
                raise support.Fail('Hurl variables file is not private')
            if not path.resolve().is_relative_to(smoke.scratch.resolve()):
                raise support.Fail('Hurl variables file escaped owned scratch')
            harvest(path.read_text())
            vars_records.append({'path': str(path), 'mode': '0o600'})
        if args.mode == 'argv' and not mode_applied:
            attempted = command + ['--variable', 'private_probe=' + smoke.owner_jwt]
            mode_applied = True
            guard_argv(attempted, current_secrets(smoke))
            raise support.Fail('unsafe-argument oracle failed to reject its counterexample')
    guard_argv(command, current_secrets(smoke))
    if is_hurl:
        argv_records.append(command)
    result = original_run(command, *positional, **options)
    if is_hurl:
        harvest(result.stdout or '')
        harvest(result.stderr or '')
        for index, value in enumerate(command):
            if value == '--report-json':
                report = Path(command[index + 1])
                if report.exists():
                    for path in report.rglob('*'):
                        if path.is_file():
                            harvest(path.read_bytes().decode('utf-8', errors='replace'))
    return result

resources = sys.modules['smoke_proxy_resources']
original_request = resources.ResourceJudge.request
original_mint = resources.mint_short_session
original_sleep = time.sleep


def qualified_request(judge, method, target, **options):
    global mode_applied
    if args.mode == 'transport' and not mode_applied and target.startswith('/ocu/f/'):
        support.kill_tree(judge.smoke.primary_proxy_pid)
        mode_applied = True
    if args.mode == 'denial-contact' and not mode_applied and method == 'GET' and options.get('expected') == 404 and options.get('upstream') is None:
        original_http = resources.http_raw
        def injected_http(*a, **kw):
            global mode_applied
            s = judge.smoke
            injected = original_http('127.0.0.1', s.stub_port, 'GET', f'/files/{s.chat_id}/page.html',
                headers={'Authorization': 'Bearer ' + s.token, 'X-User-Id': s.owner_id,
                         'X-User-Email': s.owner_email, 'X-Chat-Id': s.chat_id})
            result = original_http(*a, **kw)
            fault_observations.update(injected_status=injected[0], original_denial_status=result[0])
            mode_applied = True
            return result
        with patch.object(resources, 'http_raw', injected_http):
            return original_request(judge, method, target, **options)
    return original_request(judge, method, target, **options)


def qualified_mint(s):
    global mode_applied
    token, expiry = original_mint(s)
    if args.mode == 'fresh-session':
        parts = token.split('.')
        parts[2] = ('A' if parts[2][0] != 'A' else 'B') + parts[2][1:]
        token = '.'.join(parts)
        s.secrets.append(token)
        mode_applied = True
    return token, expiry


def qualified_sleep(seconds):
    global mode_applied
    frame = sys._getframe(1)
    if args.mode == 'expiry-wait' and frame.f_code is resources.ResourceJudge.expiry.__code__:
        judge = frame.f_locals['self']
        status, _, _ = original_request(judge, 'GET', frame.f_locals['location'],
            upstream=f'/files/{judge.smoke.chat_id}/page.html')
        fault_observations['still_valid_resource_status'] = status
        mode_applied = True
        return
    return original_sleep(seconds)


logging.basicConfig(level=logging.INFO, format='%(message)s')
with patch.object(subprocess, 'run', witnessed_run), patch.object(resources.ResourceJudge, 'request', qualified_request), patch.object(resources, 'mint_short_session', qualified_mint), patch.object(time, 'sleep', qualified_sleep):
    code = support.run_owned_lifecycle(smoke, logging.getLogger('protected-real-auth-smoke'))
current_secrets(smoke)
(private / 'credentials.json').write_text(json.dumps(sorted(canaries)) + '\n')
(private / 'argv.json').write_text(json.dumps(argv_records, indent=2) + '\n')
(private / 'vars.json').write_text(json.dumps(vars_records, indent=2) + '\n')
def retired(pid):
    try:
        os.killpg(pid, 0)
    except ProcessLookupError:
        return True
    return False


def port_closed(port):
    with socket.socket() as sock:
        sock.settimeout(1)
        return sock.connect_ex(('127.0.0.1', port)) != 0


cleanup_world['owned_process_groups_absent'] = all(retired(pid) for pid in process_ids)
cleanup_world['owned_ports_closed'] = all(port_closed(port) for port in (smoke.stub_port, smoke.proxy_port, smoke.office_port) if port)
public = {'mode': args.mode, 'exit': code, 'mode_applied': mode_applied,
          'native_mutation_validated': native_validated,
          'source_pin': smoke.pin_sha, 'source_files': source_records,
          'hurl_invocations': len(argv_records), 'private_vars_observed': len(vars_records),
          'private_vars_removed': all(not Path(row['path']).exists() for row in vars_records),
          'scratch_removed': smoke.scratch is None or not smoke.scratch.exists(),
          'owned_process_list_empty': not smoke.owned, 'private_work': str(private),
          'cleanup_world': cleanup_world, 'fault_observations': fault_observations}
args.report.write_text(json.dumps(public, indent=2) + '\n')
print(json.dumps(public))
raise SystemExit(code)
