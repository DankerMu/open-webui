from pathlib import Path
import subprocess
import json
import os
import hashlib
import time

web = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
ocu = Path('/Users/danker/Documents/31308/open-computer-use')
stage299 = Path('/tmp/issue-299-evidence')
delivery299 = Path('/tmp/issue-299-delivery')
stage299.mkdir(exist_ok=True)
delivery299.mkdir(exist_ok=True)
nodebin = '/Users/danker/.nvm/versions/node/v22.23.2/bin'
env299 = {'PATH': f'/Users/danker/.local/bin:{web}/.venv/bin:{nodebin}:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin', 'HOME':str(Path.home()), 'LANG':'C.UTF-8', 'NO_PROXY':'127.0.0.1,localhost', 'PYTHONDONTWRITEBYTECODE':'1', 'FRONTEND_BUILD_DIR':str(web/'.run/frontend-build'), 'PYTHONPATH':str(web/'backend'), 'OCU_CHECKOUT':str(ocu)}
env299['PYTHON_DOTENV_DISABLED'] = '1'
def capture299(name, args, cwd=web, expected=0, timeout=360, extra_env=None):
    target=stage299/f'{name}.json'
    assert not target.exists(), target
    start=time.monotonic()
    result=subprocess.run(args,cwd=cwd,env=env299|(extra_env or {}),capture_output=True,text=True,timeout=timeout)
    target.write_text(json.dumps({'command':args,'cwd':str(cwd),'exit':result.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':result.stdout,'stderr':result.stderr},indent=2)+'\n')
    print(name,'exit',result.returncode,(result.stdout+result.stderr)[-4000:])
    assert result.returncode==expected
    return result
