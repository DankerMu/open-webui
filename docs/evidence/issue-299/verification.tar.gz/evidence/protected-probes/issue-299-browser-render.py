"""Parent probe: actual BrowserHarness allocation/staging/rendering, not browser acceptance."""
import importlib.util
import json
import os
from pathlib import Path
import socket
import sys
ROOT = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
import time
sys.path.insert(0, str(ROOT / 'scripts'))
from smoke_proxy_support import http_raw, wait_http
spec = importlib.util.spec_from_file_location('browser_render_probe', ROOT / 'scripts/verify-ui-ocu.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
class RenderComplete(Exception):
    pass
class Probe(module.BrowserHarness):
    def render(self, nginx):
        super().render(nginx)
        ports = [self.stub_port, self.backend_port, self.frontend_port, self.proxy_port, self.office_port]
        assert len(set(ports)) == 5
        reservations = []
        try:
            for port in ports[:3]:
                sock = socket.socket()
                sock.bind(('127.0.0.1', port))
                sock.listen()
                reservations.append(sock)
            pid = self.start_owned(['bash', str(ROOT / 'scripts/proxy-dev.sh')],
                {'PATH': os.environ['PATH'], 'HOME': os.environ['HOME'], 'OCU_CHECKOUT': str(self.stage)}, None)
            deadline = time.monotonic() + 8
            while True:
                try:
                    with socket.create_connection(('127.0.0.1', self.proxy_port), timeout=0.2):
                        break
                except OSError:
                    if time.monotonic() >= deadline:
                        raise
                    time.sleep(0.05)
            public_status, _, _ = http_raw('127.0.0.1', self.proxy_port, 'GET', '/ocu/internal/parent-probe')
            assert public_status == 404, public_status
            status, _, _ = http_raw('127.0.0.1', self.office_port, 'GET', '/_ocu_session_auth')
            assert status == 404, status
            result.update(distinct_ports=5, occupied_service_ports=3, public_internal_denial=404,
                          office_listener_internal_denial=404, source_pin=self.pin_sha)
        finally:
            for sock in reservations:
                sock.close()
        raise RenderComplete
result = {}
probe = Probe()
try:
    try:
        probe.run_stack()
    except RenderComplete:
        pass
    else:
        raise AssertionError('renderer boundary was not exercised')
finally:
    probe.cleanup_data()
    probe.cleanup_procs()
    probe.assert_sentinel()
    if probe.scratch:
        import shutil
        shutil.rmtree(probe.scratch)
result.update(owned_data_removed=not probe.data_dir.exists(), scratch_removed=not probe.scratch.exists())
print(json.dumps(result))
