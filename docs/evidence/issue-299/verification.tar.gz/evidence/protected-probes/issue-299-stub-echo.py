"""Parent-only real HTTP echo fault for the exact encoded-duplicate grant resource."""
from pathlib import Path
import runpy
import sys

root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
sys.path.insert(0, str(root / 'scripts'))
stub = runpy.run_path(str(root / 'scripts/ocu-stub.py'))
handler = stub['StubHandler']
original = handler._echo_headers


def echo(self):
    original(self)
    if self.path.startswith('/files/') and self.path.endswith('/page.html?download=1&%64ownload=0'):
        self.send_header('X-Parent-Credential-Echo', self.headers.get('Authorization', ''))


handler._echo_headers = echo
raise SystemExit(stub['main']())
