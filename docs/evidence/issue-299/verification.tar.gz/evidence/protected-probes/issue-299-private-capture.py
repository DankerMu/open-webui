from pathlib import Path
import json
import os
import re
import subprocess
import tempfile
import time

_PRIVATE_ROOT_299 = Path('/tmp/issue-299-private')
_PATTERNS_299 = {
    'jwt_or_grant': re.compile(r'(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{24,}(?:\.[A-Za-z0-9_-]{24,}){1,2}(?![A-Za-z0-9_-])'),
    'capability_url': re.compile(r'(/ocu/f/)[^/\s\"\x27?#]{24,}'),
    'internal_canary': re.compile(r'Tok![0-9a-f]{24}#\$%'),
    'password_canary': re.compile(r'Proxy-[0-9a-f]{16}!'),
}


def _private_write299(path, content):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as stream:
        stream.write(content)


def capture_private299(name, command, *, cwd, env, expected=0, timeout=450, extra_secrets=()):
    target = Path('/tmp/issue-299-evidence') / (name + '.json')
    assert not target.exists(), target
    if _PRIVATE_ROOT_299.is_symlink():
        raise RuntimeError('Private capture root cannot be a symlink')
    _PRIVATE_ROOT_299.mkdir(mode=0o700, exist_ok=True)
    if _PRIVATE_ROOT_299.stat().st_mode & 0o077:
        raise RuntimeError('Private capture root must be owner-only')
    work = Path(tempfile.mkdtemp(prefix='capture-', dir=_PRIVATE_ROOT_299)).resolve()
    start = time.monotonic()
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
    _private_write299(work / 'stdout', result.stdout)
    _private_write299(work / 'stderr', result.stderr)
    values = {value for value in extra_secrets if value}
    witness_canaries = False
    if '--report' in command:
        report_path = Path(command[command.index('--report') + 1])
        if report_path.is_file():
            witness = json.loads(report_path.read_text())
            witness_work = witness.get('private_work')
            if witness_work:
                secret_path = Path(witness_work).resolve() / 'credentials.json'
                if secret_path.resolve().is_relative_to(_PRIVATE_ROOT_299.resolve()) and secret_path.is_file():
                    values.update(value for value in json.loads(secret_path.read_text()) if len(value) >= 8)
                    witness_canaries = True
    raw = result.stdout + result.stderr
    findings = {name: len(pattern.findall(raw)) for name, pattern in _PATTERNS_299.items()}
    findings['known_values'] = sum(value in raw for value in values)
    def sanitize(text):
        for value in sorted(values, key=len, reverse=True):
            text = text.replace(value, '<redacted-private-value>')
        for pattern in _PATTERNS_299.values():
            text = pattern.sub('<redacted-private-pattern>', text)
        return text
    payload = {'command': command, 'cwd': str(cwd), 'exit': result.returncode,
               'elapsed_seconds': time.monotonic() - start,
               'stdout': sanitize(result.stdout), 'stderr': sanitize(result.stderr),
               'public_credential_findings': findings, 'witness_canaries_checked': witness_canaries,
               'private_capture': str(work)}
    target.write_text(json.dumps(payload, indent=2) + '\n')
    print(name, 'exit', result.returncode, 'public credential findings', findings,
          (payload['stdout'] + payload['stderr'])[-4500:])
    assert result.returncode == expected, f'{name}: unexpected command exit; private raw output retained'
    assert not any(findings.values()), f'{name}: credential found in public output; see redacted evidence'
    return payload
