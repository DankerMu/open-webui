"""Parent-owned feasibility check; direct WebUI only, not the new gateway acceptance."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import subprocess
import sys
import time

ROOT = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
sys.path.insert(0, str(ROOT / 'scripts'))
from smoke_proxy_support import http_raw

parser = argparse.ArgumentParser()
parser.add_argument('--report', type=Path, required=True)
args = parser.parse_args()
spec = importlib.util.spec_from_file_location('owned_smoke_session_probe', ROOT / 'scripts/smoke-proxy.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
smoke = module.Smoke()
report = {'scope': 'Direct real issuer/verifier short-session feasibility; not group5 gateway proof'}
code = ('import json,sys,jwt; from datetime import timedelta; '
        'from open_webui.utils.auth import create_token; '
        'token=create_token({"id":sys.argv[1]},expires_delta=timedelta(seconds=5)); '
        'print(json.dumps({"token":token,"exp":jwt.decode(token,options={"verify_signature":False})["exp"]}))')
try:
    smoke.status()
    smoke.provision()
    minted = subprocess.run(['bash', '-c', 'source scripts/dev-env.sh; exec uv run --no-sync --quiet python -c "$1" "$2"',
                             'mint-session', code, smoke.owner_id], cwd=ROOT, env=dict(os.environ),
                            capture_output=True, text=True, timeout=90)
    report['mint_exit'] = minted.returncode
    if minted.returncode:
        raise RuntimeError('Session helper process failed; private child output not published')
    data = json.loads(minted.stdout)
    token = data['token']
    smoke.secrets.append(token)
    headers = {'Cookie': 'token=' + token, 'X-Chat-Id': smoke.chat_id,
               'X-Ocu-Resource-Path': 'page.html', 'X-Ocu-Resource-Query': 'download=1&%64ownload=0'}
    status, response, body = http_raw('127.0.0.1', 8080, 'GET', '/api/v1/ocu/resource-grants/issue', headers=headers)
    report['fresh_issuer'] = status
    if status != 302 or body:
        raise RuntimeError('Short session not admitted by real issuer')
    locations = [v for k, v in response if k.lower() == 'location']
    if len(locations) != 1 or not locations[0].startswith('/ocu/f/'):
        raise RuntimeError('Issuer redirect shape differs')
    grant = locations[0].split('/')[3]
    smoke.secrets.append(grant)
    report['raw_query_preserved'] = locations[0].endswith('?download=1&%64ownload=0')
    verifier = {'X-Ocu-Grant': grant, 'X-Chat-Id': smoke.chat_id,
                'X-Ocu-Resource-Path': 'page.html', 'X-Ocu-Resource-Method': 'GET'}
    status, _, body = http_raw('127.0.0.1', 8080, 'GET', '/api/v1/ocu/resource-grants/auth', headers=verifier)
    report['fresh_verifier'] = status
    if status != 200 or body:
        raise RuntimeError('Fresh grant not admitted')
    wait = max(0, data['exp'] - time.time() + 0.1)
    if wait > 6:
        raise RuntimeError('Session lifetime is outside the short probe bound')
    time.sleep(wait)
    report['wait_seconds'] = wait
    report['expired_issuer'] = http_raw('127.0.0.1', 8080, 'GET', '/api/v1/ocu/resource-grants/issue', headers=headers)[0]
    report['expired_verifier'] = http_raw('127.0.0.1', 8080, 'GET', '/api/v1/ocu/resource-grants/auth', headers=verifier)[0]
    if (report['expired_issuer'], report['expired_verifier']) != (401, 403):
        raise RuntimeError('Expired session/grant refusal differs')
    report['passed'] = True
except Exception as exc:
    report.update(passed=False, error_type=type(exc).__name__)
finally:
    try:
        smoke.cleanup_data()
        smoke.assert_sentinel()
        report['owned_cleanup_and_sentinel'] = True
    except Exception as exc:
        report.update(passed=False, cleanup_error_type=type(exc).__name__)
    args.report.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
raise SystemExit(0 if report.get('passed') else 1)
