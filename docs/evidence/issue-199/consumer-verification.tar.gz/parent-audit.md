# Parent consumer audit

## Requested filename is not necessarily the stored filename

`openwebui/tools/computer_use_tools.py:1086-1088` builds the new stored-file warning from the requested `filename`, despite parsing the successful upload payload immediately before it. A collision can store `brief (2).docx` while the warning says `brief.docx` was stored. The actual API smoke exercised this distinction (`report.txt` requested, `report (2).txt` committed; /tmp/issue-199-api-smoke.json). Preserve no-replace semantics and report the server's returned stored filename, with existing-client fallback only when that field is absent. Add an actual upload collision/failed-discovery tool regression before fixing it. Do not duplicate publication or alter success accounting.

## Embedded screenshot does not show the changed feedback

Default browser harness passed both functional warning assertions, but the parent opened `/tmp/issue-199-browser-green/embedded-stored-discovery-failed.png`: the embedded frame remains roughly300x150 and shows only the dashboard heading; the warning is outside the captured viewport. The standalone screenshot visibly shows stored-file/discovery-failed feedback and escaped hostile filename. Repair evidence capture by reusing the existing upload-feedback helper that temporarily sizes the owned iframe, scrolls the alert and restores its style. Assert visibility in the captured surface; do not change production layout to fit a test frame or drop the screenshot requirement.

These are in-scope pre-review corrections, not new queued issues. No source or test change made by the parent audit.

## Translation substitutes inside the supplied filename

`static/locale.js:createT` replaces parameters sequentially with replacement strings (`msg.replace(\`{${k}}\`, String(v))`). The new warning passes untrusted `filename` before `reason`. A stored filename containing `{reason}` therefore consumes the reason substitution inside the filename, leaving the actual reason placeholder unresolved; `$&` in a filename is also interpreted as replacement syntax. This follows directly from the new warning template and the existing replacement API. Extend the real browser filename canary with both literal forms, demonstrate the incorrect visible name, then fix interpolation at its owner with a single non-recursive callback substitution. Preserve ordinary translations and unknown placeholders; do not special-case the discovery filename or change layout.
