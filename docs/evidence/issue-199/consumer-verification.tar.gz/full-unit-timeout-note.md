# Full unit gate stall

Command: `uv run --offline --python 3.12 --no-project --with pytest --with pytest-asyncio --with-requirements computer-use-server/requirements.txt -- python -m pytest tests/ -q --import-mode=importlib --ignore=tests/integration`.

The first full non-image unit run exceeded its 900-second parent deadline. No passing claim. Its stdout was held in subprocess.PIPE and was not preserved when the eval exception escaped; this attempt has timeout evidence but no per-test attribution. A subsequent exact-name process query found no remaining `python.*pytest tests/` process.

The diagnostic run streams stdout directly to `/tmp/issue-199-full-unit-diagnostic.log`, adds `-vv -o faulthandler_timeout=60`, and owns a new process group with TERM/KILL cleanup at a 360-second deadline. This is an instrumented diagnosis of the stall, not a rerun to deny the observed failure. Inspect its first stuck test and stack before choosing a fix; do not relax or skip the gate.

Ranked hypotheses before reading the instrumented result:

1. Cross-test import/singleton or worker-lifetime leakage: the focused owning surface completed in29.28s, but broader ordering may strand a lock/future. Predict a blocked thread/task stack and a focused test that differs from the recorded preceding sequence.
2. An unchanged broader-suite test waits on an external or process prerequisite outside the owning surface. Predict an unrelated active node and transport/subprocess stack, rather than discovery code.
3. Genuine cumulative filesystem/runtime cost. Predict ongoing test progress and an active IO/computation stack, not repeated identical blocked frames. The focused timings make this less likely but do not exclude it.

No hypothesis is established yet. Source edits require the diagnostic node/stack and a discriminating narrowed check.
