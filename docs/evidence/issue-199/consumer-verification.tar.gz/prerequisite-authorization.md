# Approved issue199 CI prerequisites

The user was asked whether to include two newly observed test-gate repairs in this queue or leave issue199 blocked and continue only the original queue. The user selected **纳入前置修复**.

Authorized scope: repair the Office DNS deadline test's scheduling oracle and the outputs/path-security test fixture's stale Office module bindings; retain behavioral assertions and do not change Office production logic. Treat both as merge prerequisites for issue199, then continue the original queue. This is not authorization to waive failed CI, relax acceptance latency limits, change dependencies or deploy.

Observed full non-image result:3384 passed,2 failed,5 skipped; /tmp/issue-199-full-unit-final.log. Issue199 functional core, actual HTTP upload/MCP smoke, final browser surface and the unchanged latency gates have separate passing evidence. Its source candidate is checkpointed at local commit a594863 (full SHA to be recorded before review); it is not merged or declared complete.
