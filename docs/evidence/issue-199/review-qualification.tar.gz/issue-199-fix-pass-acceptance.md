# Issue199 fix pass1 acceptance evidence

Source candidate: `b7241020bd1f710c12f58d5f0ee2bb933666a088`. The only source change after reviewed01d7bfa is the existing browser harness's distinct server-stored filename fixture and assertions. Production code is unchanged.

## Dashboard collision-name coverage

The shared standalone/embedded scenario uses different requested and returned stored names while retaining literal `{reason}`, `$&` and HTML text. It asserts the returned name is distinct, the warning contains that name but not the complete requested name, stable `file_limit`, no HTML interpretation or retry affordance, and exactly one POST for each of the two selected files.

- `reviewG1`:actual full browser harness exit0,133.475s,135listing requests.
- `reviewBadEmbedded`:served-byte-only wrong consumer uses `file.name`; exit1 at the actual-stored-filename assertion,19.966s.
- `reviewBadStandalone`:same precise wrong consumer on standalone; exit1 at the same invariant,73.016s.
- `reviewRestored`:remove the fault; full default both-surfaces harness exit0,122.123s,135listing requests. Parent opened both final screenshots and observed the complete collision-renamed warning with literal canaries. Harness's unexpected-console/page-error checks passed.

No production file was mutated for the wrong-consumer controls. The preload records original/served script hashes. Every run records before/after source/harness hashes and Node22.23.2,Playwright1.62.1,Python3.12.12 and resolved Python package versions. These fresh runs supersede earlier browser acceptance for the changed harness; the actual backend/tool collision proofs remain separate from this simulated server-response discriminator.

## Missing negative classes

The qualified manifest in `issue-199-negative-qualification-audit.json` identifies20 intended semantic failures and20 restored passes across entry, directory and descriptor policy, empty-chat records, unshielded queued cancellation, and premature release during running/start-race cancellation. The original behavioral tests and policy constants are unchanged. Only guarded production-function mutations in disposable copies create wrong candidates. All accepted controls have successful setup/teardown, expected call failures, reaped children, stable input manifests and removed workspaces.

This is **late regression-sensitivity qualification**, not evidence that every class's tests were originally authored and run before implementation. The initial real10001-file RED preceded the production fix; later historical/replayed controls do not recreate that chronology. Task1.2's original sequencing wording remains unchecked pending explicit review/owner adjudication; no false chronology or silent checkbox completion.

## Invalid qualifier attempts

The first copied runtime omitted a transitive Python module; retain that setup failure without counting it as semantic evidence. A later observer bug read `pytest.ExceptionInfo.value` while a failed `pytest.raises` context was still empty. That property asserts until context exit, so the observer masked the intended pytest `Failed` exception with `AssertionError`. Primary property-source evidence is retained in `issue-199-observer-diagnosis.log`.

All earlier observer-fingerprint trials are excluded from acceptance. In particular, `ENTRY_RED3`'s earlier `expected_semantic_rejection` label is explicitly invalidated. The final observer checks populated exception state first, preserves the original `Failed`, and the policy classifier again requires the original missing-rejection assertion rather than accepting the masking error. Final accepted IDs, runner digest, raw observations and all excluded attempts are retained. No permanent test, threshold or production behavior was weakened.

## Remaining gates and attribution

The interrupted full run on01d7bfa is retained as cancelled, not PASS. A new full run is active onb724102 via the owned runner with launch PID/PGID, exact argv, toolchain and per-input pre/post hashes. Its result is still required. Final tool/lifecycle provenance comes from that run; the older actual HTTP smoke proves upload/MCP behavior only and does not certify the later Docker-manager placement change.

Fresh independent re-review must assess this evidence, the observer repair and the unresolved chronology limitation. No merge claim is made here.
