#!/usr/bin/env python3
"""One requested late regression-sensitivity qualification; never historical TDD.

Parent invocation: python3 /tmp/issue-199-negative-qualification.py
  --control entry-ceiling --mode negative --id ENTRY_RED
Repeat with --mode good and a NEW ID for restored unchanged-candidate GREEN.
No retry, live-source mutation, install, upgrade, fixture or threshold changes.
Inspect result.json: pytest exit 1 alone is NOT semantic qualification evidence.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import selectors
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time

SOURCE = Path('/Users/danker/Documents/31308/open-computer-use')
FROZEN = '01d7bfac208ed4250d395d4a7b69a16a6ef21ace'
TEST = 'tests/orchestrator/test_mcp_discovery.py'
UPLOADS = 'computer-use-server/uploads.py'
MCP = 'computer-use-server/mcp_resources.py'
REQUIREMENTS = 'computer-use-server/requirements.txt'
INPUTS = {TEST, REQUIREMENTS, 'tests/orchestrator/conftest.py',
          'tests/orchestrator/_office_store.py'}
OPTIONAL = {'conftest.py', 'pytest.ini', 'pyproject.toml', 'setup.cfg', 'tox.ini',
            'tests/conftest.py', 'tests/__init__.py', 'tests/orchestrator/__init__.py'}
ENTRY_TEST = 'test_entries_count_before_filter_and_excess_stat_is_not_performed'
EXACT_TEST = 'test_directory_and_descriptor_exact_limits_unwind_owned_fds'
CHILD_TEST = 'test_limits_reject_excess_child_before_acquisition'
EMPTY_TEST = 'test_empty_and_failed_chats_do_not_accumulate_records'
CANCEL_TEST = 'test_cancelled_discovery_keeps_admission_until_worker_ends_and_recovers'
ITERATOR_TEST = 'test_descriptor_limit_rejects_iterator_before_acquisition'
EXACT_CASES = [EXACT_TEST + suffix for suffix in
               ('[wide-paths0-5]', '[deep-paths1-3]', '[mixed-paths2-5]')]

# Each tuple is one exact source replacement; disabling multiple guards of ONE
# policy is one defect, not multiple unrelated defects. Constants remain intact.
CONTROLS = {
    'entry-ceiling': {
        'file': UPLOADS, 'function': '_scan_visible_files',
        'edits': [('                        if enumerated > MAX_DISCOVERY_ENTRIES:\n',
                   '                        if False:\n', 1)],
        'tests': [ENTRY_TEST + '[' + kind + ']' for kind in ('hidden', 'symlink', 'special', 'directory')],
        'reject': ['missing-policy-rejection'],
    },
    'directory-ceiling': {
        'file': UPLOADS, 'function': '_scan_visible_files',
        'edits': [('        if directories > MAX_DISCOVERY_DIRECTORIES:\n', '        if False:\n', 1),
                  ('                            if directories >= MAX_DISCOVERY_DIRECTORIES:\n',
                   '                            if False:\n', 1)],
        'tests': EXACT_CASES + [CHILD_TEST + '[MAX_DISCOVERY_DIRECTORIES-directory_limit-0]'],
        'reject': ['missing-policy-rejection', 'missing-directory-rejection'],
    },
    'empty-records': {
        'file': MCP, 'function': '_discover_and_publish',
        'edits': [('        else:\n            chats.pop(chat_id, None)\n',
                   '        else:\n            chats[chat_id] = fresh\n', 1)],
        'tests': [EMPTY_TEST], 'reject': ['empty-record-accumulation'],
    },
    'queued-unshielded': {
        'file': MCP, 'function': 'sync_chat_resources',
        'edits': [('    count, changed = await asyncio.shield(future)\n',
                   '    count, changed = await future\n', 1)],
        'tests': [CANCEL_TEST + '[' + outcome + '-queued]' for outcome in ('success', 'failure')],
        'reject': ['queued-worker-cancelled'],
    },
    'premature-cancellation-release': {
        'file': MCP, 'function': 'sync_chat_resources',
        'edits': [('    count, changed = await asyncio.shield(future)\n',
                   '    try:\n        count, changed = await asyncio.shield(future)\n'
                   '    except asyncio.CancelledError:\n        _discovery_admission.release()\n        raise\n', 1)],
        'tests': [CANCEL_TEST + '[' + outcome + '-' + phase + ']'
                  for outcome in ('success', 'failure') for phase in ('running', 'start-race')],
        'reject': ['lost-busy-admission'],
    },
    'descriptor-policy': {
        'file': UPLOADS, 'function': '_scan_visible_files',
        'edits': [('                if directory_fds >= MAX_DISCOVERY_DIRECTORY_FDS:\n',
                   '                if False:\n', 1),
                  ('                    if directory_fds >= MAX_DISCOVERY_DIRECTORY_FDS:\n',
                   '                    if False:\n', 1)],
        'tests': EXACT_CASES + [ITERATOR_TEST, CHILD_TEST + '[MAX_DISCOVERY_DIRECTORY_FDS-descriptor_limit-2]'],
        'reject': ['missing-policy-rejection', 'missing-descriptor-rejection'],
    },
}

# Observation-only plugin: no fixture/production patch, no assertion rewrites,
# no exception values, traceback text, auth/environment values or local reprs.
PLUGIN = r'''
import asyncio
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sys
import threading
import pytest

CONFIG = json.loads(Path(os.environ['ISSUE199_CONFIG']).read_text())
TEST = Path(CONFIG['test']).resolve()
OUTPUT = Path(CONFIG['telemetry'])
LOCATIONS = {int(line): value for line, value in CONFIG['locations'].items()}
CURRENT = None


def emit(kind, **fields):
    with OUTPUT.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps({'kind': kind, **fields}, sort_keys=True) + '\n')


def snapshot(frame):
    local = frame.f_locals
    result = {}
    for name in ('submitted', 'started', 'occupy', 'release_scan'):
        event = local.get(name)
        if isinstance(event, (asyncio.Event, threading.Event)):
            result[name] = event.is_set()
    worker = local.get('worker')
    if worker is not None and hasattr(worker, 'cancelled'):
        result['worker_cancelled'] = worker.cancelled()
        result['worker_done'] = worker.done()
    task = local.get('task')
    if isinstance(task, asyncio.Task):
        result['task_cancelled'] = task.cancelled()
    raised = local.get('raised')
    # A failed pytest.raises context is still empty when its exception is traced.
    if isinstance(raised, pytest.ExceptionInfo) and getattr(raised, '_excinfo', None) is not None:
        reason = getattr(raised.value, 'reason', None)
        result['reason'] = reason if reason in ('busy', 'io_error', 'internal_error') else '<other-or-absent>'
    inspections = local.get('inspections')
    if isinstance(inspections, list):
        result['excess_inspection_count'] = len(inspections)
    return result


def trace(frame, event, arg):
    if Path(frame.f_code.co_filename).resolve() != TEST:
        return None
    location = LOCATIONS.get(frame.f_lineno)
    if location and event == 'exception':
        emit('semantic_observation', node=CURRENT, location=location,
             line=frame.f_lineno, exception_type=arg[0].__name__, state=snapshot(frame))
    return trace


def pytest_sessionstart(session):
    executable = Path(sys.executable).resolve()
    emit('toolchain', python=sys.version, executable=str(executable),
         executable_sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),
         platform=platform.platform(), packages=sorted(
             (dist.metadata.get('Name', '<unnamed>'), dist.version)
             for dist in importlib.metadata.distributions()))


def pytest_collection_finish(session):
    emit('collection', nodes=[item.nodeid for item in session.items])


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    global CURRENT
    previous = sys.gettrace()
    if previous is not None:
        raise RuntimeError('qualification refuses existing tracing')
    CURRENT = item.nodeid
    emit('call_start', node=CURRENT)
    sys.settrace(trace)
    try:
        yield
    finally:
        sys.settrace(previous)
        emit('call_end', node=CURRENT)
        CURRENT = None


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    # Pytest report rendering may filter traceback frames; capture first.
    fields = {'node': item.nodeid}
    if call.excinfo is not None:
        fields['exception_type'] = call.excinfo.type.__name__
        if isinstance(call.excinfo.value, ModuleNotFoundError):
            name = call.excinfo.value.name
            if isinstance(name, str) and all(part.isidentifier() for part in name.split('.')):
                fields['missing_import'] = name
        locations = []
        test_frames = []
        for entry in call.excinfo.traceback:
            if Path(str(entry.path)).resolve() == TEST:
                line = entry.lineno + 1
                test_frames.append({'line': line, 'function': entry.frame.code.name,
                                    'state': snapshot(entry.frame.raw)})
                if line in LOCATIONS:
                    locations.append({'line': line, 'location': LOCATIONS[line],
                                      'state': snapshot(entry.frame.raw)})
        fields['semantic_locations'] = locations
        fields['test_frames'] = test_frames
    outcome = yield
    report = outcome.get_result()
    fields.update(phase=report.when, outcome=report.outcome, duration=report.duration)
    emit('report', **fields)


def pytest_sessionfinish(session, exitstatus):
    emit('session_finish', exitstatus=int(exitstatus))
'''


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save_json(path, value):
    with path.open('w', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def stable_bytes(root, name):
    path = root / name
    for parent in path.parents:
        if parent == root:
            break
        if parent.is_symlink():
            raise RuntimeError('symlink input parent')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise RuntimeError('nonregular input')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            data = stream.read()
        after = os.fstat(fd)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise RuntimeError('input changed during read; no retry')
        return data, stat.S_IMODE(before.st_mode)
    finally:
        os.close(fd)


def manifest(root, names):
    result = {}
    for name in names:
        data, mode = stable_bytes(root, name)
        result[name] = {'sha256': digest(data), 'size': len(data), 'mode': mode}
    return result


def git(source, *args):
    return subprocess.run(['git', '-C', str(source), *args], check=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10).stdout


def snapshot(source, copied):
    # Selection ignores browser JS and other unrelated concurrent changes.
    tracked = set(os.fsdecode(name) for name in git(source, 'ls-files', '-z').split(b'\0') if name)
    if not INPUTS <= tracked:
        raise RuntimeError('required tracked Python input missing')
    # Preserve the complete Python package so transitive imports stay real.
    server_python = {name for name in tracked
                     if name.startswith('computer-use-server/') and name.endswith('.py')}
    names = sorted(INPUTS | (OPTIONAL & tracked) | server_python)
    frozen_manifest = {}
    for name in names:
        if any(part.lower() in {'.git', '.run', 'secrets', 'node_modules'} or
               part.lower().startswith('.env') for part in Path(name).parts):
            raise RuntimeError('forbidden selected input')
        data, mode = stable_bytes(source, name)
        frozen_data = git(source, 'show', FROZEN + ':' + name)
        if data != frozen_data:
            raise RuntimeError('selected input differs from frozen candidate; no retry')
        frozen_manifest[name] = {'sha256': digest(data), 'size': len(data), 'mode': mode}
        target = copied / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        target.chmod(mode)
    if manifest(source, names) != frozen_manifest or manifest(copied, names) != frozen_manifest:
        raise RuntimeError('selected snapshot content drift; no retry')
    return names, frozen_manifest


def unique_function(tree, name):
    found = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name]
    if len(found) != 1:
        raise RuntimeError('mutation function is not unique')
    return found[0]


def mutate(copied, control):
    path = copied / control['file']
    before = path.read_bytes()
    text = before.decode('utf-8')
    tree = ast.parse(text)
    function = unique_function(tree, control['function'])
    lines = text.splitlines(keepends=True)
    original_body = ''.join(lines[function.lineno - 1:function.end_lineno])
    body = original_body
    for old, new, count in control['edits']:
        guarded = re.compile('^' + re.escape(old), re.MULTILINE)
        if len(guarded.findall(body)) != count:
            raise RuntimeError('exact mutation guard drift; no retry')
        body = guarded.sub(lambda _match: new, body)
    changed = ''.join(lines[:function.lineno - 1]) + body + ''.join(lines[function.end_lineno:])
    after_tree = ast.parse(changed)
    after_function = unique_function(after_tree, control['function'])
    if ast.dump(function) == ast.dump(after_function):
        raise RuntimeError('mutation did not change function AST')
    others = lambda parsed: [ast.dump(node) for node in parsed.body
                            if not (isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == control['function'])]
    if others(tree) != others(after_tree):
        raise RuntimeError('mutation changed another top-level AST')
    path.write_text(changed, encoding='utf-8')
    return {'file': control['file'], 'function': control['function'],
            'before_sha256': digest(before), 'after_sha256': digest(changed.encode()),
            'before_function_ast_sha256': digest(ast.dump(function).encode()),
            'after_function_ast_sha256': digest(ast.dump(after_function).encode()),
            'exact_replacements': control['edits']}


def semantic_locations(test_path):
    text = test_path.read_text(encoding='utf-8')
    tree = ast.parse(text)
    result = {}
    # AST-validated statement positions, not pinned line numbers or log matching.
    specifications = [
        ('rejected', 'with pytest.raises(Exception) as raised:\n        sync(world, chat)', 'missing-policy-rejection'),
        (ENTRY_TEST, 'rejected(w, "bounded", "entry_limit")', 'entry-overflow-contract'),
        (EXACT_TEST, 'with pytest.raises(Exception) as raised:\n                w.uploads._scan_visible_files(root_fd)', 'missing-directory-rejection'),
        (EXACT_TEST, 'with pytest.raises(Exception) as raised:\n                w.uploads._scan_visible_files(root_fd)', 'missing-descriptor-rejection'),
        (EMPTY_TEST, 'assert w.mr._chat_uris == {}', 'empty-record-accumulation'),
        (CANCEL_TEST, 'assert getattr(raised.value, "reason", None) == "busy"', 'lost-busy-admission'),
        (CANCEL_TEST, 'await asyncio.wait_for(started.wait(), 5)', 'queued-start-timeout'),
        (CANCEL_TEST, 'await asyncio.wait_for(asyncio.wrap_future(executor.discovery_future), 5)', 'queued-worker-cancelled'),
    ]
    for function_name, fragment, category in specifications:
        function = unique_function(tree, function_name)
        lines = text.splitlines(keepends=True)
        body = ''.join(lines[function.lineno - 1:function.end_lineno])
        matches = [match.start() for match in re.finditer(re.escape(fragment), body)]
        # Explicit disambiguation of the unchanged directory/descriptor branches
        # and the second started.wait() after caller cancellation.
        ordinal = 1 if category in ('missing-descriptor-rejection', 'queued-start-timeout') else 0
        expected_count = 2 if category in ('missing-directory-rejection', 'missing-descriptor-rejection', 'queued-start-timeout') else (3 if category == 'empty-record-accumulation' else 1)
        if len(matches) != expected_count:
            raise RuntimeError('protected semantic location drift')
        line = function.lineno + body[:matches[ordinal]].count('\n')
        if not any(node.lineno == line for node in ast.walk(function) if isinstance(node, (ast.Assert, ast.With, ast.Expr))):
            raise RuntimeError('semantic location is not an AST statement')
        result[line] = category
    return result


class RunnerInterrupted(RuntimeError):
    pass


class ContainmentFailure(RuntimeError):
    pass


def interrupt(signum, _frame):
    raise RunnerInterrupted(signal.Signals(signum).name)


def group_exists(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False


def stop_group(process):
    stages = []
    process.poll()
    for number in (signal.SIGTERM, signal.SIGKILL):
        if not group_exists(process.pid):
            break
        os.killpg(process.pid, number)
        stages.append(signal.Signals(number).name)
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            process.poll()
            if not group_exists(process.pid):
                break
            time.sleep(0.05)
    process.wait(timeout=3)
    if group_exists(process.pid):
        raise ContainmentFailure('owned group survived bounded shutdown')
    return stages


def run_stream(command, cwd, env, directory, wall_timeout, execution):
    process = None
    started = time.monotonic()
    blocked = {signal.SIGINT, signal.SIGTERM}
    with (directory / 'pytest.log').open('wb') as log:
        mask = signal.pthread_sigmask(signal.SIG_BLOCK, blocked)
        try:
            process = subprocess.Popen(command, cwd=cwd, env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True,
                bufsize=0, preexec_fn=lambda: signal.pthread_sigmask(signal.SIG_SETMASK, mask))
            # SIGINT/TERM remain blocked until ownership is durable, immediately
            # after launch. No version probe or pipe setup precedes this record.
            save_json(directory / 'launch.json', {'runner_pid': os.getpid(),
                'child_pid': process.pid, 'child_pgid': process.pid,
                'command': command, 'cwd': str(cwd), 'workspace': str(cwd.parent),
                'launched_monotonic': started, 'reaped': False})
            signal.pthread_sigmask(signal.SIG_SETMASK, mask)
            os.set_blocking(process.stdout.fileno(), False)
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ)
                while selector.get_map():
                    if time.monotonic() - started >= wall_timeout:
                        execution['interrupted'] = 'wall_timeout'
                        break
                    for key, _ in selector.select(0.2):
                        chunk = os.read(key.fd, 65536)
                        if not chunk:
                            selector.unregister(key.fileobj)
                            continue
                        log.write(chunk)
                        log.flush()
                        sys.stdout.buffer.write(chunk)
                        sys.stdout.buffer.flush()
                if execution['interrupted'] is None:
                    try:
                        process.wait(timeout=max(0.01, wall_timeout - (time.monotonic() - started)))
                    except subprocess.TimeoutExpired:
                        execution['interrupted'] = 'wall_timeout'
        except RunnerInterrupted:
            execution['interrupted'] = 'runner_signal'
        finally:
            signal.pthread_sigmask(signal.SIG_BLOCK, blocked)
            try:
                if process is not None:
                    try:
                        execution['shutdown_signals'] = stop_group(process)
                        execution['reaped'] = True
                    except Exception as error:
                        execution['containment_failure'] = True
                        raise ContainmentFailure('owned child not confirmed stopped/reaped') from error
                    finally:
                        execution['child_exit'] = process.returncode
                        execution['wall_seconds'] = time.monotonic() - started
                        save_json(directory / 'process-end.json', execution)
                    deadline = time.monotonic() + 0.5
                    while time.monotonic() < deadline:
                        try:
                            chunk = os.read(process.stdout.fileno(), 65536)
                        except BlockingIOError:
                            break
                        if not chunk:
                            break
                        log.write(chunk)
                        sys.stdout.buffer.write(chunk)
                    log.flush()
                    sys.stdout.buffer.flush()
                    process.stdout.close()
            finally:
                signal.pthread_sigmask(signal.SIG_SETMASK, mask)


def classify(mode, control, nodes, execution, records):
    if execution['interrupted'] or execution['shutdown_signals'] or not execution['reaped']:
        return 'invalid_process_shutdown'
    collections = [row for row in records if row['kind'] == 'collection']
    if len(collections) != 1 or collections[0]['nodes'] != nodes:
        return 'invalid_collection'
    finishes = [row for row in records if row['kind'] == 'session_finish']
    if len(finishes) != 1 or finishes[0]['exitstatus'] != execution['child_exit']:
        return 'invalid_session_exit'
    reports = [row for row in records if row['kind'] == 'report']
    if len(reports) != 3 * len(nodes):
        return 'invalid_report_count'
    for node in nodes:
        phases = {row['phase']: row for row in reports if row['node'] == node}
        if any(phases.get(phase, {}).get('outcome') != 'passed' for phase in ('setup', 'teardown')):
            return 'invalid_setup_or_teardown'
        call = phases.get('call', {})
        if mode == 'good':
            if call.get('outcome') != 'passed':
                return 'invalid_restored_good_failure'
            continue
        if execution['child_exit'] != 1 or call.get('outcome') != 'failed':
            return 'invalid_negative_exit_or_outcome'
        allowed = [location for location in call.get('semantic_locations', [])
                   if location['location'] in control['reject']]
        exception = call.get('exception_type')
        if not allowed:
            return 'invalid_unrelated_call_failure'
        if 'queued-worker-cancelled' in control['reject']:
            cancelled = any(location['state'].get('worker_cancelled') is True
                            for location in allowed)
            timeout = any(row['kind'] == 'semantic_observation' and row.get('node') == node
                          and row.get('location') == 'queued-start-timeout'
                          and row.get('exception_type') == 'TimeoutError'
                          and row.get('state', {}).get('worker_cancelled') is True
                          and row.get('state', {}).get('started') is False for row in records)
            if exception != 'CancelledError' or not cancelled or not timeout:
                return 'invalid_queued_cancellation_observation'
        elif 'lost-busy-admission' in control['reject']:
            # Report traceback frames are inspected after test finally blocks;
            # use the exception-time observation for pre-cleanup ownership.
            ownership = any(row['kind'] == 'semantic_observation' and row.get('node') == node
                            and row.get('location') == 'lost-busy-admission'
                            and row.get('exception_type') == 'AssertionError'
                            and row.get('state', {}).get('submitted') is True
                            and row.get('state', {}).get('task_cancelled') is True
                            and row.get('state', {}).get('occupy') is True
                            and row.get('state', {}).get('release_scan') is False
                            and row.get('state', {}).get('reason') != 'busy' for row in records)
            if exception != 'AssertionError' or not ownership:
                return 'invalid_cancellation_ownership_observation'
        elif 'empty-record-accumulation' in control['reject']:
            if exception != 'AssertionError':
                return 'invalid_empty_record_exception'
        elif exception != 'Failed':
            return 'invalid_policy_exception'
    return 'restored_good_pass' if mode == 'good' and execution['child_exit'] == 0 else (
        'expected_semantic_rejection' if mode == 'negative' else 'invalid_good_exit')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--control', required=True, choices=sorted(CONTROLS))
    parser.add_argument('--mode', required=True, choices=('negative', 'good'))
    parser.add_argument('--id', required=True)
    parser.add_argument('--source', type=Path, default=SOURCE)
    parser.add_argument('--output-root', type=Path, default=Path('/tmp/issue-199-negative-evidence'))
    parser.add_argument('--wall-timeout', type=float, default=180)
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}', args.id):
        parser.error('ID must be a safe unique artifact label')
    if not 60 <= args.wall_timeout <= 300:
        parser.error('wall timeout must be 60..300 seconds')
    source = args.source.resolve(strict=True)
    root = args.output_root.resolve()
    if not root.is_relative_to(Path('/tmp').resolve()) or root == source or source in root.parents:
        parser.error('artifacts must be under /tmp, outside live source')
    root.mkdir(parents=True, exist_ok=True)
    directory = root / args.id
    directory.mkdir(mode=0o700)  # Deliberately refuses reuse/overwrite.
    control = CONTROLS[args.control]
    nodes = [TEST + '::' + name for name in control['tests']]
    result = {'id': args.id, 'control': args.control, 'mode': args.mode,
              'source': str(source), 'frozen_commit': FROZEN, 'nodes': nodes,
              'qualification': 'late regression sensitivity, not historical pre-fix TDD',
              'classification': 'not_run', 'pytest_exit': None,
              'runner_sha256': digest(Path(__file__).read_bytes()),
              'runner_python': sys.version, 'runner_platform': platform.platform()}
    execution = {'child_exit': None, 'interrupted': None, 'shutdown_signals': [],
                 'reaped': False, 'containment_failure': False}
    workspace = Path(tempfile.mkdtemp(prefix='issue-199-negative-', dir='/tmp'))
    copied = workspace / 'source'
    copied.mkdir()
    result['workspace'] = str(workspace)
    handlers = {number: signal.signal(number, interrupt) for number in (signal.SIGINT, signal.SIGTERM)}
    save_json(directory / 'result.json', result)
    try:
        names, original = snapshot(source, copied)
        save_json(directory / 'source-manifest.json', original)
        result['selected_source_manifest_sha256'] = digest(json.dumps(original, sort_keys=True).encode())
        result['requirements_sha256'] = original[REQUIREMENTS]['sha256']
        locations = semantic_locations(copied / TEST)
        if args.mode == 'negative':
            result['mutation'] = mutate(copied, control)
        candidate = manifest(copied, names)
        differences = [name for name in names if candidate[name] != original[name]]
        if differences != ([control['file']] if args.mode == 'negative' else []):
            raise RuntimeError('candidate differences exceed requested single defect')
        result['changed_copied_inputs'] = differences
        save_json(directory / 'candidate-manifest.json', candidate)
        runtime = workspace / 'observer'
        runtime.mkdir()
        (runtime / 'issue199_observer.py').write_text(PLUGIN, encoding='utf-8')
        config = {'test': str(copied / TEST), 'telemetry': str(directory / 'telemetry.jsonl'), 'locations': locations}
        save_json(directory / 'observer-config.json', config)
        result['observer_sha256'] = digest(PLUGIN.encode())
        result['semantic_locations'] = locations
        home, temp = workspace / 'home', workspace / 'tmp'
        home.mkdir()
        temp.mkdir()
        uv = shutil.which('uv')
        if uv is None:
            raise RuntimeError('uv executable unavailable')
        uv = str(Path(uv).resolve())
        env = {'PATH': os.environ.get('PATH', os.defpath), 'HOME': str(home), 'TMPDIR': str(temp),
               'LANG': 'en_US.UTF-8', 'LC_ALL': 'en_US.UTF-8', 'TZ': 'UTC',
               'UV_CACHE_DIR': os.environ.get('UV_CACHE_DIR', str(Path.home() / '.cache/uv')),
               'UV_PYTHON_INSTALL_DIR': os.environ.get('UV_PYTHON_INSTALL_DIR', str(Path.home() / '.local/share/uv/python')),
               'UV_PYTHON_DOWNLOADS': 'never', 'UV_OFFLINE': '1',
               'PYTHONUNBUFFERED': '1', 'PYTHONDONTWRITEBYTECODE': '1',
               'PYTHONPATH': str(runtime) + os.pathsep + str(copied),
               'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1', 'PYTEST_PLUGINS': 'issue199_observer',
               'ISSUE199_CONFIG': str(directory / 'observer-config.json')}
        command = [uv, 'run', '--offline', '--python', '3.12', '--no-project',
                   '--with', 'pytest', '--with', 'pytest-asyncio', '--with-requirements', REQUIREMENTS,
                   '--', 'python', '-m', 'pytest', *nodes, '-q', '--import-mode=importlib',
                   '-p', 'pytest_asyncio.plugin', '--tb=no', '--show-capture=no', '--no-summary',
                   '-o', 'log_cli=false', '-o', 'cache_dir=' + str(workspace / 'pytest-cache')]
        result.update(command=command, cwd=str(copied), uv_sha256=digest(Path(uv).read_bytes()),
                      wall_timeout=args.wall_timeout, environment_keys=sorted(env),
                      inherited_environment='Only PATH and uv cache/Python-install paths; no auth/proxy values')
        save_json(directory / 'invocation.json', result)
        run_stream(command, copied, env, directory, args.wall_timeout, execution)
        records_path = directory / 'telemetry.jsonl'
        records = [json.loads(line) for line in records_path.read_text().splitlines()] if records_path.exists() else []
        result['classification'] = classify(args.mode, control, nodes, execution, records)
        if manifest(copied, names) != candidate:
            result['classification'] = 'invalid_copied_input_drift'
        if manifest(source, names) != original:
            result['classification'] = 'invalid_selected_live_input_drift'
    except Exception as error:
        result['runner_error_type'] = type(error).__name__
        result['classification'] = 'invalid_containment' if isinstance(error, ContainmentFailure) else (
            'invalid_runner_interruption' if isinstance(error, RunnerInterrupted) else 'invalid_runner_error')
    finally:
        for number in handlers:
            signal.signal(number, signal.SIG_IGN)
        result['execution'] = execution
        result['pytest_exit'] = execution['child_exit']
        if execution['containment_failure']:
            result['retained_workspace'] = str(workspace)
        else:
            try:
                shutil.rmtree(workspace)
            except Exception as error:
                result['cleanup_error_type'] = type(error).__name__
                result['retained_workspace'] = str(workspace)
                result['classification'] = 'invalid_workspace_cleanup'
        result['disposable_workspace_removed'] = not workspace.exists()
        save_json(directory / 'result.json', result)
        print(json.dumps({'id': args.id, 'classification': result['classification'],
                          'pytest_exit': result['pytest_exit'], 'artifacts': str(directory)}, sort_keys=True), flush=True)
        for number, handler in handlers.items():
            signal.signal(number, handler)
    # Preserve pytest's actual exit, including negative-control RED. No inversion.
    code = result['pytest_exit']
    return code if code is not None and code >= 0 else (128 - code if code is not None else 70)


if __name__ == '__main__':
    raise SystemExit(main())
