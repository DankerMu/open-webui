// Disposable served-byte mutation; never writes production source.
const fs = require('node:fs/promises');
const sync = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const target = '/Users/danker/Documents/31308/open-computer-use/computer-use-server/static/preview.js';
const original = fs.readFile;
const expected = "const filename = typeof payload.filename === 'string' ? payload.filename : file.name;";
const replacement = 'const filename = file.name;';
fs.readFile = async function (filename, ...args) {
  const bytes = await original.call(this, filename, ...args);
  if (typeof filename !== 'string' || path.resolve(filename) !== target) return bytes;
  const text = Buffer.isBuffer(bytes) ? bytes.toString('utf8') : bytes;
  if (text.split(expected).length !== 2) throw new Error('Stored-name control anchor drift');
  const changed = text.replace(expected, replacement);
  const evidence = {
    fault: 'dashboard uses requested filename instead of returned stored filename',
    originalSha256: createHash('sha256').update(text).digest('hex'),
    servedSha256: createHash('sha256').update(changed).digest('hex'),
  };
  sync.appendFileSync(process.env.ISSUE199_NAME_CONTROL_LOG, JSON.stringify(evidence) + '\n');
  return Buffer.isBuffer(bytes) ? Buffer.from(changed) : changed;
};
