"""One bounded integrated #199 gate; retains output immediately and never retries."""
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path('/Users/danker/Documents/31308/open-computer-use')
EXPECTED = '01d7bfac208ed4250d395d4a7b69a16a6ef21ace'
LOG = Path('/tmp/issue-199-integrated-full-unit.log')
RESULT = Path('/tmp/issue-199-integrated-full-unit.json')
ENV = {k: v for k, v in os.environ.items() if k not in {'ALL_PROXY', 'all_proxy', 'HTTP_PROXY', 'http_proxy', 'HTTPS_PROXY', 'https_proxy'}}
UV = ['uv', 'run', '--offline', '--python', '3.12', '--no-project', '--with', 'pytest', '--with', 'pytest-asyncio', '--with-requirements', 'computer-use-server/requirements.txt', '--', 'python']
COMMAND = UV + ['-m', 'pytest', 'tests/', '-vv', '--import-mode=importlib', '--ignore=tests/integration', '--durations=20', '-o', 'faulthandler_timeout=60']

def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, env=ENV, text=True).strip()

def interrupted(signum, frame):
    raise KeyboardInterrupt('owned suite runner interrupted')

if LOG.exists() or RESULT.exists():
    raise SystemExit('Refusing to overwrite retained integrated evidence')
assert head() == EXPECTED
assert subprocess.run(['git', 'diff', '--quiet'], cwd=ROOT, env=ENV).returncode == 0
metadata_code = "import json,sys,platform,importlib.metadata as m;print(json.dumps({'python':sys.version,'platform':platform.platform(),'packages':{n:m.version(n) for n in ['pytest','pytest-asyncio','aiohttp','mcp','fastapi','anyio']}}))"
metadata = json.loads(subprocess.check_output(UV + ['-c', metadata_code], cwd=ROOT, env=ENV, text=True, timeout=60))
state = {'source_head': EXPECTED, 'argv': COMMAND, 'cwd': str(ROOT), 'toolchain': metadata, 'deadline_seconds': 3600, 'log': str(LOG), 'exit': None, 'interrupted': False}
process = None
started = time.monotonic()
for number in (signal.SIGINT, signal.SIGTERM):
    signal.signal(number, interrupted)
try:
    with LOG.open('x') as output:
        output.write(json.dumps({'argv': COMMAND, 'source_head': EXPECTED, 'toolchain': metadata}) + '\n')
        output.flush()
        process = subprocess.Popen(COMMAND, cwd=ROOT, env=ENV, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            state['exit'] = process.wait(timeout=3600)
        except (subprocess.TimeoutExpired, KeyboardInterrupt):
            state['interrupted'] = True
            raise
finally:
    for number in (signal.SIGINT, signal.SIGTERM):
        signal.signal(number, signal.SIG_IGN)
    if process is not None and process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)
    state['elapsed_seconds'] = time.monotonic() - started
    state['source_head_after'] = head()
    state['tracked_tree_clean_after'] = subprocess.run(['git', 'diff', '--quiet'], cwd=ROOT, env=ENV).returncode == 0
    state['child_reaped'] = process is None or process.poll() is not None
    RESULT.write_text(json.dumps(state, indent=2) + '\n')
    print(json.dumps(state, indent=2), flush=True)
if state['source_head_after'] != EXPECTED or not state['tracked_tree_clean_after']:
    raise SystemExit(2)
raise SystemExit(state['exit'] if state['exit'] is not None else 2)
