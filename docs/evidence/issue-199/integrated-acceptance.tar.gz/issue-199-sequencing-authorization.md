# Issue199 one-time test sequencing decision

On2026-10-11, the owner was asked whether to accept the disclosed test-first sequencing deviation: the initial regression ran RED before the production fix, but some additional failure-class negatives were qualified after implementation. The20 semantic-negative and20 restored-pass results cannot establish the original per-class pre-fix execution history. The question explicitly retained the full CI gate.

Owner selected verbatim: **“接受时序偏离，保留完整门禁”**.

Accepted scope: only this issue's historical test-execution-order deviation. Preserve every test assertion, capacity/latency threshold, negative-control record, independent review and complete integrated CI requirement. Record the deviation rather than inventing original chronology. This is not a global TDD-rule change, a production-scope reduction, a CI waiver or approval to count invalid observer attempts.

Task1.2 may close under this explicit one-time exception once the qualified behavioral evidence is retained. Tasks3.1/3.4 still require actual completed checks and normal review/merge gates.
