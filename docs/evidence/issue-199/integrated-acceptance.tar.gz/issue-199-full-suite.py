"""One bounded integrated #199 gate; retains output immediately and never retries."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path('/Users/danker/Documents/31308/open-computer-use')
parser = argparse.ArgumentParser()
parser.add_argument('--expected-sha', required=True)
parser.add_argument('--run-id', required=True)
args = parser.parse_args()
if not args.run_id.isalnum() or len(args.expected_sha) != 40:
    raise SystemExit('Invalid immutable run identity')
EXPECTED = args.expected_sha
LOG = Path(f'/tmp/issue-199-full-unit-{args.run_id}.log')
RESULT = Path(f'/tmp/issue-199-full-unit-{args.run_id}.json')
LAUNCH = Path(f'/tmp/issue-199-full-unit-{args.run_id}-launch.json')
INPUTS = (
    'computer-use-server/requirements.txt',
    'computer-use-server/uploads.py',
    'computer-use-server/mcp_resources.py',
    'computer-use-server/app.py',
    'computer-use-server/docker_manager.py',
    'computer-use-server/static/preview.js',
    'computer-use-server/static/locale.js',
    'openwebui/tools/computer_use_tools.py',
    'tests/orchestrator/test_mcp_discovery.py',
    'tests/orchestrator/test_mcp_resources.py',
    'tests/orchestrator/test_lifecycle.py',
    'tests/test_upload_claim.py',
    'tests/test_tools.py',
    'tests/orchestrator/preview_embedding_browser.cjs',
)
ENV = {k: v for k, v in os.environ.items() if k not in {'ALL_PROXY', 'all_proxy', 'HTTP_PROXY', 'http_proxy', 'HTTPS_PROXY', 'https_proxy'}}
UV = ['uv', 'run', '--offline', '--python', '3.12', '--no-project', '--with', 'pytest', '--with', 'pytest-asyncio', '--with-requirements', 'computer-use-server/requirements.txt', '--', 'python']
COMMAND = UV + ['-m', 'pytest', 'tests/', '-vv', '--import-mode=importlib', '--ignore=tests/integration', '--durations=20', '-o', 'faulthandler_timeout=60']

def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, env=ENV, text=True).strip()

def input_hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in INPUTS}

def interrupted(signum, frame):
    raise KeyboardInterrupt('owned suite runner interrupted')

if LOG.exists() or RESULT.exists() or LAUNCH.exists():
    raise SystemExit('Refusing to overwrite retained integrated evidence')
assert head() == EXPECTED
assert subprocess.run(['git', 'diff', '--quiet'], cwd=ROOT, env=ENV).returncode == 0
metadata_code = "import json,sys,platform,importlib.metadata as m;print(json.dumps({'python':sys.version,'platform':platform.platform(),'packages':{n:m.version(n) for n in ['pytest','pytest-asyncio','aiohttp','mcp','fastapi','anyio']}}))"
metadata = json.loads(subprocess.check_output(UV + ['-c', metadata_code], cwd=ROOT, env=ENV, text=True, timeout=60))
state = {'source_head': EXPECTED, 'argv': COMMAND, 'cwd': str(ROOT), 'toolchain': metadata, 'deadline_seconds': 3600, 'log': str(LOG), 'exit': None, 'interrupted': False, 'input_sha256_before': input_hashes(), 'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
process = None
started = time.monotonic()
for number in (signal.SIGINT, signal.SIGTERM):
    signal.signal(number, interrupted)
try:
    with LOG.open('x') as output:
        output.write(json.dumps({'argv': COMMAND, 'source_head': EXPECTED, 'toolchain': metadata}) + '\n')
        output.flush()
        process = subprocess.Popen(COMMAND, cwd=ROOT, env=ENV, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        state.update(runner_pid=os.getpid(), child_pid=process.pid, child_pgid=process.pid)
        LAUNCH.write_text(json.dumps(state, indent=2) + '\n')
        try:
            state['exit'] = process.wait(timeout=3600)
        except (subprocess.TimeoutExpired, KeyboardInterrupt):
            state['interrupted'] = True
            raise
finally:
    for number in (signal.SIGINT, signal.SIGTERM):
        signal.signal(number, signal.SIG_IGN)
    if process is not None and process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)
    state['elapsed_seconds'] = time.monotonic() - started
    state['source_head_after'] = head()
    state['tracked_tree_clean_after'] = subprocess.run(['git', 'diff', '--quiet'], cwd=ROOT, env=ENV).returncode == 0
    state['input_sha256_after'] = input_hashes()
    state['input_hashes_unchanged'] = state['input_sha256_after'] == state['input_sha256_before']
    state['child_reaped'] = process is None or process.poll() is not None
    RESULT.write_text(json.dumps(state, indent=2) + '\n')
    print(json.dumps(state, indent=2), flush=True)
if state['source_head_after'] != EXPECTED or not state['tracked_tree_clean_after'] or not state['input_hashes_unchanged']:
    raise SystemExit(2)
raise SystemExit(state['exit'] if state['exit'] is not None else 2)
