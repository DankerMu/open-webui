# Runtime idle control diagnosis

Attempt1 is inconclusive: 300 successful samples, max22.804041ms, p952.936833ms, zero read errors; loaded phases did not run. Threshold remains10ms. Raw attempt is retained in issue-199-runtime-attempt1.json. Owned process/thread/tree cleanup completed.

Ranked hypotheses before further measurement:

1. Cold first-request setup: predicts initial samples dominate. Refuted by the retained sequence: worst sample is87, at0.505757584s; the next worst is225 at5.638709ms.
2. Reference-host scheduling noise: compatible with an isolated steady-state outlier and no discovery workload, but not proven by these samples. A fresh final-candidate run with idle qualification must still pass the unchanged bound. Host uptime reported load averages4.69/7.11/6.14; this does not establish causation.
3. Probe/reader-path delay: remains possible; the current aggregate sample lacks per-stage timestamps. If the final idle control is also inconclusive, isolate connect/handler/read/close stages rather than relaxing the threshold or retrying until green.

No production fix is inferred from an inconclusive idle control. Defer the next acceptance run until the complete source candidate is frozen; preserve every attempt and disclose the reference-environment limit.
