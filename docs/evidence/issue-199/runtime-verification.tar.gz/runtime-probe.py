#!/usr/bin/env python3
"""Independent issue-199 oracle. Run only against an approved candidate.

The supervisor owns the deadline, evidence and temporary tree. The child imports
real uploads/mcp_resources with only mcp_tools replaced BEFORE import by an
isolated real FastMCP singleton. No scanner, registry, limits or locks are patched.
This is direct FastMCP API coverage, not an HTTP/MCP protocol implementation.
"""
from __future__ import annotations

import argparse
import asyncio
import bisect
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import resource
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import types

PREFIX = "ISSUE199_EVENT "
REASONS = frozenset({"busy", "file_limit", "registry_limit", "entry_limit",
                     "directory_limit", "descriptor_limit", "io_error", "internal_error"})
CONTROL_CHAT = "control"
CONTROL_CONTENT = b"issue199 unrelated chat content\n"
SEED_CONTENT = b"issue199 predecessor snapshot\n"
MIN_SECONDS = 10.0
MIN_SAMPLES = 300
EVENT_LOCK = threading.Lock()


class ProbeFailure(Exception):
    pass


def require(condition, message):
    if not condition:
        raise ProbeFailure(message)


def emit(kind, **payload):
    with EVENT_LOCK:
        print(PREFIX + json.dumps({"kind": kind, **payload}, sort_keys=True), flush=True)


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def inventory_digest(uris):
    return digest_bytes("\n".join(sorted(uris)).encode())


def uri(chat, name):
    # The generated names deliberately use ASCII without escaping. Expectations
    # are independent of production's encoder and scanner.
    return f"file://uploads/{chat}/{name}"


def source_identity(source):
    hashes = {}
    # Hash all Python implementation inputs, including any new error module,
    # but never environment files, credentials or workspace data.
    for path in sorted(source.glob("*.py")):
        hashes[path.name] = digest_bytes(path.read_bytes())
    for name in ("requirements.txt",):
        path = source / name
        if path.is_file():
            hashes[name] = digest_bytes(path.read_bytes())
    return hashes


def environment(source):
    return {
        "platform": platform.platform(), "system": platform.system(),
        "machine": platform.machine(), "processor": platform.processor(),
        "cpu_count": os.cpu_count(), "python": sys.version,
        "python_executable": sys.executable, "mcp": importlib.metadata.version("mcp"),
        "source_path": str(source), "source_sha256": source_identity(source),
        "probe_sha256": digest_bytes(Path(__file__).read_bytes()),
        "monotonic_clock": vars(time.get_clock_info("monotonic")),
        "rlimit_nofile": list(resource.getrlimit(resource.RLIMIT_NOFILE)),
        "percentile": "nearest rank: sorted samples[ceil(0.95*n)-1]",
    }


def merged_intervals(operations, phase):
    # Busy rejection itself is not substantive load. For stress, tiny lists of
    # the two seeded resources are not permitted to qualify the loaded samples.
    intervals = sorted((op["start_ns"], op["end_ns"]) for op in operations
                       if op.get("substantive") and op["phase"] == phase)
    merged = []
    for start, end in intervals:
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return merged


def overlapping_samples(samples, intervals):
    starts = [item[0] for item in intervals]
    selected = []
    for sample in samples:
        # Strict intersection, not merely a timestamp within the phase window.
        i = bisect.bisect_left(starts, sample["end_ns"]) - 1
        if i >= 0 and intervals[i][1] > sample["start_ns"]:
            selected.append(sample)
    return selected


def latency_stats(samples):
    values = sorted((item["end_ns"] - item["start_ns"]) / 1e6
                    for item in samples if item["ok"])
    return {"completed_successful_samples": len(values),
            "p95_ms": values[math.ceil(0.95 * len(values)) - 1] if values else None,
            "max_ms": values[-1] if values else None,
            "failed_samples": sum(not item["ok"] for item in samples)}


class RuntimeProbe:
    def __init__(self, source, root):
        self.source, self.root = source, root
        self.operations = []
        self.server = None
        self.writers = set()
        self.handlers = set()
        self.handler_errors = []
        self.driver = None
        self.driver_stop = None
        self.phase_samples = []
        self.loop = None
        self.mcp = None
        self.mr = None
        self.ListResourcesResult = None
        self.expected = {uri(CONTROL_CHAT, "read.txt"), uri("large", "seed.txt")}
        self.load_bases = {}
        self.generations = {"load-a": "a", "load-b": "a"}
        self.phases = []
        self.operation_id = 0

    def create_files(self, chat, names, content):
        directory = self.root / chat / "outputs"
        directory.mkdir(parents=True, exist_ok=True)
        for name in names:
            (directory / name).write_bytes(content)
        return directory

    async def read_exact(self, resource_uri, expected):
        items = list(await self.mcp.read_resource(resource_uri))
        require(len(items) == 1, f"read returned {len(items)} contents: {resource_uri}")
        actual = items[0].content
        require(actual == expected.decode("utf-8"), f"resource content mismatch: {resource_uri}")
        require(items[0].mime_type == "text/plain", f"text MIME mismatch: {resource_uri}")

    async def serve(self, reader, writer):
        self.writers.add(writer)
        task = asyncio.current_task()
        self.handlers.add(task)
        try:
            request = await asyncio.wait_for(reader.readline(), timeout=2)
            require(request == b"read-control\n", "invalid loopback request")
            await self.read_exact(uri(CONTROL_CHAT, "read.txt"), CONTROL_CONTENT)
            writer.write(CONTROL_CONTENT)
            await writer.drain()
        except Exception as exc:
            error = {"type": type(exc).__qualname__, "message": str(exc)}
            self.handler_errors.append(error)
            emit("handler_error", **error)
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except (ConnectionError, OSError):
                pass
            self.writers.discard(writer)
            self.handlers.discard(task)

    def start_driver(self, phase):
        require(self.driver is None, "driver already active")
        stop = threading.Event()
        samples = []
        port = self.server.sockets[0].getsockname()[1]

        def drive():
            sequence = 0
            while not stop.is_set():
                sequence += 1
                sample = {"phase": phase, "sequence": sequence,
                          "start_ns": time.monotonic_ns(), "ok": False}
                try:
                    with socket.create_connection(("127.0.0.1", port), timeout=0.75) as sock:
                        sock.sendall(b"read-control\n")
                        data = bytearray()
                        while len(data) < len(CONTROL_CONTENT):
                            chunk = sock.recv(len(CONTROL_CONTENT) - len(data))
                            if not chunk:
                                break
                            data.extend(chunk)
                        # EOF confirms that the reply has no ignored trailing bytes.
                        trailing = sock.recv(1)
                        sample["end_ns"] = time.monotonic_ns()
                        require(bytes(data) == CONTROL_CONTENT and trailing == b"",
                                "loopback read returned wrong or additional content")
                        sample["ok"] = True
                except Exception as exc:
                    sample.setdefault("end_ns", time.monotonic_ns())
                    sample["error_type"] = type(exc).__qualname__
                    sample["error"] = str(exc)
                samples.append(sample)
                emit("read_sample", **sample)
                # Explicit driver pacing is outside the measured request interval.
                stop.wait(0.003)

        self.phase_samples = samples
        self.driver_stop = stop
        self.driver = threading.Thread(target=drive, name=f"issue199-reader-{phase}", daemon=True)
        self.driver.start()

    async def stop_driver(self):
        if self.driver is None:
            return
        self.driver_stop.set()
        await asyncio.to_thread(self.driver.join, 2)
        require(not self.driver.is_alive(), "loopback reader thread did not stop")
        self.driver = None
        self.driver_stop = None

    async def sync(self, phase, chat, entrypoint, expected_count=None, failure_reasons=None):
        self.operation_id += 1
        op = {"id": self.operation_id, "phase": phase, "operation": "sync",
              "chat": chat, "entrypoint": entrypoint, "start_ns": time.monotonic_ns()}
        emit("operation_started", **op)
        try:
            try:
                if entrypoint == "async":
                    result = await self.mr.sync_chat_resources(chat)
                else:
                    result = await asyncio.to_thread(self.mr.sync_chat_resources_sync, chat)
            except Exception as exc:
                op.update(end_ns=time.monotonic_ns(), outcome="failed",
                          exception_type=f"{type(exc).__module__}.{type(exc).__qualname__}",
                          reason=getattr(exc, "reason", None))
                require(type(exc).__module__ != "builtins" and op["reason"] in REASONS,
                        f"discovery did not return a typed fixed-reason failure: {op}")
                op["substantive"] = op["reason"] != "busy"
                if op["reason"] != "busy":
                    require(failure_reasons is not None and op["reason"] in failure_reasons,
                            f"unexpected discovery failure: {op}")
                return op
            op.update(end_ns=time.monotonic_ns(), outcome="accepted", result_count=result,
                      substantive=True)
            require(type(result) is int, f"sync must return an int, not {type(result).__name__}")
            require(failure_reasons is None, f"rejected-tree sync silently succeeded/truncated: {op}")
            require(result == expected_count, f"incomplete synchronization: {op}, expected {expected_count}")
            return op
        except BaseException as exc:
            op.setdefault("end_ns", time.monotonic_ns())
            op["oracle_error"] = f"{type(exc).__qualname__}: {exc}"
            raise
        finally:
            op.setdefault("end_ns", time.monotonic_ns())
            self.operations.append(op)
            emit("operation", **op)

    def assert_inventory(self, actual, loaded):
        require(len(actual) == len(set(actual)), "MCP list contains duplicate URIs")
        observed = set(actual)
        if not loaded:
            require(observed == self.expected,
                    f"snapshot changed: missing={sorted(self.expected-observed)[:5]}, "
                    f"unexpected={sorted(observed-self.expected)[:5]}")
            return {}
        remainder = observed - self.expected
        variants = {}
        for chat in ("load-a", "load-b"):
            base = self.load_bases[chat]
            members = {item for item in remainder if item.startswith(f"file://uploads/{chat}/")}
            choices = {generation: base | {uri(chat, f"generation-{generation}.txt")}
                       for generation in ("a", "b")}
            matching = [generation for generation, expected in choices.items() if members == expected]
            require(len(matching) == 1, f"partial or unexpected {chat} MCP snapshot: {len(members)} resources")
            variants[chat] = matching[0]
            remainder -= members
        require(not remainder and self.expected <= observed and len(actual) == 20000,
                f"global snapshot incomplete/overflow: {len(actual)} resources, extra={sorted(remainder)[:5]}")
        return variants

    async def listing(self, phase, loaded=False, include_inventory=False):
        self.operation_id += 1
        op = {"id": self.operation_id, "phase": phase, "operation": "list",
              "start_ns": time.monotonic_ns(), "substantive": loaded}
        emit("operation_started", **op)
        try:
            results = await self.mcp.list_resources()
            # Use actual protocol result serialization as well as actual FastMCP
            # conversion. This adds the bounded full-list serialization cost.
            serialized = self.ListResourcesResult(resources=results).model_dump_json(by_alias=True)
            op["end_ns"] = time.monotonic_ns()
            def validate_actual_result():
                actual = [str(item.uri) for item in results]
                require(all(item.mimeType == "text/plain" for item in results), "listed text MIME mismatch")
                variants = self.assert_inventory(actual, loaded)
                encoded = serialized.encode("utf-8")
                summary = {"outcome": "accepted", "result_count": len(actual),
                           "inventory_sha256": inventory_digest(actual), "variants": variants,
                           "serialized_bytes": len(encoded),
                           "serialized_sha256": digest_bytes(encoded)}
                if include_inventory:
                    emit("inventory", phase=phase, uris=sorted(actual), sha256=summary["inventory_sha256"])
                return summary

            # Oracle set comparisons, sorting and hashing are not production
            # list latency and must not artificially block the measured loop.
            summary = await asyncio.to_thread(validate_actual_result)
            op.update(summary)
            variants = summary["variants"]
            return variants
        except BaseException as exc:
            op["oracle_error"] = f"{type(exc).__qualname__}: {exc}"
            raise
        finally:
            op.setdefault("end_ns", time.monotonic_ns())
            self.operations.append(op)
            emit("operation", **op)

    async def must_sync(self, chat, count, entrypoint="async"):
        op = await self.sync("setup", chat, entrypoint, expected_count=count)
        require(op["outcome"] == "accepted", f"serial setup unexpectedly busy: {op}")

    async def must_reject(self, chat, reasons, loaded=False):
        op = await self.sync("capacity-check", chat, "worker", failure_reasons=reasons)
        require(op.get("reason") in reasons, f"capacity check was not admitted: {op}")
        await self.listing("capacity-check", loaded=loaded)

    async def idle(self):
        phase = "idle-control"
        start = time.monotonic_ns()
        emit("phase_started", phase=phase, start_ns=start)
        self.start_driver(phase)
        try:
            while len(self.phase_samples) < MIN_SAMPLES and (time.monotonic_ns()-start)/1e9 < 15:
                await asyncio.sleep(0.01)
        finally:
            await self.stop_driver()
        stats = latency_stats(self.phase_samples)
        row = {"phase": phase, "start_ns": start, "end_ns": time.monotonic_ns(), **stats}
        qualified = stats["completed_successful_samples"] >= MIN_SAMPLES and stats["failed_samples"] == 0
        qualified = qualified and stats["max_ms"] <= 10
        row["status"] = "qualified" if qualified else "inconclusive"
        self.phases.append(row)
        emit("phase_result", **row)
        require(qualified, "idle environment did not qualify (300 successes, zero errors, max <=10ms)")

    async def loaded_phase(self, phase, producers, loaded):
        start = time.monotonic_ns()
        emit("phase_started", phase=phase, start_ns=start)
        stop = asyncio.Event()
        self.start_driver(phase)

        async def produce(chat, entrypoint, count):
            while not stop.is_set():
                if loaded:
                    # Distinguishable same-cardinality generations catch partial
                    # removal/insertion during actual worker publication.
                    old = self.generations[chat]
                    new = "b" if old == "a" else "a"
                    directory = self.root / chat / "outputs"
                    await asyncio.to_thread(os.replace, directory / f"generation-{old}.txt",
                                            directory / f"generation-{new}.txt")
                    self.generations[chat] = new
                    await self.sync(phase, chat, entrypoint, expected_count=count)
                else:
                    await self.sync(phase, chat, entrypoint, failure_reasons={"file_limit", "entry_limit"})
                await asyncio.sleep(0.002)

        async def lists():
            while not stop.is_set():
                await self.listing(phase, loaded=loaded)
                await asyncio.sleep(0 if loaded else 0.01)

        tasks = [asyncio.create_task(produce(*producer)) for producer in producers]
        tasks.append(asyncio.create_task(lists()))
        try:
            while True:
                for task in tasks:
                    if task.done():
                        task.result()
                        raise ProbeFailure("workload task ended before phase completion")
                intervals = merged_intervals(self.operations, phase)
                selected = overlapping_samples(self.phase_samples, intervals)
                elapsed = (time.monotonic_ns() - start) / 1e9
                span = (intervals[-1][1] - intervals[0][0]) / 1e9 if intervals else 0
                active_seconds = sum(end-begin for begin, end in intervals) / 1e9
                if (elapsed >= MIN_SECONDS and span >= MIN_SECONDS and active_seconds >= MIN_SECONDS
                        and sum(s["ok"] for s in selected) >= MIN_SAMPLES):
                    break
                require(elapsed < 45, f"{phase}: insufficient sustained substantive workload/read overlap")
                await asyncio.sleep(0.1)
        finally:
            stop.set()
            # On ordinary failure let admitted calls finish; the independent
            # supervisor terminates the owned process if this cannot complete.
            outcomes = await asyncio.gather(*tasks, return_exceptions=True)
            await self.stop_driver()
            emit("workload_task_results", phase=phase,
                 errors=[f"{type(e).__qualname__}: {e}" for e in outcomes if isinstance(e, BaseException)])
        end = time.monotonic_ns()
        errors = [e for e in outcomes if isinstance(e, BaseException)]
        intervals = merged_intervals(self.operations, phase)
        selected = overlapping_samples(self.phase_samples, intervals)
        stats = latency_stats(selected)
        operations = [op for op in self.operations if op["phase"] == phase]
        syncs = [op for op in operations if op["operation"] == "sync"]
        counts = {}
        for op in syncs:
            key = f"{op['entrypoint']}:{op.get('reason', op.get('outcome', 'unknown'))}"
            counts[key] = counts.get(key, 0) + 1
        row = {"phase": phase, "start_ns": start, "end_ns": end,
               "elapsed_seconds": (end-start)/1e9, **stats,
               "total_read_samples": len(self.phase_samples),
               "nonoverlapping_read_samples": len(self.phase_samples)-len(selected),
               "failed_total_read_samples": sum(not sample["ok"] for sample in self.phase_samples),
               "substantive_busy_intervals_ns": intervals,
               "substantive_busy_seconds": sum(b-a for a,b in intervals)/1e9,
               "substantive_span_seconds": (intervals[-1][1]-intervals[0][0])/1e9 if intervals else 0,
               "sync_outcomes": counts, "list_count": sum(op["operation"] == "list" for op in operations),
               "status": "failed"}
        self.phases.append(row)
        emit("phase_result", **row)
        require(not errors, f"{phase}: workload error: {errors}")
        require(intervals and row["substantive_span_seconds"] >= MIN_SECONDS
                and row["substantive_busy_seconds"] >= MIN_SECONDS,
                f"{phase}: fewer than ten substantive workload seconds or no sustained overlap")
        require(stats["completed_successful_samples"] >= MIN_SAMPLES,
                f"{phase}: fewer than 300 completed overlapping reads")
        require(row["failed_total_read_samples"] == 0, f"{phase}: external read failures")
        require(stats["p95_ms"] <= 250 and stats["max_ms"] <= 500,
                f"{phase}: loaded latency exceeded thresholds: {stats}")
        for entrypoint in ("async", "worker"):
            admitted = [op for op in syncs if op["entrypoint"] == entrypoint and op.get("substantive")]
            require(len(admitted) >= 2, f"{phase}: {entrypoint} did not make repeated admitted progress")
        require(row["list_count"] >= 2, f"{phase}: actual lists were not repeated")
        row["status"] = "passed"
        emit("phase_result", **row)

    async def run(self):
        self.loop = asyncio.get_running_loop()
        require(not any(name in sys.modules for name in ("uploads", "mcp_resources", "mcp_tools")),
                "candidate modules were imported before singleton isolation")
        os.environ["BASE_DATA_DIR"] = str(self.root)
        sys.path.insert(0, str(self.source))
        from mcp.server.fastmcp import FastMCP
        from mcp.types import ListResourcesResult
        self.ListResourcesResult = ListResourcesResult
        singleton = types.ModuleType("mcp_tools")
        singleton.mcp = FastMCP("issue199-independent-runtime-oracle")
        sys.modules["mcp_tools"] = singleton
        import mcp_resources
        import uploads
        self.mcp, self.mr = singleton.mcp, mcp_resources
        require(Path(uploads.__file__).resolve() == (self.source / "uploads.py").resolve(),
                "wrong uploads source imported")
        require(Path(mcp_resources.__file__).resolve() == (self.source / "mcp_resources.py").resolve(),
                "wrong discovery source imported")
        require(uploads.BASE_DATA_DIR == self.root, "real upload data root was not isolated")
        identity = environment(self.source)
        require(identity["mcp"] == "1.27.0", "MCP pin must be 1.27.0")
        emit("environment", **identity)
        await asyncio.to_thread(self.create_files, CONTROL_CHAT, ["read.txt"], CONTROL_CONTENT)
        await asyncio.to_thread(self.create_files, "large", ["seed.txt"], SEED_CONTENT)
        await self.must_sync(CONTROL_CHAT, 1)
        await self.must_sync("large", 1, "worker")
        await self.listing("seed-snapshot", include_inventory=True)
        await self.read_exact(uri("large", "seed.txt"), SEED_CONTENT)
        self.server = await asyncio.start_server(self.serve, "127.0.0.1", 0)
        await self.idle()

        # Exactly 100000 real regular files, including the retained seed. The
        # predecessor is never cleared or privately modified by the probe.
        await asyncio.to_thread(self.create_files, "large",
                                (f"f{i:06}.txt" for i in range(99999)), b"stress-file-content\n")
        emit("filesystem_fixture", chat="large", visible_regular_files=100000,
             seed_uri=uri("large", "seed.txt"), seed_content_sha256=digest_bytes(SEED_CONTENT))
        await self.loaded_phase("100000-file-explicit-rejection",
                                [("large", "async", None), ("large", "worker", None)], loaded=False)
        await self.listing("preserved-big-tree-snapshot", include_inventory=True)
        await self.read_exact(uri("large", "seed.txt"), SEED_CONTENT)
        await self.read_exact(uri(CONTROL_CHAT, "read.txt"), CONTROL_CONTENT)

        for chat, count in (("load-a", 10000), ("load-b", 9998)):
            names = [f"f{i:05}.txt" for i in range(count-1)]
            self.load_bases[chat] = {uri(chat, name) for name in names}
            await asyncio.to_thread(self.create_files, chat, names, f"{chat} ordinary file\n".encode())
            await asyncio.to_thread(self.create_files, chat, ["generation-a.txt"], f"{chat} sentinel\n".encode())
            await self.must_sync(chat, count, "async" if chat == "load-a" else "worker")
        await self.listing("exact-global-capacity", loaded=True, include_inventory=True)
        # Capacity contains control(1), preserved seed(1), A(10000), B(9998).
        await asyncio.to_thread(self.create_files, "load-a", ["overflow.txt"], b"overflow\n")
        await self.must_reject("load-a", {"file_limit"}, loaded=True)
        (self.root / "load-a" / "outputs" / "overflow.txt").unlink()
        await asyncio.to_thread(self.create_files, "overflow-chat", ["overflow.txt"], b"overflow\n")
        await self.must_reject("overflow-chat", {"registry_limit"}, loaded=True)
        emit("capacity_checks", global_resources=20000, per_chat_exact=10000,
             per_chat_overflow_rejected=True, global_overflow_rejected=True,
             unrelated_and_seed_resources_included=True, silent_truncation_allowed=False)
        await self.loaded_phase("multichat-sync-and-list-at-20000",
                                [("load-a", "async", 10000), ("load-b", "worker", 9998)], loaded=True)
        variants = await self.listing("final-inventory", loaded=True, include_inventory=True)
        # With producers finished, registry generations must match the physical
        # files. A final busy call leaving unpublished bytes cannot qualify.
        for chat, count in (("load-a", 10000), ("load-b", 9998)):
            await self.must_sync(chat, count, "worker")
            await self.read_exact(uri(chat, f"generation-{self.generations[chat]}.txt"),
                                  f"{chat} sentinel\n".encode())
            await self.read_exact(uri(chat, "f00000.txt"), f"{chat} ordinary file\n".encode())
        variants = await self.listing("settled-final-inventory", loaded=True, include_inventory=True)
        require(variants == self.generations, "final registered generations differ from filesystem")
        await self.read_exact(uri("large", "seed.txt"), SEED_CONTENT)
        await self.read_exact(uri(CONTROL_CHAT, "read.txt"), CONTROL_CONTENT)
        require(not self.handler_errors, "loopback server reported read/content errors")
        require(source_identity(self.source) == identity["source_sha256"], "source changed during measurement")
        emit("content_checks", control_exact=True, preserved_seed_exact=True,
             multichat_ordinary_and_sentinel_exact=True, global_resources=20000)

    async def cleanup(self):
        await self.stop_driver()
        if self.server is not None:
            self.server.close()
            await self.server.wait_closed()
        for writer in tuple(self.writers):
            writer.close()
        if self.writers:
            await asyncio.gather(*(writer.wait_closed() for writer in tuple(self.writers)),
                                 return_exceptions=True)
        if self.handlers:
            await asyncio.gather(*tuple(self.handlers), return_exceptions=True)
        emit("child_cleanup", driver_stopped=self.driver is None,
             server_closed=self.server is None or not self.server.is_serving(),
             remaining_connections=len(self.writers))
        require(self.driver is None and (self.server is None or not self.server.is_serving())
                and not self.writers and not self.handlers, "owned runtime resources did not finish cleanup")


async def child_main(source, root):
    probe = RuntimeProbe(source, root)
    status = "passed"
    try:
        await probe.run()
    except BaseException as exc:
        status = "inconclusive" if probe.phases and probe.phases[-1]["status"] == "inconclusive" else "failed"
        emit("failure", type=type(exc).__qualname__, message=str(exc), traceback=traceback.format_exc())
    finally:
        try:
            await probe.cleanup()
        except BaseException as exc:
            status = "failed"
            emit("failure", type=type(exc).__qualname__, message=f"cleanup: {exc}")
        emit("finished", status=status)
    return 0 if status == "passed" else 1


def stop_owned_process(process):
    if process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=5)
    return process.returncode


def write_report(path, report):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".issue199-{os.getpid()}.tmp")
    try:
        temporary.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def supervise(args, source):
    start = time.monotonic_ns()
    report = {"schema": "issue199-runtime-probe-v1", "status": "failed",
              "invocation": sys.argv, "source": str(source), "deadline_seconds": args.deadline,
              "start_ns": start, "events": [], "child_output": [],
              "requirements": {"loaded_seconds_each": MIN_SECONDS, "completed_overlapping_reads_each": MIN_SAMPLES,
                               "idle_samples": MIN_SAMPLES, "idle_max_ms": 10,
                               "loaded_p95_ms": 250, "loaded_max_ms": 500},
              "boundary": "Real temporary filesystem, uploads/mcp_resources, actual FastMCP list/read and full list result serialization; external-thread TCP loopback read driver. Isolated singleton only; no registry/scanner/admission patching. Not full ASGI, MCP HTTP wire transport, Docker, LAN or Linux certification."}
    process = None
    collector = None
    root = None
    try:
        root = Path(tempfile.mkdtemp(prefix="issue199-runtime-"))
        report["owned_data_root"] = str(root)
        report["environment"] = {
            "platform": platform.platform(), "machine": platform.machine(),
            "python": sys.version, "python_executable": sys.executable,
            "source_sha256": source_identity(source),
            "probe_sha256": digest_bytes(Path(__file__).read_bytes()),
        }
        try:
            report["environment"]["mcp"] = importlib.metadata.version("mcp")
        except importlib.metadata.PackageNotFoundError:
            report["environment"]["mcp"] = None
        command = [sys.executable, str(Path(__file__).resolve()), "--_child", "--source", str(source),
                   "--report", str(args.report), "--deadline", str(args.deadline), "--_data-root", str(root)]
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                   text=True, bufsize=1, start_new_session=True)

        def collect():
            for line in process.stdout:
                if line.startswith(PREFIX):
                    try:
                        report["events"].append(json.loads(line[len(PREFIX):]))
                    except (ValueError, TypeError) as exc:
                        report.setdefault("collector_errors", []).append(str(exc))
                elif len(report["child_output"]) < 1000:
                    report["child_output"].append(line.rstrip("\n"))
                else:
                    report["omitted_child_output_lines"] = report.get("omitted_child_output_lines", 0) + 1

        collector = threading.Thread(target=collect, name="issue199-evidence-collector", daemon=True)
        collector.start()
        try:
            remaining = max(0.001, args.deadline - (time.monotonic_ns()-start)/1e9)
            process.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            report["failure"] = "independent supervisor deadline exceeded; partial raw evidence retained"
            report["timed_out"] = True
            stop_owned_process(process)
        collector.join(timeout=5)
        require(not collector.is_alive(), "evidence collector did not finish")
        report["exit_code"] = process.returncode
        finishes = [event for event in report["events"] if event["kind"] == "finished"]
        phases = {}
        for event in report["events"]:
            if event["kind"] == "phase_result":
                phases[event["phase"]] = event
        report["phase_results"] = phases
        if not report.get("timed_out") and not report.get("collector_errors") and finishes:
            report["status"] = finishes[-1]["status"]
        required_phases = {"idle-control", "100000-file-explicit-rejection", "multichat-sync-and-list-at-20000"}
        if report["status"] == "passed":
            require(process.returncode == 0 and set(phases) == required_phases,
                    "child passed without complete phases and successful exit")
            require(phases["idle-control"]["status"] == "qualified" and
                    all(phases[p]["status"] == "passed" for p in required_phases - {"idle-control"}),
                    "child passed without qualifying every latency gate")
    except BaseException as exc:
        report["status"] = "failed"
        report["failure"] = f"{type(exc).__qualname__}: {exc}"
        report["traceback"] = traceback.format_exc()
    finally:
        try:
            if process is not None:
                stop_owned_process(process)
            if collector is not None:
                collector.join(timeout=5)
            if process is not None and process.stdout is not None:
                process.stdout.close()
            if root is not None:
                shutil.rmtree(root)
            report["cleanup"] = {"owned_child_reaped": process is None or process.poll() is not None,
                                 "collector_stopped": collector is None or not collector.is_alive(),
                                 "owned_data_removed": root is None or not root.exists()}
        except BaseException as exc:
            report["status"] = "failed"
            report["cleanup_failure"] = f"{type(exc).__qualname__}: {exc}"
        report["end_ns"] = time.monotonic_ns()
        try:
            write_report(args.report, report)
        except BaseException as exc:
            report["status"] = "failed"
            report["report_write_failure"] = f"{type(exc).__qualname__}: {exc}"
        # Stdout is a JSON report even if the explicit report path is unwritable.
        print(json.dumps(report, indent=2, sort_keys=True), flush=True)
    return 0 if report["status"] == "passed" else 1


class JsonArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        raise ProbeFailure(message)


def main():
    args = None
    report_is_safe = False
    try:
        parser = JsonArgumentParser(description=__doc__)
        parser.add_argument("--source", type=Path, required=True,
                            help="explicit source checkout root or computer-use-server directory")
        parser.add_argument("--report", type=Path, required=True, help="explicit JSON evidence path")
        parser.add_argument("--deadline", type=float, default=180,
                            help="independent wall deadline in seconds (30..1800; default 180)")
        parser.add_argument("--_child", action="store_true", help=argparse.SUPPRESS)
        parser.add_argument("--_data-root", type=Path, help=argparse.SUPPRESS)
        args = parser.parse_args()
        require(math.isfinite(args.deadline) and 30 <= args.deadline <= 1800, "deadline must be finite and between 30 and 1800 seconds")
        source = args.source.expanduser().resolve()
        if (source / "computer-use-server").is_dir():
            source = source / "computer-use-server"
        require((source / "uploads.py").is_file() and (source / "mcp_resources.py").is_file(),
                "source must contain real uploads.py and mcp_resources.py")
        args.report = args.report.expanduser().resolve()
        require(not args.report.is_relative_to(source.parent if source.name == "computer-use-server" else source),
                "report must be outside the source checkout")
        report_is_safe = True
        if args._child:
            require(args._data_root is not None and args._data_root.is_dir(), "child requires owned temporary data root")
            return asyncio.run(child_main(source, args._data_root))
        require(args._data_root is None, "data root is supervisor-owned, not caller-provided")
        return supervise(args, source)
    except BaseException as exc:
        report = {"schema": "issue199-runtime-probe-v1", "status": "failed",
                  "failure": f"{type(exc).__qualname__}: {exc}", "invocation": sys.argv}
        if args is not None and not args._child and report_is_safe:
            try:
                write_report(args.report, report)
            except BaseException as write_exc:
                report["report_write_failure"] = str(write_exc)
        if args is not None and args._child:
            emit("failure", **report)
            emit("finished", status="failed")
        else:
            print(json.dumps(report, indent=2, sort_keys=True), flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
