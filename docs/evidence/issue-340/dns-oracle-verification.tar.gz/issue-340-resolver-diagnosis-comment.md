## Resolver backend discriminator

The first event-based candidate, still using unchanged production code and its configured10s deadline, failed with no socket resolver entry (`1 failed` in10.71s). This is retained, not retried away.

A read-only dependency inspection resolved aiohttp3.14.4 with `DefaultResolver=AsyncResolver`. Instrumenting the actual callback connector then established:

| Controlled dependency | Result | Actual boundary |
| --- | --- | --- |
| Environment default | exit1 | `AsyncResolver`; HTTP502/download_failed after10.018s, no intercepted `socket.getaddrinfo` call |
| Test-only selection of aiohttp's real `ThreadedResolver` | exit0 | expected-host entry, HTTP502/download_failed after10.008s while DNS remained blocked; explicit release and resolver return followed; request worker joined |

Both runs exercised the real callback/downloader; only the threaded control reached and passed the retained state/content assertions. The default control stopped at the missing-entry assertion. The only discriminator was the resolver dependency selection; no canned resolution result, production change or deadline relaxation. Exact commands and structured timestamps are retained in `/tmp/issue-340-resolver-{default,threaded}.{log,json}`, with `/tmp/issue_340_resolver_probe.py` and installed-version inspection.

This proves the current environment's backend mismatch: a socket hook does not intercept the native asynchronous resolver. It does not establish the original full run's exact backend or scheduler history. The earlier preamble-delay counterexample remains a possible mechanism, not the attributed natural cause.

The fixture has been revised to explicitly select the real threaded backend in test scope, restore it afterward, retain the configured deadline plus150ms allowance, and make no claim about native asynchronous DNS coverage. Strict validation passed; independent fixture re-review precedes the permanent test adjustment. Historical-bad qualification, restoration and the dedicated S1/S2/S3 stability trials remain required.
