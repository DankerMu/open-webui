#!/usr/bin/env python3
"""Issue #340 one-shot qualification; no live-source writes or automatic retries.

Run with Python 3; the child uses the established offline uv/Python 3.12 command.
Artifacts are retained under OUTPUT_ROOT/ID; disposable copied sources are removed.
A pytest exit of 1 is NOT evidence of a discriminating historical-bad rejection:
inspect result.json classification and telemetry.jsonl as well as pytest.log.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import selectors
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time

SOURCE_DEFAULT = "/Users/danker/Documents/31308/open-computer-use"
TEST = "tests/orchestrator/test_office_callback_processing.py"
FUNCTION = "test_callback_dns_stall_returns_before_resolver_executor_shutdown"
NODE = TEST + "::" + FUNCTION
DOWNLOAD = "computer-use-server/office/download.py"
REQUIREMENTS = "computer-use-server/requirements.txt"

# This is an observation-only plugin, not an alternate fixture or downloader.
PLUGIN = r'''
import ast
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sys
import threading
import time
import pytest

TARGET = "test_callback_dns_stall_returns_before_resolver_executor_shutdown"
TEST = Path(os.environ["ISSUE340_TEST"]).resolve()
NODE = "tests/orchestrator/test_office_callback_processing.py::" + TARGET
OUTPUT = Path(os.environ["ISSUE340_TELEMETRY"])
SCALARS = ("configured_timeout", "deadline_allowance", "readiness_timeout", "cleanup_timeout", "deadline", "elapsed", "resolver_finished")
EVENTS = ("started", "entered", "release", "returned", "completed", "escaped", "entered_or_completed")
TIMES = ("started", "entered", "responded", "released", "returned")
OUTCOME = ("entered", "released", "returned", "escaped")
LATEST = {}
PREVIOUS = None
ASSERTIONS = {}


def emit(kind, **fields):
    with OUTPUT.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps({"kind": kind, "observed_monotonic": time.monotonic(), **fields}, sort_keys=True) + "\n")


def target(frame):
    return frame.f_code.co_name == TARGET and Path(frame.f_code.co_filename).resolve() == TEST


def snapshot(frame):
    local = frame.f_locals
    result = {"line": frame.f_lineno}
    result["scalars"] = {key: local[key] for key in SCALARS if type(local.get(key)) in (bool, int, float)}
    result["events"] = {key: local[key].is_set() for key in EVENTS if isinstance(local.get(key), threading.Event)}
    stamps = local.get("timestamps")
    result["timestamps"] = {key: stamps[key] for key in TIMES if isinstance(stamps, dict) and type(stamps.get(key)) in (int, float)}
    outcome = local.get("outcome")
    result["response_observation"] = {key: outcome[key] for key in OUTCOME if isinstance(outcome, dict) and type(outcome.get(key)) is bool}
    worker = local.get("worker")
    if isinstance(worker, threading.Thread):
        result["worker_alive"] = worker.is_alive()
    calls = local.get("calls")
    if isinstance(calls, list):
        result["expected_resolver_calls"] = calls.count("slow-resolution.example")
        result["unexpected_resolver_calls"] = len(calls) - result["expected_resolver_calls"]
    response = outcome.get("response") if isinstance(outcome, dict) else None
    if response is not None:
        status = getattr(response, "status_code", None)
        if type(status) is int:
            result["response_status"] = status
        try:
            body = response.json()
            reason = body.get("reason") if isinstance(body, dict) else None
            # Never serialize a response body, token, header, or arbitrary string.
            result["response_reason"] = reason if reason in ("download_failed", "download_url_rejected", "file_too_large", "invalid_content") else "<other-or-absent>"
        except Exception:
            result["response_reason"] = "<not-json>"
    return result


def trace(frame, event, arg):
    global LATEST, PREVIOUS
    if not target(frame):
        return None
    if event in ("line", "return", "exception"):
        observed = snapshot(frame)
        LATEST = observed
        # Suppress unchanged line-only snapshots, retaining state transitions.
        comparable = {key: value for key, value in observed.items() if key != "line"}
        if comparable != PREVIOUS or event in ("return", "exception"):
            fields = {"event": event, "snapshot": observed}
            if event == "exception":
                fields["exception_type"] = arg[0].__name__
                fields["assertion_kind"] = ASSERTIONS.get(frame.f_lineno, "other")
            emit("observation", **fields)
            PREVIOUS = comparable
    return trace


def pytest_sessionstart(session):
    tree = ast.parse(TEST.read_text(encoding="utf-8"))
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == TARGET]
    if len(functions) != 1:
        raise RuntimeError("qualification target is not unique")
    expected = {
        "completed.wait(max(0, deadline - time.monotonic()))": "response_deadline",
        "elapsed <= configured_timeout + deadline_allowance": "elapsed_deadline",
        'not outcome["released"] and not outcome["returned"] and not outcome["escaped"]': "response_order",
        "not release.is_set() and not returned.is_set() and not escaped.is_set()": "response_order",
    }
    expressions = {ast.dump(ast.parse(text, mode="eval").body): kind for text, kind in expected.items()}
    for node in ast.walk(functions[0]):
        if isinstance(node, ast.Assert):
            kind = expressions.get(ast.dump(node.test), "other")
            for line in range(node.lineno, node.end_lineno + 1):
                ASSERTIONS[line] = kind
    packages = sorted((dist.metadata.get("Name", "<unnamed>"), dist.version) for dist in importlib.metadata.distributions())
    import aiohttp.resolver
    resolver = aiohttp.resolver.DefaultResolver
    executable = Path(sys.executable).resolve()
    emit("toolchain", python=sys.version, executable=str(executable), executable_sha256=hashlib.sha256(executable.read_bytes()).hexdigest(), platform=platform.platform(), packages=packages, aiohttp_default_resolver=resolver.__module__ + "." + resolver.__qualname__)


def pytest_collection_finish(session):
    emit("collection", nodes=[item.nodeid for item in session.items])


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    if item.nodeid != NODE:
        yield
        return
    previous = sys.gettrace()
    emit("call_start", node=item.nodeid, prior_trace_present=previous is not None)
    if previous is not None:
        raise RuntimeError("qualification refuses to replace an existing trace")
    sys.settrace(trace)
    try:
        yield
    finally:
        sys.settrace(previous)
        emit("call_end", snapshot=LATEST)


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    result = yield
    report = result.get_result()
    fields = {"node": item.nodeid, "phase": report.when, "outcome": report.outcome, "duration": report.duration}
    if call.excinfo is not None:
        fields["exception_type"] = call.excinfo.type.__name__
        # No traceback text or arbitrary exception value/local repr is emitted.
        for entry in call.excinfo.traceback:
            if Path(str(entry.path)).resolve() == TEST and entry.frame.code.name == TARGET:
                fields["failure_line"] = entry.lineno + 1
                fields["assertion_kind"] = ASSERTIONS.get(entry.lineno + 1, "other")
    emit("report", **fields)


def pytest_sessionfinish(session, exitstatus):
    emit("session_finish", exitstatus=int(exitstatus))
'''


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def tracked(source):
    result = subprocess.run(["git", "-C", str(source), "ls-files", "-z"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
    return sorted(os.fsdecode(name) for name in result.stdout.split(b"\0") if name)


def selected(name):
    path = Path(name)
    parts = path.parts
    excluded = {".git", ".run", "node_modules", "__pycache__", ".pytest_cache", ".ruff_cache", ".venv", "secrets", ".secrets"}
    if path.is_absolute() or ".." in parts or excluded.intersection(parts):
        return False
    if any(part.lower().startswith(".env") for part in parts):
        return False
    if any(part.lower() in {"credentials", ".credentials", ".ssh", ".aws", ".gnupg"} for part in parts):
        return False
    if path.name.lower().startswith(("id_rsa", "id_ed25519", "credentials.", "secrets.")):
        return False
    if path.suffix.lower() in {".pem", ".key", ".p12", ".pfx", ".keystore", ".pyc"}:
        return False
    return name.startswith(("computer-use-server/", "tests/orchestrator/")) or name in {
        "tests/__init__.py", "conftest.py", "pytest.ini", "pyproject.toml", "setup.cfg", "tox.ini",
    }


def stable_bytes(source, name):
    path = source / name
    # Reject even in-tree symlinks: copied inputs must not read outside the scope.
    for parent in path.parents:
        if parent == source:
            break
        if parent.is_symlink():
            raise RuntimeError("symlink input parent: " + name)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise RuntimeError("non-regular input: " + name)
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            data = stream.read()
        after = os.fstat(descriptor)
        current = path.lstat()
        identity = lambda row: (row.st_dev, row.st_ino, row.st_size, row.st_mtime_ns, row.st_ctime_ns, row.st_mode)
        if identity(before) != identity(after) or identity(after) != identity(current):
            raise RuntimeError("input changed while reading: " + name)
        return data, stat.S_IMODE(before.st_mode)
    finally:
        os.close(descriptor)


def input_manifest(root, names):
    manifest = {}
    for name in names:
        data, mode = stable_bytes(root, name)
        manifest[name] = {"sha256": digest(data), "mode": mode, "size": len(data)}
    return manifest


def snapshot(source, copy):
    inventory = tracked(source)
    names = [name for name in inventory if selected(name)]
    if not {TEST, DOWNLOAD, REQUIREMENTS}.issubset(names):
        raise RuntimeError("required tracked input missing")
    before = {}
    for name in names:
        data, mode = stable_bytes(source, name)
        before[name] = {"sha256": digest(data), "mode": mode, "size": len(data)}
        target = copy / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        target.chmod(mode)
    if tracked(source) != inventory or input_manifest(source, names) != before:
        raise RuntimeError("source inventory/content changed during snapshot; no retry")
    if input_manifest(copy, names) != before:
        raise RuntimeError("copy identity differs from source")
    return names, before, [name for name in inventory if name not in names]


def mutate_historical(copy):
    path = copy / DOWNLOAD
    data = path.read_bytes()
    text = data.decode("utf-8")
    tree = ast.parse(text)
    definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "fetch_callback_content"]
    if len(definitions) != 1:
        raise RuntimeError("fetch_callback_content is not a unique top-level function")
    node = definitions[0]
    expected = ast.parse('''def fetch_callback_content(url: str, loop: asyncio.AbstractEventLoop) -> bytes:
    target = confined_internal_url(url)
    if loop.is_closed() or loop.is_running() is False:
        raise DownloadFailed("callback download loop is unavailable")
    future = asyncio.run_coroutine_threadsafe(_download(target), loop)
    try:
        return future.result(timeout=commands.HTTP_TIMEOUT_SECONDS)
    except FutureTimeoutError as extra:
        future.cancel()
        raise DownloadFailed("callback download transfer failed") from extra
    except FutureCancelledError as extra:
        raise DownloadFailed("callback download transfer failed") from extra
''').body[0]
    if ast.dump(node) != ast.dump(expected):
        raise RuntimeError("production function signature/body drift; historical mutation refused")
    lines = data.splitlines(keepends=True)
    start = node.body[0].lineno - 1
    end = node.end_lineno
    prefix = b"".join(lines[:start])
    suffix = b"".join(lines[end:])
    replacement = b"    target = confined_internal_url(url)\n    return asyncio.run(_download(target))\n"
    mutated = prefix + replacement + suffix
    ast.parse(mutated.decode("utf-8"))
    path.write_bytes(mutated)
    # Verify all other top-level definitions/imports remain identical.
    after = ast.parse(mutated.decode("utf-8"))
    original_other = [ast.dump(item) for item in tree.body if item is not node]
    mutated_other = [ast.dump(item) for item in after.body if not (isinstance(item, ast.FunctionDef) and item.name == node.name)]
    if original_other != mutated_other:
        raise RuntimeError("historical mutation touched another definition")
    return {"file": DOWNLOAD, "body_start_line": start + 1, "body_end_line": end, "before_sha256": digest(data), "after_sha256": digest(mutated), "replacement": replacement.decode("ascii")}


def group_exists(group):
    try:
        os.killpg(group, 0)
        return True
    except ProcessLookupError:
        return False


def stop_group(process):
    stages = []
    for sig, allowance in ((signal.SIGTERM, 3), (signal.SIGKILL, 3)):
        if not group_exists(process.pid):
            break
        os.killpg(process.pid, sig)
        stages.append(sig.name)
        deadline = time.monotonic() + allowance
        while group_exists(process.pid) and time.monotonic() < deadline:
            process.poll()
            time.sleep(0.05)
    process.wait(timeout=3)
    if group_exists(process.pid):
        raise ContainmentFailure("owned process group survived bounded termination")
    return stages


def run_stream(command, cwd, env, log_path, wall_timeout):
    process = None
    shutdown = []
    interrupted = None
    started = time.monotonic()
    signals = {signal.SIGINT, signal.SIGTERM}
    # Pending cancellation is delivered only after ownership is recorded.
    with log_path.open("wb") as log:
        prior_mask = signal.pthread_sigmask(signal.SIG_BLOCK, signals)
        try:
            # Runner has no threads; unblock cancellation in the forked child
            # before exec so TERM remains an effective bounded shutdown stage.
            process = subprocess.Popen(command, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True, bufsize=0, preexec_fn=lambda: signal.pthread_sigmask(signal.SIG_SETMASK, prior_mask))
            signal.pthread_sigmask(signal.SIG_SETMASK, prior_mask)
            os.set_blocking(process.stdout.fileno(), False)
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ)
                while selector.get_map():
                    if time.monotonic() - started >= wall_timeout:
                        interrupted = "wall_timeout"
                        break
                    for key, _events in selector.select(timeout=0.2):
                        chunk = os.read(key.fd, 65536)
                        if not chunk:
                            selector.unregister(key.fileobj)
                            continue
                        log.write(chunk)
                        log.flush()
                        sys.stdout.buffer.write(chunk)
                        sys.stdout.buffer.flush()
                if interrupted is None and process.poll() is None:
                    try:
                        process.wait(timeout=max(0.01, wall_timeout - (time.monotonic() - started)))
                    except subprocess.TimeoutExpired:
                        interrupted = "wall_timeout"
        except RunnerInterrupted:
            interrupted = "runner_signal"
        finally:
            signal.pthread_sigmask(signal.SIG_BLOCK, signals)
            try:
                if process is not None:
                    try:
                        if group_exists(process.pid):
                            shutdown += stop_group(process)
                        else:
                            process.wait(timeout=3)
                    except Exception as error:
                        raise ContainmentFailure("owned process group could not be stopped/reaped") from error
                    # Retain buffered output after shutdown; never wait for EOF
                    # from an escaped descendant holding a copied pipe open.
                    os.set_blocking(process.stdout.fileno(), False)
                    drain_deadline = time.monotonic() + 0.5
                    while time.monotonic() < drain_deadline:
                        try:
                            chunk = os.read(process.stdout.fileno(), 65536)
                        except BlockingIOError:
                            break
                        if not chunk:
                            break
                        log.write(chunk)
                        sys.stdout.buffer.write(chunk)
                    log.flush()
                    sys.stdout.buffer.flush()
                    process.stdout.close()
            finally:
                signal.pthread_sigmask(signal.SIG_SETMASK, prior_mask)
    return {"child_exit": process.returncode if process is not None else None, "wall_seconds": time.monotonic() - started, "interrupted": interrupted, "shutdown_signals": shutdown}


def classify(mode, execution, records):
    if execution.get("interrupted") or execution.get("shutdown_signals"):
        return "invalid_process_shutdown"
    collection = [record for record in records if record["kind"] == "collection"]
    if len(collection) != 1 or collection[0]["nodes"] != [NODE]:
        return "invalid_collection"
    reports = [record for record in records if record["kind"] == "report"]
    by_phase = {report["phase"]: report for report in reports}
    if len(reports) != 3 or any(by_phase.get(phase, {}).get("outcome") != "passed" for phase in ("setup", "teardown")):
        return "invalid_setup_or_teardown"
    final = next((record["snapshot"] for record in reversed(records) if record["kind"] == "call_end"), {})
    events = final.get("events", {})
    scalars = final.get("scalars", {})
    if scalars.get("configured_timeout") != 10 or scalars.get("deadline_allowance") != 0.15:
        return "invalid_timeout_contract"
    if not events.get("entered"):
        return "invalid_missing_resolver_entry"
    cleaned = all(events.get(key) for key in ("release", "returned", "completed")) and events.get("escaped") is False and final.get("worker_alive") is False
    if not cleaned:
        return "invalid_cleanup_or_emergency_escape"
    stamps = final.get("timestamps", {})
    if not all(key in stamps for key in ("started", "entered", "released", "returned")):
        return "invalid_missing_timestamps"
    if not stamps["started"] <= stamps["entered"] <= stamps["released"] <= stamps["returned"]:
        return "invalid_event_order"
    call = by_phase.get("call", {})
    if mode == "historical-bad":
        failure = next((record for record in reversed(records) if record["kind"] == "observation" and record.get("event") == "exception" and record.get("assertion_kind") == call.get("assertion_kind")), {})
        observed = failure.get("snapshot", {}).get("events", {})
        held_at_failure = observed.get("entered") is True and all(observed.get(key) is False for key in ("release", "returned", "escaped"))
        semantic = call.get("exception_type") == "AssertionError" and call.get("assertion_kind") in ("response_deadline", "elapsed_deadline", "response_order")
        if execution["child_exit"] == 1 and call.get("outcome") == "failed" and semantic and held_at_failure:
            return "expected_semantic_rejection"
        return "invalid_bad_control_rejection"
    observation = final.get("response_observation", {})
    order = observation.get("entered") is True and all(observation.get(key) is False for key in ("released", "returned", "escaped"))
    timely = "responded" in stamps and stamps["entered"] <= stamps["responded"] <= stamps["released"] and stamps["responded"] - stamps["started"] <= scalars["configured_timeout"] + scalars["deadline_allowance"]
    refusal = final.get("response_status") == 502 and final.get("response_reason") == "download_failed"
    if execution["child_exit"] == 0 and call.get("outcome") == "passed" and order and timely and refusal:
        return "known_good_pass"
    return "invalid_known_good_observation"


class ContainmentFailure(RuntimeError):
    pass


class RunnerInterrupted(RuntimeError):
    pass


def interrupt(signum, _frame):
    raise RunnerInterrupted("runner interrupted by " + signal.Signals(signum).name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", required=True, choices=("good", "historical-bad"))
    parser.add_argument("--id", required=True, help="unique retained result ID, e.g. G1, BAD, RESTORED, S1, S2, S3")
    parser.add_argument("--source", type=Path, default=Path(SOURCE_DEFAULT))
    parser.add_argument("--output-root", type=Path, default=Path("/tmp/issue-340-evidence"))
    parser.add_argument("--wall-timeout", type=float, default=90)
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", args.id):
        parser.error("ID must be a safe unique artifact label")
    if not 30 <= args.wall_timeout <= 300:
        parser.error("wall timeout must be between 30 and 300 seconds")
    source = args.source.resolve(strict=True)
    output_root = args.output_root.resolve()
    if output_root == source or source in output_root.parents:
        parser.error("artifacts must not be inside live source")
    output_root.mkdir(parents=True, exist_ok=True)
    result_dir = output_root / args.id
    result_dir.mkdir(mode=0o700)  # Collision refuses to overwrite ANY previous trial.
    result = {"id": args.id, "mode": args.mode, "source": str(source), "node": NODE, "classification": "not_run", "pytest_exit": None, "runner_sha256": digest(Path(__file__).read_bytes()), "runner_python": sys.version, "runner_platform": platform.platform()}
    signal_handlers = {number: signal.signal(number, interrupt) for number in (signal.SIGINT, signal.SIGTERM)}
    workspace = Path(tempfile.mkdtemp(prefix="issue-340-", dir="/tmp"))
    copy = workspace / "source"
    copy.mkdir()
    names = None
    original = None
    execution = None
    try:
        names, original, excluded = snapshot(source, copy)
        save_json(result_dir / "source-manifest.json", {"files": original, "excluded_tracked_paths": excluded, "scope": "tracked server and orchestrator inputs plus root pytest configuration"})
        result["source_test_sha256"] = original[TEST]["sha256"]
        result["source_download_sha256"] = original[DOWNLOAD]["sha256"]
        result["requirements_sha256"] = original[REQUIREMENTS]["sha256"]
        if args.mode == "historical-bad":
            result["mutation"] = mutate_historical(copy)
        candidate = input_manifest(copy, names)
        differences = [name for name in names if candidate[name] != original[name]]
        expected = [DOWNLOAD] if args.mode == "historical-bad" else []
        if differences != expected:
            raise RuntimeError("copied-file differences exceed requested mutation")
        result["changed_copied_inputs"] = differences
        save_json(result_dir / "candidate-manifest.json", candidate)
        runtime = workspace / "runtime"
        runtime.mkdir()
        (runtime / "issue340_observer.py").write_text(PLUGIN, encoding="utf-8")
        result["observer_sha256"] = digest(PLUGIN.encode("utf-8"))
        home = workspace / "home"
        temp = workspace / "tmp"
        home.mkdir()
        temp.mkdir()
        uv = shutil.which("uv")
        if uv is None:
            raise RuntimeError("uv executable unavailable")
        uv = str(Path(uv).resolve())
        user_home = Path.home()
        env = {
            "PATH": os.environ.get("PATH", os.defpath),
            "HOME": str(home),
            "TMPDIR": str(temp),
            "LANG": "en_US.UTF-8", "LC_ALL": "en_US.UTF-8", "TZ": "UTC",
            "UV_CACHE_DIR": os.environ.get("UV_CACHE_DIR", str(user_home / ".cache/uv")),
            "UV_PYTHON_INSTALL_DIR": os.environ.get("UV_PYTHON_INSTALL_DIR", str(user_home / ".local/share/uv/python")),
            "UV_PYTHON_DOWNLOADS": "never", "UV_OFFLINE": "1",
            "PYTHONUNBUFFERED": "1", "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONPATH": str(runtime) + os.pathsep + str(copy),
            "PYTEST_PLUGINS": "issue340_observer",
            # Avoid pytest traceback/captured logs exposing synthetic auth headers.
            "PYTEST_ADDOPTS": "--tb=no --show-capture=no -o log_cli=false -o cache_dir=" + str(workspace / "pytest-cache"),
            "ISSUE340_TEST": str(copy / TEST),
            "ISSUE340_TELEMETRY": str(result_dir / "telemetry.jsonl"),
        }
        command = [uv, "run", "--offline", "--python", "3.12", "--no-project", "--with", "pytest", "--with", "pytest-asyncio", "--with-requirements", REQUIREMENTS, "--", "python", "-m", "pytest", NODE, "-q", "--import-mode=importlib"]
        result.update(command=command, cwd=str(copy), environment=env, uv_sha256=digest(Path(uv).read_bytes()), wall_timeout=args.wall_timeout, proxy_variables="none inherited; ALL_PROXY/all_proxy/HTTP_PROXY/http_proxy/HTTPS_PROXY/https_proxy absent")
        version = subprocess.run([uv, "--version"], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5, check=True)
        result["uv_version"] = version.stdout.decode("utf-8", errors="replace").strip()
        save_json(result_dir / "invocation.json", result)
        execution = run_stream(command, copy, env, result_dir / "pytest.log", args.wall_timeout)
        result["execution"] = execution
        result["pytest_exit"] = execution["child_exit"]
        telemetry_path = result_dir / "telemetry.jsonl"
        records = [json.loads(line) for line in telemetry_path.read_text(encoding="utf-8").splitlines()] if telemetry_path.exists() else []
        result["classification"] = classify(args.mode, execution, records)
        if input_manifest(copy, names) != candidate:
            result["classification"] = "invalid_copied_input_drift"
        if input_manifest(source, names) != original:
            result["classification"] = "invalid_live_source_drift"
        result["source_and_candidate_hashes_stable_after_run"] = result["classification"] not in ("invalid_copied_input_drift", "invalid_live_source_drift")
    except Exception as error:
        result["runner_error_type"] = type(error).__name__
        # Own error strings only; subprocess stderr/exception repr may contain data.
        if type(error) is RunnerInterrupted:
            result["runner_error"] = str(error)
        result["classification"] = "invalid_interrupted_runner" if isinstance(error, RunnerInterrupted) else "invalid_runner_error"
        if execution is not None:
            result["pytest_exit"] = execution["child_exit"]
    finally:
        for number in signal_handlers:
            signal.signal(number, signal.SIG_IGN)
        if result.get("runner_error_type") == "ContainmentFailure":
            result["retained_workspace"] = str(workspace)
        else:
            try:
                shutil.rmtree(workspace)
            except Exception as error:
                result["cleanup_error_type"] = type(error).__name__
                result["retained_workspace"] = str(workspace)
                result["classification"] = "invalid_workspace_cleanup"
        result["disposable_workspace_removed"] = not workspace.exists()
        save_json(result_dir / "result.json", result)
        print(json.dumps({"id": args.id, "classification": result["classification"], "pytest_exit": result["pytest_exit"], "artifacts": str(result_dir)}, sort_keys=True), flush=True)
        for number, handler in signal_handlers.items():
            signal.signal(number, handler)
    # Expected bad controls keep pytest's nonzero exit; no inversion or retry.
    code = result["pytest_exit"]
    return code if code is not None and code >= 0 else (128 - code if code is not None else 70)


if __name__ == "__main__":
    raise SystemExit(main())
