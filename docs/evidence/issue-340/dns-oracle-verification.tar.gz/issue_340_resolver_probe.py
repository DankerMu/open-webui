import json
import os
from pathlib import Path
import sys

import pytest

TARGET = 'test_callback_dns_stall_returns_before_resolver_executor_shutdown'
DATA = {'connectors': [], 'observation': None, 'phases': []}

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    if item.name != TARGET:
        yield
        return
    import aiohttp.connector
    import aiohttp.resolver
    patch = item.funcargs['monkeypatch']
    mode = os.environ['ISSUE340_RESOLVER_MODE']
    DATA['mode'] = mode
    DATA['aiohttp_version'] = aiohttp.__version__
    DATA['default_resolver'] = aiohttp.connector.DefaultResolver.__name__
    if mode == 'threaded':
        patch.setattr(aiohttp.connector, 'DefaultResolver', aiohttp.resolver.ThreadedResolver)
    elif mode != 'default':
        raise ValueError('unknown probe mode')
    original = aiohttp.connector.TCPConnector.__init__
    def observed_init(self, *args, **kwargs):
        original(self, *args, **kwargs)
        DATA['connectors'].append(type(self._resolver).__name__)
    patch.setattr(aiohttp.connector.TCPConnector, '__init__', observed_init)
    previous = sys.gettrace()
    assert previous is None
    code = item.obj.__code__
    def trace(frame, event, arg):
        if frame.f_code is not code:
            return None
        if event == 'return':
            values = frame.f_locals
            outcome = values.get('outcome', {})
            response = outcome.get('response')
            DATA['observation'] = {
                'configured_timeout': values.get('configured_timeout'),
                'timestamps': dict(values.get('timestamps', {})),
                'calls': list(values.get('calls', [])),
                'response_status': None if response is None else response.status_code,
                'response_reason': None if response is None else response.json().get('reason'),
                'response_events': {k: outcome.get(k) for k in ('entered', 'released', 'returned', 'escaped')},
                'events_at_cleanup': {k: values[k].is_set() for k in ('entered', 'release', 'returned', 'escaped', 'completed')},
                'request_worker_alive': values['worker'].is_alive(),
            }
        return trace
    sys.settrace(trace)
    try:
        yield
    finally:
        sys.settrace(previous)

def pytest_runtest_logreport(report):
    DATA['phases'].append({'when': report.when, 'outcome': report.outcome})

def pytest_sessionfinish(session, exitstatus):
    DATA['exit'] = int(exitstatus)
    Path(os.environ['ISSUE340_RESOLVER_JSON']).write_text(json.dumps(DATA, indent=2)+'\n')
