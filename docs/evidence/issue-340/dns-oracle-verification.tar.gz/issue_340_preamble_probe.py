"""Diagnostic-only external-client delay; never patches the downloader."""
import hashlib
import json
from pathlib import Path
import time

import aiohttp
import pytest

EVENTS = []
REPORT = Path('/tmp/issue-340-preamble-observation.json')


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    if item.name != 'test_callback_dns_stall_returns_before_resolver_executor_shutdown':
        yield
        return
    original = aiohttp.ClientSession.__init__

    def delayed_client(self, *args, **kwargs):
        started = time.monotonic_ns()
        # Fault input: client setup consumes more than the test-local50ms budget.
        time.sleep(0.1)
        try:
            return original(self, *args, **kwargs)
        finally:
            EVENTS.append({'kind': 'client_setup', 'start_ns': started,
                           'end_ns': time.monotonic_ns(), 'injected_delay_seconds': 0.1})

    aiohttp.ClientSession.__init__ = delayed_client
    try:
        yield
    finally:
        aiohttp.ClientSession.__init__ = original


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    result = outcome.get_result()
    if item.name != 'test_callback_dns_stall_returns_before_resolver_executor_shutdown' or call.when != 'call':
        return
    observed = {}
    if call.excinfo is not None:
        for entry in call.excinfo.traceback:
            if entry.frame.code.name == item.name:
                local = entry.frame.f_locals
                observed = {key: local.get(key) for key in ('calls', 'elapsed')}
    source = Path(item.path)
    REPORT.write_text(json.dumps({
        'node': item.nodeid, 'outcome': result.outcome, 'observed': observed,
        'events': EVENTS, 'test_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'boundary': 'One controlled100ms external aiohttp client-construction delay; real callback/download unchanged; no claim about the original failure exact cause.'
    }, indent=2) + '\n')
