# Resolver-entry failure diagnosis

Observed repaired-oracle command `/tmp/issue-340-live-good.log`: exit1,1failed10.71s; response before resolver entry. Production unchanged, configured timeout10s. Do not retry this unchanged command until green.

Ranked falsifiable hypotheses:
1. Installed aiohttp defaults to an asynchronous DNS backend that bypasses socket.getaddrinfo. Predict: runtime connector resolver identity is AsyncResolver; selecting the real library ThreadedResolver in test dependency scope causes entry and a502 response while its executor invocation remains held.
2. Request-loop scheduling prevents the real downloader/resolver from starting. Predict: actual request trace never reaches resolver construction/resolve before response; selecting a different backend alone does not resolve entry.
3. Accepted URL does not resolve the expected host. Predict: resolver trace reports a different host or download fails before any resolve call; changing backend alone does not produce expected-host entry.

Inspection command (recorded `/tmp/issue-340-resolver-identity.log`) resolved aiohttp3.14.4, DefaultResolver=AsyncResolver, pytest-asyncio1.3.0. ThreadedResolver uses loop.getaddrinfo and the loop executor. This establishes installed selection, not yet the actual callback instance. Next: instrument the actual connector; retain unchanged control and one backend-only controlled run. Test contract targets executor-shutdown behavior, not native asynchronous DNS implementation. Any fixture revision must explicitly declare the dependency selection and be independently reviewed before permanent changes.
