## Authorized prerequisite and controlled diagnosis

The user explicitly selected **纳入前置修复** for #340 and #341 as prerequisites to merging #199. Scope remains test scheduling/isolation only; no Office production logic, production timeout increase or failed-CI waiver.

A single controlled probe on the unchanged owning test injected100 ms into the external `aiohttp.ClientSession` constructor. It did not replace `fetch_callback_content`, `_download` or the download result.

Command (exit1, expected counterexample):

```sh
PYTHONPATH=/tmp uv run --offline --python 3.12 --no-project --with pytest --with pytest-asyncio --with-requirements computer-use-server/requirements.txt -- python -m pytest tests/orchestrator/test_office_callback_processing.py::test_callback_dns_stall_returns_before_resolver_executor_shutdown -q --import-mode=importlib -p issue_340_preamble_probe
```

Observed: `502 download_failed` and the existing `<0.2s` assertion passed; `calls == []` failed the resolver-entry assertion. Actual request elapsed was0.12298395799007267s. The one client-construction interval was107.464ms, including the injected100ms delay. Test source SHA-256: `db253664274967ba7e9fe0783ced026b46962f7f0640b34fa45327379e3b46bb`.

This demonstrates one real mechanism for the recorded failure shape; it does not establish the exact cause of the earlier full-suite occurrence. The original trace did not execute the later state/receipt/version assertions.

The independent fixture is `ocu-callback-dns-oracle`. It keeps the real configured deadline (currently10s), the existing150ms deadline-overrun allowance and the end-to-end clock; requires resolver entry and response-before-release/return; and requires a rejected per-call-loop/shutdown-wait control plus bounded cleanup. Fixture review and implementation remain pending.
