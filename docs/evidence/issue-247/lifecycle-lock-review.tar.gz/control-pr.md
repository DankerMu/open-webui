## Summary

Fixes #247, paired with [OCU PR #101](https://github.com/DankerMu/open-computer-use/pull/101) at [`2a01cda01346b362054d388ce2a41af0e82dcd4b`](https://github.com/DankerMu/open-computer-use/commit/2a01cda01346b362054d388ce2a41af0e82dcd4b). Merge the source PR before this control-plane PR.

Add the expanded `lifecycle-lock-nofollow` fixture, update the existing lifecycle decision, and retain executable evidence. Shared lock admission pins the canonical chat directory, refuses symlink/non-regular lock targets before flock, and preserves synchronization and cross-worker behavior. No WebUI runtime change.

Frozen control head: `b899c951fb066366c273d01d42f6fa11421bb256`.

## Type of change

- [x] chore / docs / test / ci / build / perf

## Test plan

- `make doc-gate decisions-verify`: exit 0; 43 records conform.
- `openspec validate lifecycle-lock-nofollow --strict --no-interactive`: exit 0. Initial expanded fixture independently passed before implementation; final design clarifies bounded creation without changing acceptance.
- Scoped Markdown/fixture `npx prettier --check`: exit 0; manifest `npx prettier --write`: exit 0.
- Paired source canonical Docker-free suite: **3571 passed, 5 existing opt-in live-CLI skips, 332 subtests passed**, exit 0. Full command, environment and all input hashes are retained. The preceding full run's four fence-observer failures and their diagnosis remain in the archive.
- Source Ruff F comparison: 51 baseline / 51 current diagnostics; zero additions, no suppressions. Source commit hooks passed.

## Runtime evidence

[Manifest](https://github.com/DankerMu/open-webui/blob/b899c951fb066366c273d01d42f6fa11421bb256/docs/evidence/issue-247/verification.json) and [297759-byte proof archive](https://github.com/DankerMu/open-webui/blob/b899c951fb066366c273d01d42f6fa11421bb256/docs/evidence/issue-247/lifecycle-lock-verification.tar.gz), SHA-256 `56df5f575999084cdc80243fc0845fdf01070badc14f4bdc1ae7e582c2aaa04e`.

- Actual filesystem/process smoke: a second process is denied while the regular inode is locked and acquires that same inode after release; nested depth retires; symlink targets are neither opened nor flocked; parent replacement stays pinned; missing/existing-chat semantics and thread reacquisition pass. Owned temporary tree removed.
- Final lock oracle rejects original source, leaf-following, redirected-parent and inherited-exception variants; restored module **48 passed**. Original two-process creation case passed **10 dedicated stability trials**.
- Fence observer diagnosis: retained fd13 was already `EBADF` in all four phases. Actual-retirement oracle rejects four real omitted-close cases; restored full fence module **76 passed**.
- Initial proof scan found 150 filename-keyed SHA false positives. Every match equals a measured unchanged Python-file digest. Reversible path/value encoding reconstructs exact original bytes; no allowlist or scanner change. Encoded 1.59 MB payload: gitleaks exit 0, no leaks.
- No UI change, screenshot or deployment certification is claimed.

## 偏离记录

1. Use bounded existing-open / exclusive-create / winner-open instead of a combined creation open. The latter reproduced native concurrent `ENOENT` on the same live parent; no retry loop, platform branch or pathname fallback was added.
2. Three existing fault seams move to actual directory/descriptor admission while retaining source401/callback404/history404 and no-recreation outcomes. Renamed-after-pin is tested separately.
3. The full suite exposed a fourth observer migration: file-object close bypasses Python `os.close`. Preserve all resource/durability/consumer assertions and inspect actual FD retirement rather than callback-set emptiness.

## Risk

Shared OCU lifecycle owner; host-side control-directory writer precondition, not a remote exploit. Hard links, arbitrary regular-inode replacement and trusted-root retargeting are outside this boundary. Existing release-failure cleanup remains [#382](https://github.com/DankerMu/open-webui/issues/382). Local macOS/Python 3.13 evidence is not Linux/Docker/LAN certification or an OS-isolated verifier enclave. Rollback is an in-place source revert; no persisted format changes.

## Canonicality check

- [x] One production owner, no compatibility implementation or dead exports.
- [x] Control diff is below 400 lines; binary proof archive is retained evidence.
- [x] No WebUI upstream runtime files changed.
- [x] Existing lifecycle decision updated with the paired source change.

## Agent Review

Expanded three-seat implementation review pending. Merge requires its clean result and owner-authorized exact-head local CI; no synthetic GitHub Actions run or protection bypass.
