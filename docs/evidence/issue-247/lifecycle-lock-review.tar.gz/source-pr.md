## Summary

Implements DankerMu/open-webui#247. Paired expanded fixture, decision and durable evidence: [WebUI PR #383](https://github.com/DankerMu/open-webui/pull/383). Merge this source PR before #383 closes the issue.

Harden the single shared lifecycle lock owner: pin trusted base/canonical chat descriptors, acquire the leaf without following symlinks, verify a regular inode before flock, and retire acquisition resources on failure. Preserve parent synchronization, reentrant ownership, missing-chat behavior, file modes and cross-process exclusion. Production head: `2a01cda01346b362054d388ce2a41af0e82dcd4b`.

## Type of change

- [x] fix

## Test plan

Executed under parent-owned verification on macOS arm64/Python 3.13.3:

```sh
uv run --no-project --python 3.13 --no-python-downloads --with pytest --with pytest-asyncio --with PyYAML==6.0.2 --with-requirements computer-use-server/requirements.txt -- python /tmp/issue-235-pytest-env.py tests/ -q --import-mode=importlib --ignore=tests/integration -p no:cacheprovider -ra
```

Exit 0: **3571 passed, 5 existing opt-in live-CLI skips, 37 dependency warnings, 332 subtests passed**. The wrapper removes inherited proxy variables for local fixture traffic; its source and complete command/output/input identities are archived. No selected test was suppressed.

- Initial affected matrix: 248 passed after diagnosed acquisition fixes. Final consolidated lock module: 48 passed.
- Final fence module: 76 passed; real omitted-close negative fails all four durability phases before emergency cleanup.
- Original cross-process creation preservation test: 10/10 dedicated stability trials pass.
- `python3 /tmp/issue-247-lint-baseline.py`: exit 0; six Python files, 51 baseline / 51 current Ruff F diagnostics, zero additions, no suppressions.
- Source commit hooks pass. Central docs/decisions (43 records), strict fixture and scoped formatting pass.

## Runtime evidence

[Durable manifest](https://github.com/DankerMu/open-webui/blob/b899c951fb066366c273d01d42f6fa11421bb256/docs/evidence/issue-247/verification.json); archive SHA-256 `56df5f575999084cdc80243fc0845fdf01070badc14f4bdc1ae7e582c2aaa04e`.

Real filesystem/process smoke proves independent-process denial while held and acquisition of the same inode after release, nested depth retirement, symlink refusal without external open/flock, existing-chat missing-lock creation, absent-base noncreation, pinned-parent replacement and another-thread reacquisition. Owned temporary trees are removed.

Final regression qualification rejects original source, leaf-following, redirected-parent and inherited-exception variants, then returns green. Initial failures and diagnostics remain retained, including the scratch classifier correction for pytest's tuple rendering. The first full-suite run's four fence-observer failures were diagnosed at the actual syscall boundary, not ignored: every purported survivor was already EBADF.

## 偏离记录

1. Existing-open / exclusive-create / winner-open is bounded and retains no-follow on every branch. A combined O_CREAT|O_NOFOLLOW call reproduced concurrent ENOENT on the same live parent. No retry loop, platform branch or pathname fallback.
2. Existing lifecycle/control-plane/history fault seams target actual descriptor admission, preserving failure propagation, source401/callback404/history404 and no recreation. Parent replacement after pinning has a separate inode oracle.
3. Fence resource assertions inspect actual FD retirement because file-object close bypasses Python os.close. All pause, bytes, journal, marker and cleanup assertions remain; actual leak omission is rejected.

## Risk

Shared owner serves lifecycle, Office sweep and sandbox reap. Host-side control-directory writer precondition; no remote exploit or external-content write claim. Trusted-root aliases remain supported. Hard links, arbitrary regular-inode replacement and trusted-root retargeting are outside scope. Existing unlock-failure cleanup stays in [WebUI #382](https://github.com/DankerMu/open-webui/issues/382); `__exit__` is unchanged. No Docker/Linux/LAN certification or OS-isolated verifier-enclave claim. No persisted format change; revert this source commit for rollback.

## Canonicality check

- [x] One production lock owner; no compatibility implementation, new dependency or suppression.
- [x] **Diff-size justification:** 882 changed lines, primarily the 48-case deterministic filesystem/failure/race test module and four existing consumer-observer migrations. Production changes stay in one owner. Keeping the owner and its preservation/safety proof atomic avoids an unverified cutover.
- [x] Other production modules and independent test-side lock holders unchanged.
- [x] Source changelog and existing central lifecycle decision updated.

## Agent Review

Expanded three-seat cross-review pending on this source head and central head `b899c951fb066366c273d01d42f6fa11421bb256`. Merge requires clean adjudication and owner-authorized local CI; no fabricated Actions run.
