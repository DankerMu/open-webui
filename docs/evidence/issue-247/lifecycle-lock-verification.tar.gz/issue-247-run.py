import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time

source = Path('/Users/danker/Documents/31308/open-computer-use')
control = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
label, location, *argv = sys.argv[1:]
root = {'source': source, 'control': control}[location]
output = Path('/tmp') / f'issue-247-{label}.command.json'
if output.exists():
    raise SystemExit('Refusing to overwrite earlier evidence')
def identities():
    groups = [
        (source, source/'computer-use-server', '*.py'),
        (source, source/'tests', '*.py'),
        (control, control/'openspec/changes/lifecycle-lock-nofollow', '*'),
    ]
    result = {}
    for base, directory, pattern in groups:
        assert directory.is_dir(), f'Required input directory missing: {directory}'
        for path in sorted(directory.rglob(pattern)):
            if path.is_file():
                result[base.name+'/'+str(path.relative_to(base))] = hashlib.sha256(path.read_bytes()).hexdigest()
    for base, name in (
        (source, 'CHANGELOG.md'),
        (source, 'computer-use-server/requirements.txt'),
        (control, 'docs/decisions/implemented/architecture/2026-09-22-ocu-lifecycle-lock-and-launch-semantics.md'),
    ):
        path = base/name
        assert path.is_file(), f'Required input missing: {path}'
        result[base.name+'/'+name] = hashlib.sha256(path.read_bytes()).hexdigest()
    manifest = control/'docs/evidence/issue-247/verification.json'
    result['evidence_manifest'] = {'exists': manifest.is_file(), 'sha256': hashlib.sha256(manifest.read_bytes()).hexdigest() if manifest.is_file() else None}
    return result
env = os.environ.copy()
env['PATH'] = str(control/'.venv/bin') + ':/Users/danker/.nvm/versions/node/v22.23.2/bin:' + env['PATH']
record = {'argv': argv, 'cwd': str(root), 'platform': platform.platform(), 'source_head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(), 'control_head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=control,text=True).strip(), 'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'inputs_before': identities()}
started = time.time()
child = subprocess.Popen(argv, cwd=root, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
interrupted = False
try:
    stdout, stderr = child.communicate(timeout=1800)
except (subprocess.TimeoutExpired, KeyboardInterrupt):
    interrupted = True
    os.killpg(child.pid, signal.SIGINT)
    try:
        stdout, stderr = child.communicate(timeout=30)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGKILL)
        stdout, stderr = child.communicate()
record.update(exit=child.returncode, elapsed=time.time()-started, interrupted=interrupted, stdout=stdout, stderr=stderr, inputs_after=identities())
record['inputs_unchanged'] = record['inputs_before'] == record['inputs_after']
output.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({key:value for key,value in record.items() if key not in ('inputs_before','inputs_after','stdout','stderr')}))
print(stdout[-7500:])
print(stderr[-5000:])
raise SystemExit(child.returncode if not interrupted else 124)
