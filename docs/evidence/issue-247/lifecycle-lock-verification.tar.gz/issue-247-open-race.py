import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

child=r'''
import json,os,sys
root,leaf,style=sys.argv[1:]
fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
flags=os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC
print('ready',flush=True)
assert sys.stdin.readline()=='go\n'
try:
    if style=='existing-first':
        try:
            opened=os.open(leaf,flags & ~os.O_CREAT,dir_fd=fd)
        except FileNotFoundError:
            try:
                opened=os.open(leaf,flags|os.O_EXCL,0o666,dir_fd=fd)
            except FileExistsError:
                opened=os.open(leaf,flags & ~os.O_CREAT,dir_fd=fd)
    else:
        opened=os.open(leaf,flags,0o666,dir_fd=fd)
except OSError as error:
    row={'outcome':'error','errno':error.errno,'error':type(error).__name__}
else:
    info=os.fstat(opened)
    row={'outcome':'opened','inode':[info.st_dev,info.st_ino],'mode':info.st_mode}
    os.close(opened)
finally:
    info=os.fstat(fd)
    row['directory_inode']=[info.st_dev,info.st_ino]
    try:
        entry=os.stat(leaf,dir_fd=fd,follow_symlinks=False)
        row['entry_inode']=[entry.st_dev,entry.st_ino]
    except OSError as error:row['entry_errno']=error.errno
    os.close(fd)
print(json.dumps(row),flush=True)
'''
result={'platform':sys.platform,'child_sha256':hashlib.sha256(child.encode()).hexdigest(),'cases':[],'qualification':'Real POSIX opens in fresh directories; ready/stdin barriers, no race sleeps. Candidate alternatives are probe-only, not live source.'}
try:
    with tempfile.TemporaryDirectory(prefix='issue-247-bare-open-') as temporary:
        root=Path(temporary)
        for style in ('combined-create','existing-first'):
            for index in range(30):
                directory=root/f'{style}-{index}';directory.mkdir()
                processes=[subprocess.Popen([sys.executable,'-c',child,str(directory),'.lifecycle.lock',style],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for _ in range(2)]
                rows=[]
                try:
                    for process in processes:assert process.stdout.readline().strip()=='ready'
                    for process in processes:
                        process.stdin.write('go\n');process.stdin.flush()
                    for process in processes:
                        stdout,stderr=process.communicate(timeout=5)
                        assert process.returncode==0,(stdout,stderr)
                        rows.append(json.loads(stdout))
                finally:
                    for process in processes:
                        if process.poll() is None:
                            process.kill();process.communicate(timeout=5)
                result['cases'].append({'style':style,'trial':index,'results':rows})
                if any(row['outcome']=='error' for row in rows):
                    print(json.dumps(result['cases'][-1]),flush=True)
                    break
    result['owned_directories_removed']=not Path(temporary).exists()
finally:
    Path('/tmp/issue-247-open-race-result.json').write_text(json.dumps(result,indent=2)+'\n')
for style in ('combined-create','existing-first'):
    rows=[row for row in result['cases'] if row['style']==style]
    print(json.dumps({'style':style,'trials':len(rows),'failures':sum(any(item['outcome']=='error' for item in row['results']) for row in rows)}))
