import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

source=Path('/Users/danker/Documents/31308/open-computer-use')
owner=Path('/tmp/issue-247-owner-before-close-fix.py')
tests=source/'tests/orchestrator/test_lifecycle.py'
module=ast.parse(tests.read_text())
function=next(node for node in module.body if isinstance(node,ast.FunctionDef) and node.name=='test_two_processes_share_one_creation')
assignment=next(node for node in function.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='script' for target in node.targets))
child=ast.literal_eval(assignment.value)
probe=r'''
_real_open=os.open
_observation_path=Path(os.environ['OCU_SHARED'])/f'open-{os.getpid()}.jsonl'
def _observe_open(path,*args,**kwargs):
    watched=os.fspath(path)=='.lifecycle.lock'
    row={'path':os.fspath(path),'args':list(args),'dir_fd':kwargs.get('dir_fd')}
    def snapshot():
        fd=kwargs.get('dir_fd')
        if fd is None:return {}
        info=os.fstat(fd)
        result={'dir_inode':[info.st_dev,info.st_ino],'dir_nlink':info.st_nlink}
        root=Path(os.environ['OCU_BASE'])/os.environ['OCU_CHAT']
        try:
            info=root.lstat();result['path_inode']=[info.st_dev,info.st_ino]
        except OSError as exc:result['path_errno']=exc.errno
        try:
            info=os.stat('.lifecycle.lock',dir_fd=fd,follow_symlinks=False)
            result['leaf']={'inode':[info.st_dev,info.st_ino],'mode':info.st_mode}
        except OSError as exc:result['leaf_errno']=exc.errno
        return result
    if watched:row['before']=snapshot()
    try:
        fd=_real_open(path,*args,**kwargs)
    except OSError as exc:
        if watched:
            row.update(error=type(exc).__name__,errno=exc.errno,after=snapshot())
            with _observation_path.open('a') as log:log.write(json.dumps(row)+'\n')
        raise
    if watched:
        info=os.fstat(fd);row.update(returned_inode=[info.st_dev,info.st_ino],after=snapshot())
        with _observation_path.open('a') as log:log.write(json.dumps(row)+'\n')
    return fd
os.open=_observe_open
'''
assert child.count('import docker_manager\n')==1
instrumented=child.replace('import docker_manager\n','import docker_manager\n'+probe,1)
result={'owner_sha256':hashlib.sha256(owner.read_bytes()).hexdigest(),'original_child_sha256':hashlib.sha256(child.encode()).hexdigest(),'instrumented_child_sha256':hashlib.sha256(instrumented.encode()).hexdigest(),'trials':[],'limit':'Forwarding syscall observation may alter scheduling; a passing trial does not refute the observed prior failure.'}
try:
    with tempfile.TemporaryDirectory(prefix='issue-247-open-diagnosis-') as temporary:
        root=Path(temporary)
        archive=root/'source.tar'
        with archive.open('wb') as stream:
            subprocess.run(['git','archive','61d115e6c8098981dab0c6a8512898521a8305e0','computer-use-server'],cwd=source,stdout=stream,check=True)
        with tarfile.open(archive) as content:content.extractall(root,filter='data')
        server=root/'computer-use-server'
        shutil.copyfile(owner,server/'docker_manager.py')
        for index in range(20):
            trial=root/f'trial-{index}'
            shared=trial/'shared';shared.mkdir(parents=True)
            env=os.environ.copy()
            env.update(OCU_SERVER_DIR=str(server),OCU_BASE=str(trial/'data'),OCU_SHARED=str(shared),OCU_CHAT='a1b2c3d4-e5f6-7890-abcd-ef1234567890',PUBLIC_BASE_URL='/ocu')
            env.pop('OCU_BROKEN_FLOCK',None)
            processes=[subprocess.Popen([sys.executable,'-c',instrumented],env=env,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE) for _ in range(2)]
            outputs=[]
            try:
                for process in processes:
                    stdout,stderr=process.communicate(timeout=30)
                    outputs.append({'exit':process.returncode,'stdout':stdout,'stderr':stderr})
            finally:
                for process in processes:
                    if process.poll() is None:
                        process.kill();process.communicate(timeout=5)
            observations={p.name:[json.loads(line) for line in p.read_text().splitlines()] for p in shared.glob('open-*.jsonl')}
            row={'trial':index,'outputs':outputs,'observations':observations}
            result['trials'].append(row)
            print(json.dumps(row),flush=True)
            if any(row['exit']!=0 for row in outputs):
                result['stopped_on_failure']=True
                break
    result['owned_snapshot_removed']=not Path(temporary).exists()
finally:
    Path('/tmp/issue-247-crossprocess-diagnosis-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'trials':len(result['trials']),'stopped_on_failure':result.get('stopped_on_failure',False),'owned_snapshot_removed':result.get('owned_snapshot_removed',False)}))
