## 1. Exact current lock-owner behaviour (evidence, current head)

`docker_manager.py`

- `_control_dir` 175-177: `BASE_DATA_DIR / canonical_lock_chat_id(chat_id)`. Pure path join, no validation. Also feeds `_idle_path` 1582-1583 and (via import) `office/control_plane.py::_chat_directory_exists` 57-67.
- `canonical_lock_chat_id` 160-162 -> `security.sanitize_chat_id` 10-24: `strip().lower()`, rejects `..`, `/`, `\\`, NUL, and raises FastAPI `HTTPException(400)`. All reaper call sites therefore wrap it in try/except (1924-1926, 1949-1951).
- `__init__` 190-196: canonicalize (191), fetch RLock (192), `_file=None`, `_create`, `_acquired=False`.
- `__enter__` 199-247, exact order:
  1. 200 `self._thread_lock.acquire()`.
  2. 201-205 reentrancy: `if _FLOCK_DEPTH.get(chat)` -> depth+1, `_acquired=True`, `return self`. No filesystem access at all.
  3. 206 `root = _control_dir(...)`; 207-213 `create=False`: `os.lstat(root)`; `FileNotFoundError` -> `return None`; `S_ISLNK` or not `S_ISDIR` -> `return None` (any other OSError propagates through 247).
  4. 214 `path = root / ".lifecycle.lock"`.
  5. 215-230 create path: 216 `BASE_DATA_DIR.mkdir(parents=True, exist_ok=True)`; 217-218 `os.open(BASE_DATA_DIR, descriptor_io.DIRECTORY_FLAGS & ~descriptor_io.NO_FOLLOW)` (O_NOFOLLOW deliberately stripped, base may be a symlink); 220-222 `os.mkdir(self.chat_id, dir_fd=parent_fd)` with `FileExistsError: pass` (no type check of the existing entry); 224-225 `os.open(self.chat_id, descriptor_io.DIRECTORY_FLAGS, dir_fd=parent_fd)`; 226-227 `os.fsync(parent_fd)`; **227 `os.close(root_fd)`; 228 `os.close(parent_fd)` — both directory descriptors are gone before the lock is opened**.
  6. 231-234 `handle = path.open("a+")` — pathname re-walk from `/`; `O_RDWR|O_CREAT|O_APPEND`, no `O_NOFOLLOW`, no `O_DIRECTORY`, no fstat; follows a symlink entry; creates `.lifecycle.lock` (umask mode) even when `create=False`.
  7. 234-238 `FileNotFoundError` -> `None` if `create=False` else re-raise.
  8. 239-243 `fcntl.flock(handle.fileno(), fcntl.LOCK_EX)` (blocking); `BaseException` -> close handle, raise.
  9. 244-246 `_FLOCK_DEPTH[chat]=1`, `_acquired=True`, `return self`.
  10. 247-248 `except BaseException: self._thread_lock.release(); raise`.
- Early `return None` (212/213/237) leaves `_acquired=False`; the RLock is released only in `__exit__` 253-254 (`if not self._acquired: release; return False`), which the `with` protocol always calls — correct for every production caller (all use `with`).
- `__exit__` 250-267: depth>1 -> decrement (258); else pop depth (260), `flock(LOCK_UN)` (262), `close()` (263), `_file=None` (265); `finally: _thread_lock.release()` (266). LOCK_UN/close are unguarded.

Issue-anchor drift map: issue `:197-201` -> 214 + 231-234; issue `:1817-1819` -> today `describe_sandbox` 1815-1818 **and** `reap_idle` 1856-1858 (the cited block is ambiguous at this head); issue `:1907-1910` -> 1946-1951; issue `sweep.py:53-58` -> 60-66; issue `sweep.py:75` -> 87-88; issue `store.py:19-23,193-244` -> still ~19-23 and 193-244.
Issue metadata to carry: source head `b119cd71f2489b2986b517e9b671bfb2f87c9d46`, review base `30c65aba`, blame `c6ad9a38`; fork URL `https://github.com/DankerMu/open-webui/issues/247`; AC = deterministic symlink-swap at the lock-open boundary (no sleep timing) + direct symlink/non-regular rejection through the reap path + a regular lock still excluding.

## 2. Production direct-openers and callers (compact inventory)

Single production opener of `.lifecycle.lock`: `docker_manager.py:231-234`. Confirmed by repo-wide grep for `lifecycle.lock` — the only other hits are tests.

`_combined_lock` call sites (create flag in parentheses):
- docker_manager.py: `_get_or_create_container` 992 (T), `_reset_shutdown_timer` 1287 (T), `record_heartbeat` 1668 (T), `launch_sandbox` 1739 (T), `describe_sandbox` 1817 (T), `reap_idle` 1858 (T), `startup_idle_sweep` 1928 (T).
- app.py: `_recover_then_reconcile` 126 (T), `_store_upload` 612 (T), `_list_import_ids` 665 (T).
- outputs_broker.py: `current_revision` 132, `(listing)` 141, `(path validation)` 155, `reconcile` 200 — all (T) after a path-based `_assert_chat_root_safe(allow_missing=True)`.
- office, create=False: control_plane 79, 121; history 46; publish 741, 909; resolution 82; restore 99; sweep 88.
- office, default/creating: sessions 179, 474, 679, 769, 818; store 50, 57; versions 111, 349; workspace 51.

Other production path-based chat-root traversals (not the lock, but the same canonical root, useful for boundary consistency): `app.py:617` (`BASE_DATA_DIR / chat_id`, then `open_directory_path` + dir_fd-relative upload), `app.py:662/754/824` (`security.safe_path` realpath containment), `uploads.py:319` `_open_outputs_root`, `uploads.py:547-560` `_require_control_directory` (opens `control.parent` by absolute path with `DIRECTORY_FLAGS`), `outputs_broker.py:264` (`os.open(control.parent, DIRECTORY_FLAGS)`), `office/router.py:60` (`(docker_manager.BASE_DATA_DIR / chat_id).is_dir()`), `docker_manager.py:1453` `_get_meta_path`, `docker_manager.py:1590/1601` idle state, `docker_manager.py:1091` `os.makedirs(chat_data_path/outputs)` + `chmod 0o777`.

Boundary contract of the office read paths (the check->open window): `store._assert_chat_root_safe(chat, allow_missing=True)` (store.py 137-149, output_broker 243-254) -> `_combined_lock(create=False)` -> `lock is None` means 'chat gone' -> 401 `invalid_ticket` (control_plane 79-81), 404 `unknown_session` (control_plane 121-123), `StateCorruptError` (publish 741-743, 909-911, resolution 82-84), `FileIdNotFoundError` (history 46-48, restore 99-101). Every one of these then re-runs `_assert_chat_root_safe(allow_missing=False)` **inside** the lock (store 51/58, broker 133/142/156/201, control_plane 84, sessions 180, versions 112/350, workspace 52).

## 3. Reap / startup / launch boundaries and side effects

- `startup_idle_sweep` 1914-1934: `BASE_DATA_DIR.exists()` guard (1918); `iterdir()`; `child.is_dir()` **follows symlinks** and `.meta.json`/`.idle.json` `.exists()` are path-based; `canonical_lock_chat_id(child.name)` computed **without comparing to `child.name`** (1924); `_combined_lock(chat_id)` create=True (1928) so a directory that vanished between the is_dir check and the lock is **re-created** (222) and the parent fsynced; per-chat `except Exception as exc: print(f"[IDLE] startup sweep failed for {child.name}: {exc}")` (1933-1934) — raw entry name plus exception text.
- `list_reap_candidates` 1936-1943: iterdir + `is_dir()` (follows links) + `.meta.json`/`.idle.json` exists; returns raw names.
- `reap_known_sandboxes` 1946-1951: `reap_idle` per candidate; `except Exception as exc: print(f"[IDLE] reap failed for {chat_id}: {exc}")` 1950-1951.
- `reap_idle` 1854-1910: canonicalize (1856), `_combined_lock` create=True (1858), pause/running/uncertain/expiry logic 1859-1910; **no `.lifecycle.lock` regularity precheck anywhere on this path** (confirms the issue).
- `office/sweep.py`: `_sweep` 28-50 does `os.scandir(BASE_DATA_DIR)`, `child.is_dir(follow_symlinks=False)`, canonical-name equality `chat != child.name -> continue` (42-43), `_has_state` precheck at 46, then `visit`; failures print fixed strings only ('[OFFICE] session sweep state durability failed' 47, '[OFFICE] session sweep chat failed' 49-50, with an explicit comment that identities/exception text can carry secrets). `_has_state` 52-73 opens base->chat->.ocu->office via `store._open_tree` and `os.lstat(".lifecycle.lock", dir_fd=opened[1])` rejecting non-regular with `StateCorruptError`; `_sweep_chat` 86-89 runs `_assert_chat_root_safe` then `_combined_lock(chat, create=False)` and re-checks `_has_state` inside the lock. So the precheck is outside the lock and the open is path-based: the check-to-open window the issue describes.
- `app.py` `_idle_reaper` 404-432: startup sweep (fixed string 409), publication sweep (414), reap tick (`[IDLE] reap tick failed: {exc}` 425), session sweep (432); all swallow except `CancelledError`. Log/capsys assertions that constrain message changes: test_office_sweep.py 475-478, 504-506, 558-561; test_lifecycle.py 2019-2046, 2048-2080.
- `launch_sandbox` 1735-1742 wraps `_launch_locked` in `_combined_lock` with `current_credential_source` token set/reset in `finally`; `describe_sandbox` 1815-1818 docstring promises 'without creating', yet the default create=True lock creates the chat entry and lock file.

## 4. Action-changing blind spots (file:line evidence)

1. **Parent-directory replacement race / verified dir != flocked dir.** The chat entry is verified only at 224-225 via `parent_fd`, then `root_fd` is closed at 227 and `parent_fd` at 228, and the lock is opened by pathname at 234. A rename/replace of `{BASE}/{chat}` (or a retarget of a symlinked `BASE_DATA_DIR` — explicitly supported by 217-218 and by `base_kind="configured-symlink"` at test_lifecycle.py 1658-1695) between 228 and 234 makes the flock land on an unverified inode. `_control_dir` 175-177 and `root`/`path` 206/214 are re-derived literals, never pinned descriptors.
2. **create=False is not non-creating.** With an existing chat dir but no `.lifecycle.lock`, 231-234 `Path.open("a+")` (O_CREAT) **creates** the lock entry (umask mode). Office tests only cover the case where `_has_state` bails first (test_office_sweep.py 435-436). The controlling decision record says 'non-creating acquisition remains non-creating' while the office sweep path depends on `create=False` not adding entries — contract text vs behaviour is unresolved (labelled [CONFLICT-TO-RESOLVE], parent owns it).
3. **Missing root with create=False.** 208-212 returns `None` on `FileNotFoundError` (no flock, no error, no exclusion); 213 returns `None` for symlink/non-dir; other OSErrors escape. Pinned by test_lifecycle.py 1607-1613 and exercised by test_office_history.py 164-217.
4. **Non-regular / FIFO entries accepted.** Only the *root* is type-checked (210); the lock entry is never type-checked. A symlink is followed; a FIFO opens with `a+` and then flocks (Linux permits O_RDWR on a FIFO without blocking [INFERENCE, not executed]); a device node can block the open while the per-chat RLock is held; a directory raises `IsADirectoryError` from `Path.open` -> OSError out of `__enter__`. Behaviour therefore differs by entry type, and nothing enforces 'regular'.
5. **Mutually-exclusive release is not exception-safe.** `_FLOCK_DEPTH` is popped at 260 before `flock(LOCK_UN)` 262 and `close()` 263, with no try; an OSError from LOCK_UN leaks the descriptor, leaves `self._file` set, and a later acquire (create=True) opens a second open-file-description whose `LOCK_EX` conflicts with the leaked one -> intra-process self-deadlock. Depth accounting itself is sound (mutated only under the per-chat RLock: 201-204, 256-260).
6. **Nested depth bypasses everything.** 201-205 returns `self` without touching the filesystem, so (a) any new dir/lock validation is unreachable at depth>=1, (b) nested `create=False` never returns `None` even after the root is removed, contradicting the class docstring 184-187, and (c) `_acquired=True` is set while no file descriptor exists (asymmetric with 245).
7. **BASE_DATA_DIR trust asymmetry.** 216 `mkdir(parents=True)` and 234 `Path.open` follow symlinks in ancestors of BASE_DATA_DIR and in the base itself; only the chat entry is no-followed (224). `descriptor_io.NO_FOLLOW` silently degrades to 0 on platforms lacking it, whereas `office/store.py` 43-46 hard-fails — a new check routed through descriptor_io would be a no-op on such platforms.
8. **Creating locks on non-canonical or absent entries in the reapers.** `startup_idle_sweep` 1924 and `reap_idle` 1856 canonicalize without comparing to `child.name`/`list_reap_candidates` output, so a directory whose name is non-canonical (e.g. `UPPER`) with `.meta.json` yields a create of the canonical sibling plus a BASE_DATA_DIR fsync. The office sweep does compare (sweep.py 42-43); the sandbox reapers do not.
9. **Docstring vs behaviour on read-only paths.** `describe_sandbox` 1815-1818 'without creating or changing a sandbox' but takes the creating lock (1817).

## 5. Existing test/fixture surface that constrains any rewrite

Fixtures: `tests/orchestrator/_office_store.py::world` 176-195 (env `BASE_DATA_DIR`, `importlib.reload` of docker_manager/office.store/office.versions/office.workspace, clears `_chat_locks`/`_FLOCK_DEPTH`) re-exported by `tests/orchestrator/conftest.py`; `test_lifecycle.py::world` 263-302 sets `docker_manager.BASE_DATA_DIR = tmp_path/"data"` as a module attribute (not env) and clears state; `test_outputs_broker.py::world` 36+ uses env.

Boundary hooks that break if the lock open stops being `Path.open(absolute path)`:
- test_lifecycle.py 1578-1604 patches `Path.open`, matches `self.name == ".lifecycle.lock"`, expects the OSError to escape `_combined_lock` and the RLock to be released, asserts `_FLOCK_DEPTH == 0`.
- test_office_control_plane.py 419-445 `_disappearing_lock_open` patches `Path.open` keyed on `path == data/CHAT/".lifecycle.lock"`, then `shutil.rmtree`, relying on the follow-up `FileNotFoundError` -> `None` for `create=False`.
- test_office_history.py 164-217 (`removed_at="lock_open"`) patches `Path.open` and `os.lstat` for the same window.
- test_lifecycle.py 1697-1769 patches the **global** `os.open` and asserts every recorded descriptor is closed on the fsync-failure path (a new `os.open` for the lock entry changes the recorded set); 1658-1695 and 1771-1818 patch `os.fsync` and assert a `(dev, ino, S_IFDIR, True)` parent sync of BASE_DATA_DIR occurs after the chat entry exists.
- Path-independent flock detection that AC #1/#2 can reuse: `os.fstat(fd)` inode comparison inside a patched `fcntl.flock` — already used at test_lifecycle.py 1007-1017 and in `_office_store.py::_PROCESS` `wait-then-store` 148-165.
- External exclusion contract: test_upload_claim.py 599-602 opens `{chat}/.lifecycle.lock` with `Path.open("a+")` and requires `flock(LOCK_EX|LOCK_NB)` to raise; test_lifecycle.py 1861+ and `_office_store.py` 148-165 pin cross-process serialization from two processes.
- Symlink/refusal precedents: test_office_sweep.py 379-410 (chat/ocu/office/state/lock; for `linked="lock"` today the refusal comes from the `_has_state` precheck, so the lock is never even opened — the `_forbid_inode_open` proof for the lock is indirect), test_office_store.py 441+, 535-570, test_office_workspace.py 153-181, test_office_history.py 142-162, test_office_control_plane.py 404-412.
- Note for fixture design: `_forbid_inode_open` (test_office_workspace.py 39-45) patches `module.os.open` and therefore cannot observe `Path.open` (CPython `io.open` calls `open(2)` directly), so a canary-based test today cannot prove the lock inode was never opened through the existing helper — detection must use `Path.open`/`fcntl.flock` or the patch set must follow the new open call.

## 6. Sibling descriptor-relative templates the parent can mirror (facts, not a proposal)

- `office/store.py::_open_tree` 193-232 / `_open_dir` 234-244: base fd `O_RDONLY|O_DIRECTORY|O_CLOEXEC` (no NO_FOLLOW), then per-component `lstat` -> `mkdir(0o700, dir_fd=)` on ENOENT -> `S_ISLNK`/not-`S_ISDIR` rejection -> `os.open(..., DIRECTORY_FLAGS, dir_fd=)`; `StateCorruptError` labels; `_load` 168-190 additionally fstat-verifies `S_ISREG` after opening `state.json`; `__init__` 43-46 hard-fails when O_NOFOLLOW/O_DIRECTORY are unavailable.
- `outputs_broker.py::_control_fd` 256-304: absolute-path open of the chat root with `DIRECTORY_FLAGS`, `os.mkdir(".ocu", 0o700, dir_fd=parent_fd)`, `lstat`+`open` relative to the fd, `fsync(parent_fd)` 295-296, `UnsafePathError`/'became a symlink' wording, owned-fd cleanup 300-303.
- `uploads.py::open_control_directory` 237-263 and `_require_control_directory` 547-585: same shape with `fchmod(0700)` on create and `CorruptReceiptsError` policy; `uploads._open_outputs_root` 318+ for the outputs root.
- `descriptor_io.py`: `DIRECTORY_FLAGS = O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC`, `FILE_FLAGS = O_RDONLY|O_NOFOLLOW|O_NONBLOCK|O_CLOEXEC`, `open_directory`/`open_regular` fstat-verify the type and close on every post-open failure, with `DescriptorOpenError`/`DescriptorTypeError` and `is_missing`/`is_nofollow_error` (ELOOP, EMLINK) classifiers. `_CombinedLock` already imports `descriptor_io` (217) but not `is_nofollow_error`/`open_regular`; it imports `stat`, `fcntl`, `Path` (14-22).

## 7. Unknowns / not established (labelled)

- [UNKNOWN] mkdir mode for the chat entry: 221 passes no mode, so the chat directory is created `0o777 & ~umask`; every sibling uses an explicit `0o700`/`0o777` policy. Intent unverified.
- [UNKNOWN] Whether any *production* caller acquires `create=False` at depth>=1 (which would mask blind spot 6). Nested `create=False` appears only in tests (test_office_store.py 123-134, test_lifecycle.py 1631-1656).
- [INFERENCE] FIFO/char-device `open("a+")` behaviour on the deployment platform (Linux image) — not executed (read-only ticket, no probes). Linux O_RDWR on a FIFO does not block; device open may block.
- [UNKNOWN] Whether `test_office_control_plane_concurrency.py` (20-53, 118-190) and `test_office_session_lifecycle.py` 1088+ instrumentation depends on the lock's internals beyond wrapping `docker._combined_lock`; only headers inspected.
- [UNKNOWN] `test_office_sweep.py::_poll` 33-45 body not fully read; it drives the app tick, so log/paths assertions may add constraints.
- Control repo has no #247 record yet: grep for `247`/`_CombinedLock`/`lifecycle.lock` found only the #214 archive, the office-file-store decision reference, and unrelated changelog hits.
