import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

source = Path('/Users/danker/Documents/31308/open-computer-use')
base = '61d115e6c8098981dab0c6a8512898521a8305e0'
names = ['computer-use-server/docker_manager.py', 'tests/orchestrator/test_lifecycle_lock.py',
         'tests/orchestrator/test_lifecycle.py', 'tests/orchestrator/test_office_control_plane.py',
         'tests/orchestrator/test_office_history.py', 'tests/orchestrator/test_office_publish_fence.py']
inputs = {name: (source/name).read_bytes() for name in names}
name = names[-1]
original = inputs[name].decode()
probe = '''    actual_states = {}
    for watched_fd in opened_fds:
        try:
            observed_stat = os.fstat(watched_fd)
            actual_states[watched_fd] = {"state": "open", "inode": [observed_stat.st_dev, observed_stat.st_ino]}
        except OSError as observation_error:
            actual_states[watched_fd] = {"state": "error", "errno": observation_error.errno}
    print("FENCE-FD-DIAG", phase, actual_states, flush=True)
'''
assert original.count('    assert opened_fds == set()') == 1
instrumented = original.replace('    assert opened_fds == set()', probe+'    assert opened_fds == set()')
result = {'base': base, 'inputs': {name: hashlib.sha256(data).hexdigest() for name, data in inputs.items()},
          'instrumented_test_sha256': hashlib.sha256(instrumented.encode()).hexdigest()}
try:
    with tempfile.TemporaryDirectory(prefix='issue-247-fence-diagnosis-') as temporary:
        root = Path(temporary)
        with (root/'source.tar').open('wb') as stream:
            subprocess.run(['git', 'archive', base, 'computer-use-server', 'tests'], cwd=source, stdout=stream, check=True)
        with tarfile.open(root/'source.tar') as archive:
            archive.extractall(root, filter='data')
        for path, data in inputs.items():
            (root/path).write_bytes(data)
        (root/name).write_text(instrumented)
        env = os.environ.copy()
        for key in ('ALL_PROXY', 'HTTP_PROXY', 'HTTPS_PROXY', 'all_proxy', 'http_proxy', 'https_proxy'):
            env.pop(key, None)
        env.update(NO_PROXY='*', no_proxy='*')
        argv = [sys.executable, '-m', 'pytest', name+'::test_marker_durability_failure_cannot_request_pause_and_closes_descriptors', '-q', '--import-mode=importlib', '-p', 'no:cacheprovider', '--tb=short']
        run = subprocess.run(argv, cwd=root, env=env, capture_output=True, text=True, timeout=90)
        result.update(argv=argv, exit=run.returncode, stdout=run.stdout, stderr=run.stderr)
    result['snapshot_removed'] = not Path(temporary).exists()
    result['inputs_unchanged'] = all((source/path).read_bytes() == data for path, data in inputs.items())
finally:
    Path('/tmp/issue-247-fence-diagnosis-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
assert result['exit'] == 1 and '4 failed' in result['stdout']
assert result['snapshot_removed'] and result['inputs_unchanged']
