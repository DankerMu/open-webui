import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile

source = Path('/Users/danker/Documents/31308/open-computer-use')
base = '61d115e6c8098981dab0c6a8512898521a8305e0'
owner_name = 'computer-use-server/docker_manager.py'
test_name = 'tests/orchestrator/test_office_publish_fence.py'
names = [owner_name, test_name, 'tests/orchestrator/test_lifecycle_lock.py',
         'tests/orchestrator/test_lifecycle.py', 'tests/orchestrator/test_office_control_plane.py',
         'tests/orchestrator/test_office_history.py']
inputs = {name: (source/name).read_bytes() for name in names}
text = inputs[test_name].decode()
function = next(node for node in ast.parse(text).body if isinstance(node, ast.FunctionDef) and node.name == 'test_marker_durability_failure_cannot_request_pause_and_closes_descriptors')
closed = next(node for node in function.body if isinstance(node, ast.FunctionDef) and node.name == 'closed')
segment = ast.get_source_segment(text, closed)
assert segment.count('result = real_close(fd)') == 1
leaking = segment.replace('result = real_close(fd)', 'result = None  # Controlled omission of actual descriptor close.')
assert text.count(segment) == 1
mutant = text.replace(segment, leaking)
result = {'base': base, 'inputs': {name: hashlib.sha256(data).hexdigest() for name, data in inputs.items()},
          'mutant_test_sha256': hashlib.sha256(mutant.encode()).hexdigest(), 'runs': [],
          'defeater': 'Forwarded open succeeds; observed close intentionally does not call the OS. The resource oracle must reject actual live descriptors, not trust callback bookkeeping.'}
try:
    with tempfile.TemporaryDirectory(prefix='issue-247-fence-qualification-') as temporary:
        root = Path(temporary)
        with (root/'source.tar').open('wb') as stream:
            subprocess.run(['git', 'archive', base, 'computer-use-server', 'tests'], cwd=source, stdout=stream, check=True)
        with tarfile.open(root/'source.tar') as archive:
            archive.extractall(root, filter='data')
        for path, data in inputs.items():
            (root/path).write_bytes(data)
        env = os.environ.copy()
        for key in ('ALL_PROXY', 'HTTP_PROXY', 'HTTPS_PROXY', 'all_proxy', 'http_proxy', 'https_proxy'):
            env.pop(key, None)
        env.update(NO_PROXY='*', no_proxy='*')
        for label, content, selection, expected in (
            ('omitted-close', mutant, test_name+'::'+function.name, 1),
            ('restored-fence-module', text, test_name, 0),
        ):
            (root/test_name).write_text(content)
            shutil.rmtree(root/'tests/orchestrator/__pycache__', ignore_errors=True)
            argv = [sys.executable, '-m', 'pytest', selection, '-q', '--import-mode=importlib', '-p', 'no:cacheprovider', '--tb=short']
            run = subprocess.run(argv, cwd=root, env=env, capture_output=True, text=True, timeout=180)
            row = {'label': label, 'argv': argv, 'exit': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr}
            result['runs'].append(row)
            print(json.dumps(row), flush=True)
            assert run.returncode == expected, row
            if label == 'omitted-close':
                assert '4 failed' in run.stdout and 'DID NOT RAISE' in run.stdout, row
        result['candidate_restored'] = (root/test_name).read_bytes() == inputs[test_name]
    result['snapshot_removed'] = not Path(temporary).exists()
    result['inputs_unchanged'] = all((source/path).read_bytes() == data for path, data in inputs.items())
    assert result['snapshot_removed'] and result['inputs_unchanged'] and result['candidate_restored']
    result['completed'] = True
finally:
    Path('/tmp/issue-247-fence-qualification-result.json').write_text(json.dumps(result, indent=2)+'\n')
