import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile

source = Path('/Users/danker/Documents/31308/open-computer-use')
base = '61d115e6c8098981dab0c6a8512898521a8305e0'
owner_name = 'computer-use-server/docker_manager.py'
test_name = 'tests/orchestrator/test_lifecycle_lock.py'
overlays = [owner_name, test_name, 'tests/orchestrator/test_lifecycle.py',
            'tests/orchestrator/test_office_control_plane.py',
            'tests/orchestrator/test_office_history.py']
inputs = {name: (source/name).read_bytes() for name in overlays}
sha = lambda data: hashlib.sha256(data).hexdigest()
result = {'base': base, 'inputs': {name: sha(data) for name, data in inputs.items()},
          'runs': [], 'limit': 'Disposable source snapshots; parent-owned verification, not an OS-isolated acceptance enclave.'}
original = subprocess.check_output(['git', 'show', f'{base}:{owner_name}'], cwd=source)
candidate = inputs[owner_name].decode()
start = candidate.index('    def _open_file(self):')
end = candidate.index('    def __enter__(self):', start)
opening = candidate[start:end]
assert opening.count('os.O_RDWR | descriptor_io.NO_FOLLOW |') == 1
follow = opening.replace('os.O_RDWR | descriptor_io.NO_FOLLOW |', 'os.O_RDWR |')
assert opening.count('dir_fd=root_fd') == 3
redirect = opening.replace('".lifecycle.lock"', '(BASE_DATA_DIR / self.chat_id / ".lifecycle.lock")').replace(', dir_fd=root_fd', '')
variants = [
    ('original-source', original, ['-k', 'test_office_sweep_never_opens_or_flocks_canary_after_lock_precheck'], 1, 'AssertionError'),
    ('leaf-following', (candidate[:start]+follow+candidate[end:]).encode(), ['-k', 'test_office_sweep_never_opens_or_flocks_canary_after_lock_precheck'], 1, 'AssertionError'),
    ('redirected-parent', (candidate[:start]+redirect+candidate[end:]).encode(), ['-k', 'test_chat_replacement_after_pin_cannot_redirect_lock'], 1, 'AssertionError'),
    ('inherited-exception', Path('/tmp/issue-247-owner-before-close-fix.py').read_bytes(), ['-k', 'test_directory_close_error_inside_handled_exception_still_refuses_admission'], 1, 'DID NOT RAISE'),
    ('candidate-restored', inputs[owner_name], [], 0, 'passed'),
]
prior = json.loads(Path('/tmp/issue-247-qualification-result.json').read_text())
assert prior['inputs'] == result['inputs']
assert [row['label'] for row in prior['runs']] == [row[0] for row in variants[:3]]
assert all(row['exit'] == 1 for row in prior['runs'])
assert all('AssertionError' in row['stdout'] for row in prior['runs'][:2])
assert 'os.fstat(held._file.fileno()).st_dev' in prior['runs'][2]['stdout']
assert 'At index 1 diff:' in prior['runs'][2]['stdout']
assert '2 failed, 46 deselected' in prior['runs'][2]['stdout']
result['prior_controls'] = prior['runs']
result['controller_correction'] = 'The redirected-parent control correctly rejected two wrong inode identities. pytest rendered tuple comparisons without the literal AssertionError; corrected only the scratch controller classifier. No production/test change and no repeated completed controls.'
variants = variants[3:]
try:
    with tempfile.TemporaryDirectory(prefix='issue-247-qualification-') as temporary:
        root = Path(temporary)
        archive = root/'source.tar'
        with archive.open('wb') as stream:
            subprocess.run(['git', 'archive', base, 'computer-use-server', 'tests'], cwd=source, stdout=stream, check=True)
        with tarfile.open(archive) as content:
            content.extractall(root, filter='data')
        for name, data in inputs.items():
            (root/name).write_bytes(data)
        env = os.environ.copy()
        for name in ('ALL_PROXY', 'HTTP_PROXY', 'HTTPS_PROXY', 'all_proxy', 'http_proxy', 'https_proxy'):
            env.pop(name, None)
        env.update(NO_PROXY='*', no_proxy='*')
        for label, owner, selection, expected, signal in variants:
            (root/owner_name).write_bytes(owner)
            shutil.rmtree(root/'computer-use-server/__pycache__', ignore_errors=True)
            argv = [sys.executable, '-m', 'pytest', test_name, '-q', '--import-mode=importlib', '-p', 'no:cacheprovider', '--tb=short', *selection]
            run = subprocess.run(argv, cwd=root, env=env, text=True, capture_output=True, timeout=180)
            row = {'label': label, 'argv': argv, 'owner_sha256': sha(owner), 'exit': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr}
            result['runs'].append(row)
            print(json.dumps(row), flush=True)
            assert run.returncode == expected and signal in run.stdout, row
        # Fixed-count no-change trials for the previously failing real two-process creation path.
        for index in range(10):
            argv = [sys.executable, '-m', 'pytest', 'tests/orchestrator/test_lifecycle.py::test_two_processes_share_one_creation', '-q', '--import-mode=importlib', '-p', 'no:cacheprovider', '--tb=short']
            run = subprocess.run(argv, cwd=root, env=env, text=True, capture_output=True, timeout=90)
            row = {'label': f'creation-stability-{index+1}', 'argv': argv, 'exit': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr}
            result['runs'].append(row)
            print(json.dumps(row), flush=True)
            assert run.returncode == 0 and '1 passed' in run.stdout, row
        result['candidate_restored'] = (root/owner_name).read_bytes() == inputs[owner_name]
    result['snapshot_removed'] = not Path(temporary).exists()
    result['live_inputs_unchanged'] = all((source/name).read_bytes() == data for name, data in inputs.items())
    assert result['live_inputs_unchanged'] and result['candidate_restored'] and result['snapshot_removed']
    result['completed'] = True
finally:
    Path('/tmp/issue-247-qualification-continuation-result.json').write_text(json.dumps(result, indent=2)+'\n')
