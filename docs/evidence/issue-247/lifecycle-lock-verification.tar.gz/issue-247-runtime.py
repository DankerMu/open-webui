import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import threading

source = Path('/Users/danker/Documents/31308/open-computer-use')
sys.path.insert(0, str(source/'computer-use-server'))
import docker_manager as manager

chat = 'd046c97b-201a-4788-a750-6c38c7ef9555'
real_open, real_flock = os.open, fcntl.flock
original_base = manager.BASE_DATA_DIR
result = {'cases': [], 'source_sha256': hashlib.sha256((source/'computer-use-server/docker_manager.py').read_bytes()).hexdigest(), 'scope': 'Real temporary filesystem and independent processes; no Docker engine or deployment mutation.'}
child = r'''
import fcntl,json,os,sys
fd=os.open(sys.argv[1],os.O_RDWR)
try:
    try:
        fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        print(json.dumps({'outcome':'blocked','inode':[os.fstat(fd).st_dev,os.fstat(fd).st_ino]}))
    else:
        print(json.dumps({'outcome':'acquired','inode':[os.fstat(fd).st_dev,os.fstat(fd).st_ino]}))
        fcntl.flock(fd,fcntl.LOCK_UN)
finally:
    os.close(fd)
'''
def inode(path):
    item = path.stat()
    return item.st_dev, item.st_ino

def independent(lock):
    command = [sys.executable, '-c', child, str(lock)]
    process = subprocess.run(command, capture_output=True, text=True, timeout=10)
    assert process.returncode == 0, process.stderr
    return json.loads(process.stdout)

try:
    with tempfile.TemporaryDirectory(prefix='issue-247-runtime-') as temporary:
        root = Path(temporary)
        base = root/'data'
        manager.BASE_DATA_DIR = base
        with manager._combined_lock(chat, create=False) as held:
            assert held is None
        assert not base.exists() and chat not in manager._FLOCK_DEPTH
        result['cases'].append({'case':'missing-base-noncreating','absent':True})
        with manager._combined_lock(chat.upper()) as held:
            assert held is not None
            lock = base/chat/'.lifecycle.lock'
            actual = inode(lock)
            info = os.fstat(held._file.fileno())
            assert (info.st_dev,info.st_ino) == actual and stat.S_ISREG(info.st_mode)
            with manager._combined_lock(chat, create=False):
                assert manager._FLOCK_DEPTH[chat] == 2
            assert manager._FLOCK_DEPTH[chat] == 1
            contended = independent(lock)
            assert contended['outcome']=='blocked' and tuple(contended['inode'])==actual
        released = independent(lock)
        assert released['outcome']=='acquired' and chat not in manager._FLOCK_DEPTH
        result['cases'].append({'case':'regular-cross-process','during':contended,'after':released,'nested_depth_retired':True})
        lock.unlink()
        canary = root/'canary'
        canary.write_bytes(b'outside-lock-canary')
        canary_id = inode(canary)
        lock.symlink_to(canary)
        successful_opens, flock_targets = [], []
        def observing_open(*args, **kwargs):
            fd = real_open(*args, **kwargs)
            info = os.fstat(fd)
            successful_opens.append((info.st_dev,info.st_ino))
            return fd
        def observing_flock(fd, operation):
            info = os.fstat(fd)
            flock_targets.append((info.st_dev,info.st_ino))
            return real_flock(fd,operation)
        os.open, fcntl.flock = observing_open, observing_flock
        rejected = []
        try:
            for creating in (False, True):
                try:
                    with manager._combined_lock(chat,create=creating):
                        raise AssertionError('symlink lock admitted')
                except OSError as error:
                    rejected.append({'create':creating,'errno':error.errno})
                assert chat not in manager._FLOCK_DEPTH
        finally:
            os.open, fcntl.flock = real_open, real_flock
        assert canary_id not in successful_opens and canary_id not in flock_targets
        assert canary.read_bytes()==b'outside-lock-canary' and inode(canary)==canary_id
        result['cases'].append({'case':'symlink-refusal','rejections':rejected,'external_inode_not_opened_or_flocked':True,'canary_unchanged':True})
        lock.unlink()
        with manager._combined_lock(chat,create=False) as held:
            assert held is not None and stat.S_ISREG(os.fstat(held._file.fileno()).st_mode)
        result['cases'].append({'case':'existing-root-missing-lock','regular_lock_created':lock.is_file()})
        detached = root/'pinned-chat'
        outside = root/'outside'
        outside.mkdir()
        outside_lock = outside/'.lifecycle.lock'
        outside_lock.write_bytes(b'outside-parent-canary')
        outside_id = inode(outside_lock)
        pinned_id = inode(lock)
        swapped = False
        flock_targets = []
        def replacing_open(path, *args, **kwargs):
            global swapped
            if not swapped and os.fspath(path)=='.lifecycle.lock' and kwargs.get('dir_fd') is not None:
                (base/chat).rename(detached)
                (base/chat).symlink_to(outside,target_is_directory=True)
                swapped = True
            return real_open(path,*args,**kwargs)
        os.open, fcntl.flock = replacing_open, observing_flock
        try:
            with manager._combined_lock(chat,create=False) as held:
                assert held is not None
                info=os.fstat(held._file.fileno())
                assert (info.st_dev,info.st_ino)==pinned_id
        finally:
            os.open, fcntl.flock = real_open, real_flock
        assert swapped and outside_id not in flock_targets
        assert outside_lock.read_bytes()==b'outside-parent-canary' and inode(outside_lock)==outside_id
        result['cases'].append({'case':'parent-replacement-after-pin','lock_stayed_on_pinned_inode':True,'outside_unchanged':True})
        (base/chat).unlink()
        detached.rename(base/chat)
        outcomes=[]
        def retry():
            try:
                with manager._combined_lock(chat,create=False):
                    outcomes.append('acquired')
            except BaseException as error:
                outcomes.append(type(error).__name__)
        worker=threading.Thread(target=retry,daemon=True)
        worker.start()
        worker.join(5)
        assert not worker.is_alive() and outcomes==['acquired'] and chat not in manager._FLOCK_DEPTH
        result['cases'].append({'case':'another-thread-after-rejection','acquired':True,'depth_retired':True})
    result['temporary_tree_removed']=not Path(temporary).exists()
    result['completed']=True
finally:
    os.open,fcntl.flock=real_open,real_flock
    manager.BASE_DATA_DIR=original_base
    Path('/tmp/issue-247-runtime-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
