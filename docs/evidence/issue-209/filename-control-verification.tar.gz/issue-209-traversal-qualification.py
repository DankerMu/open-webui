import hashlib
import json
import os
import pathlib
import shutil
import signal
import subprocess
import tempfile
import time

root = pathlib.Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
source = root / 'scripts/ocu-stub.py'
smoke = root / 'scripts/smoke-stub.sh'
original = source.read_text()
needle = "('', '.', '..')"
assert original.count(needle) == 1
mutant = original.replace(needle, "('.', '..')")
protected = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in (source, smoke)}
results = []
with tempfile.TemporaryDirectory(prefix='issue-209-traversal-') as owned:
    tree = pathlib.Path(owned)
    for module in (root / 'scripts').glob('*.py'):
        shutil.copy2(module, tree / module.name)
    candidate = tree / 'ocu-stub.py'
    env = {key: os.environ[key] for key in ('HOME', 'USER', 'TMPDIR', 'LANG', 'LC_ALL') if key in os.environ}
    env.update(PATH=str(root / '.venv/bin') + ':/Users/danker/.nvm/versions/node/v22.23.2/bin:' + os.environ['PATH'], OCU_STUB_SCRIPT=str(candidate), PYTHONDONTWRITEBYTECODE='1')
    for label, content in [('missing-empty', mutant), ('restored', original)]:
        candidate.write_text(content)
        log_path = pathlib.Path('/tmp/issue-209-traversal-' + label + '.log')
        start = time.monotonic()
        with log_path.open('x') as log:
            process = subprocess.Popen(['make', 'smoke-stub'], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = process.wait(timeout=60)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                raise
        output = log_path.read_text()
        results.append({'label': label, 'argv': ['make', 'smoke-stub'], 'stub_script': str(candidate), 'source_sha256': hashlib.sha256(content.encode()).hexdigest(), 'smoke_sha256': protected['scripts/smoke-stub.sh'], 'exit': code, 'seconds': time.monotonic() - start, 'child_reaped': process.poll() is not None, 'semantic_rejection': 'expected traversal 400, got (200' in output})
        print(label, code, output)
assert protected == {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in (source, smoke)}
record = {'protected_inputs': protected, 'inputs_unchanged': True, 'results': results, 'owned_tree_removed': not tree.exists(), 'runner_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
pathlib.Path('/tmp/issue-209-traversal-qualification.json').write_text(json.dumps(record, indent=2) + '\n')
assert results[0]['exit'] != 0 and results[0]['semantic_rejection'], results[0]
assert results[1]['exit'] == 0, results[1]
print('Traversal mutation rejected semantically; restored full smoke GREEN; owned copy removed.')
