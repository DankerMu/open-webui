import hashlib
import json
import os
import pathlib
import shutil
import signal
import subprocess
import tempfile
import time

root = pathlib.Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
base = 'a70ea4ff8f435151b11397481cbb8094f0427f8a'
source = root / 'scripts/ocu-stub.py'
smoke = root / 'scripts/smoke-stub.sh'
original = source.read_text()
assert original == subprocess.check_output(['git', 'show', base + ':scripts/ocu-stub.py'], cwd=root, text=True)
append = "body['files'].extend(entry for _, entry in uploaded.values())"
failure = "if _scenario(chat_id) == 'partial_after' and offset > 0:"
assert original.count(append) == original.count(failure) == 1
cases = [
    ('missing-large-upload', original.replace(append, "body['files'].extend(entry for _, entry in uploaded.values() if _scenario(chat_id) != 'large')"), 'large: expected uploaded path exactly once on cursor 100'),
    ('masked-partial-error', original.replace(failure, "if _scenario(chat_id) == 'partial_after' and offset < 0:"), 'partial_after: expected intentional cursor-100 HTTP 503, got (200'),
    ('restored', original, None),
]
protected_paths = sorted((root / 'scripts').glob('*.py')) + [smoke]
def snapshot():
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in protected_paths}
protected = snapshot()
record = {'base': base, 'argv': ['make', 'smoke-stub'], 'protected_inputs': protected, 'results': [], 'caller_asset_input': 'unset', 'runner_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
owned = tempfile.TemporaryDirectory(prefix='issue-210-qualification-')
tree = pathlib.Path(owned.name)
try:
    for label, content, semantic_marker in cases:
        copy_root = tree / label / 'source'
        copy_root.mkdir(parents=True)
        for module in (root / 'scripts').glob('*.py'):
            shutil.copy2(module, copy_root / module.name)
        candidate = copy_root / source.name
        candidate.write_text(content)
        runtime_tmp = tree / label / 'runtime'
        runtime_tmp.mkdir()
        env = {key: os.environ[key] for key in ('HOME', 'USER', 'LANG', 'LC_ALL') if key in os.environ}
        env.update(PATH=str(root / '.venv/bin') + ':/Users/danker/.nvm/versions/node/v22.23.2/bin:' + os.environ['PATH'], TMPDIR=str(runtime_tmp) + '/', OCU_STUB_SCRIPT=str(candidate), PYTHONDONTWRITEBYTECODE='1')
        log_path = pathlib.Path('/tmp/issue-210-' + label + '.log')
        started = time.monotonic()
        timed_out = False
        with log_path.open('x') as log:
            child = subprocess.Popen(['make', 'smoke-stub'], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = child.wait(timeout=60)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                code = 124
        output = log_path.read_text()
        leftovers = sorted(path.name for path in runtime_tmp.iterdir())
        result = {'label': label, 'stub_script': str(candidate), 'source_sha256': hashlib.sha256(content.encode()).hexdigest(), 'smoke_sha256': protected['scripts/smoke-stub.sh'], 'exit': code, 'seconds': time.monotonic() - started, 'timed_out': timed_out, 'child_reaped': child.poll() is not None, 'runtime_temporary_entries_after_exit': leftovers, 'semantic_marker': semantic_marker, 'semantic_marker_observed': semantic_marker in output if semantic_marker else None}
        record['results'].append(result)
        print(json.dumps(result, indent=2))
        assert not timed_out and not leftovers, result
        if semantic_marker:
            assert code != 0 and semantic_marker in output and 'AssertionError:' in output, result
        else:
            assert code == 0 and 'smoke-stub: ok (port ' in output, result
finally:
    owned.cleanup()
    record['owned_tree_removed'] = not tree.exists()
    record['protected_inputs_unchanged'] = protected == snapshot()
    pathlib.Path('/tmp/issue-210-qualification.json').write_text(json.dumps(record, indent=2) + '\n')
assert record['protected_inputs_unchanged'] and record['owned_tree_removed']
print('Both pagination mutants rejected semantically; restored full smoke GREEN; maps and owned copies removed.')
