import hashlib
import json
import os
import pathlib
import signal
import subprocess
import sys
import time

root = pathlib.Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
label, *argv = sys.argv[1:]
prefix = pathlib.Path('/tmp/issue-210-' + label)
assert not prefix.with_suffix('.json').exists()
paths = ['Makefile', 'constraints.yaml', 'pyproject.toml', 'uv.lock', 'package.json', 'package-lock.json']
paths += [str(p.relative_to(root)) for p in (root / 'scripts').iterdir() if p.is_file() and p.suffix in {'.py', '.sh'}]
paths += ['backend/open_webui/test/test_ocu_stub_public.py']
def snapshot():
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sorted(paths)}
before = snapshot()
fixture_paths = ['.openspec.yaml', 'proposal.md', 'design.md', 'tasks.md', 'specs/ocu-stub/spec.md']
fixture_root = root / 'openspec/changes/ocu-stub-upload-pagination'
fixture_before = {name: hashlib.sha256((fixture_root / name).read_bytes()).hexdigest() for name in fixture_paths}
record = {'runner_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(), 'argv': argv, 'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'input_sha256_before': before, 'fixture_sha256_before': fixture_before}
env = {k: os.environ[k] for k in ('HOME', 'USER', 'TMPDIR', 'LANG', 'LC_ALL') if k in os.environ}
env['PATH'] = str(root / '.venv/bin') + ':/Users/danker/.nvm/versions/node/v22.23.2/bin:' + os.environ['PATH']
record['python_version'] = subprocess.check_output(['python3', '--version'], env=env, text=True).strip()
record['node_version'] = subprocess.check_output(['node', '--version'], env=env, text=True).strip()
start = time.monotonic()
with prefix.with_suffix('.log').open('x') as log:
    child = subprocess.Popen(argv, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = child.wait(timeout=600)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGTERM)
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait()
        code = 124
record['fixture_inputs_unchanged'] = fixture_before == {name: hashlib.sha256((fixture_root / name).read_bytes()).hexdigest() for name in fixture_paths}
record.update(exit=code, elapsed_seconds=time.monotonic() - start, inputs_unchanged=before == snapshot(), child_reaped=child.poll() is not None)
prefix.with_suffix('.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k:v for k,v in record.items() if k != 'input_sha256_before'}, indent=2))
print(prefix.with_suffix('.log').read_text())
assert record['inputs_unchanged'] and record['fixture_inputs_unchanged']
sys.exit(code)
