"""Parent-only fault qualification; each subprocess restores the actual source automatically."""
import os

import pytest


@pytest.fixture(autouse=True)
def grant_fault(monkeypatch):
    from open_webui.routers import ocu_resource_grants as grants

    fault = os.environ.get('ISSUE295_FAULT')
    if fault == 'signature':
        monkeypatch.setattr(grants.hmac, 'compare_digest', lambda left, right: True)
    elif fault == 'claims':
        monkeypatch.setattr(grants, '_valid_claims', lambda claims, now: True)
    elif fault == 'owner':
        async def unchecked_owner(user_id, chat_id):
            return await grants.Users.get_user_by_id(user_id)
        monkeypatch.setattr(grants, '_authorized_owner', unchecked_owner)
    elif fault == 'revocation':
        async def unchecked_revocation(request, session):
            return None
        monkeypatch.setattr(grants, '_revocation_status', unchecked_revocation)
    elif fault == 'path':
        monkeypatch.setattr(grants, '_valid_path', lambda path: True)
    else:
        raise RuntimeError('Unknown parent qualification fault')
