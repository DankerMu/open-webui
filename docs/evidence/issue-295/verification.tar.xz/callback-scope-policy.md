## 批准的范围扩展：既有 callback 声明告警

用户明确选择：**允许 #295 本 PR 做机械修复**，不另建前置 PR，不降低门禁。

`make anti-drift` 在当前分支报告旧文件的四个未使用参数；在合并前提交 `80767f3af568241967a524c58f405d191ceb9706` 的完整、同范围 Python 源码上重现了同样四项：
- `backend/open_webui/test/test_smoke_proxy_office.py`：两个 subprocess 测试替身的未使用 `capture_output` 参数。
- `scripts/ocu_stub_office.py`：Expat callback 未使用的 `standalone` / `attributes` 参数。

授权边界：仅调整测试替身的未使用 keyword 接收方式及 XML callback 的未使用参数声明；保留所有 callback 函数体、实际调用兼容性和 Office 凭据隐私/清理断言。不得添加虚假读取来消除告警、删除断言、修改阈值或跳过检查。

共享 fixture group1 增加任务1.2。验证包含原 Office 测试模块、`make smoke-stub` 的实际 DOCX/HTTP 路径和 `make anti-drift`。这不是 Office 行为、网关或浏览器 grant 能力的交付声明。
