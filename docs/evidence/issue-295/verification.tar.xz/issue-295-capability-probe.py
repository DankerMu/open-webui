"""Parent-owned route oracle and controlled-fault qualification; no credential output."""
import asyncio
import base64
import hashlib
import hmac
import json
import os
from types import SimpleNamespace
from unittest.mock import patch

from open_webui.test.ocu_harness import _cleanup_owner, _owner_and_chat, _session_headers, session_test_client
from open_webui.utils import auth
from open_webui.routers import ocu_resource_grants as grants


def encoded(value):
    return base64.urlsafe_b64encode(value).rstrip(b'=').decode('ascii')


def sign(payload):
    key = hmac.new(auth.SESSION_SECRET.encode(), b'ocu-resource-grants', hashlib.sha256).digest()
    return encoded(payload) + '.' + encoded(hmac.new(key, payload, hashlib.sha256).digest())


def token(claims):
    return sign(json.dumps(claims, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())


def run():
    owner, chat = asyncio.run(_owner_and_chat(prefix='grant-oracle'))
    foreign, other = asyncio.run(_owner_and_chat(prefix='grant-oracle-foreign'))
    results = []
    patches = []
    try:
        with session_test_client() as client:
            issued = client.get('/api/v1/ocu/resource-grants/issue', headers=_session_headers(owner.id) | {'X-Chat-Id': chat.id, 'X-Ocu-Resource-Path': 'report.html'}, follow_redirects=False)
            if issued.status_code != 302:
                raise AssertionError('oracle setup issuance status=' + str(issued.status_code))
            grant = issued.headers['location'].split('/')[3]
            payload = grant.split('.')[0]
            claims = json.loads(base64.urlsafe_b64decode(payload + '=' * (-len(payload) % 4)))
            clock = SimpleNamespace(time=lambda: claims['iat'])
            patches.append(patch.object(grants, 'time', clock))
            fault = os.environ.get('ISSUE295_FAULT')
            if fault == 'signature':
                patches.append(patch.object(grants.hmac, 'compare_digest', lambda left, right: True))
            elif fault == 'claims':
                patches.append(patch.object(grants, '_valid_claims', lambda body, now: True))
            elif fault == 'owner':
                async def unchecked_owner(user_id, chat_id):
                    return await grants.Users.get_user_by_id(user_id)
                patches.append(patch.object(grants, '_authorized_owner', unchecked_owner))
            elif fault == 'revocation':
                async def unchecked_revocation(request, session):
                    return None
                patches.append(patch.object(grants, '_revocation_status', unchecked_revocation))
            elif fault == 'path':
                patches.append(patch.object(grants, '_valid_path', lambda path: True))
            elif fault:
                raise AssertionError('unknown fault')
            for context in patches:
                context.start()
            headers = {'X-Ocu-Grant': grant, 'X-Chat-Id': chat.id, 'X-Ocu-Resource-Path': 'other/data.json', 'X-Ocu-Resource-Method': 'GET'}

            def observe(label, request_headers, expected):
                response = client.get('/api/v1/ocu/resource-grants/auth', headers=request_headers)
                good = response.status_code == expected and response.content == b'' and response.headers.get('cache-control') == 'no-store'
                if expected == 200:
                    good = good and response.headers.get('x-user-id') == owner.id
                results.append({'case': label, 'expected': expected, 'actual': response.status_code, 'accepted': good})

            observe('valid-independent-signature', headers | {'X-Ocu-Grant': token(claims)}, 200)
            signature = grant.split('.')[1]
            altered = ('A' if signature[0] != 'A' else 'B') + signature[1:]
            observe('altered-signature', headers | {'X-Ocu-Grant': payload + '.' + altered}, 403)
            changes = [
                ('wrong-purpose', {'purpose': 'webui-session'}),
                ('wrong-owner', {'user_id': foreign.id}),
                ('future-issue', {'iat': claims['iat'] + 1}),
                ('excess-lifetime', {'exp': claims['iat'] + 601}),
                ('expired-exactly', {'exp': claims['iat']}),
                ('session-expiry-cap', {'session_exp': claims['exp'] - 1}),
                ('session-after-grant', {'session_iat': claims['iat'] + 1}),
                ('boolean-time', {'iat': True}),
                ('string-time', {'exp': str(claims['exp'])}),
                ('nonfinite-time', {'exp': float('inf')}),
                ('nan-time', {'session_iat': float('nan')}),
                ('mistyped-binding', {'session_jti': 42}),
                ('empty-binding', {'session_jti': ''}),
                ('oversized-token', {'session_jti': 'j' * 4096}),
                ('extra-claim', {'extra': 'unsupported'}),
            ]
            for label, change in changes:
                observe(label, headers | {'X-Ocu-Grant': token(claims | change)}, 403)
            body = json.dumps(claims, sort_keys=True, separators=(',', ':')).encode()
            duplicate = b'{"purpose":"ocu-resource-read",' + body[1:]
            observe('duplicate-claim', headers | {'X-Ocu-Grant': sign(duplicate)}, 403)
            for path in ('archive', '%61rchive', '../report.html', 'a/%2e%2e/b', 'a%2fb', 'a%5cb', 'a%252fb', 'a%00b', '/report.html', 'folder/'):
                observe('path:' + path, headers | {'X-Ocu-Resource-Path': path}, 403)
            for method in ('POST', 'OPTIONS', 'DELETE'):
                observe('method:' + method, headers | {'X-Ocu-Resource-Method': method}, 403)
            with patch.object(grants.env, 'REDIS_URL', 'redis://127.0.0.1:1'), patch.object(client.app.state, 'redis', None):
                observe('configured-store-unavailable', headers, 503)
            with patch.object(grants, 'time', SimpleNamespace(time=lambda: claims['exp'])):
                observe('grant-exact-expiry', headers, 403)
            with patch.object(grants, 'time', SimpleNamespace(time=lambda: claims['exp'] - 0.001)):
                observe('grant-before-expiry', headers, 200)
        failures = [result for result in results if not result['accepted']]
        print(json.dumps({'fault': fault, 'cases': results, 'failures': len(failures), 'credential_output': False}))
        return 1 if failures else 0
    finally:
        for context in reversed(patches):
            context.stop()
        asyncio.run(_cleanup_owner(owner.id, chat.id))
        asyncio.run(_cleanup_owner(foreign.id, other.id))


if __name__ == '__main__':
    raise SystemExit(run())
