"""Parent-owned actual HTTP probe; never emits credentials or redirect URLs."""
import asyncio
import json
import sys
from datetime import timedelta
from urllib.parse import urlsplit

import httpx

from open_webui.test.ocu_harness import _cleanup_owner, _owner_and_chat
from open_webui.utils.auth import create_token


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def run():
    owner, chat = asyncio.run(_owner_and_chat(prefix='grant-http'))
    foreign, other = asyncio.run(_owner_and_chat(prefix='grant-foreign'))
    results = []
    try:
        with httpx.Client(base_url='http://127.0.0.1:8080', follow_redirects=False, trust_env=False) as client:
            token = create_token({'id': owner.id}, timedelta(minutes=5))
            target = {'X-Chat-Id': chat.id, 'X-Ocu-Resource-Path': 'nested/report%20one.html', 'X-Ocu-Resource-Query': 'view=a%2Bb&empty='}
            for method in ('GET', 'HEAD'):
                response = client.request(method, '/api/v1/ocu/resource-grants/issue', headers=target | {'Cookie': f'token={token}'})
                require(response.status_code == 302, f'{method} issuer status={response.status_code}')
                require(response.content == b'', 'issuer empty body')
                require(response.headers.get('cache-control') == 'no-store', 'issuer no-store')
                require(response.headers.get('referrer-policy') == 'no-referrer', 'issuer referrer policy')
                location = urlsplit(response.headers['location'])
                require(not location.scheme and not location.netloc, 'relative redirect')
                parts = location.path.split('/')
                require(parts[:3] == ['', 'ocu', 'f'] and parts[4] == chat.id, 'redirect route')
                require('/'.join(parts[5:]) == target['X-Ocu-Resource-Path'], 'encoded path preservation')
                require(location.query == target['X-Ocu-Resource-Query'], 'query preservation')
                grant = parts[3]
                require(grant != token and len(grant.split('.')) == 2, 'distinct credential')
                headers = {'X-Ocu-Grant': grant, 'X-Chat-Id': chat.id, 'X-Ocu-Resource-Path': 'assets/data.json', 'X-Ocu-Resource-Method': method}
                cases = [('valid', headers, 200), ('holder-unrelated-cookie', headers | {'Cookie': 'token=invalid-holder'}, 200), ('wrong-chat', headers | {'X-Chat-Id': other.id}, 403), ('archive', headers | {'X-Ocu-Resource-Path': 'archive'}, 403), ('write', headers | {'X-Ocu-Resource-Method': 'POST'}, 403), ('session-confusion', headers | {'X-Ocu-Grant': token}, 403), ('missing', {k: v for k, v in headers.items() if k != 'X-Ocu-Grant'}, 401)]
                for name, request_headers, status in cases:
                    checked = client.get('/api/v1/ocu/resource-grants/auth', headers=request_headers)
                    require(checked.status_code == status, f'{method}/{name} status={checked.status_code}')
                    require(checked.content == b'' and checked.headers.get('cache-control') == 'no-store', f'{name} denial envelope')
                    if status == 200:
                        require(checked.headers.get('x-user-id') == owner.id and checked.headers.get('x-user-email') == owner.email, 'fresh owner identity')
                    results.append({'case': f'{method}/{name}', 'status': checked.status_code})
                confused = client.get('/api/v1/ocu/auth', headers={'Authorization': f'Bearer {grant}', 'X-Chat-Id': chat.id})
                require(confused.status_code == 401, 'grant cannot log in')
            for name, auth, expected in [('anonymous', {}, 401), ('foreign', {'Authorization': 'Bearer ' + create_token({'id': foreign.id})}, 403)]:
                refused = client.get('/api/v1/ocu/resource-grants/issue', headers=target | auth)
                require(refused.status_code == expected and 'location' not in refused.headers, name + ' entry refusal')
                results.append({'case': name, 'status': refused.status_code})
        print(json.dumps({'cases': results, 'credential_output': False}))
    finally:
        asyncio.run(_cleanup_owner(owner.id, chat.id))
        asyncio.run(_cleanup_owner(foreign.id, other.id))


if __name__ == '__main__':
    try:
        run()
    except AssertionError as error:
        print('PROBE REFUSED: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
