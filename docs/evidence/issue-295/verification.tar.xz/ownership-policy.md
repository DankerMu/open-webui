## 授权存储故障的状态边界

本次执行中，用户明确选择：**保留共享 ownership helper 的拒绝语义，明确503边界，不扩大共享认证代码的修改范围。**

依据：`Chats.is_chat_owner()` 在 `backend/open_webui/models/chats.py:1796–1801` 将内部数据库异常转换成 `False`。复用这个未修改的谓词时，路由无法区分数据库故障与非 owner；两者都拒绝授权。

批准的验收解释：
- 谓词内部吞掉的数据库故障仍为403，不能获得 grant 或资源授权。
- 用户查询异常、向路由传播的校验异常和已配置 Redis 不可用返回空体、no-store 的503。
- 不增加第二套 ownership 查询，不修改共享 predicate 或旧 `/api/v1/ocu/auth`。
- 路由测试分别覆盖真实 predicate 内部失败的403和可观察依赖异常的503；不会用替换 predicate 的 mock 冒充内部故障证明。

共享 OpenSpec 的 design D2 / tasks group1 已同步这一边界。#295 仍在实现与验证中；未提交 PR、未交付网关或浏览器能力。
