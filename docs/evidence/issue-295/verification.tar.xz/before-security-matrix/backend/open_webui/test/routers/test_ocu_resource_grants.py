from __future__ import annotations

import asyncio
from contextlib import closing
from unittest.mock import AsyncMock

import pytest
from fastapi.testclient import TestClient

from open_webui.test.ocu_harness import (
    _cleanup_owner,
    _owner_and_chat,
    _session_headers,
    get_client,
    session_test_client,
)


def test_owner_session_issues_grant_for_cookie_free_reads_of_same_chat_files():
    owner, chat = asyncio.run(_owner_and_chat(prefix='resource-grant-owner'))
    try:
        issued = get_client().get(
            '/api/v1/ocu/resource-grants/issue',
            headers={
                **_session_headers(owner.id),
                'X-Chat-Id': chat.id,
                'X-Ocu-Resource-Path': 'reports/annual%20summary%20%E4%B8%AD.html',
                'X-Ocu-Resource-Query': 'view=inline&label=a%2Bb%20c&revision=7',
            },
            follow_redirects=False,
        )
        assert issued.status_code == 302
        assert issued.content == b''
        assert issued.headers.get('Cache-Control') == 'no-store'
        assert issued.headers.get('Referrer-Policy') == 'no-referrer'

        location = issued.headers['Location']
        assert location.startswith('/ocu/f/')
        grant, separator, target = location.removeprefix('/ocu/f/').partition('/')
        assert separator == '/'
        assert target == (
            f'{chat.id}/reports/annual%20summary%20%E4%B8%AD.html'
            '?view=inline&label=a%2Bb%20c&revision=7'
        )

        with session_test_client() as holder:
            authorized = holder.get(
                '/api/v1/ocu/resource-grants/auth',
                headers={
                    'X-Ocu-Grant': grant,
                    'X-Chat-Id': chat.id,
                    'X-Ocu-Resource-Path': 'assets/site%20styles.css',
                    'X-Ocu-Resource-Method': 'GET',
                },
            )
        assert 'Cookie' not in authorized.request.headers
        assert 'Authorization' not in authorized.request.headers
        assert authorized.status_code == 200
        assert authorized.content == b''
        assert authorized.headers.get('X-User-Id') == owner.id
        assert authorized.headers.get('X-User-Email') == owner.email
        assert authorized.headers.get('Cache-Control') == 'no-store'
    finally:
        asyncio.run(_cleanup_owner(owner.id, chat.id))


@pytest.mark.parametrize('lookup', ['user', 'owner'], ids=['user-lookup', 'owner-lookup'])
@pytest.mark.parametrize('surface', ['issuer', 'verifier'])
def test_resource_authorization_refuses_unavailable_storage_without_credentials(surface, lookup, monkeypatch):
    from open_webui.models.chats import Chats
    from open_webui.models.users import Users

    owner, chat = asyncio.run(_owner_and_chat(prefix='resource-grant-storage'))
    try:
        headers = {
            **_session_headers(owner.id),
            'X-Chat-Id': chat.id,
            'X-Ocu-Resource-Path': 'reports/index.html',
            'X-Ocu-Resource-Query': '',
        }
        path = '/api/v1/ocu/resource-grants/issue'
        if surface == 'verifier':
            issued = get_client().get(path, headers=headers, follow_redirects=False)
            assert issued.status_code == 302
            grant = issued.headers['Location'].removeprefix('/ocu/f/').partition('/')[0]
            path = '/api/v1/ocu/resource-grants/auth'
            headers = {
                'X-Ocu-Grant': grant,
                'X-Chat-Id': chat.id,
                'X-Ocu-Resource-Path': 'assets/styles.css',
                'X-Ocu-Resource-Method': 'GET',
            }
        model, method = (Users, 'get_user_by_id') if lookup == 'user' else (Chats, 'is_chat_owner')
        with monkeypatch.context() as patch:
            patch.setattr(model, method, AsyncMock(side_effect=RuntimeError('Database unavailable')))
            with closing(TestClient(get_client().app, raise_server_exceptions=False)) as unavailable:
                response = unavailable.get(
                    path,
                    headers=headers,
                    follow_redirects=False,
                )
        assert response.status_code == 503
        assert response.content == b''
        assert response.headers.get('Cache-Control') == 'no-store'
        assert 'Location' not in response.headers
        assert 'X-User-Id' not in response.headers
        assert 'X-User-Email' not in response.headers
    finally:
        asyncio.run(_cleanup_owner(owner.id, chat.id))
