import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile

location = json.loads(Path('/tmp/issue-248-pin-location.json').read_text())
root = Path(location['snapshot']).resolve()
helper_path = root/'tests/orchestrator/test_outputs_endpoint.py'
spec = importlib.util.spec_from_file_location('pinned_outputs_endpoint_trace', helper_path)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
result = {
    'pin': location['pin'],
    'source_inputs': [
        {'path': name, 'sha256': hashlib.sha256((root/name).read_bytes()).hexdigest()}
        for name in ('computer-use-server/app.py', 'computer-use-server/outputs_broker.py',
                     'computer-use-server/docker_manager.py', 'tests/orchestrator/test_outputs_endpoint.py')
    ],
    'requests': [],
    'scope': 'Exact pinned FastAPI listing and broker on owned temporary files. No live Docker, network service or deployment mutation.',
}
try:
    with tempfile.TemporaryDirectory(prefix='issue-248-rename-data-') as temporary:
        with helper._isolated_app(Path(temporary)) as (app, manager, broker_module, data):
            assert Path(app.__file__).resolve().is_relative_to(root)
            assert Path(broker_module.__file__).resolve().is_relative_to(root)
            result['module_origins'] = {
                'app': str(Path(app.__file__).resolve()),
                'broker': str(Path(broker_module.__file__).resolve()),
            }
            docker_calls = []
            def forbid_docker():
                docker_calls.append(True)
                raise AssertionError('Listing contacted Docker')
            manager.get_docker_client = forbid_docker
            body = b'<p>same content across extension rename</p>\n'
            old_path = helper._put(data, 'notes.txt', body)
            new_path = old_path.with_name('notes.html')
            http = helper._client(app)
            try:
                first = http.get(helper._list_url(), headers=helper._auth())
                assert first.status_code == 200, first.text
                before = first.json()
                initial = before['files'][0]
                assert len(before['files']) == 1
                assert (initial['path'], initial['type'], initial['mime']) == ('notes.txt', 'text', 'text/plain')
                first_etag = first.headers['etag']
                unchanged = http.get(helper._list_url(), headers={**helper._auth(), 'If-None-Match': first_etag})
                assert unchanged.status_code == 304 and unchanged.content == b''
                old_path.rename(new_path)
                second = http.get(helper._list_url(), headers={**helper._auth(), 'If-None-Match': first_etag})
                assert second.status_code == 200, second.text
                after = second.json()
                renamed = after['files'][0]
                assert len(after['files']) == 1
                assert (renamed['path'], renamed['type'], renamed['mime']) == ('notes.html', 'html', 'text/html')
                assert renamed['file_id'] == initial['file_id']
                assert renamed['hash'] == initial['hash'] == hashlib.sha256(body).hexdigest()
                assert renamed['size'] == initial['size'] == len(body)
                assert renamed['revision'] == initial['revision'] + 1
                assert after['revision'] == before['revision'] + 1
                assert renamed['url'] == f'/ocu/files/{helper.CHAT}/notes.html'
                assert second.headers['etag'] != first_etag
                current = http.get(helper._list_url(), headers={**helper._auth(), 'If-None-Match': second.headers['etag']})
                assert current.status_code == 304 and current.content == b''
                index = json.loads(helper._index(data).read_text())
                assert set(index['active']) == {'notes.html'} and index['tombstones'] == {}
                assert new_path.read_bytes() == body and not old_path.exists()
                assert docker_calls == []
                result['requests'] = [
                    {'status': first.status_code, 'etag': first_etag, 'body': before},
                    {'status': unchanged.status_code, 'body_bytes': len(unchanged.content)},
                    {'status': second.status_code, 'etag': second.headers['etag'], 'body': after},
                    {'status': current.status_code, 'body_bytes': len(current.content)},
                ]
                result.update(same_identity=True, same_content=True, no_tombstone=True,
                              revision_increment=1, conditional_rename_response=200, docker_calls=0)
            finally:
                http.close()
    result['temporary_data_removed'] = not Path(temporary).exists()
    result['completed'] = True
finally:
    Path('/tmp/issue-248-producer-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
