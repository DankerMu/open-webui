import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time

root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
label, *argv = sys.argv[1:]
output = Path('/tmp') / f'issue-248-{label}.command.json'
if output.exists():
    raise SystemExit('Refusing to overwrite earlier evidence')
paths = [
    'src/lib/components/chat/WorkspaceArtifact.svelte',
    'src/lib/components/chat/WorkspaceArtifact.tree.test.ts',
    'src/lib/components/chat/WorkspaceArtifact.preview.test.ts',
    'src/lib/components/chat/WorkspaceSelectedFile.svelte',
    'src/lib/components/chat/workspace-file-rows.ts',
    'src/lib/components/chat/workspace-reconciliation.ts',
    'src/lib/stores/ocu.ts', 'src/lib/apis/ocu/index.ts',
    'test/ocu-workspace-fixtures.ts', 'e2e/ocu-tree.e2e.ts', 'e2e/ocu-fixtures.ts',
    'scripts/verify-ui-ocu.py', 'scripts/smoke-proxy.py', 'scripts/ocu-stub.py',
    'scripts/ocu_stub_nested.py', 'scripts/coverage-gate.sh', 'scripts/dev-env.sh',
    'Makefile', 'package.json', 'package-lock.json', 'vite.config.ts',
    'svelte.config.js', 'playwright.ocu.config.ts', 'constraints.yaml',
    'docs/decisions/implemented/architecture/2026-10-04-ocu-workspace-file-tree.md',
]

def identities():
    files = [root/name for name in paths]
    files += sorted((root/'openspec/changes/workspace-row-kind-refresh').rglob('*'))
    assert all((root/name).is_file() for name in paths)
    result = [{'path': str(p.relative_to(root)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
              for p in files if p.is_file()]
    manifest = root/'docs/evidence/issue-248/verification.json'
    result.append({'path': 'evidence_manifest', 'exists': manifest.is_file(),
                   'sha256': hashlib.sha256(manifest.read_bytes()).hexdigest() if manifest.is_file() else None})
    return result

env = os.environ.copy()
env['PATH'] = str(root/'.venv/bin') + ':/Users/danker/.nvm/versions/node/v22.23.2/bin:' + env['PATH']
# Verification reuses the installed locked environment instead of resyncing it mid-probe.
env['UV_NO_SYNC'] = '1'
record = {'argv': argv, 'cwd': str(root), 'platform': platform.platform(),
          'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
          'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'inputs_before': identities()}
started = time.time()
child = subprocess.Popen(argv, cwd=root, env=env, text=True, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, start_new_session=True)
interrupted = False
try:
    stdout, stderr = child.communicate(timeout=1800)
except (subprocess.TimeoutExpired, KeyboardInterrupt):
    interrupted = True
    os.killpg(child.pid, signal.SIGINT)
    try:
        stdout, stderr = child.communicate(timeout=30)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGKILL)
        stdout, stderr = child.communicate()
record.update(exit=child.returncode, elapsed=time.time()-started, interrupted=interrupted,
              stdout=stdout, stderr=stderr, inputs_after=identities())
record['inputs_unchanged'] = record['inputs_before'] == record['inputs_after']
output.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({key: value for key, value in record.items()
                  if key not in ('inputs_before', 'inputs_after', 'stdout', 'stderr')}))
print(stdout[-11000:])
print(stderr[-6000:])
raise SystemExit(child.returncode if not interrupted else 124)
