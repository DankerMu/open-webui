const fs = require('fs');
const crypto = require('crypto');
const { compile } = require('svelte/compiler');
const input = fs.readFileSync('src/lib/components/chat/WorkspaceArtifact.svelte', 'utf8');
const records = [false, true].map(dev => {
 const result = compile(input, { filename: 'src/lib/components/chat/WorkspaceArtifact.svelte', generate: 'client', dev });
 const lines = result.js.code.split('\n');
 const positions = lines.flatMap((line, i) => line.includes('KindIcon') ? [i] : []);
 return { dev, warnings: result.warnings.map(w => ({code:w.code,message:w.message})), fragments: positions.map(i => ({line:i+1,text:lines.slice(Math.max(0,i-3),Math.min(lines.length,i+5)).join('\n')})) };
});
console.log(JSON.stringify({svelte:require('svelte/package.json').version, source_sha256:crypto.createHash('sha256').update(input).digest('hex'),records},null,2));
