const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const root = '/Users/danker/Documents/31308/open-webui-ocu-plan2';
const load = createRequire(`${root}/package.json`);
const ts = load('typescript');
const before = fs.readFileSync('/tmp/issue-248-component-red-inputs/ocu-tree.e2e.ts', 'utf8');
const after = fs.readFileSync(`${root}/e2e/ocu-tree.e2e.ts`, 'utf8');
const hash = (value) => crypto.createHash('sha256').update(value).digest('hex');
function syntax(text) {
  const source = ts.createSourceFile('ocu-tree.e2e.ts', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  assert.deepEqual(source.parseDiagnostics, []);
  function visit(node) {
    const children = node.getChildren(source);
    return children.length ? [node.kind, children.map(visit)] : [node.kind, node.getText(source)];
  }
  return visit(source);
}
const first = syntax(before);
assert.deepEqual(syntax(after), first);
const result = {
  before_sha256: hash(before),
  after_sha256: hash(after),
  syntax_tree_sha256: hash(JSON.stringify(first)),
  identical_typescript_syntax_and_token_text: true,
  typescript_version: ts.version,
  evidence: 'The original browser RED used before_sha256; browser GREEN must use after_sha256. Comparison preserves syntax tree and token text, not only stripped whitespace.'
};
fs.writeFileSync('/tmp/issue-248-format-identity.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
