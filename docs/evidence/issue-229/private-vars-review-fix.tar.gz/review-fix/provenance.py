import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
base = '25ea240f0ca8bf99b6f660170d917ebdc68b01f7'
files = ['scripts/smoke_proxy_office.py', 'scripts/smoke_proxy_support.py', 'scripts/smoke-proxy.py', 'smoke/proxy/office.hurl', 'backend/open_webui/test/test_smoke_proxy_office.py']
fixtures = sorted(str(path.relative_to(root)) for path in (root / 'openspec/changes/office-hurl-private-vars').rglob('*') if path.is_file())
tracked_inputs = files + fixtures + ['docs/decisions/implemented/architecture/2026-09-25-ocu-cookie-gateway-and-paired-smoke.md']
def hashes():
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in tracked_inputs}
env = os.environ.copy()
env['PATH'] = '/Users/danker/.nvm/versions/node/v22.23.2/bin:' + str(root / '.venv/bin') + ':' + env['PATH']
result = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'inputs_before': hashes(), 'commands': []}
def run(label, argv, cwd=root):
    before = hashes()
    started = time.time()
    proc = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True, timeout=1800)
    row = {'label': label, 'argv': argv, 'exit': proc.returncode, 'elapsed': time.time()-started, 'inputs_before': before, 'inputs_after': hashes(), 'stdout': proc.stdout, 'stderr': proc.stderr}
    result['commands'].append(row)
    print(label, proc.returncode, proc.stdout[-1200:], proc.stderr[-1200:])
    return row
try:
    with tempfile.TemporaryDirectory(prefix='issue-229-final-red-') as temporary:
        copy = Path(temporary)
        for name in [files[0], files[1], files[3], files[4]]:
            destination = copy / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(root / name, destination)
        source = copy / files[0]
        candidate = source.read_bytes()
        original = subprocess.check_output(['git', 'show', base + ':' + files[0]], cwd=root)
        argv = [str(root / '.venv/bin/python'), '-m', 'pytest', '-q', '-p', 'no:cacheprovider', '--tb=short', '--basetemp', str(copy / 'pytest-runtime'), '-k', 'test_office_credentials_remain_private', str(copy / files[4])]
        source.write_bytes(original)
        red = run('final-test-original-source-red', argv, copy)
        red['executed_source_sha256'] = hashlib.sha256(original).hexdigest()
        assert red['exit'] == 1 and 'Office child argv exposed a managed credential' in red['stdout']
        source.write_bytes(candidate)
        green = run('final-test-restored-source-green', argv, copy)
        green['executed_source_sha256'] = hashlib.sha256(candidate).hexdigest()
        assert green['exit'] == 0
    result['owned_copy_removed'] = not copy.exists()
    shutil.copyfile('/tmp/issue-229-smoke-result.json', '/tmp/issue-229-initial-smoke-result.json')
    smoke = run('hash-bound-real-smoke', ['python3', '/tmp/issue-229-smoke.py'])
    result['runtime_result'] = json.loads(Path('/tmp/issue-229-smoke-result.json').read_text())
    assert smoke['exit'] == 0 and result['runtime_result']['success']
    assert run('hash-bound-docs', ['make', 'doc-gate', 'decisions-verify'])['exit'] == 0
    assert run('hash-bound-fixture', ['openspec', 'validate', 'office-hurl-private-vars', '--strict', '--no-interactive'])['exit'] == 0
finally:
    result['inputs_after'] = hashes()
    result['inputs_unchanged'] = result['inputs_before'] == result['inputs_after']
    Path('/tmp/issue-229-provenance-result.json').write_text(json.dumps(result, indent=2)+'\n')
assert result['inputs_unchanged']
