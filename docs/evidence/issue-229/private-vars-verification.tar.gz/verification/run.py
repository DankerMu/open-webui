import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
name, *argv = sys.argv[1:]
output = Path('/tmp') / f'issue-229-{name}.command.json'
if output.exists():
    raise SystemExit(f'Refusing evidence overwrite: {output}')
env = os.environ.copy()
env['PATH'] = '/Users/danker/.nvm/versions/node/v22.23.2/bin:' + str(root / '.venv/bin') + ':' + env['PATH']
inputs = ['scripts/smoke_proxy_office.py', 'scripts/smoke_proxy_support.py', 'smoke/proxy/office.hurl', 'backend/open_webui/test/test_smoke_proxy_office.py']
def identities():
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in inputs if (root / p).exists()}
before = identities()
start = time.time()
p = subprocess.run(argv, cwd=root, env=env, text=True, capture_output=True, timeout=1800)
record = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'argv': argv, 'exit': p.returncode, 'elapsed': time.time()-start, 'inputs_before': before, 'inputs_after': identities(), 'stdout': p.stdout, 'stderr': p.stderr}
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('stdout','stderr')}))
print(p.stdout[-6000:])
print(p.stderr[-2000:])
raise SystemExit(p.returncode)
