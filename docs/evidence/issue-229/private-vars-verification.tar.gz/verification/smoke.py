import collections
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile
import time

root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
env = os.environ.copy()
env['PATH'] = '/Users/danker/.nvm/versions/node/v22.23.2/bin:' + str(root / '.venv/bin') + ':' + env['PATH']
env['OCU_CHECKOUT'] = '/Users/danker/Documents/31308/open-computer-use'
audit_root = Path(tempfile.mkdtemp(prefix='issue-229-audit-', dir=root / '.run'))
bin_dir = audit_root / 'bin'
bin_dir.mkdir(mode=0o700)
shutil.copy2('/tmp/issue-229-hurl-audit.py', bin_dir / 'hurl')
(bin_dir / 'hurl').chmod(0o700)
commands = []
started = False
success = False
rows = []
def run(argv, command_env):
    begin = time.time()
    proc = subprocess.Popen(argv, cwd=root, env=command_env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    interrupted = False
    try:
        stdout, stderr = proc.communicate(timeout=900)
    except (subprocess.TimeoutExpired, KeyboardInterrupt):
        interrupted = True
        os.killpg(proc.pid, signal.SIGINT)
        stdout, stderr = proc.communicate()
    result = {'argv': argv, 'exit': proc.returncode, 'elapsed': time.time()-begin, 'interrupted': interrupted, 'stdout': stdout, 'stderr': stderr}
    commands.append(result)
    return result
try:
    status = run(['make', 'dev-status'], env)
    if status['exit']:
        started = True
        start = run(['make', 'dev-bg'], env)
        if start['exit'] or start['interrupted']:
            raise AssertionError('Owned development harness failed to start')
    active = env.copy()
    active['PATH'] = str(bin_dir) + ':' + env['PATH']
    smoke = run(['make', 'smoke-proxy'], active)
    audit = bin_dir / 'hurl-audit.jsonl'
    rows = [json.loads(line) for line in audit.read_text().splitlines()] if audit.exists() else []
    if smoke['exit'] or smoke['interrupted']:
        raise AssertionError('Permanent proxy smoke failed')
    if len(rows) != 40:
        raise AssertionError('Office child audit did not cover every expected launch')
    if not all(row['argv_credentials_absent'] and row['private_file'] and row['prior_request_files_removed'] for row in rows):
        raise AssertionError('Office credential or request-file lifetime audit failed')
    paths = [row['variables_path'] for row in rows]
    if len(set(paths)) != len(rows) or any(Path(path).exists() for path in paths):
        raise AssertionError('Office request variable files were reused or retained')
    expected_entries = {1: 1, 2: 4, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 7, 9: 17, 10: 5, 11: 1}
    if dict(collections.Counter(row['entry'] for row in rows)) != expected_entries:
        raise AssertionError('Office matrix entry coverage changed')
    anonymous = [row for row in rows if row['entry'] in (8, 9) and row['expected_status'] == '401']
    if len(anonymous) != 7 or any(row['cookie_class'] != 'empty' for row in anonymous):
        raise AssertionError('Anonymous matrix inherited an authenticated cookie')
    marker = 'Office: seven owner rows, 24 auth/guard denials and five unlisted denials passed'
    if marker not in smoke['stdout'] + smoke['stderr'] or 'smoke-proxy: ok' not in smoke['stdout'] + smoke['stderr']:
        raise AssertionError('Permanent matrix success evidence missing')
    success = True
finally:
    if started:
        stopped = run(['make', 'dev-stop'], env)
        if stopped['exit'] or stopped['interrupted']:
            success = False
    shutil.rmtree(audit_root)
    result = {'success': success, 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'commands': commands, 'office_audit': rows, 'office_launches': len(rows), 'services_started_by_probe': started, 'owned_audit_removed': not audit_root.exists()}
    Path('/tmp/issue-229-smoke-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ('commands', 'office_audit')}))
for command in commands:
    print(command['argv'], command['exit'])
    print(command['stdout'][-1500:])
    print(command['stderr'][-1500:])
raise SystemExit(0 if success else 1)
