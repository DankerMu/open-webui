#!/usr/bin/env python3
import json
import os
from pathlib import Path
import stat
import sys

REAL_HURL = '/opt/homebrew/bin/hurl'
args = sys.argv[1:]
if any(Path(arg).name == 'office.hurl' for arg in args):
    try:
        files = [Path(args[i + 1]) for i, arg in enumerate(args[:-1]) if arg == '--variables-file']
        if len(files) != 2 or files[0] == files[1]:
            raise RuntimeError('Office request must have dedicated variables file')
        maps = []
        for path in files:
            values = {}
            for line in path.read_text(encoding='utf-8').splitlines():
                name, separator, value = line.partition('=')
                if separator:
                    values[name] = value
            maps.append(values)
        base, current = maps
        if not all(base.get(key) for key in ('owner_cookie', 'foreign_cookie', 'owner_jwt')):
            raise RuntimeError('Missing credential audit inputs')
        sensitive = set()
        for values in maps:
            for key in ('owner_cookie', 'foreign_cookie', 'owner_jwt', 'office_cookie'):
                value = values.get(key, '')
                if value:
                    sensitive.add(value)
                    if value.startswith('token='):
                        sensitive.add(value.partition('=')[2])
        absent = not any(value in arg for value in sensitive for arg in args)
        path = files[1]
        info = path.lstat()
        mode = stat.S_IMODE(info.st_mode)
        parent_mode = stat.S_IMODE(path.parent.stat().st_mode)
        private = stat.S_ISREG(info.st_mode) and mode == 0o600 and parent_mode == 0o700 and path.parent == files[0].parent
        cookie = current.get('office_cookie')
        kind = 'empty' if cookie == '' else 'owner' if cookie == base['owner_cookie'] else 'foreign' if cookie == base['foreign_cookie'] else 'unexpected'
        entry = int(args[args.index('--from-entry') + 1])
        record = {'entry': entry, 'cookie_class': kind, 'expected_status': current.get('office_expected'), 'argv_credentials_absent': absent, 'private_file': private, 'mode': oct(mode), 'parent_mode': oct(parent_mode), 'variables_path': str(path)}
        # The production helper intentionally forwards only PATH, HOME and TERM.
        audit_dir = Path(__file__).resolve().parent
        if stat.S_IMODE(audit_dir.stat().st_mode) != 0o700:
            raise RuntimeError('Audit directory is not private')
        audit = audit_dir / 'hurl-audit.jsonl'
        prior = [json.loads(line) for line in audit.read_text().splitlines()] if audit.exists() else []
        prior_removed = all(not Path(row['variables_path']).exists() for row in prior)
        record['prior_request_files_removed'] = prior_removed
        fd = os.open(audit, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        with os.fdopen(fd, 'a') as stream:
            stream.write(json.dumps(record) + '\n')
        if not absent or not private or not prior_removed or kind == 'unexpected':
            raise RuntimeError('Office argv or variable-file privacy failed')
    except BaseException:
        sys.stderr.write('Office Hurl credential transport audit failed; values suppressed\n')
        raise SystemExit(97) from None
os.execv(REAL_HURL, [REAL_HURL, *args])
