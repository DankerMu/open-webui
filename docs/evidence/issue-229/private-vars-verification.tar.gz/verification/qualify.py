import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
files = ['scripts/smoke_proxy_office.py', 'scripts/smoke_proxy_support.py', 'smoke/proxy/office.hurl', 'backend/open_webui/test/test_smoke_proxy_office.py']
result = {'mode': 'cleanup mutant qualification, not a historical cleanup bug', 'cases': []}
with tempfile.TemporaryDirectory(prefix='issue-229-qualification-') as temporary:
    copy = Path(temporary)
    for name in files:
        destination = copy / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / name, destination)
    source = copy / files[0]
    candidate = source.read_text()
    needle = 'with tempfile.NamedTemporaryFile('
    assert candidate.count(needle) == 1
    mutant = candidate.replace(needle, 'with tempfile.NamedTemporaryFile(delete=False,', 1)
    result['input_hashes'] = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files}
    for label, content, expected in [('retained-private-file-mutant', mutant, 1), ('restored-candidate', candidate, 0)]:
        source.write_text(content)
        argv = [str(root / '.venv/bin/python'), '-m', 'pytest', '-q', '-p', 'no:cacheprovider', '--tb=short', str(copy / files[3])]
        started = time.time()
        completed = subprocess.run(argv, cwd=copy, capture_output=True, text=True, timeout=120)
        row = {'label': label, 'argv': argv, 'exit': completed.returncode, 'elapsed': time.time()-started, 'stdout': completed.stdout, 'stderr': completed.stderr, 'source_hash': hashlib.sha256(source.read_bytes()).hexdigest()}
        result['cases'].append(row)
        if completed.returncode != expected:
            break
result['owned_copy_removed'] = not copy.exists()
result['live_inputs_unchanged'] = result['input_hashes'] == {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files}
Path('/tmp/issue-229-qualification-result.json').write_text(json.dumps(result, indent=2)+'\n')
for row in result['cases']:
    print(row['label'], row['exit'])
    print(row['stdout'])
    print(row['stderr'])
assert len(result['cases']) == 2 and [row['exit'] for row in result['cases']] == [1, 0]
assert result['owned_copy_removed'] and result['live_inputs_unchanged']
