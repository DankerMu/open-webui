import http.server
import json
import os
from pathlib import Path
import secrets
import shutil
import stat
import subprocess
import tempfile
import threading

root = Path(tempfile.mkdtemp(prefix='issue-229-hurl-vars-'))
scratch_mode = stat.S_IMODE(root.stat().st_mode)
variable_modes = []
argv_leaks = []
received = []
markers = ['token=' + secrets.token_urlsafe(32) for _ in range(2)]
class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        received.append(self.headers.get('Cookie', ''))
        self.send_response(200)
        self.end_headers()
    def log_message(self, *args):
        pass
server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
thread = threading.Thread(target=server.serve_forever)
thread.start()
def private_file(path, content):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as stream:
        stream.write(content)
    variable_modes.append(stat.S_IMODE(path.stat().st_mode))
    if variable_modes[-1] != 0o600:
        raise AssertionError('Private variable file mode differs')
results = []
try:
    if scratch_mode != 0o700:
        raise AssertionError('Private scratch mode differs')
    base = root / 'base.vars'
    private_file(base, f'url=http://127.0.0.1:{server.server_port}\noffice_cookie={markers[0]}\n')
    request = root / 'request.hurl'
    request.write_text('GET {{url}}/probe\nCookie: {{office_cookie}}\nHTTP 200\n')
    for label, value in [('owner_override', markers[1]), ('anonymous_empty', '')]:
        override = root / (label + '.vars')
        private_file(override, f'office_cookie={value}\n')
        argv = ['hurl', '--test', '--max-time', '5', '--variables-file', str(base), '--variables-file', str(override), str(request)]
        argv_leaks.append(any(marker in arg for marker in markers for arg in argv))
        if argv_leaks[-1]:
            raise AssertionError('Probe credential present in argv')
        run = subprocess.run(argv, text=True, capture_output=True, timeout=10)
        safe_error = run.stderr
        for marker in markers:
            safe_error = safe_error.replace(marker, '<redacted>')
        results.append({'case': label, 'exit': run.returncode, 'effective_cookie_matches': bool(received) and received[-1] == value, 'stderr': safe_error})
        if run.returncode or not received or received[-1] != value:
            raise AssertionError('Hurl variables-file precedence failed')
        override.unlink()
finally:
    server.shutdown()
    server.server_close()
    thread.join()
    shutil.rmtree(root)
    report = {'cases': results, 'argv_contains_credentials': any(argv_leaks), 'scratch_mode': oct(scratch_mode), 'variable_modes': [oct(mode) for mode in variable_modes], 'owned_scratch_removed': not root.exists(), 'server_thread_stopped': not thread.is_alive()}
    Path('/tmp/issue-229-hurl-variables-result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
