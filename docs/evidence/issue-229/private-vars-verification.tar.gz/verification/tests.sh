#!/usr/bin/env bash
set -euo pipefail
source scripts/dev-env.sh
stage_frontend_assets
selection="${1:-test_smoke_proxy_office}"
PYTEST_ADDOPTS="-k '$selection' --tb=short" UV_NO_SYNC=1 make test-backend
