from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import tempfile
import time

web = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
ocu = Path('/Users/danker/Documents/31308/open-computer-use')
stage300 = Path('/tmp/issue-300-evidence')
delivery300 = Path('/tmp/issue-300-delivery')
private300 = Path('/tmp/issue-300-private')
for path in (stage300, delivery300, private300):
    path.mkdir(mode=0o700, exist_ok=True)
    if path.is_symlink():
        raise RuntimeError('Evidence directory cannot be a symlink')
os.chmod(private300, 0o700)
env300 = {'PATH':f'{Path.home()}/.nvm/versions/node/v22.23.2/bin:{web}/.venv/bin:{Path.home()}/.local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
          'HOME':str(Path.home()), 'LANG':'C.UTF-8', 'NO_PROXY':'127.0.0.1,localhost',
          'PYTHONDONTWRITEBYTECODE':'1', 'PYTHON_DOTENV_DISABLED':'1', 'OCU_CHECKOUT':str(ocu)}
patterns300 = {
    'signed_credential': re.compile(r'(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{24,}(?:\.[A-Za-z0-9_-]{24,}){1,2}(?![A-Za-z0-9_-])'),
    'grant_url': re.compile(r'/ocu/f/[^/\s\"\x27?#]{24,}'),
    'internal_canary': re.compile(r'Tok![0-9a-f]{24}#\$%'),
    'password_canary': re.compile(r'Proxy-[0-9a-f]{16}!'),
    'cdp_endpoint': re.compile(r'ws://(?:127\.0\.0\.1|localhost|\[::1\]):\d+/devtools/browser/[a-zA-Z0-9-]+'),
}
def capture300(name, command, *, cwd=web, expected=0, timeout=600, extra_env=None, require_private=True):
    target=stage300/(name+'.json')
    assert not target.exists(), target
    private=Path(tempfile.mkdtemp(prefix='capture-',dir=private300))
    start=time.monotonic()
    result=subprocess.run(command,cwd=cwd,env=env300|(extra_env or {}),capture_output=True,text=True,timeout=timeout)
    for key in ('stdout','stderr'):
        fd=os.open(private/key,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as stream: stream.write(getattr(result,key))
    raw=result.stdout+result.stderr
    canaries = set()
    witness = (extra_env or {}).get('OCU_PARENT_QUALIFICATION')
    if witness:
        canary_file = Path(witness).resolve() / 'credentials.json'
        if not canary_file.is_relative_to(private300.resolve()):
            raise RuntimeError('Managed canary file escaped private ownership')
        if canary_file.is_file():
            canaries.update(value for value in json.loads(canary_file.read_text()) if len(value) >= 8)
    findings={name:len(pattern.findall(raw)) for name,pattern in patterns300.items()}
    findings['managed_values'] = sum(value in raw for value in canaries)
    def sanitize(text):
        for value in sorted(canaries, key=len, reverse=True):
            text = text.replace(value, '<redacted-managed-credential>')
        for pattern in patterns300.values(): text=pattern.sub('<redacted-private-credential>',text)
        return text
    data={'command':command,'cwd':str(cwd),'exit':result.returncode,'elapsed_seconds':time.monotonic()-start,
          'stdout':sanitize(result.stdout),'stderr':sanitize(result.stderr),'public_credential_findings':findings,
          'private_capture':str(private)}
    target.write_text(json.dumps(data,indent=2)+'\n')
    print(name,'exit',result.returncode,'credential_patterns',findings,(data['stdout']+data['stderr'])[-2500:])
    assert result.returncode==expected, name
    if require_private: assert not any(findings.values()), name+' exposed credential in command output'
    return data
