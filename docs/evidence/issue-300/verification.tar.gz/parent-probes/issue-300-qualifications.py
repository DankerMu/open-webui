"""Parent-only runs of the actual Make browser entry; never claims filtered acceptance."""
async def browser_qualification300(name, *, expected, case=None, fault=None, cdp_fault=None, protected=False, screenshots=False):
    witness = private300 / (name + '-witness')
    extra = {'PYTHONPATH': '/tmp/issue-300-hook', 'OCU_PARENT_QUALIFICATION': str(witness)}
    if case:
        extra['OCU_PARENT_CASE'] = case
    if fault:
        extra['OCU_PARENT_FAULT'] = fault
    if cdp_fault:
        extra['OCU_PARENT_CDP_FAULT'] = cdp_fault
    if protected:
        extra['OCU_PARENT_CONFIG'] = '/tmp/issue-300-protected-spec/playwright.config.ts'
    try:
        result = capture300(name, ['make', 'verify-ui-ocu'], expected=expected, timeout=900, extra_env=extra)
    finally:
        await retire_browser_artifacts300(name, witness=witness, screenshots=screenshots)
        if (witness / 'witness.json').exists():
            observed = json.loads((witness / 'witness.json').read_text())
            (stage300 / (name + '-witness.json')).write_text(json.dumps(observed, indent=2) + '\n')
    assert all(observed[key] for key in ('process_groups_absent', 'ports_closed', 'owned_directories_removed')), name + ' leaked owned lifecycle'
    for report_name in ('resource-fault.json', 'popup-ownership.json', 'redaction-control.json'):
        if (witness / report_name).is_file():
            (stage300 / (name + '-' + report_name)).write_bytes((witness / report_name).read_bytes())
    return result, observed
