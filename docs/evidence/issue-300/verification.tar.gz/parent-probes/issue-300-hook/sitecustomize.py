"""Parent-owned instrumentation loaded only into the actual browser harness driver."""
import atexit
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import shutil
import zipfile

if sys.argv[0].endswith('scripts/verify-ui-ocu.py') and os.environ.get('OCU_PARENT_QUALIFICATION'):
    ROOT = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
    OCU = ROOT.parent / 'open-computer-use'
    PIN = '276e00aceddb332974a0390e01d69d9430065816'
    private = Path(os.environ['OCU_PARENT_QUALIFICATION']).resolve()
    if not private.is_relative_to(Path('/tmp/issue-300-private').resolve()):
        raise RuntimeError('Qualification witness escaped private ownership')
    private.mkdir(mode=0o700, parents=True, exist_ok=True)
    mode = os.environ.get('OCU_PARENT_FAULT', 'normal')
    original_popen = subprocess.Popen
    groups, ports, directories, canaries, inputs = [], set(), set(), set(), []
    commands = []
    signed = re.compile(r'(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{24,}(?:\.[A-Za-z0-9_-]{24,}){1,2}(?![A-Za-z0-9_-])')

    def persist_canaries():
        path = private / 'credentials.json'
        path.write_text(json.dumps(sorted(canaries)) + '\n')
        path.chmod(0o600)

    def witnessed_popen(command, *args, **kwargs):
        command = list(command) if isinstance(command, (tuple, list)) else command
        env = kwargs.get('env')
        if env:
            for key in ('WEBUI_SECRET_KEY', 'OCU_INTERNAL_TOKEN', 'OCU_E2E_PASSWORD'):
                if env.get(key):
                    canaries.add(env[key])
            for key in ('OCU_STUB_PORT', 'BACKEND_PORT', 'FRONTEND_PORT'):
                if env.get(key):
                    ports.add(int(env[key]))
            data = env.get('DATA_DIR')
            if data and Path(data).parent == ROOT / '.run/data':
                directories.add(data)
        persist_canaries()
        if isinstance(command, list):
            if any(signed.search(str(value)) or any(secret in str(value) for secret in canaries)
                   for value in command):
                raise RuntimeError('Credential appeared in browser harness child arguments')
            if mode in {'css', 'image', 'font', 'classic', 'module', 'fetch'} and any(
                str(value).endswith('/scripts/ocu-stub.py') for value in command
            ):
                command = ['/tmp/issue-300-fault-stub.py' if str(value).endswith('/scripts/ocu-stub.py') else value
                           for value in command]
                env = dict(env)
                env.update(OCU_QUALIFICATION_FAULT=mode, OCU_QUALIFICATION_REPORT=str(private / 'resource-fault.json'))
                kwargs['env'] = env
            if any(str(value).endswith('/scripts/proxy-dev.sh') for value in command) and env:
                stage = Path(env['OCU_CHECKOUT'])
                directories.add(str(stage.parent))
                config = (stage / 'deploy/proxy/nginx.conf').read_text()
                ports.update(int(value) for value in re.findall(r'listen\s+(?:127\.0\.0\.1:)?(\d+)\s*;', config))
                for relative in ('deploy/proxy/.gitignore', 'deploy/proxy/README.md', 'deploy/proxy/nginx.conf.in',
                                 'deploy/proxy/render.py', 'deploy/proxy/routes.json', 'deploy/proxy/tests/fixture.py',
                                 'deploy/proxy/tests/test_native.py', 'deploy/proxy/tests/test_render.py',
                                 'computer-use-server/static/preview.js'):
                    expected = subprocess.run(['git', '-C', str(OCU), 'show', PIN + ':' + relative],
                                              capture_output=True, check=True).stdout
                    if (stage / relative).read_bytes() != expected:
                        raise RuntimeError('Browser stage differs from reviewed pin')
                    inputs.append({'path': relative, 'sha256': hashlib.sha256(expected).hexdigest()})
            if command and str(command[0]).endswith('/node_modules/.bin/playwright') and '--list' not in command:
                env = dict(env)
                env['NODE_OPTIONS'] = (env.get('NODE_OPTIONS', '') + ' --require /tmp/issue-300-node-witness.cjs').strip()
                env['OCU_PARENT_NODE_LEDGER'] = str(private)
                if os.environ.get('OCU_PARENT_CDP_FAULT'):
                    env['OCU_PARENT_CDP_FAULT'] = os.environ['OCU_PARENT_CDP_FAULT']
                config = os.environ.get('OCU_PARENT_CONFIG')
                if config:
                    if Path(config).resolve() != Path('/tmp/issue-300-protected-spec/playwright.config.ts').resolve():
                        raise RuntimeError('Protected Playwright configuration differs')
                    command[command.index('--config') + 1] = config
                    env['OCU_PARENT_PROTECTED_OUTPUT'] = str(private / 'protected-test-results')
                kwargs['env'] = env
                selector = os.environ.get('OCU_PARENT_CASE')
                if selector:
                    command.extend(['--grep', selector])
            commands.append([str(value) for value in command])
        proc = original_popen(command, *args, **kwargs)
        if kwargs.get('start_new_session'):
            groups.append(proc.pid)
        return proc

    subprocess.Popen = witnessed_popen
    original_rmtree = shutil.rmtree
    retained = []

    def witnessed_rmtree(path, *args, **kwargs):
        owned = Path(path)
        if str(owned) in directories and owned.parent == ROOT / '.run' and owned.is_dir() and not owned.is_symlink():
            for artifact in owned.rglob('*'):
                if not artifact.is_file() or artifact.is_symlink():
                    continue
                if artifact.name not in {'trace.zip', 'error-context.md'} and not artifact.name.startswith('test-failed-'):
                    continue
                relative = artifact.relative_to(owned)
                target = private / 'retained-artifacts' / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(artifact, target)
                target.chmod(0o600)
                retained.append({'path': str(relative), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
                if artifact.name == 'trace.zip':
                    with zipfile.ZipFile(target) as trace:
                        for member in trace.infolist():
                            if member.filename.endswith(('.trace', '.network')) and member.file_size < 50_000_000:
                                canaries.update(signed.findall(trace.read(member).decode(errors='replace')))
                elif artifact.suffix == '.md':
                    canaries.update(signed.findall(target.read_text(errors='replace')))
            persist_canaries()
        return original_rmtree(path, *args, **kwargs)

    shutil.rmtree = witnessed_rmtree

    def absent(pid):
        try:
            os.killpg(pid, 0)
        except ProcessLookupError:
            return True
        return False

    def closed(port):
        with socket.socket() as sock:
            sock.settimeout(1)
            return sock.connect_ex(('127.0.0.1', port)) != 0

    def finish():
        node_events = []
        if (private / 'node-events.jsonl').is_file():
            node_events = [json.loads(line) for line in (private / 'node-events.jsonl').read_text().splitlines()]
            ports.update(row['port'] for row in node_events if row['kind'] == 'private-cdp')
        if (private / 'node-credentials.jsonl').is_file():
            canaries.update(json.loads(line) for line in (private / 'node-credentials.jsonl').read_text().splitlines())
        persist_canaries()
        (private / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        result = {'mode': mode, 'source_pin': PIN, 'source_files': inputs,
                  'owned_process_groups': groups, 'owned_ports': sorted(ports),
                  'process_groups_absent': all(absent(pid) for pid in groups),
                  'ports_closed': all(closed(port) for port in ports),
                  'owned_directories_removed': all(not Path(path).exists() for path in directories),
                  'owned_directories': sorted(directories), 'child_argv_guard': 'managed values and signed-credential patterns',
                  'selected_case': os.environ.get('OCU_PARENT_CASE'), 'selected_config': os.environ.get('OCU_PARENT_CONFIG'),
                  'cdp_fault': os.environ.get('OCU_PARENT_CDP_FAULT'), 'private_work': str(private),
                  'private_failure_artifacts': retained, 'node_observations': node_events}
        (private / 'witness.json').write_text(json.dumps(result, indent=2) + '\n')
    atexit.register(finish)
