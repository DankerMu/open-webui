const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const childProcess = require('node:child_process');
const { syncBuiltinESMExports } = require('node:module');
const root = process.env.OCU_PARENT_NODE_LEDGER;
if (root) {
  const expected = fs.realpathSync('/tmp/issue-300-private');
  const actual = fs.realpathSync(root);
  if (!actual.startsWith(expected + path.sep)) throw new Error('Node witness escaped private ownership');
  const events = path.join(actual, 'node-events.jsonl');
  const credentialFile = path.join(actual, 'node-credentials.jsonl');
  const append = (file, value) => fs.appendFileSync(file, JSON.stringify(value) + '\n', { mode: 0o600 });
  const signed = /(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{24,}(?:\.[A-Za-z0-9_-]{24,}){1,2}(?![A-Za-z0-9_-])/;
  const canaries = JSON.parse(fs.readFileSync(path.join(actual, 'credentials.json'), 'utf8'));
  const guard = values => {
    if (values.some(value => signed.test(String(value)) || canaries.some(secret => String(value).includes(secret))))
      throw new Error('Parent argv observer refused a private credential before launch');
  };
  globalThis.__ocuParentArgvGuard = guard;
  const spawn = childProcess.spawn;
  childProcess.spawn = function(command, args, options) {
    guard([command, ...(Array.isArray(args) ? args : [])]);
    append(events, { kind: 'child-argv-checked', pid: process.pid, command: path.basename(String(command)), argc: Array.isArray(args) ? args.length : 0 });
    if (['mint-interrupt', 'mint-sigint', 'mint-worker-exit', 'mint-deadline'].includes(process.env.OCU_PARENT_CDP_FAULT) &&
        Array.isArray(args) && args.includes('--mint-session')) {
      const changed = args.map(value => value === 'scripts/verify-ui-ocu.py' ? '/tmp/issue-300-mint-boundary.py' : value);
      const child = spawn.call(this, command, changed, {
        ...options, env: { ...options.env, OCU_PARENT_MINT_WITNESS: actual }
      });
      append(events, { kind: 'mint-process', pid: child.pid, workerPid: process.pid, detached: options.detached === true });
      return child;
    }
    const child = spawn.apply(this, arguments);
    append(events, { kind: 'child-process', pid: child.pid, ownerPid: process.pid, command: path.basename(String(command)), detached: options?.detached === true });
    return child;
  };
  syncBuiltinESMExports();
  let liveResource;
  const originalTimeout = globalThis.setTimeout;
  globalThis.setTimeout = function(callback, milliseconds, ...args) {
    if (process.env.OCU_PARENT_CDP_FAULT === 'skip-expiry' &&
        typeof callback === 'function' && milliseconds > 1000 &&
        new Error().stack?.includes('expireDocument')) {
      if (!liveResource) throw new Error('Expiry qualification lacks an observed live resource');
      return originalTimeout(async () => {
        const response = await fetch(liveResource, { redirect: 'manual' });
        append(events, { kind: 'qualification-fault', name: 'skip-expiry',
          skippedMilliseconds: milliseconds, liveGrantStatus: response.status });
        await response.arrayBuffer();
        callback(...args);
      }, 0);
    }
    return originalTimeout(callback, milliseconds, ...args);
  };
  const Original = globalThis.WebSocket;
  globalThis.WebSocket = class extends Original {
    foreignSessions = new Set();
    targetQueries = new Set();
    replacing = false;
    constructor(address, protocols) {
      super(address, protocols);
      const url = new URL(address);
      if (url.hostname !== '127.0.0.1' || !url.pathname.startsWith('/devtools/browser/')) return;
      const identity = crypto.createHash('sha256').update(String(address)).digest('hex');
      append(credentialFile, String(address));
      const row = { kind: 'private-cdp', pid: process.pid, port: Number(url.port), identity };
      append(events, { ...row, phase: 'constructed' });
      this.addEventListener('open', () => append(events, { ...row, phase: 'open' }));
      this.addEventListener('close', event => append(events, { ...row, phase: 'closed', code: event.code }));
      this.addEventListener('error', () => append(events, { ...row, phase: 'error' }));
      this.addEventListener('message', event => {
        try {
          const message = JSON.parse(String(event.data));
          const fields = message?.params;
          if (message?.method === 'Network.responseReceived' &&
              typeof fields?.response?.url === 'string' &&
              /\/ocu\/f\/[^/]+\/[^/]+\/data\.json$/.test(new URL(fields.response.url).pathname))
            liveResource = fields.response.url;
          if (process.env.OCU_PARENT_CDP_FAULT === 'wrong-final-target' &&
              !this.replacing && this.targetQueries.delete(message.id) &&
              Array.isArray(message.result?.targetInfos)) {
            const targets = message.result.targetInfos.filter(target => /\/ocu\/f\//.test(target.url));
            if (targets.length) {
              for (const target of targets) target.targetId = 'parent-wrong-final-target';
              append(events, { kind: 'qualification-fault', name: 'wrong-final-target', applied: true });
              event.stopImmediatePropagation();
              this.replacing = true;
              try {
                this.dispatchEvent(new MessageEvent('message', { data: JSON.stringify(message) }));
              } finally {
                this.replacing = false;
              }
            }
          }
          const foreign = process.env.OCU_PARENT_FOREIGN_CONTEXT;
          if (foreign && message?.method === 'Target.attachedToTarget' &&
              fields?.waitingForDebugger === true && typeof fields.sessionId === 'string' &&
              fields.targetInfo?.browserContextId === foreign)
            this.foreignSessions.add(fields.sessionId);
        } catch {
          // Non-JSON input cannot identify a session; the real client still receives it.
        }
      });
    }
    send(data) {
      if (typeof data === 'string') {
        const message = JSON.parse(data);
        if (message.method === 'Target.getTargets') this.targetQueries.add(message.id);
      }
      if (process.env.OCU_PARENT_CDP_FAULT === 'drop-foreign-resume' && this.foreignSessions.size && typeof data === 'string') {
        const message = JSON.parse(data);
        if (message.method === 'Runtime.runIfWaitingForDebugger' && this.foreignSessions.has(message.sessionId)) {
          append(events, { kind: 'qualification-fault', name: 'drop-foreign-resume', applied: true });
          queueMicrotask(() => this.dispatchEvent(new MessageEvent('message', {
            data: JSON.stringify({ id: message.id, result: {}, sessionId: message.sessionId })
          })));
          return;
        }
      }
      return super.send(data);
    }
  };
}
