import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import { createRequire } from 'node:module';
const require = createRequire('/Users/danker/Documents/31308/open-webui-ocu-plan2/package.json');
const { chromium } = require('@playwright/test');
const deadline = (work, label, ms = 5000) => {
  let timer;
  return Promise.race([work, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(label)), ms); })]).finally(() => clearTimeout(timer));
};
const server = http.createServer((request, response) => {
  if (request.url === '/entry') {
    response.writeHead(302, { Location: '/final', 'Cache-Control': 'no-store' }); response.end();
  } else {
    response.writeHead(200, { 'Content-Type': 'text/html', 'Content-Security-Policy': 'sandbox allow-scripts allow-forms', 'Cache-Control': 'no-store' });
    response.end('<!doctype html><p id="proof">ready</p>');
  }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
let browser, socket;
let failure;
const jobs = [], pending = new Map(), network = [];
let nextId = 0, selectedSession, ownedTarget;
const selected = Promise.withResolvers();
void selected.promise.catch(() => undefined);
function send(method, params = {}, sessionId) {
  const id = ++nextId;
  const result = Promise.withResolvers();
  pending.set(id, result);
  socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
  return deadline(result.promise, 'flat protocol timeout: ' + method).finally(() => pending.delete(id));
}
try {
  browser = await chromium.launch({ args: ['--remote-debugging-port=0', '--enable-automation'] });
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.setContent(`<a id="open" href="${origin}/entry" target="_blank">Open</a>`);
  const metadata = await browser.newBrowserCDPSession();
  const { arguments: command } = await metadata.send('Browser.getBrowserCommandLine');
  await metadata.detach();
  const profileArg = command.find(value => value.startsWith('--user-data-dir='));
  assert(profileArg);
  const profile = profileArg.slice('--user-data-dir='.length);
  const [port, route] = (await fs.readFile(path.join(profile, 'DevToolsActivePort'), 'utf8')).trim().split('\n');
  assert(/^\d+$/.test(port) && /^\/devtools\/browser\/[a-f0-9-]+$/.test(route));
  socket = new WebSocket(`ws://127.0.0.1:${port}${route}`);
  await deadline(new Promise((resolve, reject) => {
    socket.addEventListener('open', resolve, { once: true });
    socket.addEventListener('error', () => reject(new Error('Private CDP transport refused')), { once: true });
  }), 'Private CDP connection timeout');
  let existing;
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id) {
      const waiter = pending.get(message.id);
      if (message.error) waiter?.reject(new Error('Flat protocol rejected ' + message.error.code));
      else waiter?.resolve(message.result);
      return;
    }
    if (message.method === 'Target.attachedToTarget') {
      const event = message.params;
      const job = (async () => {
        const fresh = !existing.has(event.targetInfo.targetId);
        if (fresh) {
          ownedTarget = event.targetInfo.targetId;
          selectedSession = event.sessionId;
          await send('Network.enable', {}, selectedSession);
          await send('Runtime.enable', {}, selectedSession);
        }
        if (event.waitingForDebugger) await send('Runtime.runIfWaitingForDebugger', {}, event.sessionId);
        if (fresh) selected.resolve();
      })();
      jobs.push(job); job.catch(selected.reject);
    }
    if (message.sessionId === selectedSession && message.method === 'Network.requestWillBeSent' && message.params.redirectResponse)
      network.push({ kind: 'redirect', status: message.params.redirectResponse.status, from: message.params.redirectResponse.url, to: message.params.request.url });
    if (message.sessionId === selectedSession && message.method === 'Network.responseReceived' && message.params.type === 'Document')
      network.push({ kind: 'final', status: message.params.response.status, url: message.params.response.url });
  });
  existing = new Set((await send('Target.getTargets')).targetInfos.map(row => row.targetId));
  await send('Target.setAutoAttach', { autoAttach: true, waitForDebuggerOnStart: true, flatten: true,
    filter: [{ type: 'page', exclude: false }, { exclude: true }] });
  await page.locator('#open').click({ modifiers: ['ControlOrMeta'], timeout: 5000 });
  await deadline(selected.promise, 'Native flat target missing');
  let proof;
  const until = Date.now() + 5000;
  do {
    const result = await send('Runtime.evaluate', { expression: 'document.querySelector("#proof")?.textContent', returnByValue: true }, selectedSession);
    proof = result.result?.value;
    if (proof === 'ready' && network.some(row => row.kind === 'final')) break;
    await new Promise(resolve => setTimeout(resolve, 25));
  } while (Date.now() < until);
  assert.equal(proof, 'ready');
  assert(network.some(row => row.kind === 'redirect' && row.status === 302 && row.from === origin + '/entry' && row.to === origin + '/final'));
  assert(network.some(row => row.kind === 'final' && row.status === 200 && row.url === origin + '/final'));
  const discovery = `http://127.0.0.1:${port}/json/version`;
  const privileged = await fetch(discovery);
  assert(privileged.ok);
  assert.equal((await privileged.json()).webSocketDebuggerUrl, socket.url);
  const untrusted = await send('Runtime.evaluate', {
    expression: `(async()=>{try{const response=await fetch(${JSON.stringify(discovery)},{credentials:'omit'});await response.text();return 'readable';}catch{return 'blocked';}})()`,
    returnByValue: true, awaitPromise: true
  }, selectedSession);
  assert.equal(untrusted.result?.value, 'blocked');
  console.log(JSON.stringify({ native_modifier_click: true, flattened_transport: true, canonical302: true, final200: true,
    opaque_origin: (await send('Runtime.evaluate', { expression: 'self.origin', returnByValue: true }, selectedSession)).result.value,
    document: proof, browser_version: browser.version(), debug_port: Number(port), privileged_debug_discovery: true, opaque_debug_discovery: 'blocked' }));
} catch (error) {
  failure = error;
} finally {
  if (socket?.readyState === WebSocket.OPEN) {
    await send('Target.setAutoAttach', { autoAttach: true, waitForDebuggerOnStart: false, flatten: true,
      filter: [{ type: 'page', exclude: false }, { exclude: true }] }).catch(() => undefined);
    await Promise.allSettled(jobs);
    await send('Target.setAutoAttach', { autoAttach: false, waitForDebuggerOnStart: false, flatten: true }).catch(() => undefined);
    if (ownedTarget) await send('Target.closeTarget', { targetId: ownedTarget }).catch(() => undefined);
    socket.close();
  }
  if (browser) await deadline(browser.close(), 'Browser close timeout');
  server.closeAllConnections();
  await new Promise(resolve => server.close(resolve));
}
if (failure) throw failure;
