"""Parent-owned browser evidence capture; preserve pre-session files and private traces."""
import hashlib
import json
from pathlib import Path
import shutil

async def retire_browser_artifacts300(name, *, witness=None, screenshots=False):
    before = json.loads((stage300 / 'artifact-ownership-baseline.json').read_text())['files']
    private_run = private300 / (name + '-artifacts')
    private_run.mkdir(mode=0o700)
    canaries = set()
    if witness and (Path(witness) / 'credentials.json').is_file():
        canaries.update(value for value in json.loads((Path(witness) / 'credentials.json').read_text()) if len(value) >= 8)
    changed, findings, public_images = [], [], []
    for relative_root in ('.run/ui-evidence', 'test-results'):
        root = web / relative_root
        if not root.exists():
            continue
        for path in list(root.rglob('*')):
            if not path.is_file() or path.is_symlink():
                continue
            relative = str(path.relative_to(web))
            content = path.read_bytes()
            digest = hashlib.sha256(content).hexdigest()
            if relative in before and before[relative]['sha256'] == digest:
                continue
            target = private_run / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
            target.chmod(0o600)
            changed.append({'path': relative, 'sha256': digest, 'bytes': len(content)})
            if path.suffix in {'.json', '.log', '.md', '.txt', '.html'}:
                text = content.decode(errors='replace')
                matched = {key: len(pattern.findall(text)) for key, pattern in patterns300.items()}
                matched['managed_values'] = sum(value in text for value in canaries)
                if any(matched.values()):
                    findings.append({'path': relative, 'findings': matched})
                for value in sorted(canaries, key=len, reverse=True):
                    text = text.replace(value, '<redacted-managed-credential>')
                for pattern in patterns300.values():
                    text = pattern.sub('<redacted-private-credential>', text)
                await tool.write({'i': 'Saving sanitized browser artifact',
                    'path': str(stage300 / name / relative), 'content': text})
            elif screenshots and path.suffix == '.png' and relative.startswith('.run/ui-evidence/'):
                public = stage300 / name / 'screenshots' / path.name
                public.parent.mkdir(parents=True, exist_ok=True)
                public.write_bytes(content)
                public_images.append(str(public))
            path.unlink()
    for relative, metadata in before.items():
        target = web / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        backup = private300 / 'before-browser-artifacts' / relative
        if not target.exists() or hashlib.sha256(target.read_bytes()).hexdigest() != metadata['sha256']:
            shutil.copyfile(backup, target)
            target.chmod(metadata['mode'])
    for relative_root in ('.run/ui-evidence', 'test-results'):
        root = web / relative_root
        if root.exists():
            for path in sorted(root.rglob('*'), key=lambda item: len(item.parts), reverse=True):
                if path.is_dir() and not any(path.iterdir()):
                    path.rmdir()
    result = {'run': name, 'changed_files': changed, 'text_credential_findings': findings,
              'public_images_pending_visual_inspection': public_images,
              'preexisting_files_restored': len(before), 'raw_artifacts_private': str(private_run)}
    (stage300 / (name + '-artifacts.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(name, 'captured', len(changed), 'files; text credential findings', len(findings),
          'screenshots awaiting inspection', len(public_images), '; prior files restored')
    return result
