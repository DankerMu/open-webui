import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import { test, openAuthenticatedPage } from '/Users/danker/Documents/31308/open-webui-ocu-plan2/e2e/ocu-auth';
import { context as fixture, observeNativeOcuPopup, redactOcu } from '/Users/danker/Documents/31308/open-webui-ocu-plan2/e2e/ocu-fixtures';
import { openBrowserCdp, type BrowserCdpController, type CdpTargetSession } from '/Users/danker/Documents/31308/open-webui-ocu-plan2/scripts/ocu-target-bridge.mjs';
const require = createRequire('/Users/danker/Documents/31308/open-webui-ocu-plan2/package.json');
const { expect } = require('@playwright/test');
const privateRoot = process.env.OCU_PARENT_NODE_LEDGER!;
type ForeignTarget = { targetId: string; session: CdpTargetSession };
async function createForeignTarget(root: BrowserCdpController, browserContextId: string): Promise<ForeignTarget> {
  const html = '<p id="alive">0</p><script>setInterval(()=>document.querySelector("#alive").textContent=String(Number(document.querySelector("#alive").textContent)+1),20)</script>';
  const { targetId } = await root.send('Target.createTarget', {
    browserContextId, url: 'data:text/html,' + encodeURIComponent(html)
  });
  const { sessionId } = await root.send('Target.attachToTarget', { targetId, flatten: true });
  return { targetId, session: root.session(sessionId) };
}
async function foreignHeartbeat(target: ForeignTarget) {
  const result = await target.session.send('Runtime.evaluate', {
    expression: 'Number(document.querySelector("#alive")?.textContent ?? -1)', returnByValue: true
  });
  if (result.exceptionDetails) throw new Error('Foreign document evaluation failed');
  return result.result?.value;
}

test('parent native popup resumes foreign targets and retires after controlled failure', async ({ page, context, browser }) => {
  test.setTimeout(45_000);
  const foreignRoot = await openBrowserCdp(browser);
  const { browserContextId } = await foreignRoot.send('Target.createBrowserContext', { disposeOnDetach: true });
  process.env.OCU_PARENT_FOREIGN_CONTEXT = browserContextId;
  let foreignFirst: ForeignTarget | undefined;
  await context.addInitScript(() => {
    const events: Array<{ origin: string; type: string; storage: string; parentAccess: string; cookie: string }> = [];
    Object.defineProperty(window, 'fixtureEvents', { value: events, writable: true, configurable: true });
    window.addEventListener('message', event => {
      const data: unknown = event.data;
      if (data !== null && typeof data === 'object' &&
          'type' in data && (data.type === 'fixture-opaque' || data.type === 'fixture-svg') &&
          'storage' in data && data.storage === 'blocked' &&
          'parentAccess' in data && data.parentAccess === 'blocked' &&
          'cookie' in data && data.cookie === 'blocked')
        events.push({ origin: event.origin, type: data.type, storage: data.storage, parentAccess: data.parentAccess, cookie: data.cookie });
    });
  });
  const canonical = `/ocu/files/${fixture.chats.link}/page.html`;
  const screenshot = path.join(privateRoot, 'owned-native-popup.png');
  let foreignSecond: ForeignTarget | undefined;
  let reachedOwned = false;
  let failureObserved = false;
  try {
    foreignFirst = await createForeignTarget(foreignRoot, browserContextId);
    await expect.poll(() => foreignHeartbeat(foreignFirst!)).toBeGreaterThan(0);
    await openAuthenticatedPage(page, `/c/${fixture.chats.link}`);
    const link = page.getByRole('link', { name: 'Open generated workspace file', exact: true });
    await expect(link).toBeVisible();
    try {
      await observeNativeOcuPopup(context, page, canonical, 'html',
        () => link.click({ modifiers: ['ControlOrMeta'] }), screenshot,
        async popup => {
          reachedOwned = true;
          expect(await popup.evaluate('document.querySelector("#proof").textContent')).toBe('null|blocked|blocked|blocked');
          const before = await foreignHeartbeat(foreignFirst!);
          foreignSecond = await createForeignTarget(foreignRoot, browserContextId);
          fs.writeFileSync(path.join(privateRoot, 'foreign-evaluation.json'), JSON.stringify({
            ownedPopupReached: reachedOwned, existingHeartbeat: before, foreignTargetCreated: true
          }));
          try {
            await expect.poll(() => foreignHeartbeat(foreignSecond!), {
              message: 'foreign paused target did not resume while native observer was active', timeout: 5000
            }).toBeGreaterThan(0);
          } catch (error) {
            throw new Error('foreign paused target did not resume while native observer was active', { cause: error });
          }
          await expect.poll(() => foreignHeartbeat(foreignFirst!)).toBeGreaterThan(before);
          throw new Error('parent-controlled-native-observer-failure');
        });
    } catch (error) {
      failureObserved = String(error).includes('parent-controlled-native-observer-failure');
      if (!failureObserved) throw error;
    }
    expect(reachedOwned && failureObserved, 'controlled failure occurs after real owned popup and foreign liveness').toBe(true);
    const { targetInfos } = await foreignRoot.send('Target.getTargets');
    for (const target of [foreignFirst!, foreignSecond!])
      expect(targetInfos.some((info: { targetId: string }) => info.targetId === target.targetId),
        'observer did not close foreign targets').toBe(true);
    await expect.poll(() => foreignHeartbeat(foreignSecond!)).toBeGreaterThan(0);
    const after = await createForeignTarget(foreignRoot, browserContextId);
    await expect.poll(() => foreignHeartbeat(after)).toBeGreaterThan(0);
    await observeNativeOcuPopup(context, page, canonical, 'html',
      () => link.click({ modifiers: ['ControlOrMeta'] }), path.join(privateRoot, 'native-after-retirement.png'),
      async popup => expect(await popup.evaluate('document.querySelector("#proof").textContent')).toBe('null|blocked|blocked|blocked'));
    fs.writeFileSync(path.join(privateRoot, 'popup-ownership.json'), JSON.stringify({
      actualNativePopup: true, foreignResumedDuringVisit: true, controlledFailurePreserved: true,
      foreignTargetsNotClosed: true, subsequentForeignPageRuns: true, subsequentNativePopupRuns: true
    }));
  } finally {
    delete process.env.OCU_PARENT_FOREIGN_CONTEXT;
    try {
      await foreignRoot.send('Target.disposeBrowserContext', { browserContextId });
    } finally {
      await foreignRoot.close();
    }
  }
});

test('parent public evidence masks a controlled capability-bearing failure', async () => {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const payload = Buffer.from(JSON.stringify({ sub: 'parent-redaction-control', exp: 4102444800 })).toString('base64url');
  const capability = `${header}.${payload}.${'a'.repeat(43)}`;
  const input = `parent-intentional-redaction-boundary ${fixture.origin}/ocu/f/${capability}/${fixture.chats.link}/page.html`;
  fs.appendFileSync(path.join(privateRoot, 'node-credentials.jsonl'), JSON.stringify(capability) + '\n', { mode: 0o600 });
  const negativeDetected = input.includes(capability);
  expect(negativeDetected, 'independent observer rejects the unredacted negative control').toBe(true);
  expect(redactOcu(input).includes(capability), 'browser/popup sanitizer removes capability').toBe(false);
  expect(redactOcu('ws://127.0.0.1:12345/devtools/browser/parent-private-endpoint')).toBe('[private CDP endpoint]');
  fs.writeFileSync(path.join(privateRoot, 'redaction-control.json'), JSON.stringify({
    unsanitizedNegativeDetected: negativeDetected, browserSanitizerMaskedCapability: true,
    browserSanitizerMaskedDebuggerEndpoint: true, pythonReporterBoundaryExercised: true
  }));
  throw new Error(input);
});
