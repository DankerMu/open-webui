import base from '/Users/danker/Documents/31308/open-webui-ocu-plan2/playwright.ocu.config';

export default {
  ...base,
  testDir: '/tmp/issue-300-protected-spec',
  testMatch: ['popup-ownership.e2e.ts', 'cleanup-order.e2e.ts'],
  outputDir: process.env.OCU_PARENT_PROTECTED_OUTPUT,
  retries: 0,
  workers: 1
};
