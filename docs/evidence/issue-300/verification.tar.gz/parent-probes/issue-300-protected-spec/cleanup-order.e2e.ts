import fs from 'node:fs';
import path from 'node:path';
import { expect } from '/Users/danker/Documents/31308/open-webui-ocu-plan2/node_modules/@playwright/test';
import { test } from '/Users/danker/Documents/31308/open-webui-ocu-plan2/e2e/ocu-auth';
import '/Users/danker/Documents/31308/open-webui-ocu-plan2/e2e/ocu-resources.e2e';

const transitions: Array<{ event: string; at: number }> = [];
test.beforeEach(async ({ context }) => {
  const attach = context.newCDPSession.bind(context);
  context.newCDPSession = async target => {
    const session = await attach(target);
    if (!('context' in target)) throw new Error('Direct teardown qualification requires the actual Page');
    target.once('close', () => transitions.push({ event: 'page-closed', at: performance.now() }));
    const detach = session.detach.bind(session);
    session.detach = async () => {
      transitions.push({ event: 'detach-start', at: performance.now() });
      const delay = Promise.withResolvers<void>();
      setTimeout(delay.resolve, 200);
      await delay.promise;
      await detach();
      transitions.push({ event: 'detach-end', at: performance.now() });
    };
    return session;
  };
});
test.afterEach(async () => {
  const detached = transitions.find(row => row.event === 'detach-end');
  const closed = transitions.find(row => row.event === 'page-closed');
  expect(detached, 'actual delayed CDP detach completed').toBeDefined();
  expect(closed, 'actual owned direct Page closed').toBeDefined();
  expect(closed!.at, 'page retirement follows completed dependent-session retirement').toBeGreaterThan(detached!.at);
  fs.writeFileSync(path.join(process.env.OCU_PARENT_NODE_LEDGER!, 'cleanup-order.json'), JSON.stringify(transitions));
});
