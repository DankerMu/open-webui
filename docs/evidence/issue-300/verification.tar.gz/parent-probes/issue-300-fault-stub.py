"""Parent-only byte faults; executes the actual deterministic OCU HTTP stub."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import struct
import sys
import zlib

ROOT = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
sys.path.insert(0, str(ROOT / 'scripts'))
loaded = runpy.run_path(str(ROOT / 'scripts/ocu-stub.py'))
files = loaded['FILES']
mode = os.environ['OCU_QUALIFICATION_FAULT']
paths = {'css': 'style.css', 'image': 'relative.png', 'font': 'font.ttf',
         'classic': 'classic.js', 'module': 'module.js', 'fetch': 'data.json'}
name = paths[mode]
mime, original = files[name]
if mode == 'css':
    rule = b'#styled { color: rgb(17, 34, 51); }\n'
    if original.count(rule) != 1:
        raise RuntimeError('Stylesheet counterexample requires one relative-only rule')
    candidate = original.replace(rule, b'')
elif mode == 'image':
    def chunk(kind, data):
        return struct.pack('!I', len(data)) + kind + data + struct.pack('!I', zlib.crc32(kind + data))
    candidate = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('!IIBBBBB', 7, 3, 8, 6, 0, 0, 0))
    candidate += chunk(b'IDAT', zlib.compress((b'\x00' + b'\xff\x00\x00\xff' * 7) * 3)) + chunk(b'IEND', b'')
elif mode == 'font':
    candidate = b'parent qualification invalid font bytes'
elif mode == 'classic':
    candidate = b'void 0;\n'
elif mode == 'module':
    if b'ocu-stub-module' not in original:
        raise RuntimeError('Module counterexample requires its preserved marker')
    candidate = original.replace(b'ocu-stub-module', b'qualified-wrong-module')
else:
    def wrong(value):
        if isinstance(value, dict):
            return {key: wrong(child) for key, child in value.items()}
        if isinstance(value, list):
            return [wrong(child) for child in value]
        if isinstance(value, bool):
            return not value
        if isinstance(value, (int, float)):
            return value + 1
        return 'qualified-wrong-data'
    candidate = json.dumps(wrong(json.loads(original))).encode()
if candidate == original:
    raise RuntimeError('Qualification fault did not change resource bytes')
files[name] = (mime, candidate)
report = Path(os.environ['OCU_QUALIFICATION_REPORT'])
report.write_text(json.dumps({'mode': mode, 'resource': name, 'mime': mime,
    'original_sha256': hashlib.sha256(original).hexdigest(),
    'candidate_sha256': hashlib.sha256(candidate).hexdigest()}) + '\n')
raise SystemExit(loaded['main']())
