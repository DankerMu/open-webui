"""Parent-only pause after the real canonical signer returns a token; no candidate edits."""
import json
import os
from pathlib import Path
import runpy
import sys

ROOT = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
private = Path(os.environ['OCU_PARENT_MINT_WITNESS']).resolve()
if not private.is_relative_to(Path('/tmp/issue-300-private').resolve()):
    raise RuntimeError('Minter interruption witness escaped ownership')
sys.path.insert(0, str(ROOT / 'scripts'))
import smoke_proxy_resources

original_popen = smoke_proxy_resources.subprocess.Popen

def held_signer(command, *args, **kwargs):
    if isinstance(command, list) and command and isinstance(command[-1], str) and 'token=create_token(' in command[-1]:
        command = list(command)
        marker = private / 'mint-boundary.json'
        hold = (
            'import os,pathlib,time; '
            f'pathlib.Path({str(marker)!r}).write_text(json.dumps({{"signer_pid":os.getpid(),'
            '"signer_pgid":os.getpgrp(),"signer_parent":os.getppid(),"token_created":bool(token),'
            '"static_dir":os.environ["STATIC_DIR"],"data_dir":os.environ["DATA_DIR"]})); '
            'time.sleep(120); '
        )
        old = 'print("OCU_SHORT_SESSION="'
        if command[-1].count(old) != 1:
            raise RuntimeError('Actual signer publication boundary differs')
        command[-1] = command[-1].replace(old, hold + old)
    return original_popen(command, *args, **kwargs)

smoke_proxy_resources.subprocess.Popen = held_signer
(private / 'mint-wrapper.json').write_text(json.dumps({'pid':os.getpid(),'pgid':os.getpgrp(),'parent':os.getppid()}))
sys.argv = [str(ROOT / 'scripts/verify-ui-ocu.py'), '--mint-session']
runpy.run_path(sys.argv[0], run_name='__main__')
