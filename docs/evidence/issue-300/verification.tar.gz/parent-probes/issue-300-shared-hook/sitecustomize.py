"""Parent-only observation of the real shared smoke signer's cancellation boundary."""
import ast
import atexit
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import sqlite3
import subprocess
import sys
import threading
import time

if sys.argv[0].endswith('scripts/smoke-proxy.py') and os.environ.get('OCU_PARENT_QUALIFICATION'):
    root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
    private = Path(os.environ['OCU_PARENT_QUALIFICATION']).resolve()
    if not private.is_relative_to(Path('/tmp/issue-300-private').resolve()):
        raise RuntimeError('Shared signer witness escaped private ownership')
    private.mkdir(mode=0o700, parents=True, exist_ok=True)
    mode = os.environ['OCU_PARENT_SHARED_FAULT']
    groups, canaries, assets, removals, processes = [], set(), set(), [], []
    original_popen, original_rmtree = subprocess.Popen, shutil.rmtree
    pidfiles = {name: (root / '.run' / name).read_bytes() for name in ('backend.pid', 'frontend.pid')}
    database = root / '.run/data/webui.db'

    def identities():
        with sqlite3.connect(f'file:{database}?mode=ro', uri=True) as connection:
            return {table: sorted(row[0] for row in connection.execute(f'SELECT id FROM "{table}"'))
                    for table in ('user', 'chat', 'folder')}

    before_rows = identities()

    def alive(pid):
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        return True

    def group_absent(group):
        try:
            os.killpg(group, 0)
        except ProcessLookupError:
            return True
        return False

    def persist_canaries():
        file = private / 'credentials.json'
        file.write_text(json.dumps(sorted(canaries)))
        file.chmod(0o600)

    def capture_ancestry(leader):
        output = subprocess.run(['ps', '-axo', 'pid=,ppid=,pgid='], capture_output=True, text=True, check=True).stdout
        rows = [dict(zip(('pid', 'parent', 'group'), map(int, line.split()))) for line in output.splitlines()]
        owned = {leader}
        while True:
            expanded = owned | {row['pid'] for row in rows if row['parent'] in owned}
            if expanded == owned:
                break
            owned = expanded
        processes[:] = [row for row in rows if row['pid'] in owned]

    def interrupt_after_signing(leader):
        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            try:
                marker = json.loads((private / 'mint-boundary.json').read_text())
                if marker['token_created']:
                    capture_ancestry(leader)
                    if marker['signer_pid'] not in {row['pid'] for row in processes}:
                        raise RuntimeError('Real shared signer escaped observed ancestry')
                    (private / 'interruption-trigger.json').write_text(json.dumps({'mode': mode, 'actual_token_created': True}))
                    os.kill(os.getpid(), signal.SIGTERM)
                    return
            except (FileNotFoundError, json.JSONDecodeError):
                pass
            time.sleep(.02)
        raise RuntimeError('Real shared signer boundary was not reached')

    def tracked_popen(command, *args, **kwargs):
        env = kwargs.get('env') or {}
        for key in ('WEBUI_SECRET_KEY', 'OCU_INTERNAL_TOKEN', 'OCU_E2E_PASSWORD'):
            if env.get(key):
                canaries.add(env[key])
        if isinstance(command, list) and '--variables-file' in command:
            file = Path(command[command.index('--variables-file') + 1]).resolve()
            if not file.is_relative_to((root / '.run').resolve()):
                raise RuntimeError('Hurl variables escaped owned runtime directory')
            canaries.update(re.findall(r'(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{24,}(?:\.[A-Za-z0-9_-]{24,}){1,2}', file.read_text()))
        if isinstance(command, list) and any(secret in str(argument) for secret in canaries for argument in command):
            raise RuntimeError('Private credential appeared in child argv')
        persist_canaries()
        proc = original_popen(command, *args, **kwargs)
        if kwargs.get('start_new_session'):
            groups.append(proc.pid)
        signer = isinstance(command, list) and command and isinstance(command[-1], str) and 'token=create_token(' in command[-1]
        if signer:
            asset = Path(env['STATIC_DIR']).parent
            if asset.parent.parent != root / '.run' or not asset.parent.name.startswith('smoke-proxy-'):
                raise RuntimeError('Shared signer assets escaped owning scratch')
            assets.add(str(asset))
            (private / 'signer-owner.json').write_text(json.dumps({'leader': proc.pid, 'group': os.getpgid(proc.pid), 'asset': str(asset)}))
            if mode == 'registration':
                capture_ancestry(proc.pid)
                blocked = signal.SIGTERM in signal.pthread_sigmask(signal.SIG_BLOCK, set())
                (private / 'interruption-trigger.json').write_text(json.dumps({'mode': mode, 'signal_blocked_before_source_registration': blocked}))
                os.kill(os.getpid(), signal.SIGTERM)
            else:
                threading.Thread(target=interrupt_after_signing, args=(proc.pid,), daemon=True).start()
        return proc

    # Reuse the same canonical post-token hold; import only its function AST, never its CLI body.
    probe = Path('/tmp/issue-300-mint-boundary.py')
    tree = ast.parse(probe.read_text())
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'held_signer')
    namespace = {'private': private, 'original_popen': tracked_popen}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(probe), 'exec'), namespace)
    subprocess.Popen = namespace['held_signer']

    def observed_rmtree(path, *args, **kwargs):
        if str(path) in assets:
            removals.append({'asset': str(path), 'live_signer_processes': [row['pid'] for row in processes if alive(row['pid'])]})
        return original_rmtree(path, *args, **kwargs)

    shutil.rmtree = observed_rmtree

    def finish():
        persist_canaries()
        result = {'mode': mode, 'owned_groups': groups, 'all_groups_absent': all(group_absent(group) for group in groups),
                  'signer_processes': processes, 'signer_processes_alive': [row['pid'] for row in processes if alive(row['pid'])],
                  'asset_removals': removals, 'assets_removed': all(not Path(asset).exists() for asset in assets),
                  'dev_pidfiles_unchanged': all((root / '.run' / name).read_bytes() == value for name, value in pidfiles.items()),
                  'unowned_and_created_row_identities_restored': identities() == before_rows,
                  'hold_probe_sha256': hashlib.sha256(probe.read_bytes()).hexdigest()}
        if (private / 'mint-boundary.json').is_file():
            result['signer_boundary'] = json.loads((private / 'mint-boundary.json').read_text())
        if (private / 'interruption-trigger.json').is_file():
            result['trigger'] = json.loads((private / 'interruption-trigger.json').read_text())
        (private / 'witness.json').write_text(json.dumps(result, indent=2) + '\n')
    atexit.register(finish)
