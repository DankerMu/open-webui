"""Parent-owned AST fault seam; never writes candidate source or changes discovery."""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys


def pytest_configure(config):
    root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
    source = root / 'scripts/smoke_proxy_resources.py'
    text = source.read_text()
    tree = ast.parse(text, filename=str(source))
    mode = os.environ['OCU_PARENT_MINTER_FAULT']
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'mint_short_session')
    changed = []
    for node in ast.walk(function):
        if not isinstance(node, ast.If):
            continue
        expression = ast.unparse(node.test)
        selected = (mode == 'lifetime' and expression.startswith('type(lifetime)')) or (
            mode == 'metadata' and 'math.isfinite(expiry)' in expression)
        if selected:
            changed.append(node.lineno)
            node.test = ast.copy_location(ast.Constant(False), node.test)
    if len(changed) != 1:
        raise RuntimeError('Minter fault did not select exactly one actual guard')
    ast.fix_missing_locations(tree)
    sys.path.insert(0, str(root / 'scripts'))
    spec = importlib.util.spec_from_file_location('smoke_proxy_resources', source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    exec(compile(tree, str(source), 'exec'), module.__dict__)
    report = Path(os.environ['OCU_PARENT_MINTER_REPORT'])
    report.write_text(json.dumps({'mode': mode, 'source_sha256': hashlib.sha256(text.encode()).hexdigest(),
        'changed_guard_lines': changed, 'candidate_source_unchanged': source.read_text() == text}) + '\n')
