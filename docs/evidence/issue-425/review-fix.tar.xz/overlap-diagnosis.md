# #425 overlapping info callbacks — diagnosis

Candidate: `c3b036ecaedca138a01399593153ebeb7b26f053`. No repository source/test edits during diagnosis.

## Feedback loop

Parent-only pytest plugin `overlap_probe.py` uses existing actual command HTTP and authenticated callback routes. Command in `overlap-diagnostic.json` exits1 in0.87s at `close_sequences == [1,1]`: observed `[1,2]`; finalstatus4 commits/publishes2. Two infos were already outstanding before first close admission. Callback2 observes closing/pending1 and returns editing/pendingNone. This is not evidence of document-byte loss.

## Ranked hypotheses after RED

1. Independent unlocked observations allow another info-induced callback to cross close admission and clear its reservation. Predict: staged real callback2 after admission produces allocations1/2 without any participant joining.
2. Synthetic responder allows an order pinned B1 serializes away. Predict: actual B1 never emits callback2 while first reservation can exist.
3. Host duplicate command filtering prevents API duplication. Predict: direct concurrent authenticated API consumers remain reachable, so host filtering cannot establish broker invariant; this is a broker contract.

## Discriminator

Real pinned B1 run `issue425-real-overlap-after-resource-race`, source exact candidate. Parent diagnostic injector coordinates two actual info calls and holds only the second actual status1 ingress until reservation1 exists; callback payload/state are not synthesized or modified. This barrier is diagnosis only, not production acceptance.

Runtime `.run/office-53e93608a5f84fbaaad7e7689959099d-2_4zpxal`:

- Two actual lookups admitted; B1 emits two real status1 callbacks.
- Callback2 released with state closing/reserved1; original callback changes it to editing/pendingNone.
- Both close responses202, sequences `[2,1]` in request order.
- Real editor release produces status4; broker closed/save_seq=committed=published2.
- Browser rejects common-reservation assertion; outer make exit2. No owned groups/new browser PIDs; Docker identity/state and paused172source unchanged.

Thus hypothesis1 is observed; hypothesis2 is refuted by actual callback emission/schedule. Host-only filtering cannot repair the API-level invariant. First diagnostic attempt stopped before service startup because a Docker baseline object disappeared during inventory; retained separately, not treated as bug proof.

## Required repair boundary

Coordinate callback-bearing lookup observations and close admission across processes, without holding the canonical callback lock during remote I/O or waiting for coordination while holding that lock. Preserve authoritative reread/revalidation, command budgets, real later remaining-participant status1, queued/running transaction cancellation and all four caller surfaces. Do not suppress status1, correlate by guessed user counts, add process-local-only serialization, restore the original lock cycle, or patch verifier timing.

Permanent regression must combine two outstanding command attempts and induced authenticated callbacks, plus a true cross-process variant and the existing later-participant control. Parent retains this counterexample and actual B1 diagnostic as frozen evidence; repaired acceptance must run without the diagnostic barrier.
