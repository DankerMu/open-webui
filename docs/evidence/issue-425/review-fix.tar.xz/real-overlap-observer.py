"""Diagnostic-only barriers around real B1 commands/callbacks; no synthesized payloads."""
import asyncio
import builtins
import json
import os
from pathlib import Path
import sys
import threading
import time

observer = Path('/tmp/issue-172-broker-observer/sitecustomize.py')
exec(compile(observer.read_text(), str(observer), 'exec'), {})
trace = Path(os.environ['OCU_PARENT_BROKER_TRACE'])
arm = trace.parent / 'overlap-armed'
lock = threading.Lock()
lookup_count = 0
callback_count = 0
both_started = threading.Event()
prior_import = builtins.__import__
installing = False


def emit(row):
    with (trace.parent / 'real-overlap-probe.jsonl').open('a') as output:
        output.write(json.dumps({'wall_ns': time.time_ns(), **row}) + '\n')


def install(*args, **kwargs):
    global installing
    result = prior_import(*args, **kwargs)
    if installing:
        return result
    installing = True
    try:
        commands = sys.modules.get('office.commands')
        if commands and hasattr(commands, 'lookup_key') and not getattr(commands, '__overlap_probe', False):
            commands.__overlap_probe = True
            original_lookup = commands.lookup_key

            async def lookup(key):
                global lookup_count
                if not arm.exists():
                    return await original_lookup(key)
                with lock:
                    lookup_count += 1
                    number = lookup_count
                    if lookup_count >= 2:
                        both_started.set()
                emit({'kind': 'lookup-admitted', 'ordinal': number})
                if number <= 2:
                    deadline = time.monotonic() + 2
                    while not both_started.is_set() and time.monotonic() < deadline:
                        await asyncio.sleep(0.005)
                    emit({'kind': 'lookup-barrier', 'ordinal': number, 'two_started': both_started.is_set()})
                return await original_lookup(key)

            commands.lookup_key = lookup
        control = sys.modules.get('office.control_plane')
        if control and hasattr(control, '_admit_authenticated_callback') and not getattr(control, '__overlap_probe', False):
            control.__overlap_probe = True
            original_admit = control._admit_authenticated_callback

            def admit(chat, session_id, payload, loop):
                global callback_count
                if arm.exists() and payload.get('status') == 1:
                    with lock:
                        callback_count += 1
                        number = callback_count
                    emit({'kind': 'real-status1-ingress', 'ordinal': number, 'users': payload.get('users')})
                    if number == 2:
                        from office.store import OfficeStore
                        store = OfficeStore()
                        deadline = time.monotonic() + 2
                        reserved = None
                        while time.monotonic() < deadline:
                            record = store.read(chat)['sessions'][session_id]
                            reserved = record.get('pending_close_seq')
                            if record['state'] == 'closing' and reserved is not None:
                                break
                            time.sleep(0.005)
                        emit({'kind': 'second-real-callback-release', 'reserved': reserved,
                              'state': record['state']})
                return original_admit(chat, session_id, payload, loop)

            control._admit_authenticated_callback = admit
    finally:
        installing = False
    return result


builtins.__import__ = install
