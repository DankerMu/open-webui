"""Parent-only control: remove observation serialization without changing callbacks."""
from contextlib import contextmanager
from pathlib import Path
import sys

import pytest


@contextmanager
def uncoordinated(_chat, *, create=False):
    yield True


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_call(item):
    sessions = sys.modules['office.sessions']
    expected = Path('/Users/danker/Documents/31308/open-computer-use/computer-use-server/office/sessions.py')
    assert Path(sessions.__file__).resolve() == expected
    original = sessions.lookup_admission
    sessions.lookup_admission = uncoordinated
    try:
        yield
    finally:
        sessions.lookup_admission = original
