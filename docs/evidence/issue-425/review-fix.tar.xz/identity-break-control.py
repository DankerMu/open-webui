"""Deliberately broken in-process authority guards for one parent-owned negative control."""
from pathlib import Path
import sys
import pytest

@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_call(item):
    sessions = sys.modules['office.sessions']
    expected = Path('/Users/danker/Documents/31308/open-computer-use/computer-use-server/office/sessions.py')
    assert Path(sessions.__file__).resolve() == expected
    identity, authority = sessions._session_identity, sessions._lookup_authority
    sessions._session_identity = lambda record: ()
    sessions._lookup_authority = lambda state, record, restore_epoch: ()
    try:
        yield
    finally:
        sessions._session_identity, sessions._lookup_authority = identity, authority
