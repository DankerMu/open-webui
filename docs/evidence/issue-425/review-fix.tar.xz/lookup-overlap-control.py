"""Parent-only diagnostic: real command HTTP and authenticated callback routes."""
import json
import threading
from urllib.parse import urlsplit

import pytest


def pytest_collection_modifyitems(items):
    owner = items[0].module
    parent = items[0].parent

    def overlap(office_world, monkeypatch):
        http, data, recording, _manager, _broker = office_world
        _file_id, session = owner._prepare(office_world, monkeypatch, "close")
        first_entered, second_entered = threading.Event(), threading.Event()
        release_first, release_second = threading.Event(), threading.Event()
        ordinal_lock = threading.Lock()
        observations, responses, failures = [], {}, []
        ordinal = 0

        def respond(_handler, body, _origin):
            nonlocal ordinal
            command = owner._oracle_verify(json.loads(body)["token"], owner.JWT_SECRET)
            assert command == {"c": "info", "key": session["document_key"]}
            with ordinal_lock:
                ordinal += 1
                number = ordinal
            if number == 1:
                first_entered.set()
                assert release_first.wait(5), "first info emergency escape"
            elif number == 2:
                second_entered.set()
                assert release_second.wait(5), "second info emergency escape"
            before = json.loads(owner._state(data).read_bytes())["sessions"][session["session_id"]]
            callback = owner._post(http, session, owner.recorded_status_1_payload(
                document_key=session["document_key"],
            ))
            assert callback.status_code == 200 and callback.json() == {"error": 0}
            after = json.loads(owner._state(data).read_bytes())["sessions"][session["session_id"]]
            observations.append({"info": number, "before_state": before["state"],
                                 "before_pending": before.get("pending_close_seq"),
                                 "after_state": after["state"],
                                 "after_pending": after.get("pending_close_seq")})
            return 200, {"Content-Type": "application/json"}, b'{"error":0}'

        def request(name):
            try:
                response = owner._close(http, session["session_id"])
                responses[name] = {"status": response.status_code, "body": response.json()}
            except BaseException as error:
                failures.append(error)

        first = threading.Thread(target=request, args=("first",))
        second = threading.Thread(target=request, args=("second",))
        with owner._command_origin(respond, release=release_first) as origin:
            monkeypatch.setenv("OCU_OFFICE_DOCSERVER_URL", f"http://localhost:{urlsplit(origin.url).port}")
            try:
                first.start()
                assert first_entered.wait(2), "first close did not reach command transport"
                second.start()
                # A corrected serialization boundary may prevent a second observation.
                overlapped = second_entered.wait(2)
                release_first.set()
                first.join(5)
                assert not first.is_alive(), "first close did not finish after callback acknowledgement"
                release_second.set()
                second.join(5)
                assert not second.is_alive(), "duplicate close did not finish"
                assert not failures, failures
                final = owner._post(http, session, owner.recorded_status_4_payload(
                    document_key=session["document_key"],
                ))
                assert final.status_code == 200 and final.json() == {"error": 0}
                record = json.loads(owner._state(data).read_bytes())["sessions"][session["session_id"]]
                summary = {"two_outstanding_infos": overlapped,
                           "close_statuses": [responses[name]["status"] for name in ("first", "second")],
                           "close_sequences": [responses[name]["body"].get("save_seq") for name in ("first", "second")],
                           "callbacks": observations,
                           "final": {key: record[key] for key in ("state", "save_seq", "last_committed_seq", "last_published_seq")}}
                print("OVERLAP_PROBE " + json.dumps(summary, sort_keys=True))
                assert summary["close_statuses"] == [202, 202]
                assert summary["close_sequences"] == [1, 1], "duplicate closes lost their common reserved sequence"
                assert summary["final"] == {"state": "closed", "save_seq": 1,
                                             "last_committed_seq": 1, "last_published_seq": 1}
            finally:
                release_first.set()
                release_second.set()
                if first.ident is not None:
                    first.join(15)
                if second.ident is not None:
                    second.join(15)
                assert not first.is_alive() and not second.is_alive()
        assert recording.hits == 0

    items[:] = [pytest.Function.from_parent(parent, name="test_parent_overlapping_info_closes", callobj=overlap)]
