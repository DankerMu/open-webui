# #425 broad regression repair

Parent ran explicit28-file affectedinventory:1975collected;51failed,1916passed,8setuperrors in971.26s. Rawprivate artifacts /tmp/issue-425-evidence/affected-unit-regression.{json,xml}; structuredfailures affected-failures.json. Do not rerun to confirm. Rawpytesttrace contains syntheticJWTs; do not paste them publicly.

## Confirmed groups

1. **Six production epoch/recovery regressions** in test_office_resolution andtest_office_history. Newunconditionalidentityguard in sessions._orphan_session returnswithoutorphaning when accepted save-as recovery movesfile responsibility. For `restore_epoch_changed`, existingcontract requires acceptedrecoverycomplete THEN orphan the still-old-epoch editor evenwhen acceptedrecoverymoved itsfile. Those are not stale remote-key outcomes. Keep stale query/unknown-key successorprotection, but distinguish authoritativeepochinvalidity from a captured remoteI/Oresult; don't weaken oldassertions. Failures show editing/None versus orphaned/restore_epoch_changed aftersave-as recovery. Preserve finalclosed/conflict cases and newparentqualifiedlookup tests.

2. **43 crashed-worker fixture failures** in test_office_restore_recovery. _WORKER line104 constructs TestClient without enteringlifespan; create/restore now correctlyrequire transactionexecutionownership. Use existingminimal transaction_worker_lifespan fixturepattern (as test_office_resolution) forrequest/create modes, withowned TestClientcontext. Do notenableunrelated MCP/reaperstartup that wouldinvalidate controlledcrashcuts, do notaddproductionfallback. Recover/startup directrecoverymodesretain theircontrols. Auditotherdirectconsumers ofnewownerrequirement.

3. **One superseded implementation assertion** test_office_save_close::test_two_processes_close_reuse_one_allocation expects exactlyoneinfo request whileconcurrentclosersholdI/O. Lock-freequery canissue2validreads. Remove thisincidentalcommand-countassumption ratherthanrepinningto2; preserve genuine two-process progress and identicalsingleallocatedclose/receipt/history assertions. This is explicitlock-contractmigration, notpermissiontoalterpubliccloseoutcomes.

4. **One pre-existing unsupported identity assertion** test_office_commands::test_command_bridge_propagates_operation_errors_including_timeout[TimeoutError]. Parentstdlib-onlyprobe /tmp/issue-425-evidence/timeout-identity-stdlib-probe.json proves asyncio.run_coroutine_threadsafe clones builtinTimeoutError onPython3.12.12 evenwithoutcandidatecommands: same_original_object=false, same_stored_future_exception=true, args_preserved=true. Removeobject-identity assertion/caughtbinding whilepreserving pytest.raises(error_type) propagation-vs-unreachablebehavior. Do notchange commands.py toforce unsupportedidentity orpinmessagewording.

5. **Eight lifecycle startup errors** reportactualpreflightmissing OCU_OFFICE_JWT_SECRET. NonOffice app_module setsinternal/public/MCPinputs but hasan enabledOfficeURL inbroadrun withoutmatchingOfficeconfig. OriginabsenceisNOTcause (authguard allowsabsentorigin). Parenttracer minimal new sweep-overlapcase+lifecyclesingular passes2/2, falsifyingthat specificleakerhypothesis. Need isolate source ofenvironment contamination (possiblycollection/priorfixture) and restoreownedsettings, notdisablepreflight orblanketignoreconfigurationerrors. Parent investigates thisgroup; do NOTedit test_lifecycle.py or otherenvironmentfixtures without coordination/evidence.

## Parent fixture corrections already applied

- Newrestoreselection mutator lambda.pop returnedvalue, violating OfficeStore's None-returncontract; changedto explicitmutator returningNone, preserving allassertions.
- Newacceptedfinal-overlap helper boundthecontentorigin outside_pending_info, which overwroteit; callbackdownloadcorrectly422rejectedwrongorigin. Moved existing_bind_internal into thecontrolledcallback action whileinfo alreadyheld; noauthguardbypass. Singleregressionthenpassed.
- Focused2file run had51passed and1dependencyfixturefailure above; original12REDcases nowexecutedgreen withinthose51. No fullGREENclaimyet.

## Constraints

Sole source implementer; leaf only; no nested agents/workflow/tests/build/lint/format/services/Git. Parent owns checks/docs. Fix groups 1-4 in one bounded pass; preserve the 52 focused cases and their behavior assertions. Add tests only for meaningful gaps. Return changes and remaining unknowns as a terminal report; no wait loops. This is broad-check repair cycle 1 of 3. Keep production flags, dependencies, schema, timeouts and status-1 callback semantics unchanged.
