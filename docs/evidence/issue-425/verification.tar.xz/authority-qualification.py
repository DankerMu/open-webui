"""Parent-owned negative control; no repository source mutation."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/Users/danker/Documents/31308/open-computer-use')
stage = Path('/tmp/issue-425-evidence')
source = root / 'computer-use-server/office/sessions.py'
original = hashlib.sha256(source.read_bytes()).hexdigest()
env = {key: os.environ[key] for key in ('PATH', 'HOME', 'TMPDIR', 'USER', 'LOGNAME', 'LANG', 'UV_CACHE_DIR') if key in os.environ}
env.update(UV_PYTHON='3.12', PYTHON_DOTENV_DISABLED='1', PYTHONPATH='/tmp/issue-425-oracle-controls')
command = ['uv', 'run', '--no-project', '--with', 'pytest', '--with-requirements', 'computer-use-server/requirements.txt', '--', 'python', '-m', 'pytest']
cases = [
    'tests/orchestrator/test_office_command_deadline.py::test_join_discards_unknown_lookup_for_replaced_session_and_key',
    'tests/orchestrator/test_office_command_deadline.py::test_close_never_allocates_for_replacement_session_responsibility[key]',
    'tests/orchestrator/test_office_command_deadline.py::test_close_never_allocates_for_replacement_session_responsibility[file]',
]
results = []
for label, plugin in [('authority-negative-control', ['-p', 'identity_break']), ('authority-control-restored', [])]:
    path = stage / (label + '.json')
    if path.exists():
        raise RuntimeError(f'Preserving existing evidence: {path}')
    args = command + cases + ['-q', '--import-mode=importlib', '--junitxml=' + str(stage / (label + '.xml'))] + plugin
    result = subprocess.run(args, cwd=root, env=env, capture_output=True, text=True, timeout=120)
    record = {'command': args, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr, 'source_sha256': original}
    path.write_text(json.dumps(record, indent=2) + '\n')
    path.chmod(0o600)
    results.append({'label': label, 'exit': result.returncode})
    print(label, 'exit', result.returncode, flush=True)
    if hashlib.sha256(source.read_bytes()).hexdigest() != original:
        raise RuntimeError('Source changed during oracle qualification')
assert [row['exit'] for row in results] == [1, 0], results
print('Negative control rejected; restoration passed; source unchanged.')
