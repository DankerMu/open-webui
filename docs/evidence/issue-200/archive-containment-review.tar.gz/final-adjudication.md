# Issue200 review adjudication

Mode: hybrid; risk: high; source head `9945963f8510d5852e9a69f9f75ec3606df44f21`; base `0c23ca3ffc20f97791b2c04e983da07af3521ee2`.

Three independent round1 seats: correctness+integration, test-evidence+spec-compliance, security-perf+invariant-state. All returned no actionable findings. Parent inspected the full reports, source cutover, semantic failures, restored passes and actual HTTP responses. Gate349 records round1 clean with0/2 fix passes used; no re-review is claimed.

The end-to-end invariant holds within the fixture: original requested chat identity reaches the canonical no-follow root/ancestor/leaf reader, ZIP receives verified bytes rather than reopening a pathname, and errors occur before response publication. Ordinary names/bytes, hidden exclusion, auth and HTTP headers retain exercised coverage. All four replacement-race negative cases reached decoded target-byte disclosure before the fix; the same tests pass after. Static directory-link omission is a positive control, not a claimed failure.

Parent gap sweep found no additional blocking defect. Missing-directory preflight is unchanged; selected-file disappearance, special-file replacement and descriptor unwind have inspected control-flow support but no separate new runtime cases. Content snapshots, hard-link/bind-mount provenance and deployment remain excluded rather than certified.

## Tracked nonblocking resource trade-off

Whole-member materialization adds size-dependent transient allocations compared with the former8KiB source copy. Static mechanism is confirmed; operational magnitude is unmeasured, with no demonstrated OOM or throughput failure. The independent scribe verified and deduplicated [issue350](https://github.com/DankerMu/open-webui/issues/350), separate from issue201/202. Preserve containment while using bounded copies from verified descriptors in that focused follow-up. This is not added automatically to the user's original queue, and no performance improvement is claimed for issue200.

## Evidence integrity

Durable runtime archive SHA256 `90a931d53b708ac8a4d21ca27c14819d57a4644280b23e99130595ed31180287`. Reviewers independently compared recorded GREEN inputs against frozen candidate blobs; no mismatches. Test assertions unchanged across9-failure/4-pass RED and13-pass GREEN; scoped suite282pass/0skip/3subtests; actual HTTP6-case REDexit1/GREENexit0 with unchanged inputs and owned cleanup.

Deep gitleaks exit1 produced68 matches. Independent evidence review verified every fingerprint and all five distinct tracked-file digests against both base and candidate; all are public file SHA256 values, not credentials. Raw scan and exact adjudication accompany review evidence. No suppression and no zero-match claim.

Source/static and central/doc gate results are parent-observed command outputs; the retained index labels itself as an index, not a raw shell transcript. No full-suite, Linux/image, LAN or unexecuted Actions claim. Only mechanical source README/changelog prose was parent-authored after smoke; no test-execution chronology deviation.
