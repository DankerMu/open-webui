import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

source = Path('/Users/danker/Documents/31308/open-computer-use')
base = '43fccbd9552933193721a4c8c30f857aec119046'
helper_name = 'tests/orchestrator/_http_origin.py'
test_name = 'tests/orchestrator/test_http_origin.py'
command_name = 'tests/orchestrator/test_office_commands.py'
result = {'base': base, 'cases': [], 'qualification': 'Disposable semantic faults; live source is never mutated.'}
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
changes = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=source, text=True).splitlines()
inputs = sorted(set(changes + [helper_name, test_name]))
result['live_inputs_before'] = {name: digest(source / name) for name in inputs}
try:
    with tempfile.TemporaryDirectory(prefix='issue-235-qualification-') as temporary:
        copy = Path(temporary) / 'repo'
        subprocess.run(['git', 'clone', '--quiet', '--local', '--no-hardlinks', str(source), str(copy)], check=True, capture_output=True, text=True, timeout=120)
        for name in inputs:
            destination = copy / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source / name, destination)
        assert all(digest(copy / name) == expected for name, expected in result['live_inputs_before'].items())
        helper, command = copy / helper_name, copy / command_name
        candidate = helper.read_text()
        current_command = command.read_bytes()
        original_command = subprocess.check_output(['git', 'show', base + ':' + command_name], cwd=source)
        no_drain = 'workers = tuple(self._workers)'
        no_error = '            errors = list(self._errors)\n        _raise_errors(errors, body_error)'
        assert candidate.count(no_drain) == 1 and candidate.count(no_error) == 1
        env = os.environ.copy()
        env['PYTHONPATH'] = str(copy) + os.pathsep + str(copy / 'computer-use-server')
        def run(label, expected, selection=None):
            argv = [sys.executable, '-m', 'pytest', test_name, '-q', '--import-mode=importlib', '-p', 'no:cacheprovider', '--tb=short', '--basetemp', str(Path(temporary) / ('pytest-' + label))]
            if selection:
                argv += ['-k', selection]
            begin = time.time()
            proc = subprocess.run(argv, cwd=copy, env=env, capture_output=True, text=True, timeout=120)
            row = {'label': label, 'argv': argv, 'exit': proc.returncode, 'elapsed': time.time()-begin, 'helper_sha256': digest(helper), 'command_origin_sha256': digest(command), 'test_sha256': digest(copy / test_name), 'stdout': proc.stdout, 'stderr': proc.stderr}
            result['cases'].append(row)
            print(label, proc.returncode, proc.stdout[-1600:], proc.stderr[-1000:])
            assert proc.returncode == expected, 'Qualification exit did not match the declared semantic control'
            return row
        run('candidate-baseline', 0)
        helper.write_text(candidate.replace(no_drain, 'workers = ()', 1))
        run('missing-handler-drain', 1)
        helper.write_text(candidate.replace(no_error, '            errors = list(self._errors)\n        return', 1))
        run('lost-owner-errors', 1)
        helper.write_bytes(Path('/tmp/issue-235-http-origin-before-blocking.py').read_bytes())
        framing = run('inherited-nonblocking-transport', 1, 'waits_for_complete_fragmented_request')
        assert 'responder ran before headers were complete' in framing['stdout']
        helper.write_text(candidate)
        command.write_bytes(original_command)
        old = run('final-tracer-original-command-origin', 1, 'reports_responder_failure_to_owning_test')
        assert 'DID NOT RAISE' in old['stdout']
        command.write_bytes(current_command)
        run('restored-candidate', 0)
    result['owned_copy_removed'] = not Path(temporary).exists()
finally:
    result['live_inputs_after'] = {name: digest(source / name) for name in inputs}
    result['live_inputs_unchanged'] = result['live_inputs_before'] == result['live_inputs_after']
    Path('/tmp/issue-235-qualification-result.json').write_text(json.dumps(result, indent=2)+'\n')
assert result['owned_copy_removed'] and result['live_inputs_unchanged']
