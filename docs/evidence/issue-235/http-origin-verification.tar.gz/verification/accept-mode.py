import fcntl
import json
import os
from pathlib import Path
import runpy
import sys

root = Path('/Users/danker/Documents/31308/open-computer-use')
sys.path.insert(0, str(root))
from tests.orchestrator._http_origin import _OwnedHTTPServer

observed = []
original = _OwnedHTTPServer.get_request
def observed_accept(server):
    request, address = original(server)
    observed.append({'descriptor_nonblocking': bool(fcntl.fcntl(request.fileno(), fcntl.F_GETFL) & os.O_NONBLOCK), 'python_timeout_is_none': request.gettimeout() is None})
    return request, address
_OwnedHTTPServer.get_request = observed_accept
try:
    runpy.run_path('/tmp/issue-235-runtime.py', run_name='__main__')
finally:
    _OwnedHTTPServer.get_request = original
    Path('/tmp/issue-235-accept-mode-result.json').write_text(json.dumps({'accepted_socket_observations': observed}, indent=2)+'\n')
    print(json.dumps({'accepted_socket_observations': observed}))
