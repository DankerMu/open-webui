import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

probe = Path('/tmp/issue-235-runtime.py')
records = []
# Fresh interpreters exercise first-use aiohttp admission rather than warm-loop retries.
for trial in range(20):
    started = time.time()
    completed = subprocess.run([sys.executable, str(probe)], capture_output=True, text=True, timeout=30)
    row = {'trial': trial + 1, 'exit': completed.returncode, 'elapsed': time.time()-started, 'stdout': completed.stdout, 'stderr': completed.stderr}
    records.append(row)
    if completed.returncode:
        break
result = {'planned_fresh_process_trials': 20, 'trials': records, 'probe_sha256': hashlib.sha256(probe.read_bytes()).hexdigest(), 'all_completed': len(records) == 20 and all(row['exit'] == 0 for row in records), 'initial_failed_probe_retained': '/tmp/issue-235-runtime.command.json', 'purpose': 'Diagnose missing cancellation admission; no source repair or historical-cause claim; fail fast, never retry a failed trial.'}
Path('/tmp/issue-235-stability-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'completed_trials': len(records), 'all_completed': result['all_completed'], 'exits': [row['exit'] for row in records]}))
if not result['all_completed']:
    print(records[-1]['stdout'])
    print(records[-1]['stderr'])
    raise SystemExit(1)
