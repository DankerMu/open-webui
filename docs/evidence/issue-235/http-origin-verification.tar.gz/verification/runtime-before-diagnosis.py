import asyncio
import hashlib
import http.client
import json
import os
from pathlib import Path
import socket
import sys
import threading
import time

root = Path('/Users/danker/Documents/31308/open-computer-use')
sys.path.insert(0, str(root))
from tests.orchestrator.test_office_commands import _command_origin, commands
from tests.orchestrator._http_origin import HttpOriginLifetime, OriginRequestHandler

rows = []
def visible(error, expected):
    pending, seen = [error], set()
    while pending:
        current = pending.pop()
        if current is expected:
            return True
        if id(current) in seen:
            continue
        seen.add(id(current))
        if isinstance(current, BaseExceptionGroup):
            pending.extend(current.exceptions)
        if current.__cause__ is not None:
            pending.append(current.__cause__)
        elif not current.__suppress_context__ and current.__context__ is not None:
            pending.append(current.__context__)
    return False

def resources(observed):
    return bool(observed) and all(not worker.is_alive() and accepted.fileno() == -1 and listener.fileno() == -1 for worker, accepted, listener in observed)

def observe(handler, observed):
    observed.append((threading.current_thread(), handler.connection, handler.server.socket))

def request(url, errors, status, timeout=2):
    connection = http.client.HTTPConnection(url.removeprefix('http://'), timeout=timeout)
    try:
        connection.request('POST', '/command', body=b'{}')
        response = connection.getresponse()
        status.append((response.status, response.read()))
        response.close()
    except BaseException as error:
        errors.append(error)
    finally:
        connection.close()

def case(mode):
    entered, release, finished = threading.Event(), threading.Event(), threading.Event()
    observed, errors, status = [], [], []
    body_error = ValueError('owned-body-failure')
    handler_error = AssertionError('owned-handler-failure')
    reported = None
    client = None
    def responder(handler, _body, _origin):
        observe(handler, observed)
        entered.set()
        try:
            if mode != 'success' and not release.wait(5):
                raise AssertionError('Runtime proof emergency release expired')
            if mode in ('handler-error', 'combined-error'):
                raise handler_error
            return 200, {'Content-Length': '2'}, b'ok'
        finally:
            finished.set()
    started = time.monotonic()
    try:
        try:
            with _command_origin(responder, release=release) as origin:
                if mode == 'cancel':
                    previous = {key: os.environ.get(key) for key in ('OCU_OFFICE_DOCSERVER_URL', 'OCU_OFFICE_JWT_SECRET')}
                    os.environ['OCU_OFFICE_DOCSERVER_URL'] = origin.url
                    os.environ['OCU_OFFICE_JWT_SECRET'] = 'runtime-owned-jwt-canary'
                    try:
                        async def cancel_request():
                            pending = asyncio.create_task(commands.forcesave('runtime-document', 1, 'publish'))
                            try:
                                assert await asyncio.to_thread(entered.wait, 2), 'Command handler did not enter'
                                pending.cancel()
                                try:
                                    await pending
                                except asyncio.CancelledError:
                                    return True
                                return False
                            finally:
                                if not pending.done():
                                    pending.cancel()
                                    try:
                                        await pending
                                    except asyncio.CancelledError:
                                        pass
                        assert asyncio.run(cancel_request()), 'Command cancellation was swallowed'
                    finally:
                        for key, value in previous.items():
                            if value is None:
                                os.environ.pop(key, None)
                            else:
                                os.environ[key] = value
                else:
                    client = threading.Thread(target=request, args=(origin.url, errors, status, 0.05 if mode == 'timeout' else 2), name='issue-235-runtime-client')
                    client.start()
                    assert entered.wait(2), 'Runtime handler did not enter'
                    if mode == 'success':
                        client.join(2)
                        assert not client.is_alive() and status == [(200, b'ok')] and not errors
                    elif mode == 'timeout':
                        client.join(2)
                        assert not client.is_alive() and len(errors) == 1 and isinstance(errors[0], TimeoutError)
                        assert not finished.is_set(), 'Timeout did not leave an active handler'
                    elif mode == 'handler-error':
                        release.set()
                        client.join(2)
                        assert not client.is_alive()
                    elif mode in ('body-error', 'combined-error'):
                        raise body_error
        except BaseException as error:
            reported = error
        expected = {'body-error': [body_error], 'handler-error': [handler_error], 'combined-error': [body_error, handler_error]}.get(mode, [])
        if expected:
            assert reported is not None and all(visible(reported, error) for error in expected), 'Origin lost an expected owning-test failure'
        elif reported is not None:
            raise reported
        assert finished.is_set() and resources(observed), 'Origin exited before all handler resources retired'
        rows.append({'case': mode, 'handler_finished': True, 'worker_and_sockets_retired': True, 'expected_failures_visible': len(expected), 'elapsed': time.monotonic()-started})
    finally:
        release.set()
        if client is not None and client.ident is not None:
            client.join(5)
            assert not client.is_alive(), 'Runtime client survived cleanup'
        for worker, accepted, _listener in observed:
            accepted.close()
            worker.join(5)
            assert not worker.is_alive(), 'Runtime handler survived emergency cleanup'

def idle_socket_case(partial):
    entered = threading.Event()
    observed = []
    class Handler(OriginRequestHandler):
        protocol_version = 'HTTP/1.1'
        def log_message(self, *_args):
            pass
        def do_GET(self):
            observe(self, observed)
            self.send_response(200)
            self.send_header('Content-Length', '2')
            self.end_headers()
            self.wfile.write(b'ok')
            entered.set()
        def do_POST(self):
            observe(self, observed)
            entered.set()
            self.rfile.read(100)
    raw = connection = None
    try:
        with HttpOriginLifetime(Handler) as owner:
            if partial:
                raw = socket.create_connection(owner.server.server_address, timeout=2)
                raw.sendall(b'POST / HTTP/1.1\r\nHost: localhost\r\nContent-Length: 100\r\n\r\nx')
            else:
                connection = http.client.HTTPConnection(owner.url.removeprefix('http://'), timeout=2)
                connection.request('GET', '/')
                response = connection.getresponse()
                assert response.status == 200 and response.read() == b'ok'
                response.close()
                assert connection.sock is not None, 'Keep-alive control did not retain its connection'
            assert entered.wait(2), 'Idle-socket handler did not enter'
        assert resources(observed), 'Accepted idle socket or handler survived origin exit'
        rows.append({'case': 'partial-input' if partial else 'keep-alive', 'worker_and_sockets_retired': True})
    finally:
        if raw is not None:
            raw.close()
        if connection is not None:
            connection.close()
        for worker, accepted, _listener in observed:
            accepted.close()
            worker.join(5)
            assert not worker.is_alive(), 'Idle-socket worker survived emergency cleanup'

try:
    for mode in ('success', 'timeout', 'cancel', 'body-error', 'handler-error', 'combined-error'):
        case(mode)
    idle_socket_case(False)
    idle_socket_case(True)
finally:
    result = {'cases': rows, 'completed': len(rows) == 8, 'probe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    Path('/tmp/issue-235-runtime-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
