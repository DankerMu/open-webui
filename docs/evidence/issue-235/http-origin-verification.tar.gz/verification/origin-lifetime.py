import hashlib
import http.client
import json
from pathlib import Path
import runpy
import subprocess
import threading
import time
from urllib.parse import urlsplit

root = Path('/Users/danker/Documents/31308/open-computer-use')
source = root / 'tests/orchestrator/test_office_commands.py'
module = runpy.run_path(str(source))
entered, release, finished, stopped = (threading.Event() for _ in range(4))
workers = []
errors = []
def responder(_handler, _body, _parent):
    workers.append(threading.current_thread())
    entered.set()
    try:
        if not release.wait(5):
            raise AssertionError('Owned counterexample release did not arrive')
        return 200, {'Content-Length': '0'}, b''
    finally:
        finished.set()
origin = module['_CommandOrigin'](responder)
address = urlsplit(origin.url)
def request():
    connection = http.client.HTTPConnection(address.hostname, address.port, timeout=5)
    try:
        connection.request('POST', '/command', body=b'{}')
        response = connection.getresponse()
        response.read()
        if response.status != 200:
            raise AssertionError('Counterexample request did not complete')
    except BaseException as error:
        errors.append(type(error).__name__)
    finally:
        connection.close()
def stop():
    try:
        origin.stop()
    except BaseException as error:
        errors.append(type(error).__name__)
    finally:
        stopped.set()
client = threading.Thread(target=request, name='issue-235-client')
stopper = threading.Thread(target=stop, name='issue-235-stop')
result = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
try:
    client.start()
    assert entered.wait(3), 'Counterexample handler did not enter'
    stopper.start()
    result['stop_returned_before_release'] = stopped.wait(2)
    result['handler_finished_when_stop_returned'] = finished.is_set()
    result['handler_alive_when_stop_returned'] = workers[0].is_alive()
finally:
    release.set()
    client.join(5)
    if stopper.ident is not None:
        stopper.join(5)
    else:
        origin.stop()
    for worker in workers:
        worker.join(5)
    result['owned_threads_stopped'] = not any(worker.is_alive() for worker in [client, stopper, *workers])
    result['handler_finished_after_cleanup'] = finished.is_set()
    result['listening_socket_closed'] = origin._server.socket.fileno() == -1
    result['errors'] = errors
    Path('/tmp/issue-235-origin-lifetime-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
assert result['stop_returned_before_release'] and not result['handler_finished_when_stop_returned'] and result['handler_alive_when_stop_returned']
assert result['owned_threads_stopped'] and result['handler_finished_after_cleanup'] and result['listening_socket_closed'] and not errors
