import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

source = Path('/Users/danker/Documents/31308/open-computer-use')
control = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
label, location, *argv = sys.argv[1:]
root = {'source': source, 'control': control}[location]
output = Path('/tmp') / f'issue-235-{label}.command.json'
if output.exists():
    raise SystemExit('Refusing to overwrite earlier command evidence')
def identities():
    groups = [(source, source / 'tests/orchestrator', '*.py'), (control, control / 'openspec/changes/office-http-origin-lifetime', '*')]
    result = {}
    for base, directory, pattern in groups:
        for path in sorted(directory.rglob(pattern)):
            if path.is_file():
                result[str(base.name + '/' + str(path.relative_to(base)))] = hashlib.sha256(path.read_bytes()).hexdigest()
    for base, relative in (
        (source, 'CHANGELOG.md'),
        (control, 'docs/decisions/implemented/testing/2026-10-11-office-http-origin-lifetime.md'),
    ):
        path = base / relative
        result[base.name + '/' + relative] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result
env = os.environ.copy()
env['PATH'] = str(control / '.venv/bin') + ':/Users/danker/.nvm/versions/node/v22.23.2/bin:' + env['PATH']
record = {'argv': argv, 'cwd': str(root), 'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip(), 'control_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=control, text=True).strip(), 'inputs_before': identities()}
started = time.time()
child = subprocess.Popen(argv, cwd=root, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
interrupted = False
try:
    stdout, stderr = child.communicate(timeout=1800)
except (subprocess.TimeoutExpired, KeyboardInterrupt):
    interrupted = True
    os.killpg(child.pid, signal.SIGINT)
    try:
        stdout, stderr = child.communicate(timeout=30)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid, signal.SIGKILL)
        stdout, stderr = child.communicate()
record.update({'exit': child.returncode, 'elapsed': time.time()-started, 'interrupted': interrupted, 'inputs_after': identities(), 'stdout': stdout, 'stderr': stderr})
record['inputs_unchanged'] = record['inputs_before'] == record['inputs_after']
output.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({key:value for key,value in record.items() if key not in ('inputs_before','inputs_after','stdout','stderr')}))
print(stdout[-7000:])
print(stderr[-5000:])
raise SystemExit(child.returncode if not interrupted else 124)
