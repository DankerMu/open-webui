from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path('/Users/danker/Documents/31308/open-computer-use')
ruff = '/Users/danker/Documents/31308/open-webui-ocu-plan2/.venv/bin/ruff'
base = '43fccbd9552933193721a4c8c30f857aec119046'
changed = subprocess.check_output(['git', 'diff', '--name-only', base], cwd=root, text=True).splitlines()
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', 'tests/orchestrator'], cwd=root, text=True).splitlines()
files = sorted(set(name for name in changed + untracked if name.endswith('.py')))
rows = []
def check(name, content):
    argv = [ruff, 'check', '--select', 'F', '--target-version', 'py313', '--output-format', 'json', '--stdin-filename', name, '-']
    process = subprocess.run(argv, cwd=root, input=content, capture_output=True, text=True, check=False)
    assert process.returncode in (0, 1), process.stderr
    diagnostics = json.loads(process.stdout)
    return {'argv': argv, 'exit': process.returncode, 'diagnostics': diagnostics, 'stderr': process.stderr, 'content_sha256': hashlib.sha256(content.encode()).hexdigest()}
def counts(result):
    return Counter((item['code'], re.sub(r'from line \d+', 'from line <location>', item['message'])) for item in result['diagnostics'])
for name in files:
    original = subprocess.run(['git', 'show', base + ':' + name], cwd=root, capture_output=True, text=True)
    baseline = check(name, original.stdout) if original.returncode == 0 else None
    current = check(name, (root / name).read_text())
    added = counts(current) - (counts(baseline) if baseline else Counter())
    rows.append({'path': name, 'baseline': baseline, 'current': current, 'added_diagnostics': [{'code': key[0], 'message': key[1], 'count': value} for key, value in added.items()]})
result = {'base': base, 'files': rows, 'baseline_count': sum(len(row['baseline']['diagnostics']) if row['baseline'] else 0 for row in rows), 'current_count': sum(len(row['current']['diagnostics']) for row in rows), 'new_count': sum(item['count'] for row in rows for item in row['added_diagnostics']), 'policy': 'Compare F diagnostics against exact pre-change files; preserve pytest fixture imports. No source edits or lint suppressions.'}
Path('/tmp/issue-235-fix-lint-baseline-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key != 'files'}))
for row in rows:
    print(row['path'], 'baseline', len(row['baseline']['diagnostics']) if row['baseline'] else 0, 'current', len(row['current']['diagnostics']), 'new', row['added_diagnostics'])
raise SystemExit(0 if result['new_count'] == 0 else 1)
