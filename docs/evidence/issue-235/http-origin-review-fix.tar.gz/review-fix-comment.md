## Review round 1 — fix pass 1

Reviewed source `5287bc589643f62f9cc932158a9b8aa3d0029ee6`, control `6885576e543119c0005b28be8acbbe1810baf4b5`.

- **Coverage gap, confirmed:** all three seats require fault evidence through the actual acquired `_hold_save` and manual-box consumer paths. Direct owner-thread startup tests do not cover saver-client startup/readiness or manual body-plus-handler failure forwarding. Add real-resource tests and omission/reversion controls; do not weaken existing assertions.
- **P2 idle polling regression, confirmed:** `handle_request()` clamps server timeout0.05 to the nonblocking listener's socket timeout0. Parent observation recorded28,040 zero-timeout polls in0.2600s with no positive readiness wait. Request and teardown still completed; this is not a measured CPU-percentage or service-latency claim. Use an explicitly bounded blocking readiness wait while retaining nonblocking accept and accepted-socket normalization.

The gate records round1 not clean; one fix pass is active. Source/control-plane integration remains blocked until fresh proof and a fresh correctness+test-evidence re-review. Fixture requirements are unchanged. Full raw review reports and the new idle counterexample will be retained with the fix evidence.

Paired PRs: [OCU #100](https://github.com/DankerMu/open-computer-use/pull/100), [control #378](https://github.com/DankerMu/open-webui/pull/378).
