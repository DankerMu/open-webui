from collections import Counter
import hashlib
from http.client import HTTPConnection
import json
from pathlib import Path
import selectors
import socketserver
import sys
import threading
import time

root = Path('/Users/danker/Documents/31308/open-computer-use')
sys.path.insert(0, str(root))
from tests.orchestrator._http_origin import HttpOriginLifetime, OriginRequestHandler

counts = Counter()
recording = True
originals = {}
observed = []
for selector_class in {socketserver._ServerSelector, selectors.DefaultSelector}:
    original = selector_class.select
    originals[selector_class] = original
    def selected(self, timeout=None, *, original=original):
        if recording:
            counts[timeout] += 1
        return original(self, timeout)
    selector_class.select = selected

class Handler(OriginRequestHandler):
    def log_message(self, *_args):
        pass
    def do_GET(self):
        observed.append((threading.current_thread(), self.connection, self.server.socket))
        self.send_response(200)
        self.send_header('Content-Length', '2')
        self.end_headers()
        self.wfile.write(b'ok')

try:
    with HttpOriginLifetime(Handler) as owner:
        wall = time.monotonic()
        cpu = time.process_time()
        threading.Event().wait(0.25)
        idle_cpu = time.process_time() - cpu
        idle_wall = time.monotonic() - wall
        recording = False
        admission = time.monotonic()
        connection = HTTPConnection(owner.url.removeprefix('http://'), timeout=2)
        try:
            connection.request('GET', '/')
            with connection.getresponse() as response:
                assert response.status == 200 and response.read() == b'ok'
        finally:
            connection.close()
        admission_elapsed = time.monotonic() - admission
        teardown = time.monotonic()
    teardown_elapsed = time.monotonic() - teardown
    retired = bool(observed) and all(not worker.is_alive() and accepted.fileno() == -1 and listener.fileno() == -1 for worker, accepted, listener in observed) and not owner._thread.is_alive()
finally:
    for selector_class, original in originals.items():
        selector_class.select = original

result = {'idle_seconds': idle_wall, 'idle_process_cpu_seconds': idle_cpu, 'idle_selector_timeouts': {str(key): value for key, value in counts.items()}, 'observed_positive_idle_wait': any(timeout is not None and timeout > 0 for timeout in counts), 'request_seconds': admission_elapsed, 'teardown_seconds': teardown_elapsed, 'owned_resources_retired': retired, 'source_sha256': hashlib.sha256((root / 'tests/orchestrator/_http_origin.py').read_bytes()).hexdigest(), 'measurement_limit': 'One diagnostic observation, not a CPU benchmark or service latency guarantee. Selector wrappers forward every real call unchanged.'}
Path('/tmp/issue-235-idle-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
assert retired
assert result['observed_positive_idle_wait'], 'Idle origin only issued zero-timeout polls instead of waiting for readiness'
