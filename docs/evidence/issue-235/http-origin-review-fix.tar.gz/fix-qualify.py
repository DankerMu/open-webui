import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

source = Path('/Users/danker/Documents/31308/open-computer-use')
base = '43fccbd9552933193721a4c8c30f857aec119046'
helper_name = 'tests/orchestrator/_http_origin.py'
test_name = 'tests/orchestrator/test_http_origin.py'
holder_test = 'tests/orchestrator/test_office_http_holders.py'
holder_name = 'tests/orchestrator/test_office_save_close.py'
command_name = 'tests/orchestrator/test_office_commands.py'
result = {'base': base, 'cases': [], 'qualification': 'Disposable semantic faults; live source is never mutated.'}
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
changes = subprocess.check_output(['git', 'diff', '--name-only', base], cwd=source, text=True).splitlines()
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', 'tests/orchestrator'], cwd=source, text=True).splitlines()
inputs = sorted(set(changes + [name for name in untracked if name.endswith('.py')]))
assert (source / holder_test).is_file()
result['live_inputs_before'] = {name: digest(source / name) for name in inputs}
try:
    with tempfile.TemporaryDirectory(prefix='issue-235-fix-qualification-') as temporary:
        copy = Path(temporary) / 'repo'
        subprocess.run(['git', 'clone', '--quiet', '--local', '--no-hardlinks', str(source), str(copy)], check=True, capture_output=True, text=True, timeout=120)
        for name in inputs:
            destination = copy / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source / name, destination)
        assert all(digest(copy / name) == expected for name, expected in result['live_inputs_before'].items())
        helper, command, holder = copy / helper_name, copy / command_name, copy / holder_name
        candidate = helper.read_text()
        current_command = command.read_bytes()
        current_holder = holder.read_text()
        original_command = subprocess.check_output(['git', 'show', base + ':' + command_name], cwd=source)
        no_drain = 'workers = tuple(self._workers)'
        no_error = '            errors = list(self._errors)\n        _raise_errors(errors, body_error)'
        cleanup = '            box.__exit__(*sys.exc_info())'
        assert candidate.count(no_drain) == 1 and candidate.count(no_error) == 1
        assert current_holder.count(cleanup) == 1
        manual_start = current_holder.index('def test_delayed_accepted_save_keeps_concurrent_close(')
        manual_end = current_holder.index('\ndef ', manual_start + 4)
        manual = current_holder[manual_start:manual_end]
        assert manual.count('box.__exit__(*sys.exc_info())') == 1
        env = os.environ.copy()
        removed = []
        for name in ('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy', 'all_proxy'):
            if name in env:
                removed.append(name)
                del env[name]
        env.update(NO_PROXY='*', no_proxy='*')
        env['PYTHONPATH'] = str(copy) + os.pathsep + str(copy / 'computer-use-server')
        result['removed_proxy_variable_names'] = removed
        def run(label, expected, files, selection=None):
            argv = [sys.executable, '-m', 'pytest', *files, '-q', '--import-mode=importlib', '-p', 'no:cacheprovider', '--tb=short', '--basetemp', str(Path(temporary) / ('pytest-' + label))]
            if selection:
                argv += ['-k', selection]
            begin = time.time()
            proc = subprocess.run(argv, cwd=copy, env=env, capture_output=True, text=True, timeout=180)
            row = {'label': label, 'argv': argv, 'exit': proc.returncode, 'elapsed': time.time()-begin, 'inputs': {name: digest(copy/name) for name in inputs}, 'stdout': proc.stdout, 'stderr': proc.stderr}
            result['cases'].append(row)
            print(label, proc.returncode, proc.stdout[-2400:], proc.stderr[-1000:])
            assert proc.returncode == expected, 'Qualification exit did not match declared semantic control'
            return row
        run('candidate-baseline', 0, [test_name, holder_test])
        helper.write_text(candidate.replace(no_drain, 'workers = ()', 1))
        run('missing-handler-drain', 1, [test_name])
        helper.write_text(candidate.replace(no_error, '            errors = list(self._errors)\n        return', 1))
        run('lost-owner-errors', 1, [test_name])
        helper.write_bytes(Path('/tmp/issue-235-http-origin-before-blocking.py').read_bytes())
        framing = run('inherited-nonblocking-transport', 1, [test_name], 'waits_for_complete_fragmented_request')
        assert 'responder ran before headers were complete' in framing['stdout']
        helper.write_text(candidate)
        command.write_bytes(original_command)
        old = run('final-tracer-original-command-origin', 1, [test_name], 'reports_responder_failure_to_owning_test')
        assert 'DID NOT RAISE' in old['stdout']
        command.write_bytes(current_command)
        holder.write_text(current_holder.replace(cleanup, '            pass', 1))
        run('missing-acquired-box-cleanup', 1, [holder_test])
        holder.write_text(current_holder[:manual_start] + manual.replace('box.__exit__(*sys.exc_info())', 'box.__exit__(None, None, None)', 1) + current_holder[manual_end:])
        run('lost-manual-body-forwarding', 1, [holder_test])
        holder.write_text(current_holder)
        run('restored-candidate', 0, [test_name, holder_test])
    result['owned_copy_removed'] = not Path(temporary).exists()
finally:
    result['live_inputs_after'] = {name: digest(source / name) for name in inputs}
    result['live_inputs_unchanged'] = result['live_inputs_before'] == result['live_inputs_after']
    Path('/tmp/issue-235-fix-qualification-result.json').write_text(json.dumps(result, indent=2)+'\n')
assert result['owned_copy_removed'] and result['live_inputs_unchanged']
