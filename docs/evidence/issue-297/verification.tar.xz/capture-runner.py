from pathlib import Path
import subprocess
import json
import os
import hashlib
import shutil
import time

web = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
ocu = Path('/Users/danker/Documents/31308/open-computer-use')
stage297 = Path('/tmp/issue-297-evidence')
delivery297 = Path('/tmp/issue-297-delivery')
nodebin = '/Users/danker/.nvm/versions/node/v22.23.2/bin'
env297 = {
    'PATH': f'/Users/danker/.local/bin:{web}/.venv/bin:{nodebin}:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
    'HOME': str(Path.home()), 'LANG': 'C.UTF-8',
    'NO_PROXY': '127.0.0.1,localhost', 'PYTHONDONTWRITEBYTECODE': '1',
    'NODE_PATH': '/Users/danker/.npm/_npx/db89d7302a373f10/node_modules',
}
uv297 = ['uv', 'run', '--offline', '--no-project', '--python', '3.12', '--no-python-downloads', '--with', 'pytest', '--with', 'pytest-asyncio', '--with', 'PyYAML==6.0.2', '--with-requirements', str(ocu / 'computer-use-server/requirements.txt'), '--']
browser297 = uv297 + ['python', '/tmp/issue-199-run-browser.py']

def capture297(name, args, cwd=ocu, expected=0, timeout=360, extra_env=None):
    target = stage297 / f'{name}.json'
    assert not target.exists(), target
    started = time.monotonic()
    result = subprocess.run(args, cwd=cwd, env=env297 | (extra_env or {}), capture_output=True, text=True, timeout=timeout)
    target.write_text(json.dumps({'command': args, 'cwd': str(cwd), 'exit': result.returncode, 'elapsed_seconds': time.monotonic()-started, 'stdout': result.stdout, 'stderr': result.stderr}, indent=2) + '\n')
    print(name, 'exit', result.returncode, (result.stdout + result.stderr)[-3500:])
    assert result.returncode == expected
    return result
