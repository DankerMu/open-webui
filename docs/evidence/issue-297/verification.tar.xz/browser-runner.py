import os
import sys

os.environ["OCU_PREVIEW_PYTHON"] = sys.executable
os.execvp("node", ["node", "tests/orchestrator/preview_embedding_browser.cjs"])
