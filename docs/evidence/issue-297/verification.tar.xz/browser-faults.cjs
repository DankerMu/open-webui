// Parent-only served-byte faults. The repository and acceptance assertions stay unchanged.
const fs = require('node:fs/promises');
const syncFs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const target = path.resolve(process.env.ISSUE297_SOURCE);
const expected = process.env.ISSUE297_SOURCE_SHA256;
const fault = process.env.ISSUE297_FAULT;
const journal = process.env.ISSUE297_JOURNAL;
if (!expected || !fault || !journal) throw new Error('Missing protected fault identity');
const originalRead = fs.readFile.bind(fs);
const digest = value => createHash('sha256').update(value).digest('hex');
function replaceOnce(text, before, after) {
  if (text.split(before).length !== 2) throw new Error('Protected fault seam is not unique');
  return text.replace(before, () => after);
}
fs.readFile = async function(filename, ...args) {
  const content = await originalRead(filename, ...args);
  if (typeof filename !== 'string' || path.resolve(filename) !== target) return content;
  if (digest(content) !== expected) throw new Error('Candidate source identity changed');
  let changed = content.toString();
  if (fault === 'canonical-resource-base') {
    changed = replaceOnce(changed,
      "base.setAttribute('href', new URL('.', resp.url).href);",
      "base.setAttribute('href', new URL('.', new URL(file.url, window.location.origin)).href);");
  } else if (fault === 'transient-navigation') {
    changed = replaceOnce(changed, "'resolvedUrl:resolvedUrl'", "'resolvedUrl:a.href'");
  } else if (fault === 'same-origin-sandbox') {
    changed = replaceOnce(changed, "const sandbox = 'allow-scripts allow-forms';",
      "const sandbox = 'allow-scripts allow-forms allow-same-origin';");
  } else if (fault === 'replacement-token-interpolation') {
    changed = replaceOnce(changed,
      "text.replace('<head>', () => '<head>' + injection)",
      "text.replace('<head>', '<head>' + injection)");
    changed = replaceOnce(changed,
      "text.replace('<html>', () => '<html><head>' + injection + '</head>')",
      "text.replace('<html>', '<html><head>' + injection + '</head>')");
  } else {
    throw new Error('Unknown protected browser fault');
  }
  syncFs.appendFileSync(journal, JSON.stringify({ fault, sourceSha256: expected,
    servedSha256: digest(changed) }) + '\n');
  return Buffer.isBuffer(content) ? Buffer.from(changed) : changed;
};
