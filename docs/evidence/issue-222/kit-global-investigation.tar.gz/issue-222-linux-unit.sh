#!/usr/bin/env bash
set -euo pipefail
node --version
npm --version
python3 --version
uname -sm
git clone --no-checkout /input/source.bundle .
git checkout --detach 9b344222ab308090b622c62aea0591ba5dc9e109
python3 -m venv /tmp/issue-222-uv
/tmp/issue-222-uv/bin/python -m pip install --disable-pip-version-check uv==0.9.18
export PATH="/tmp/issue-222-uv/bin:$PATH"
uv --version
uv sync --frozen --group dev --no-install-project
npm ci
source scripts/dev-env.sh
stage_frontend_assets
export UV_NO_SYNC=1
make test
make coverage-gate
