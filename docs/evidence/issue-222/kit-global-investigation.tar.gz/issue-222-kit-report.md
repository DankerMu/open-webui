## A. Kit define generation (verified)

`node_modules/@sveltejs/kit/src/exports/vite/index.js` plugin `config` hook:
- `:299` `is_build = config_env.command === 'build'`. Vitest creates its Vite server with `createServer` (vite dist :63011-63015 → `resolveConfig(..., 'serve')`), so `is_build === false` → **the dev branch always runs in vitest** (index.js:465-475):
  - `__SVELTEKIT_PAYLOAD__: 'globalThis.__sveltekit_dev'` (an *expression*, not a JSON value)
  - `__SVELTEKIT_APP_VERSION_POLL_INTERVAL__: '0'`, `__SVELTEKIT_HAS_SERVER_LOAD__/_UNIVERSAL_LOAD__: 'true'`, plus the common `:416-431` keys (`__SVELTEKIT_PATHS_BASE__`, `__SVELTEKIT_PATHS_ASSETS__`, `__SVELTEKIT_APP_DIR__`, `__SVELTEKIT_HASH_ROUTING__`, `__SVELTEKIT_DEV__` …).
  - `:474-475` `globalThis.__sveltekit_dev = {}` executes **in the process that runs the plugin's config hook = the Vitest main process**. Worker processes/threads do NOT have it (relevant below).
  - `:477-482` `ssr.external = ['cookie','set-cookie-parser']`.
- `:365-378` `ssr.noExternal: ['esm-env', '@sveltejs/kit/src/runtime']`. The in-file comment is the crux: this string is not a valid bare specifier; it only works because vite-node matches it by string concatenation.
- `:325-331` `$app` alias → `${runtime_directory}/app`, `runtime_directory` = `<...>/node_modules/@sveltejs/kit/src/runtime` (core/utils.js:17).

## B. How defines reach executing code (verified)

`vite:define` (vite dist :47346-47351):
```js
async transform(code, id, options) {
  const ssr = options?.ssr === true;
  if (!ssr && !isBuild) { return; }   // dev + client transform ⇒ NO replacement at all
```
So in dev:
- **ssr transform** (`transformRequest(id, {ssr:true})`, vite-node server.mjs :404-430 else-branch) ⇒ identifiers are **statically replaced** (`globalThis.__sveltekit_dev`, `""`, etc.).
- **web/client transform** (`transformRequest(id)` without `{ssr:true}`, vite-node :404-430 first branch) ⇒ identifiers stay **bare**; the only rescue is the dev-global injection: `clientInjectionsPlugin` (:47481-47508) replaces `__DEFINES__` in `<vite>/dist/client/env.mjs`, which does `Object.keys(defines).forEach(key => context[key] = defines[key])` (vite/dist/client/env.mjs). Vite's own dev client loads it via `import '@vite/env'` (vite/dist/client/client.mjs:1); Vitest loads it via `await runner.executeId('/@vite/env')` (execute.fL3szUAI.js:364-368) because `/@vite/client` is stubbed (execute.fL3szUAI.js:441-448) — `/@vite/env` itself is *not* stubbed and is served by the Vite server.
- Build (`command === 'build'`) ⇒ static replacement in both environments.

Consequences that separate failure signatures:
- `ReferenceError: __SVELTEKIT_PAYLOAD__ is not defined` ⇒ **neither** static replacement **nor** the `/@vite/env` global existed in the evaluating realm.
- `TypeError: Cannot read properties of undefined (reading 'data')` (kit runtime/client/client.js:337, non-optional access) ⇒ define/global existed but resolved to `undefined` — the expected cross-process artifact of `globalThis.__sveltekit_dev` not existing in the worker.
- Silent pass with `base === ''` ⇒ globals installed, `__SVELTEKIT_PAYLOAD__` = `undefined` (current healthy state).

## C. Resolution conditions: which runtime file is even loaded

`$app/paths` → alias → `<kit>/src/runtime/app/paths` → `index.js` = `export * from '#app/paths'` → Node subpath-import resolution against Kit's `imports` (`package.json:75-84`): `browser` → `client.js`, `default` → `server.js`.

Condition computation (vite dist :46644-46667): `additionalConditions = options.overrideConditions ?? ['production','development','module', ...options.conditions]`, then `browser: targetWeb` adds either `'browser'` or `'node'`; entry keys are matched in package.json order, so `client.js` wins whenever `browser` is in the set.
- web transform: `targetWeb = true` ⇒ `browser` always added ⇒ **client.js** (no config needed).
- ssr transform: `targetWeb = false` ⇒ `node` added; plus `ssrConditions = ssrConfig.resolve.conditions || resolveOptions.conditions` (:46082-46087). Because vite.config.ts:36 sets `ssr.resolve.conditions: ['browser']`, `browser` is ALSO in the SSR set ⇒ **client.js is loaded through the SSR pipeline too**. Without that line SSR would take `default` → `server.js`, which never touches `__SVELTEKIT_PAYLOAD__`.
So the observed error file is only reachable because the browser variant is selected; that selection is intended by the repo config (mirrors pages/`$app/state` client semantics in jsdom) and is NOT by itself a bug.

## D. vite-node externalization (verified) — how the file can dodge all processing

`_shouldExternalize` (vite-node server.mjs :70-105), in order:
1. builtin / `data:` / http → external.
2. `options.deps.cacheDir` substring → external (optimized-dep ids / `.vite-node` dumps).
3. user `inline` patterns match → **inline** (returns false). For string patterns: `id.includes(join(dir, pattern))` with `dir ∈ moduleDirectories`; `moduleDirectories` always contains `/node_modules/` (vitest cli-api:9426-9431/9472-9474; vite-node constructor :221-224). Kit's `'@sveltejs/kit/src/runtime'` therefore becomes the literal substring `/node_modules/@sveltejs/kit/src/runtime`.
4. user `external` patterns → external.
5. `defaultInline`, `depsExternal` (`/\/node_modules\/.*\.mjs$/`, `/\/node_modules\/.*\.cjs\.js$/`) → inline/external.
6. else `isValidNodeImport(id)` (:37-63): `.js` inside a `{type: 'module'}` package ⇒ **external** (Kit qualifies).

So the runtime file is inlined **only if** the id/filePath passed in literally contains `/node_modules/@sveltejs/kit/src/runtime`. Ways to lose that (all require the Kit package files to sit at a path without that substring, or a substituted id): pnpm global virtual store / `npm link` realpath outside `node_modules`, a workspace root whose `node_modules` is not on that path, custom `VITE_NODE_DEPS_MODULE_DIRECTORIES`/`deps.moduleDirectories` (note: those *append*, so they cannot remove the default), or an id already in the cache dir. When externalized, `_fetchModule` returns `{externalize}` (:384-389) and the runner does a native `import()` (vite-node client.mjs :251-255; vitest execute.fL3szUAI.js:379-383) — **no Vite transform**, so the only possible rescue is the `/@vite/env` globals in whatever realm that native import executes in.

Note also `toFilePath`/`normalizeModuleId` (vite-node utils.mjs) keep `?v=<hash>` queries in `path` (dev node_modules ids get one, vite dist :46290-46294), but that does not break the substring match.

## E. Vitest 1.6 plumbing that decides mode/realm (verified)

- Per-worker transform mode = `state.environment.transformMode ?? 'ssr'` (execute.fL3szUAI.js:403-405), sent with every module RPC (:412) and used server-side (:7936-7940).
- jsdom env declares `transformMode: 'web'` (index.GVFv9dZ0.js:436-437); `ctx.environment.transformMode` only overrides it when `test.testTransformMode` patterns match (cli-api:7878-7884, default `{}` at :9688) — **the repo never sets `testTransformMode`, so every module fetched by a jsdom test is transformed in web mode**. ChatControls.test.ts is jsdom (`:1`).
- Sequence in a worker: jsdom `setup(globalThis, …)` → `startViteNode` → `createVitestExecutor` → `executeId('/@vite/env')` (globals installed) → test-module graph. So within the runner realm the dev globals should be present.
- **Realm caveat**: with `pool: 'vmThreads'` (or any vm-context executor) inlined modules and `/@vite/env` run inside the vm context, while **externalized** modules are imported by the outer realm's ESM loader (vm chunk passes an `externalModulesExecutor`) → globals missing there. With `threads`/`forks` externalization executes in the same realm as the runner, so externalization alone should NOT produce a ReferenceError — it produces the silent-undefined/TypeError class instead. This distinction is exactly what D1/D4 test.
- Dep optimizer / `.vite` cache: `VitestOptimizer` (cli-api:10256-10267) calls `resolveOptimizerConfig`, which without an explicit `test.deps.optimizer.*.enabled: true` yields `{noDiscovery:true, include:[]}`; Kit's `optimizeDeps.entries/exclude` are dropped. vite-node 1.6.1 contains no optimizer consumer at all (no `optimizer`/`optimizeDeps` matches in vite-node/dist). So a stale `node_modules/.vite/deps` prebundle is an implausible trigger for these files; only `cacheDir`-resident ids would be externalized at all.
- `VITEST='true'` is set before config load (cli-api:18318-18320) and propagated to workers (:8825-8830), so vite.config.ts:22-37 is active during `make test-frontend` (Makefile:93-94 → `npx vitest run --passWithNoTests`, default pool `threads`, cli-api:9497).

## F. Concrete bypass call chains (the answer to "actual mechanism")

File: `<repo>/node_modules/@sveltejs/kit/src/runtime/app/paths/internal/client.js`.

Chain 1 — externalized (native ESM, no define, rescue only via realm globals):
clause: some transformed module (e.g. a `.svelte`/`.ts` under `src/`, or an inlined node_modules package) imports `$app/paths` → Vite resolve (web mode: `browser` flag) → `<kit>/src/runtime/app/paths/client.js` → vite-node `fetchResult(id,'web')` → `_shouldExternalize(filePath)` returns the path because the `'/node_modules/@sveltejs/kit/src/runtime'` substring test failed (path shape) or the id is under the cache dir → `directRequest` → `interopedImport(externalize)` → Node ESM → `./internal/client.js` evaluated natively → `__SVELTEKIT_PAYLOAD__` unbound unless `globalThis.__SVELTEKIT_PAYLOAD__` was installed in that realm.

Chain 2 — inlined but transformed in web mode in dev (define plugin short-circuits):
`_shouldExternalize` → false → `_transformRequest(id, filePath, 'web')` → `server.transformRequest(id)` (no `{ssr:true}`) → `vite:define` returns early (dep-BK3b2jBa.js:47349) → code still contains `__SVELTEKIT_PAYLOAD__?.base ?? __SVELTEKIT_PATHS_BASE__` and `__SVELTEKIT_APP_DIR__` … → executes as a wrapper function in the runner; resolution succeeds **only** through the globals installed by `/@vite/env`. If that module was stubbed/skipped, fetched before its transform, or evaluated in another realm, the same ReferenceError appears — while the code is *also* silently wrong when the globals exist but `globalThis.__sveltekit_dev` is undefined in a worker.

Both chains require the same missing invariant: `globalThis.__SVELTEKIT_*` present (dev) or textual replacement performed (ssr/build). Nothing in the chain is platform-specific.

## G. Proven vs unknown

Proven (source-verified): define generation content/branch; the `vite:define` ssr/build-only guard; `__DEFINES__` → globalThis injection and who executes `/@vite/env` in Vitest; jsdom ⇒ transformMode 'web' and default `testTransformMode`; `#app/paths` condition resolution incl. the effect of vite.config.ts:36; vite-node externalization ordering and the string-concat guard; Kit's `ssr.noExternal` reaching `deps.inline`; dep-optimizer inertness; `VITEST='true'` propagation.
Unknown (needs the artifact/diagnostic): (1) the realm/execution path of the failing evaluation in the historical macOS run (externalized native import vs web-transform + missing globals) — no stored ReferenceError exists under /tmp/issue-222*; (2) whether `/@vite/env`'s injected `defines` object contained the `__SVELTEKIT_*` keys in that run; (3) whether the historical run's Kit/WORKER realm had `globalThis.__sveltekit_dev` (only the main process gets it — a second false-failure source if code ever touches `__SVELTEKIT_PAYLOAD__.data`).
Explicitly NOT supported: "macOS bug", stale `node_modules/.vite` prebundle, dep-optimizer cache, package-lock/Kit-version drift (all ruled out or inert by the code above; the lock and Kit 2.68.0 are identical to the Linux run).

## H. Minimal parent-executable diagnostics (no test-assertion or production changes)

D1 — one-shot discriminator (externalization + transform boundary + env-defines):
```bash
VITE_NODE_DEBUG_DUMP=1 npx vitest run src/lib/components/chat/ChatControls.test.ts
# artifacts (written by the MAIN process): <root>/.vite-node/dump/info.json + one .js per fetched id
python3 - <<'PY'
import json,glob,re
info=json.load(open('.vite-node/dump/info.json'))
print('EXTERNALIZED:', {k:v for k,v in info['externalize'].items() if 'sveltejs' in k or 'vite/env' in k})
for f in glob.glob('.vite-node/dump/*.js'):
    c=open(f).read()
    tags=[t for t in ('__SVELTEKIT_PAYLOAD__','globalThis.__sveltekit_dev','__SVELTEKIT_APP_DIR__') if t in c]
    if tags: print(f, tags)
PY
```
Interpretation: `EXTERNALIZED` non-empty for a Kit runtime file ⇒ Chain 1; the Kit file dump listing `__SVELTEKIT_PAYLOAD__` ⇒ web-mode (Chain 2) with the rescue on `/@vite/env`; listing `globalThis.__sveltekit_dev` ⇒ ssr-mode textual define (healthy); the `_vite_env` dump containing `__SVELTEKIT_PAYLOAD__` inside its `defines` object ⇒ injection worked. (Caveat: dump filenames are keyed by id only, so if the same id is fetched in both modes the later write wins — run one test file at a time.) For a custom dump dir, a scratch config can set `server: { debug: { dumpModules: '/tmp/vn-dump' } }` since Vitest passes `config.server` straight into `ViteNodeServer` (cli-api:10670).

D2 — resolution (which variant, and does `/@vite/env` resolve to Vite's env entry):
```bash
DEBUG='vite:resolve' npx vitest run src/lib/components/chat/ChatControls.test.ts 2>&1 | grep -E '#app/paths|app/paths/(client|server)|@vite/env'
```

D3 — transform-mode switch, no repo edits (separates "web-mode define bypass" from everything else):
```bash
cat > /tmp/vitest-ssr-mode.config.ts <<'EOF'
import { mergeConfig } from 'vite';
import base from '/Users/danker/Documents/31308/open-webui-ocu-plan2/vite.config.ts';
export default mergeConfig(base as never, { test: { testTransformMode: { ssr: ['**/*'] } } } as never);
EOF
npx vitest run --config /tmp/vitest-ssr-mode.config.ts src/lib/components/chat/ChatControls.test.ts
```
If the error vanishes/behaviour changes under forced `ssr` transform mode, the failure lives at the define-transform boundary (Chain 2), i.e. it depends on `/@vite/env` globals, not on externalization.

D4 — realm/pool bisect (externalized-module realm):
```bash
for p in threads forks vmThreads; do echo "== $p"; npx vitest run src/lib/components/chat/ChatControls.test.ts --pool=$p 2>&1 | tail -5; done
```
Failure only under `vmThreads` ⇒ externalized modules evaluate in the outer realm where `/@vite/env` never ran (Chain 1 + realm).

D5 — mechanism control with zero app involvement (proves the identifier only exists after Vite processing):
```bash
cd node_modules/@sveltejs/kit
node --input-type=module -e "console.log(import.meta.resolve('#app/paths'))"                 # → .../paths/server.js
node --conditions=browser --input-type=module -e "console.log(import.meta.resolve('#app/paths'))"  # → .../paths/client.js
node --conditions=browser --input-type=module -e "import('#app/paths')"                     # → ReferenceError: __SVELTEKIT_PAYLOAD__ is not defined
```

D6 — env-globals probe (optional, scratch file only): a temp test (wired via a scratch `test.include`) asserting `'__SVELTEKIT_PAYLOAD__' in globalThis` and `globalThis.APP_VERSION` inside the run; `src/lib/constants.ts:21` uses the repo's own `APP_VERSION` define through the same mechanism, so the historical stderr itself is a probe: if it shows only the Kit ReferenceError while app code using `APP_VERSION` evaluated fine, then `config.define`/injection content — not the realm — is implicated; if both identifiers fail, `/@vite/env` never ran in that realm.

Cache row of the requested matrix: check `.vite-node/dump/info.json` for `cacheDir`-resident ids and `ls -la node_modules/.vite/deps` (expected empty/absent given VitestOptimizer disabling noDiscovery/include:[]); per-process Vite/vite-node caches cannot explain a cross-run difference.
