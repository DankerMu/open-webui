#!/usr/bin/env bash
set -euo pipefail
node --version
npm --version
uname -sm
tar -xf /input/source.tar -C /work
npm ci
make test-frontend
