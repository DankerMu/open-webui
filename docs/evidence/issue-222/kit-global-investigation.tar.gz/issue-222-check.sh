#!/usr/bin/env bash
set -euo pipefail
source scripts/dev-env.sh
stage_frontend_assets
UV_NO_SYNC=1 make check
