import json
from pathlib import Path
import subprocess
import sys
import time

mode = sys.argv[1] if len(sys.argv) > 1 else 'frontend'
assert mode in ('frontend', 'unit')
name = f'issue-222-linux-{mode}-9b344222'
source = 'bundle' if mode == 'unit' else 'tar'
script = '/tmp/issue-222-linux-unit.sh' if mode == 'unit' else '/tmp/issue-222-linux.sh'
output = Path(f'/tmp/issue-222-linux-{mode}.command.json')
if output.exists():
    raise SystemExit(f'Refusing evidence overwrite: {output}')
argv = ['docker', 'run', '--rm', '--name', name, '--platform', 'linux/amd64', '--entrypoint', '/bin/bash', '--workdir', '/work', '-e', 'CI=true', '-v', f'/tmp/issue-222-source.{source}:/input/source.{source}:ro', '-v', f'{script}:/input/run.sh:ro', 'sha256:65d7442f55419a4f90d8b0fb88010029854ed4a95a76bbab49ae7c2d571f08d2', '/input/run.sh']
start = time.time()
try:
    p = subprocess.run(argv, text=True, capture_output=True, timeout=3500)
    result = {'argv': argv, 'exit': p.returncode, 'elapsed': time.time()-start, 'stdout': p.stdout, 'stderr': p.stderr}
except subprocess.TimeoutExpired as e:
    result = {'argv': argv, 'exit': 'timeout', 'elapsed': time.time()-start, 'stdout': (e.stdout or b'').decode(), 'stderr': (e.stderr or b'').decode()}
finally:
    cleanup = subprocess.run(['docker', 'rm', '-f', name], text=True, capture_output=True)
result['cleanup'] = {'exit': cleanup.returncode, 'stdout': cleanup.stdout, 'stderr': cleanup.stderr}
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('stdout','stderr')}))
print(result['stdout'][-6000:])
print(result['stderr'][-3000:])
raise SystemExit(0 if result['exit'] == 0 else 1)
