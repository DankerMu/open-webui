// /src/lib/components/chat/ChatControls.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_3__ = await __vite_ssr_import__("/node_modules/svelte/src/index-client.js", {"importedNames":["onMount","tick","getContext"]});
const __vite_ssr_import_4__ = await __vite_ssr_import__("/src/lib/stores/index.ts", {"importedNames":["config","terminalServers","showControls","showCallOverlay","temporaryChatEnabled","showArtifacts","showEmbeds","settings","showFileNavPath","selectedTerminalId","user"]});
const __vite_ssr_import_5__ = await __vite_ssr_import__("/src/lib/components/chat/Controls/Controls.svelte", {"importedNames":["default"]});
const __vite_ssr_import_6__ = await __vite_ssr_import__("/src/lib/components/chat/MessageInput/CallOverlay.svelte", {"importedNames":["default"]});
const __vite_ssr_import_7__ = await __vite_ssr_import__("/src/lib/components/common/Drawer.svelte", {"importedNames":["default"]});
const __vite_ssr_import_8__ = await __vite_ssr_import__("/src/lib/components/common/ResizableSidePanel.svelte", {"importedNames":["default"]});
const __vite_ssr_import_9__ = await __vite_ssr_import__("/src/lib/components/chat/Artifacts.svelte", {"importedNames":["default"]});
const __vite_ssr_import_10__ = await __vite_ssr_import__("/src/lib/components/chat/ChatControls/Embeds.svelte", {"importedNames":["default"]});
const __vite_ssr_import_11__ = await __vite_ssr_import__("/src/lib/components/chat/FileNav.svelte", {"importedNames":["default"]});
const __vite_ssr_import_12__ = await __vite_ssr_import__("/src/lib/components/chat/PyodideFileNav.svelte", {"importedNames":["default"]});
const __vite_ssr_import_13__ = await __vite_ssr_import__("/src/lib/components/chat/Overview.svelte", {"importedNames":["default"]});
const __vite_ssr_import_14__ = await __vite_ssr_import__("/src/lib/utils/chatId.ts", {"importedNames":["isSavedChatId"]});
const __vite_ssr_import_15__ = await __vite_ssr_import__("/src/lib/components/chat/WorkspaceArtifact.svelte", {"importedNames":["default"]});
const __vite_ssr_import_16__ = await __vite_ssr_import__("/src/lib/apis/ocu/index.ts", {"importedNames":["workspaceFilesEnabled"]});
const __vite_ssr_import_17__ = await __vite_ssr_import__("/src/lib/stores/ocu.ts", {"importedNames":["closeWorkspacePanel","ocuWorkspaces","openWorkspacePanel"]});
const __vite_ssr_import_18__ = await __vite_ssr_import__("/src/lib/components/chat/workspace-reconciliation.ts", {"importedNames":["WORKSPACE_RECONCILIATION"]});



ChatControls[__vite_ssr_import_2__.FILENAME] = 'src/lib/components/chat/ChatControls.svelte';





















let savedTab = 'controls';
var root = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span role="status"> </span>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[312, 24]]);
var root_1 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span role="status"> </span>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[313, 24]]);
var root_2 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="fixed right-3 top-14 z-40 flex items-center gap-2 rounded-lg bg-white p-2 text-sm shadow-md dark:bg-gray-900"><button type="button"> </button> <!> <!></div>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[302, 1, [[305, 2]]]]);
var root_3 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<p class="fixed right-3 top-28 z-40 rounded-lg bg-white p-2 text-sm dark:bg-gray-900" role="alert"> </p>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[316, 20]]);
var root_4 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="h-full max-h-[100dvh] bg-white text-gray-700 dark:bg-black dark:text-gray-300 flex justify-center"><!></div>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[332, 5]]);
var root_5 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button> </button>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[362, 9]]);
var root_6 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button> </button>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[373, 9]]);
var root_7 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button> </button>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[384, 9]]);
var root_8 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span role="status"> </span>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[405, 30]]);
var root_9 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span role="status"> </span>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[406, 30]]);
var root_10 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button type="button"> </button> <!> <!>`, 1), ChatControls[__vite_ssr_import_2__.FILENAME], [[396, 8]]);

var root_11 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="flex flex-col h-full min-h-0"><div class="flex items-center justify-between px-2 pt-2 pb-2 shrink-0"><div class="flex gap-1 min-w-0 overflow-x-auto scrollbar-hidden"><!> <!> <!></div> <!> <button class="p-1 rounded-lg text-gray-500 dark:text-gray-400"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="size-4"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12"></path></svg></button></div> <div><!></div></div>`), ChatControls[__vite_ssr_import_2__.FILENAME], [
	[
		357,
		5,
		[
			[359, 6, [[360, 7], [410, 7, [[415, 8, [[423, 9]]]]]]],
			[428, 6]
		]
	]
]);

var root_12 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="h-[100dvh] flex flex-col"><!></div>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[330, 3]]);
var root_13 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="w-full h-full flex justify-center"><!></div>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[478, 5]]);
var root_14 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button> </button>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[506, 9]]);
var root_15 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button> </button>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[517, 9]]);
var root_16 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button> </button>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[528, 9]]);
var root_17 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span role="status"> </span>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[549, 30]]);
var root_18 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span role="status"> </span>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[550, 30]]);
var root_19 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button type="button"> </button> <!> <!>`, 1), ChatControls[__vite_ssr_import_2__.FILENAME], [[540, 8]]);

var root_20 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="flex flex-col h-full min-h-0"><div class="flex items-center justify-between px-2 pt-2 pb-2 shrink-0"><div class="flex gap-1 min-w-0 overflow-x-auto scrollbar-hidden"><!> <!> <!></div> <!> <button class="p-1 rounded-lg text-gray-500 dark:text-gray-400"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="size-4"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18 18 6M6 6l12 12"></path></svg></button></div> <div><!></div></div>`), ChatControls[__vite_ssr_import_2__.FILENAME], [
	[
		501,
		5,
		[
			[503, 6, [[504, 7], [554, 7, [[559, 8, [[567, 9]]]]]]],
			[572, 6]
		]
	]
]);

var root_21 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="flex h-full max-h-full min-h-full"><div id="controls-container"><!></div></div>`), ChatControls[__vite_ssr_import_2__.FILENAME], [[468, 2, [[469, 3]]]]);
var root_22 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<!> <!> <!>`, 1), ChatControls[__vite_ssr_import_2__.FILENAME], []);

function ChatControls($$anchor, $$props) {
	__vite_ssr_import_2__.check_target(new.target);
	__vite_ssr_import_2__.push($$props, false, ChatControls);

	var $$ownership_validator = __vite_ssr_import_2__.create_ownership_validator($$props);

	const $config = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_4__.config, 'config'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_4__.config, '$config', $$stores)
	);

	const $temporaryChatEnabled = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_4__.temporaryChatEnabled, 'temporaryChatEnabled'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_4__.temporaryChatEnabled, '$temporaryChatEnabled', $$stores)
	);

	const $ocuWorkspaces = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_17__.ocuWorkspaces, 'ocuWorkspaces'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_17__.ocuWorkspaces, '$ocuWorkspaces', $$stores)
	);

	const $showControls = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_4__.showControls, 'showControls'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_4__.showControls, '$showControls', $$stores)
	);

	const $showArtifacts = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_4__.showArtifacts, 'showArtifacts'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_4__.showArtifacts, '$showArtifacts', $$stores)
	);

	const $showEmbeds = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_4__.showEmbeds, 'showEmbeds'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_4__.showEmbeds, '$showEmbeds', $$stores)
	);

	const $showCallOverlay = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_4__.showCallOverlay, 'showCallOverlay'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_4__.showCallOverlay, '$showCallOverlay', $$stores)
	);

	const $user = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_4__.user, 'user'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_4__.user, '$user', $$stores)
	);

	const $terminalServers = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_4__.terminalServers, 'terminalServers'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_4__.terminalServers, '$terminalServers', $$stores)
	);

	const $selectedTerminalId = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_4__.selectedTerminalId, 'selectedTerminalId'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_4__.selectedTerminalId, '$selectedTerminalId', $$stores)
	);

	const $showFileNavPath = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_4__.showFileNavPath, 'showFileNavPath'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_4__.showFileNavPath, '$showFileNavPath', $$stores)
	);

	const $i18n = () => (
		__vite_ssr_import_2__.validate_store(i18n, 'i18n'),
		__vite_ssr_import_2__.store_get(i18n, '$i18n', $$stores)
	);

	const [$$stores, $$cleanup] = __vite_ssr_import_2__.setup_stores();
	const workspaceActionAvailable = __vite_ssr_import_2__.mutable_source();
	const workspaceAvailable = __vite_ssr_import_2__.mutable_source();
	const workspace = __vite_ssr_import_2__.mutable_source();
	const showWorkspace = __vite_ssr_import_2__.mutable_source();
	const workspaceChanged = __vite_ssr_import_2__.mutable_source();
	const hasMessages = __vite_ssr_import_2__.mutable_source();
	const showControlsTab = __vite_ssr_import_2__.mutable_source();
	const selectedSystemTerminal = __vite_ssr_import_2__.mutable_source();
	const selectedSystemTerminalAvailable = __vite_ssr_import_2__.mutable_source();
	const terminalFilesAvailable = __vite_ssr_import_2__.mutable_source();
	const showFilesTab = __vite_ssr_import_2__.mutable_source();
	const showOverviewTab = __vite_ssr_import_2__.mutable_source();
	const specialPanel = __vite_ssr_import_2__.mutable_source();
	const i18n = __vite_ssr_import_3__.getContext('i18n');
	const workspaceController = __vite_ssr_import_3__.getContext(__vite_ssr_import_18__.WORKSPACE_RECONCILIATION);
	let history = __vite_ssr_import_2__.prop($$props, 'history', 12);
	let models = __vite_ssr_import_2__.prop($$props, 'models', 24, () => []);
	let chatId = __vite_ssr_import_2__.prop($$props, 'chatId', 8, null);
	let chatUser = __vite_ssr_import_2__.prop($$props, 'chatUser', 8, null);
	let chatFiles = __vite_ssr_import_2__.prop($$props, 'chatFiles', 28, () => []);
	let params = __vite_ssr_import_2__.prop($$props, 'params', 28, () => ({}));
	let eventTarget = __vite_ssr_import_2__.prop($$props, 'eventTarget', 8);
	let submitPrompt = __vite_ssr_import_2__.prop($$props, 'submitPrompt', 8);
	let stopResponse = __vite_ssr_import_2__.prop($$props, 'stopResponse', 8);
	let showMessage = __vite_ssr_import_2__.prop($$props, 'showMessage', 8);
	let ensureSavedChat = __vite_ssr_import_2__.prop($$props, 'ensureSavedChat', 8);
	let firstSendPending = __vite_ssr_import_2__.prop($$props, 'firstSendPending', 8, false);
	let files = __vite_ssr_import_2__.prop($$props, 'files', 12);
	let modelId = __vite_ssr_import_2__.prop($$props, 'modelId', 8);
	let codeInterpreterEnabled = __vite_ssr_import_2__.prop($$props, 'codeInterpreterEnabled', 8, false);
	let largeScreen = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'largeScreen');
	let dragged = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'dragged');
	let mounted = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'mounted');
	let controlsWidth = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(350), 'controlsWidth');
	let workspaceActionPending = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'workspaceActionPending');
	let workspaceError = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'workspaceError');
	let controlsWasOpen = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'controlsWasOpen');
	let actionEpoch = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(0), 'actionEpoch');
	let actionChatId = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(chatId()), 'actionChatId');
	let actionHistory = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(history()), 'actionHistory');

	// Tab state for Controls+Files panel
	let activeTab = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(savedTab), 'activeTab');

	// svelte-ignore reactive_declaration_module_script_dependency
	const chatContext = (terminal) => terminal?.contexts?.chat ?? {};

	const chatContextAvailable = (terminal) => __vite_ssr_import_2__.strict_equals(chatContext(terminal), false, false);
	const chatContextNeedsSavedChat = (terminal) => __vite_ssr_import_2__.strict_equals(chatContext(terminal)?.context_id, 'chat_id');

	// Tab fallback: if active tab becomes hidden, switch to next available
	// Auto-close if there are no visible tabs
	// Auto-switch to Files tab when display_file is triggered
	// Keep Files selected when a terminal is active; opening the panel is handled by selection UI.
	// Clear selected direct terminal if user lost permission
	const handleMediaQuery = async (e) => {
		if (e.matches) {
			__vite_ssr_import_2__.set(largeScreen, true);

			if ($showCallOverlay()) {
				__vite_ssr_import_4__.showCallOverlay.set(false);
				(await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_3__.tick()))();
				__vite_ssr_import_4__.showCallOverlay.set(true);
			}
		} else {
			__vite_ssr_import_2__.set(largeScreen, false);

			if ($showCallOverlay()) {
				__vite_ssr_import_4__.showCallOverlay.set(false);
				(await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_3__.tick()))();
				__vite_ssr_import_4__.showCallOverlay.set(true);
			}
		}
	};

	const onMouseDown = () => {
		__vite_ssr_import_2__.set(dragged, true);
	};

	const onMouseUp = () => {
		__vite_ssr_import_2__.set(dragged, false);
	};

	__vite_ssr_import_3__.onMount(() => {
		const mediaQuery = window.matchMedia('(min-width: 1024px)');

		mediaQuery.addEventListener('change', handleMediaQuery);
		handleMediaQuery(mediaQuery);

		let isDestroyed = false;

		const init = async () => {
			(await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_3__.tick()))();

			if (isDestroyed) return;

			setTimeout(
				() => {
					__vite_ssr_import_2__.set(mounted, true);
				},
				0
			);
		};

		init();
		document.addEventListener('mousedown', onMouseDown);
		document.addEventListener('mouseup', onMouseUp);

		return () => {
			isDestroyed = true;
			__vite_ssr_import_2__.set(mounted, false);

			if (!__vite_ssr_import_2__.get(largeScreen)) {
				__vite_ssr_import_4__.showControls.set(false);
			}

			mediaQuery.removeEventListener('change', handleMediaQuery);
			document.removeEventListener('mousedown', onMouseDown);
			document.removeEventListener('mouseup', onMouseUp);
		};
	});

	const persistOpen = (id, open) => {
		void workspaceController.writePrefs(id, { open }).catch(() => {
			if (__vite_ssr_import_2__.strict_equals(chatId(), id)) __vite_ssr_import_2__.set(workspaceError, $i18n().t('Workspace preference could not be saved'));
		});
	};

	const openWorkspace = async () => {
		if (!__vite_ssr_import_2__.get(workspaceActionAvailable) || firstSendPending() || __vite_ssr_import_2__.get(workspaceActionPending)) return;

		const sourceId = chatId();
		const sourceHistory = history();
		const epoch = __vite_ssr_import_2__.get(actionEpoch);

		__vite_ssr_import_2__.set(workspaceActionPending, true);
		__vite_ssr_import_2__.set(workspaceError, '');

		const savedId = (await __vite_ssr_import_2__.track_reactivity_loss(ensureSavedChat()()))();

		if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(actionEpoch), epoch)) __vite_ssr_import_2__.set(workspaceActionPending, false);

		if (!savedId) {
			if (__vite_ssr_import_2__.strict_equals(chatId(), sourceId) && __vite_ssr_import_2__.strict_equals(history(), sourceHistory) && !$temporaryChatEnabled()) __vite_ssr_import_2__.set(workspaceError, $i18n().t('Workspace chat could not be saved'));

			return;
		}

		if (!__vite_ssr_import_2__.get(workspaceActionAvailable) || __vite_ssr_import_2__.strict_equals(history(), sourceHistory, false) || chatId() && __vite_ssr_import_2__.strict_equals(chatId(), savedId, false)) return;

		__vite_ssr_import_4__.showArtifacts.set(false);
		__vite_ssr_import_4__.showEmbeds.set(false);
		__vite_ssr_import_4__.showCallOverlay.set(false);
		__vite_ssr_import_4__.showControls.set(true);
		__vite_ssr_import_17__.openWorkspacePanel(savedId);
		persistOpen(savedId, true);
	};

	const closeHandler = () => {
		if (__vite_ssr_import_2__.get(showWorkspace) && chatId()) {
			__vite_ssr_import_17__.closeWorkspacePanel(chatId());
			persistOpen(chatId(), false);
		}

		if (!__vite_ssr_import_2__.get(largeScreen)) __vite_ssr_import_4__.showControls.set(false);

		__vite_ssr_import_4__.showArtifacts.set(false);
		__vite_ssr_import_4__.showEmbeds.set(false);

		if ($showCallOverlay()) __vite_ssr_import_4__.showCallOverlay.set(false);
	};

	const closeWorkspace = () => {
		if (__vite_ssr_import_2__.get(showWorkspace)) closeHandler();

		__vite_ssr_import_4__.showControls.set(false);
	};

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			__vite_ssr_import_2__.get(actionChatId),
			__vite_ssr_import_2__.deep_read_state(chatId()),
			__vite_ssr_import_2__.get(actionHistory),
			__vite_ssr_import_2__.deep_read_state(history()),
			__vite_ssr_import_2__.get(actionEpoch)
		),
		() => {
			if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(actionChatId), chatId(), false) || __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(actionHistory), history(), false)) {
				__vite_ssr_import_2__.set(actionChatId, chatId());
				__vite_ssr_import_2__.set(actionHistory, history());
				__vite_ssr_import_2__.update(actionEpoch);
				__vite_ssr_import_2__.set(workspaceActionPending, false);
				__vite_ssr_import_2__.set(workspaceError, '');
			}
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			__vite_ssr_import_16__.workspaceFilesEnabled,
			$config(),
			$temporaryChatEnabled(),
			__vite_ssr_import_2__.deep_read_state(chatId()),
			__vite_ssr_import_14__.isSavedChatId
		),
		() => {
			__vite_ssr_import_2__.set(workspaceActionAvailable, __vite_ssr_import_16__.workspaceFilesEnabled($config()) && !$temporaryChatEnabled() && (!chatId() || __vite_ssr_import_14__.isSavedChatId(chatId()) && __vite_ssr_import_2__.strict_equals(chatId(), 'default', false)));
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			__vite_ssr_import_2__.get(workspaceActionAvailable),
			__vite_ssr_import_14__.isSavedChatId,
			__vite_ssr_import_2__.deep_read_state(chatId())
		),
		() => {
			__vite_ssr_import_2__.set(workspaceAvailable, __vite_ssr_import_2__.get(workspaceActionAvailable) && __vite_ssr_import_14__.isSavedChatId(chatId()));
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(chatId()), $ocuWorkspaces()), () => {
		__vite_ssr_import_2__.set(workspace, chatId() ? $ocuWorkspaces()[chatId()] : undefined);
	});

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			__vite_ssr_import_2__.get(workspaceAvailable),
			__vite_ssr_import_2__.get(workspace),
			$showControls(),
			$showArtifacts(),
			$showEmbeds(),
			$showCallOverlay()
		),
		() => {
			__vite_ssr_import_2__.set(showWorkspace, __vite_ssr_import_2__.get(workspaceAvailable) && __vite_ssr_import_2__.get(workspace)?.open && $showControls() && !$showArtifacts() && !$showEmbeds() && !$showCallOverlay());
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.get(workspace)), () => {
		__vite_ssr_import_2__.set(workspaceChanged, !!__vite_ssr_import_2__.get(workspace) && !__vite_ssr_import_2__.get(workspace).open && __vite_ssr_import_2__.get(workspace).revision > __vite_ssr_import_2__.get(workspace).acknowledgedRevision);
	});

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			$showControls(),
			__vite_ssr_import_2__.get(mounted),
			__vite_ssr_import_2__.deep_read_state(chatId()),
			__vite_ssr_import_2__.get(workspace),
			__vite_ssr_import_2__.get(controlsWasOpen),
			__vite_ssr_import_17__.closeWorkspacePanel,
			__vite_ssr_import_2__.get(workspaceAvailable),
			$showArtifacts(),
			$showEmbeds(),
			$showCallOverlay(),
			__vite_ssr_import_4__.showControls
		),
		() => {
			const controlsOpen = $showControls();

			if (__vite_ssr_import_2__.get(mounted) && chatId() && __vite_ssr_import_2__.get(workspace)?.open) {
				if (__vite_ssr_import_2__.get(controlsWasOpen) && !controlsOpen) {
					__vite_ssr_import_17__.closeWorkspacePanel(chatId());
					persistOpen(chatId(), false);
				} else if (!__vite_ssr_import_2__.get(controlsWasOpen) && !controlsOpen && __vite_ssr_import_2__.get(workspaceAvailable) && !$showArtifacts() && !$showEmbeds() && !$showCallOverlay()) {
					__vite_ssr_import_4__.showControls.set(true);
				}
			}

			__vite_ssr_import_2__.set(controlsWasOpen, controlsOpen);
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			__vite_ssr_import_2__.get(mounted),
			__vite_ssr_import_2__.deep_read_state(chatId()),
			__vite_ssr_import_2__.get(workspace),
			$showArtifacts(),
			$showEmbeds(),
			$showCallOverlay(),
			__vite_ssr_import_17__.closeWorkspacePanel
		),
		() => {
			if (__vite_ssr_import_2__.get(mounted) && chatId() && __vite_ssr_import_2__.get(workspace)?.open && ($showArtifacts() || $showEmbeds() || $showCallOverlay())) {
				__vite_ssr_import_17__.closeWorkspacePanel(chatId());
				persistOpen(chatId(), false);
			}
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(history())), () => {
		__vite_ssr_import_2__.set(hasMessages, history()?.messages && Object.keys(history().messages).length > 0);
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.get(hasMessages)), () => {
		__vite_ssr_import_2__.set(showOverviewTab, __vite_ssr_import_2__.get(hasMessages));
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.get(showOverviewTab), __vite_ssr_import_2__.get(activeTab)), () => {
		if (!__vite_ssr_import_2__.get(showOverviewTab) && __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'overview')) __vite_ssr_import_2__.set(activeTab, 'controls');
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => ($terminalServers(), $selectedTerminalId()), () => {
		__vite_ssr_import_2__.set(selectedSystemTerminal, ($terminalServers() ?? []).find((t) => t.id && __vite_ssr_import_2__.strict_equals(t.id, $selectedTerminalId())));
	});

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			__vite_ssr_import_2__.get(selectedSystemTerminal),
			__vite_ssr_import_14__.isSavedChatId,
			__vite_ssr_import_2__.deep_read_state(chatId())
		),
		() => {
			__vite_ssr_import_2__.set(selectedSystemTerminalAvailable, __vite_ssr_import_2__.get(selectedSystemTerminal) && chatContextAvailable(__vite_ssr_import_2__.get(selectedSystemTerminal)) && !(chatContextNeedsSavedChat(__vite_ssr_import_2__.get(selectedSystemTerminal)) && !__vite_ssr_import_14__.isSavedChatId(chatId())));
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			$selectedTerminalId(),
			__vite_ssr_import_2__.get(selectedSystemTerminalAvailable),
			__vite_ssr_import_2__.get(selectedSystemTerminal),
			$user()
		),
		() => {
			__vite_ssr_import_2__.set(terminalFilesAvailable, !!($selectedTerminalId() && (__vite_ssr_import_2__.get(selectedSystemTerminalAvailable) || !__vite_ssr_import_2__.get(selectedSystemTerminal) && (__vite_ssr_import_2__.strict_equals($user()?.role, 'admin') || ($user()?.permissions?.features?.direct_tool_servers ?? true)))));
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			__vite_ssr_import_2__.get(terminalFilesAvailable),
			__vite_ssr_import_2__.deep_read_state(codeInterpreterEnabled()),
			$config()
		),
		() => {
			__vite_ssr_import_2__.set(showFilesTab, __vite_ssr_import_2__.get(terminalFilesAvailable) || codeInterpreterEnabled() && __vite_ssr_import_2__.strict_equals($config()?.code?.interpreter_engine, 'jupyter', false));
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.get(showFilesTab), __vite_ssr_import_2__.get(activeTab)), () => {
		if (!__vite_ssr_import_2__.get(showFilesTab) && __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'files')) __vite_ssr_import_2__.set(activeTab, 'controls');
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => ($user()), () => {
		__vite_ssr_import_2__.set(showControlsTab, __vite_ssr_import_2__.strict_equals($user()?.role, 'admin') || ($user()?.permissions?.chat?.controls ?? true));
	});

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			__vite_ssr_import_2__.get(showControlsTab),
			__vite_ssr_import_2__.get(activeTab),
			__vite_ssr_import_2__.get(showFilesTab),
			__vite_ssr_import_2__.get(showOverviewTab)
		),
		() => {
			if (!__vite_ssr_import_2__.get(showControlsTab) && __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'controls')) {
				if (__vite_ssr_import_2__.get(showFilesTab)) __vite_ssr_import_2__.set(activeTab, 'files'); else if (__vite_ssr_import_2__.get(showOverviewTab)) __vite_ssr_import_2__.set(activeTab, 'overview');
			}
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			$showFileNavPath(),
			__vite_ssr_import_2__.get(terminalFilesAvailable),
			__vite_ssr_import_4__.showControls
		),
		() => {
			if ($showFileNavPath() && __vite_ssr_import_2__.get(terminalFilesAvailable)) {
				__vite_ssr_import_2__.set(activeTab, 'files');
				__vite_ssr_import_4__.showControls.set(true);
			}
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(() => ($selectedTerminalId(), __vite_ssr_import_2__.get(terminalFilesAvailable)), () => {
		if ($selectedTerminalId() && __vite_ssr_import_2__.get(terminalFilesAvailable)) {
			__vite_ssr_import_2__.set(activeTab, 'files');
		}
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.get(activeTab)), () => {
		savedTab = __vite_ssr_import_2__.get(activeTab);
	});

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			__vite_ssr_import_2__.get(showControlsTab),
			__vite_ssr_import_2__.get(showFilesTab),
			__vite_ssr_import_2__.get(showOverviewTab),
			__vite_ssr_import_4__.showControls
		),
		() => {
			if (!__vite_ssr_import_2__.get(showControlsTab) && !__vite_ssr_import_2__.get(showFilesTab) && !__vite_ssr_import_2__.get(showOverviewTab)) {
				__vite_ssr_import_4__.showControls.set(false);
			}
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			$selectedTerminalId(),
			$terminalServers(),
			$user(),
			__vite_ssr_import_4__.selectedTerminalId
		),
		() => {
			if ($selectedTerminalId() && __vite_ssr_import_2__.strict_equals($terminalServers(), null, false) && !($terminalServers() ?? []).some((t) => t.id && __vite_ssr_import_2__.strict_equals(t.id, $selectedTerminalId())) && !(__vite_ssr_import_2__.strict_equals($user()?.role, 'admin') || ($user()?.permissions?.features?.direct_tool_servers ?? true))) {
				__vite_ssr_import_4__.selectedTerminalId.set(null);
			}
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.get(mounted), __vite_ssr_import_2__.deep_read_state(chatId())), () => {
		if (__vite_ssr_import_2__.get(mounted) && !chatId()) closeHandler();
	});

	__vite_ssr_import_2__.legacy_pre_effect(
		() => (
			$showCallOverlay(),
			$showArtifacts(),
			$showEmbeds(),
			__vite_ssr_import_2__.get(showWorkspace)
		),
		() => {
			__vite_ssr_import_2__.set(specialPanel, $showCallOverlay() || $showArtifacts() || $showEmbeds() || __vite_ssr_import_2__.get(showWorkspace));
		}
	);

	__vite_ssr_import_2__.legacy_pre_effect_reset();

	var $$exports = { ...__vite_ssr_import_2__.legacy_api() };

	__vite_ssr_import_2__.init();

	var fragment = root_22();
	var node_1 = __vite_ssr_import_2__.first_child(fragment);

	{
		var consequent_2 = ($$anchor) => {
			var div = root_2();
			var button = __vite_ssr_import_2__.child(div);
			var text = __vite_ssr_import_2__.child(button, true);

			__vite_ssr_import_2__.reset(button);

			var node_2 = __vite_ssr_import_2__.sibling(button, 2);

			{
				var consequent = ($$anchor) => {
					var span = root();
					var text_1 = __vite_ssr_import_2__.child(span, true);

					__vite_ssr_import_2__.reset(span);

					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_1, $0), [
						() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Workspace changed')))
					]);

					__vite_ssr_import_2__.append($$anchor, span);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_2, ($$render) => {
						if (__vite_ssr_import_2__.get(workspaceChanged)) $$render(consequent);
					}),
					'if',
					ChatControls,
					312,
					2
				);
			}

			var node_3 = __vite_ssr_import_2__.sibling(node_2, 2);

			{
				var consequent_1 = ($$anchor) => {
					var span_1 = root_1();
					var text_2 = __vite_ssr_import_2__.child(span_1, true);

					__vite_ssr_import_2__.reset(span_1);

					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_2, $0), [
						() => (
							$i18n(),
							__vite_ssr_import_2__.untrack(() => $i18n().t('Waiting for chat to save'))
						)
					]);

					__vite_ssr_import_2__.append($$anchor, span_1);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_3, ($$render) => {
						if (firstSendPending()) $$render(consequent_1);
					}),
					'if',
					ChatControls,
					313,
					2
				);
			}

			__vite_ssr_import_2__.reset(div);

			__vite_ssr_import_2__.template_effect(
				($0, $1, $2) => {
					button.disabled = firstSendPending() || __vite_ssr_import_2__.get(workspaceActionPending);
					__vite_ssr_import_2__.set_attribute(button, 'title', $0);
					__vite_ssr_import_2__.set_attribute(button, 'aria-label', $1);
					__vite_ssr_import_2__.set_text(text, $2);
				},
				[
					() => (
						__vite_ssr_import_2__.deep_read_state(firstSendPending()),
						$i18n(),
						__vite_ssr_import_2__.untrack(() => firstSendPending()
							? $i18n().t('Waiting for chat to save')
							: $i18n().t('Workspace Files'))
					),
					() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Workspace Files'))),
					() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Workspace Files')))
				]
			);

			__vite_ssr_import_2__.event('click', button, openWorkspace);
			__vite_ssr_import_2__.append($$anchor, div);
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node_1, ($$render) => {
				if (__vite_ssr_import_2__.get(workspaceActionAvailable) && (!$showControls() || $showArtifacts() || $showEmbeds() || $showCallOverlay())) $$render(consequent_2);
			}),
			'if',
			ChatControls,
			301,
			0
		);
	}

	var node_4 = __vite_ssr_import_2__.sibling(node_1, 2);

	{
		var consequent_3 = ($$anchor) => {
			var p = root_3();
			var text_3 = __vite_ssr_import_2__.child(p, true);

			__vite_ssr_import_2__.reset(p);
			__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_3, __vite_ssr_import_2__.get(workspaceError)));
			__vite_ssr_import_2__.append($$anchor, p);
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node_4, ($$render) => {
				if (__vite_ssr_import_2__.get(workspaceError)) $$render(consequent_3);
			}),
			'if',
			ChatControls,
			316,
			0
		);
	}

	var node_5 = __vite_ssr_import_2__.sibling(node_4, 2);

	{
		var consequent_18 = ($$anchor) => {
			var fragment_1 = __vite_ssr_import_2__.comment();
			var node_6 = __vite_ssr_import_2__.first_child(fragment_1);

			{
				var consequent_17 = ($$anchor) => {
					__vite_ssr_import_2__.add_svelte_meta(
						() => __vite_ssr_import_7__.default($$anchor, {
							get show() {
								return $showControls();
							},
							onClose: closeWorkspace,
							className: 'min-h-[100dvh] !bg-white dark:!bg-gray-850',
							children: __vite_ssr_import_2__.wrap_snippet(ChatControls, ($$anchor, $$slotProps) => {
								var div_1 = root_12();
								var node_7 = __vite_ssr_import_2__.child(div_1);

								{
									var consequent_4 = ($$anchor) => {
										var div_2 = root_4();
										var node_8 = __vite_ssr_import_2__.child(div_2);

										{
											$$ownership_validator.binding('files', __vite_ssr_import_6__.default, files);

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_6__.default(node_8, {
													get submitPrompt() {
														return submitPrompt();
													},

													get stopResponse() {
														return stopResponse();
													},

													get modelId() {
														return modelId();
													},

													get chatId() {
														return chatId();
													},

													get eventTarget() {
														return eventTarget();
													},

													get files() {
														return files();
													},

													set files($$value) {
														files($$value);
													},
													$$events: { close: () => __vite_ssr_import_4__.showControls.set(false) },
													$$legacy: true
												}),
												'component',
												ChatControls,
												335,
												6,
												{ componentTag: 'CallOverlay' }
											);
										}

										__vite_ssr_import_2__.reset(div_2);
										__vite_ssr_import_2__.append($$anchor, div_2);
									};

									var consequent_5 = ($$anchor) => {
										__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_10__.default($$anchor, {}), 'component', ChatControls, 346, 5, { componentTag: 'Embeds' });
									};

									var consequent_6 = ($$anchor) => {
										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_9__.default($$anchor, {
												get history() {
													return history();
												}
											}),
											'component',
											ChatControls,
											348,
											5,
											{ componentTag: 'Artifacts' }
										);
									};

									var consequent_7 = ($$anchor) => {
										var fragment_5 = __vite_ssr_import_2__.comment();
										var node_9 = __vite_ssr_import_2__.first_child(fragment_5);

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_2__.key(node_9, chatId, ($$anchor) => {
												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_15__.default($$anchor, {
														get chatId() {
															return chatId();
														},

														get enabled() {
															return __vite_ssr_import_2__.get(workspaceAvailable);
														},
														onClose: closeWorkspace
													}),
													'component',
													ChatControls,
													350,
													18,
													{ componentTag: 'WorkspaceArtifact' }
												);
											}),
											'key',
											ChatControls,
											350,
											5
										);

										__vite_ssr_import_2__.append($$anchor, fragment_5);
									};

									var alternate_1 = ($$anchor) => {
										var div_3 = root_11();
										var div_4 = __vite_ssr_import_2__.child(div_3);
										var div_5 = __vite_ssr_import_2__.child(div_4);
										var node_10 = __vite_ssr_import_2__.child(div_5);

										{
											var consequent_8 = ($$anchor) => {
												var button_1 = root_5();
												var text_4 = __vite_ssr_import_2__.child(button_1, true);

												__vite_ssr_import_2__.reset(button_1);

												__vite_ssr_import_2__.template_effect(
													($0) => {
														__vite_ssr_import_2__.set_class(button_1, 1, `px-2.5 py-1 text-sm rounded-lg transition whitespace-nowrap ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'controls')
															? 'bg-gray-100/40 dark:bg-gray-800/25 font-normal text-gray-700 dark:text-gray-200'
															: 'text-gray-500 dark:text-gray-400 hover:bg-gray-100/30 dark:hover:bg-gray-800/20 hover:text-gray-600 dark:hover:text-gray-300'}`);

														__vite_ssr_import_2__.set_text(text_4, $0);
													},
													[() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Controls')))]
												);

												__vite_ssr_import_2__.event('click', button_1, function click() {
													return __vite_ssr_import_2__.set(activeTab, 'controls');
												});

												__vite_ssr_import_2__.append($$anchor, button_1);
											};

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_2__.if(node_10, ($$render) => {
													if (__vite_ssr_import_2__.get(showControlsTab)) $$render(consequent_8);
												}),
												'if',
												ChatControls,
												361,
												8
											);
										}

										var node_11 = __vite_ssr_import_2__.sibling(node_10, 2);

										{
											var consequent_9 = ($$anchor) => {
												var button_2 = root_6();
												var text_5 = __vite_ssr_import_2__.child(button_2, true);

												__vite_ssr_import_2__.reset(button_2);

												__vite_ssr_import_2__.template_effect(
													($0) => {
														__vite_ssr_import_2__.set_class(button_2, 1, `px-2.5 py-1 text-sm rounded-lg transition whitespace-nowrap ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'files')
															? 'bg-gray-100/40 dark:bg-gray-800/25 font-normal text-gray-700 dark:text-gray-200'
															: 'text-gray-500 dark:text-gray-400 hover:bg-gray-100/30 dark:hover:bg-gray-800/20 hover:text-gray-600 dark:hover:text-gray-300'}`);

														__vite_ssr_import_2__.set_text(text_5, $0);
													},
													[() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Files')))]
												);

												__vite_ssr_import_2__.event('click', button_2, function click_1() {
													return __vite_ssr_import_2__.set(activeTab, 'files');
												});

												__vite_ssr_import_2__.append($$anchor, button_2);
											};

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_2__.if(node_11, ($$render) => {
													if (__vite_ssr_import_2__.get(showFilesTab)) $$render(consequent_9);
												}),
												'if',
												ChatControls,
												372,
												8
											);
										}

										var node_12 = __vite_ssr_import_2__.sibling(node_11, 2);

										{
											var consequent_10 = ($$anchor) => {
												var button_3 = root_7();
												var text_6 = __vite_ssr_import_2__.child(button_3, true);

												__vite_ssr_import_2__.reset(button_3);

												__vite_ssr_import_2__.template_effect(
													($0) => {
														__vite_ssr_import_2__.set_class(button_3, 1, `px-2.5 py-1 text-sm rounded-lg transition whitespace-nowrap ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'overview')
															? 'bg-gray-100/40 dark:bg-gray-800/25 font-normal text-gray-700 dark:text-gray-200'
															: 'text-gray-500 dark:text-gray-400 hover:bg-gray-100/30 dark:hover:bg-gray-800/20 hover:text-gray-600 dark:hover:text-gray-300'}`);

														__vite_ssr_import_2__.set_text(text_6, $0);
													},
													[() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Overview')))]
												);

												__vite_ssr_import_2__.event('click', button_3, function click_2() {
													return __vite_ssr_import_2__.set(activeTab, 'overview');
												});

												__vite_ssr_import_2__.append($$anchor, button_3);
											};

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_2__.if(node_12, ($$render) => {
													if (__vite_ssr_import_2__.get(showOverviewTab)) $$render(consequent_10);
												}),
												'if',
												ChatControls,
												383,
												8
											);
										}

										__vite_ssr_import_2__.reset(div_5);

										var node_13 = __vite_ssr_import_2__.sibling(div_5, 2);

										{
											var consequent_13 = ($$anchor) => {
												var fragment_7 = root_10();
												var button_4 = __vite_ssr_import_2__.first_child(fragment_7);
												var text_7 = __vite_ssr_import_2__.child(button_4, true);

												__vite_ssr_import_2__.reset(button_4);

												var node_14 = __vite_ssr_import_2__.sibling(button_4, 2);

												{
													var consequent_11 = ($$anchor) => {
														var span_2 = root_8();
														var text_8 = __vite_ssr_import_2__.child(span_2, true);

														__vite_ssr_import_2__.reset(span_2);

														__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_8, $0), [
															() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Workspace changed')))
														]);

														__vite_ssr_import_2__.append($$anchor, span_2);
													};

													__vite_ssr_import_2__.add_svelte_meta(
														() => __vite_ssr_import_2__.if(node_14, ($$render) => {
															if (__vite_ssr_import_2__.get(workspaceChanged)) $$render(consequent_11);
														}),
														'if',
														ChatControls,
														405,
														8
													);
												}

												var node_15 = __vite_ssr_import_2__.sibling(node_14, 2);

												{
													var consequent_12 = ($$anchor) => {
														var span_3 = root_9();
														var text_9 = __vite_ssr_import_2__.child(span_3, true);

														__vite_ssr_import_2__.reset(span_3);

														__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_9, $0), [
															() => (
																$i18n(),
																__vite_ssr_import_2__.untrack(() => $i18n().t('Waiting for chat to save'))
															)
														]);

														__vite_ssr_import_2__.append($$anchor, span_3);
													};

													__vite_ssr_import_2__.add_svelte_meta(
														() => __vite_ssr_import_2__.if(node_15, ($$render) => {
															if (firstSendPending()) $$render(consequent_12);
														}),
														'if',
														ChatControls,
														406,
														8
													);
												}

												__vite_ssr_import_2__.template_effect(
													($0, $1, $2) => {
														button_4.disabled = firstSendPending() || __vite_ssr_import_2__.get(workspaceActionPending);
														__vite_ssr_import_2__.set_attribute(button_4, 'title', $0);
														__vite_ssr_import_2__.set_attribute(button_4, 'aria-label', $1);
														__vite_ssr_import_2__.set_text(text_7, $2);
													},
													[
														() => (
															__vite_ssr_import_2__.deep_read_state(firstSendPending()),
															$i18n(),
															__vite_ssr_import_2__.untrack(() => firstSendPending()
																? $i18n().t('Waiting for chat to save')
																: $i18n().t('Workspace Files'))
														),
														() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Workspace Files'))),
														() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Workspace Files')))
													]
												);

												__vite_ssr_import_2__.event('click', button_4, openWorkspace);
												__vite_ssr_import_2__.append($$anchor, fragment_7);
											};

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_2__.if(node_13, ($$render) => {
													if (__vite_ssr_import_2__.get(workspaceActionAvailable)) $$render(consequent_13);
												}),
												'if',
												ChatControls,
												395,
												7
											);
										}

										var button_5 = __vite_ssr_import_2__.sibling(node_13, 2);

										__vite_ssr_import_2__.reset(div_4);

										var div_6 = __vite_ssr_import_2__.sibling(div_4, 2);
										var node_16 = __vite_ssr_import_2__.child(div_6);

										{
											var consequent_14 = ($$anchor) => {
												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_13__.default($$anchor, {
														get history() {
															return history();
														},

														get chatUser() {
															return chatUser();
														},

														onNodeClick: (e) => {
															const node = e.node;

															showMessage()(node.data.message, true);
														}
													}),
													'component',
													ChatControls,
													436,
													8,
													{ componentTag: 'Overview' }
												);
											};

											var consequent_15 = ($$anchor) => {
												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_11__.default($$anchor, {
														get chatId() {
															return chatId();
														}
													}),
													'component',
													ChatControls,
													445,
													8,
													{ componentTag: 'FileNav' }
												);
											};

											var consequent_16 = ($$anchor) => {
												__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_12__.default($$anchor, {}), 'component', ChatControls, 447, 8, { componentTag: 'PyodideFileNav' });
											};

											var alternate = ($$anchor) => {
												{
													$$ownership_validator.binding('chatFiles', __vite_ssr_import_5__.default, chatFiles);
													$$ownership_validator.binding('params', __vite_ssr_import_5__.default, params);

													__vite_ssr_import_2__.add_svelte_meta(
														() => __vite_ssr_import_5__.default($$anchor, {
															embed: true,
															get models() {
																return models();
															},

															get chatFiles() {
																return chatFiles();
															},

															set chatFiles($$value) {
																chatFiles($$value);
															},

															get params() {
																return params();
															},

															set params($$value) {
																params($$value);
															},
															$$legacy: true
														}),
														'component',
														ChatControls,
														449,
														8,
														{ componentTag: 'Controls' }
													);
												}
											};

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_2__.if(node_16, ($$render) => {
													if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'overview')) $$render(consequent_14); else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'files') && __vite_ssr_import_2__.get(terminalFilesAvailable) && $selectedTerminalId()) $$render(consequent_15, 1); else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'files') && codeInterpreterEnabled()) $$render(consequent_16, 2); else $$render(alternate, -1);
												}),
												'if',
												ChatControls,
												435,
												7
											);
										}

										__vite_ssr_import_2__.reset(div_6);
										__vite_ssr_import_2__.reset(div_3);

										__vite_ssr_import_2__.template_effect(
											($0) => {
												__vite_ssr_import_2__.set_attribute(button_5, 'aria-label', $0);

												__vite_ssr_import_2__.set_class(div_6, 1, `flex-1 min-h-0 ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'overview')
													? 'h-full'
													: __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'controls') ? 'overflow-y-auto px-3 pt-1' : ''}`);
											},
											[() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Close')))]
										);

										__vite_ssr_import_2__.event('click', button_5, closeWorkspace);
										__vite_ssr_import_2__.append($$anchor, div_3);
									};

									__vite_ssr_import_2__.add_svelte_meta(
										() => __vite_ssr_import_2__.if(node_7, ($$render) => {
											if ($showCallOverlay()) $$render(consequent_4); else if ($showEmbeds()) $$render(consequent_5, 1); else if ($showArtifacts()) $$render(consequent_6, 2); else if (__vite_ssr_import_2__.get(showWorkspace) && __vite_ssr_import_2__.get(workspaceAvailable) && chatId()) $$render(consequent_7, 3); else $$render(alternate_1, -1);
										}),
										'if',
										ChatControls,
										331,
										4
									);
								}

								__vite_ssr_import_2__.reset(div_1);
								__vite_ssr_import_2__.append($$anchor, div_1);
							}),
							$$slots: { default: true }
						}),
						'component',
						ChatControls,
						325,
						2,
						{ componentTag: 'Drawer' }
					);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_6, ($$render) => {
						if ($showControls()) $$render(consequent_17);
					}),
					'if',
					ChatControls,
					324,
					1
				);
			}

			__vite_ssr_import_2__.append($$anchor, fragment_1);
		};

		var alternate_4 = ($$anchor) => {
			__vite_ssr_import_2__.add_svelte_meta(
				() => __vite_ssr_import_8__.default($$anchor, {
					get open() {
						return $showControls();
					},
					minWidth: 350,
					minSiblingWidth: 360,
					closeOnDragBelowMinWidth: true,
					onClose: closeWorkspace,
					storageKey: 'chatControlsSize',
					className: 'h-full z-10 bg-white dark:bg-gray-900',
					get width() {
						return __vite_ssr_import_2__.get(controlsWidth);
					},

					set width($$value) {
						__vite_ssr_import_2__.set(controlsWidth, $$value);
					},

					children: __vite_ssr_import_2__.wrap_snippet(ChatControls, ($$anchor, $$slotProps) => {
						var div_7 = root_21();
						var div_8 = __vite_ssr_import_2__.child(div_7);
						var node_17 = __vite_ssr_import_2__.child(div_8);

						{
							var consequent_19 = ($$anchor) => {
								var div_9 = root_13();
								var node_18 = __vite_ssr_import_2__.child(div_9);

								{
									$$ownership_validator.binding('files', __vite_ssr_import_6__.default, files);

									__vite_ssr_import_2__.add_svelte_meta(
										() => __vite_ssr_import_6__.default(node_18, {
											get submitPrompt() {
												return submitPrompt();
											},

											get stopResponse() {
												return stopResponse();
											},

											get modelId() {
												return modelId();
											},

											get chatId() {
												return chatId();
											},

											get eventTarget() {
												return eventTarget();
											},

											get files() {
												return files();
											},

											set files($$value) {
												files($$value);
											},
											$$events: { close: () => __vite_ssr_import_4__.showControls.set(false) },
											$$legacy: true
										}),
										'component',
										ChatControls,
										479,
										6,
										{ componentTag: 'CallOverlay' }
									);
								}

								__vite_ssr_import_2__.reset(div_9);
								__vite_ssr_import_2__.append($$anchor, div_9);
							};

							var consequent_20 = ($$anchor) => {
								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_10__.default($$anchor, {
										get overlay() {
											return __vite_ssr_import_2__.get(dragged);
										}
									}),
									'component',
									ChatControls,
									490,
									5,
									{ componentTag: 'Embeds' }
								);
							};

							var consequent_21 = ($$anchor) => {
								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_9__.default($$anchor, {
										get history() {
											return history();
										},

										get overlay() {
											return __vite_ssr_import_2__.get(dragged);
										}
									}),
									'component',
									ChatControls,
									492,
									5,
									{ componentTag: 'Artifacts' }
								);
							};

							var consequent_22 = ($$anchor) => {
								var fragment_15 = __vite_ssr_import_2__.comment();
								var node_19 = __vite_ssr_import_2__.first_child(fragment_15);

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_2__.key(node_19, chatId, ($$anchor) => {
										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_15__.default($$anchor, {
												get chatId() {
													return chatId();
												},

												get enabled() {
													return __vite_ssr_import_2__.get(workspaceAvailable);
												},
												onClose: closeWorkspace
											}),
											'component',
											ChatControls,
											494,
											18,
											{ componentTag: 'WorkspaceArtifact' }
										);
									}),
									'key',
									ChatControls,
									494,
									5
								);

								__vite_ssr_import_2__.append($$anchor, fragment_15);
							};

							var alternate_3 = ($$anchor) => {
								var div_10 = root_20();
								var div_11 = __vite_ssr_import_2__.child(div_10);
								var div_12 = __vite_ssr_import_2__.child(div_11);
								var node_20 = __vite_ssr_import_2__.child(div_12);

								{
									var consequent_23 = ($$anchor) => {
										var button_6 = root_14();
										var text_10 = __vite_ssr_import_2__.child(button_6, true);

										__vite_ssr_import_2__.reset(button_6);

										__vite_ssr_import_2__.template_effect(
											($0) => {
												__vite_ssr_import_2__.set_class(button_6, 1, `px-2.5 py-1 text-sm rounded-lg transition whitespace-nowrap ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'controls')
													? 'bg-gray-100/40 dark:bg-gray-800/25 font-normal text-gray-700 dark:text-gray-200'
													: 'text-gray-500 dark:text-gray-400 hover:bg-gray-100/30 dark:hover:bg-gray-800/20 hover:text-gray-600 dark:hover:text-gray-300'}`);

												__vite_ssr_import_2__.set_text(text_10, $0);
											},
											[() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Controls')))]
										);

										__vite_ssr_import_2__.event('click', button_6, function click_3() {
											return __vite_ssr_import_2__.set(activeTab, 'controls');
										});

										__vite_ssr_import_2__.append($$anchor, button_6);
									};

									__vite_ssr_import_2__.add_svelte_meta(
										() => __vite_ssr_import_2__.if(node_20, ($$render) => {
											if (__vite_ssr_import_2__.get(showControlsTab)) $$render(consequent_23);
										}),
										'if',
										ChatControls,
										505,
										8
									);
								}

								var node_21 = __vite_ssr_import_2__.sibling(node_20, 2);

								{
									var consequent_24 = ($$anchor) => {
										var button_7 = root_15();
										var text_11 = __vite_ssr_import_2__.child(button_7, true);

										__vite_ssr_import_2__.reset(button_7);

										__vite_ssr_import_2__.template_effect(
											($0) => {
												__vite_ssr_import_2__.set_class(button_7, 1, `px-2.5 py-1 text-sm rounded-lg transition whitespace-nowrap ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'files')
													? 'bg-gray-100/40 dark:bg-gray-800/25 font-normal text-gray-700 dark:text-gray-200'
													: 'text-gray-500 dark:text-gray-400 hover:bg-gray-100/30 dark:hover:bg-gray-800/20 hover:text-gray-600 dark:hover:text-gray-300'}`);

												__vite_ssr_import_2__.set_text(text_11, $0);
											},
											[() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Files')))]
										);

										__vite_ssr_import_2__.event('click', button_7, function click_4() {
											return __vite_ssr_import_2__.set(activeTab, 'files');
										});

										__vite_ssr_import_2__.append($$anchor, button_7);
									};

									__vite_ssr_import_2__.add_svelte_meta(
										() => __vite_ssr_import_2__.if(node_21, ($$render) => {
											if (__vite_ssr_import_2__.get(showFilesTab)) $$render(consequent_24);
										}),
										'if',
										ChatControls,
										516,
										8
									);
								}

								var node_22 = __vite_ssr_import_2__.sibling(node_21, 2);

								{
									var consequent_25 = ($$anchor) => {
										var button_8 = root_16();
										var text_12 = __vite_ssr_import_2__.child(button_8, true);

										__vite_ssr_import_2__.reset(button_8);

										__vite_ssr_import_2__.template_effect(
											($0) => {
												__vite_ssr_import_2__.set_class(button_8, 1, `px-2.5 py-1 text-sm rounded-lg transition whitespace-nowrap ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'overview')
													? 'bg-gray-100/40 dark:bg-gray-800/25 font-normal text-gray-700 dark:text-gray-200'
													: 'text-gray-500 dark:text-gray-400 hover:bg-gray-100/30 dark:hover:bg-gray-800/20 hover:text-gray-600 dark:hover:text-gray-300'}`);

												__vite_ssr_import_2__.set_text(text_12, $0);
											},
											[() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Overview')))]
										);

										__vite_ssr_import_2__.event('click', button_8, function click_5() {
											return __vite_ssr_import_2__.set(activeTab, 'overview');
										});

										__vite_ssr_import_2__.append($$anchor, button_8);
									};

									__vite_ssr_import_2__.add_svelte_meta(
										() => __vite_ssr_import_2__.if(node_22, ($$render) => {
											if (__vite_ssr_import_2__.get(showOverviewTab)) $$render(consequent_25);
										}),
										'if',
										ChatControls,
										527,
										8
									);
								}

								__vite_ssr_import_2__.reset(div_12);

								var node_23 = __vite_ssr_import_2__.sibling(div_12, 2);

								{
									var consequent_28 = ($$anchor) => {
										var fragment_17 = root_19();
										var button_9 = __vite_ssr_import_2__.first_child(fragment_17);
										var text_13 = __vite_ssr_import_2__.child(button_9, true);

										__vite_ssr_import_2__.reset(button_9);

										var node_24 = __vite_ssr_import_2__.sibling(button_9, 2);

										{
											var consequent_26 = ($$anchor) => {
												var span_4 = root_17();
												var text_14 = __vite_ssr_import_2__.child(span_4, true);

												__vite_ssr_import_2__.reset(span_4);

												__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_14, $0), [
													() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Workspace changed')))
												]);

												__vite_ssr_import_2__.append($$anchor, span_4);
											};

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_2__.if(node_24, ($$render) => {
													if (__vite_ssr_import_2__.get(workspaceChanged)) $$render(consequent_26);
												}),
												'if',
												ChatControls,
												549,
												8
											);
										}

										var node_25 = __vite_ssr_import_2__.sibling(node_24, 2);

										{
											var consequent_27 = ($$anchor) => {
												var span_5 = root_18();
												var text_15 = __vite_ssr_import_2__.child(span_5, true);

												__vite_ssr_import_2__.reset(span_5);

												__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_15, $0), [
													() => (
														$i18n(),
														__vite_ssr_import_2__.untrack(() => $i18n().t('Waiting for chat to save'))
													)
												]);

												__vite_ssr_import_2__.append($$anchor, span_5);
											};

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_2__.if(node_25, ($$render) => {
													if (firstSendPending()) $$render(consequent_27);
												}),
												'if',
												ChatControls,
												550,
												8
											);
										}

										__vite_ssr_import_2__.template_effect(
											($0, $1, $2) => {
												button_9.disabled = firstSendPending() || __vite_ssr_import_2__.get(workspaceActionPending);
												__vite_ssr_import_2__.set_attribute(button_9, 'title', $0);
												__vite_ssr_import_2__.set_attribute(button_9, 'aria-label', $1);
												__vite_ssr_import_2__.set_text(text_13, $2);
											},
											[
												() => (
													__vite_ssr_import_2__.deep_read_state(firstSendPending()),
													$i18n(),
													__vite_ssr_import_2__.untrack(() => firstSendPending()
														? $i18n().t('Waiting for chat to save')
														: $i18n().t('Workspace Files'))
												),
												() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Workspace Files'))),
												() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Workspace Files')))
											]
										);

										__vite_ssr_import_2__.event('click', button_9, openWorkspace);
										__vite_ssr_import_2__.append($$anchor, fragment_17);
									};

									__vite_ssr_import_2__.add_svelte_meta(
										() => __vite_ssr_import_2__.if(node_23, ($$render) => {
											if (__vite_ssr_import_2__.get(workspaceActionAvailable)) $$render(consequent_28);
										}),
										'if',
										ChatControls,
										539,
										7
									);
								}

								var button_10 = __vite_ssr_import_2__.sibling(node_23, 2);

								__vite_ssr_import_2__.reset(div_11);

								var div_13 = __vite_ssr_import_2__.sibling(div_11, 2);
								var node_26 = __vite_ssr_import_2__.child(div_13);

								{
									var consequent_29 = ($$anchor) => {
										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_13__.default($$anchor, {
												get history() {
													return history();
												},

												get chatUser() {
													return chatUser();
												},

												onNodeClick: (e) => {
													const node = e.node;

													if (node?.data?.message?.favorite) {
														history(history().messages[node.data.message.id].favorite = true, true);
													} else {
														history(history().messages[node.data.message.id].favorite = null, true);
													}

													showMessage()(node.data.message, true);
												}
											}),
											'component',
											ChatControls,
											580,
											8,
											{ componentTag: 'Overview' }
										);
									};

									var consequent_30 = ($$anchor) => {
										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_11__.default($$anchor, {
												get overlay() {
													return __vite_ssr_import_2__.get(dragged);
												},

												get chatId() {
													return chatId();
												}
											}),
											'component',
											ChatControls,
											594,
											8,
											{ componentTag: 'FileNav' }
										);
									};

									var consequent_31 = ($$anchor) => {
										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_12__.default($$anchor, {
												get overlay() {
													return __vite_ssr_import_2__.get(dragged);
												}
											}),
											'component',
											ChatControls,
											596,
											8,
											{ componentTag: 'PyodideFileNav' }
										);
									};

									var alternate_2 = ($$anchor) => {
										{
											$$ownership_validator.binding('chatFiles', __vite_ssr_import_5__.default, chatFiles);
											$$ownership_validator.binding('params', __vite_ssr_import_5__.default, params);

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_5__.default($$anchor, {
													embed: true,
													get models() {
														return models();
													},

													get chatFiles() {
														return chatFiles();
													},

													set chatFiles($$value) {
														chatFiles($$value);
													},

													get params() {
														return params();
													},

													set params($$value) {
														params($$value);
													},
													$$legacy: true
												}),
												'component',
												ChatControls,
												598,
												8,
												{ componentTag: 'Controls' }
											);
										}
									};

									__vite_ssr_import_2__.add_svelte_meta(
										() => __vite_ssr_import_2__.if(node_26, ($$render) => {
											if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'overview')) $$render(consequent_29); else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'files') && __vite_ssr_import_2__.get(terminalFilesAvailable) && $selectedTerminalId()) $$render(consequent_30, 1); else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'files') && codeInterpreterEnabled()) $$render(consequent_31, 2); else $$render(alternate_2, -1);
										}),
										'if',
										ChatControls,
										579,
										7
									);
								}

								__vite_ssr_import_2__.reset(div_13);
								__vite_ssr_import_2__.reset(div_10);

								__vite_ssr_import_2__.template_effect(
									($0) => {
										__vite_ssr_import_2__.set_attribute(button_10, 'aria-label', $0);

										__vite_ssr_import_2__.set_class(div_13, 1, `flex-1 min-h-0 ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'overview')
											? 'h-full'
											: __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'controls') ? 'overflow-y-auto px-3 pt-1' : ''}`);
									},
									[() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Close')))]
								);

								__vite_ssr_import_2__.event('click', button_10, closeWorkspace);
								__vite_ssr_import_2__.append($$anchor, div_10);
							};

							__vite_ssr_import_2__.add_svelte_meta(
								() => __vite_ssr_import_2__.if(node_17, ($$render) => {
									if ($showCallOverlay()) $$render(consequent_19); else if ($showEmbeds()) $$render(consequent_20, 1); else if ($showArtifacts()) $$render(consequent_21, 2); else if (__vite_ssr_import_2__.get(showWorkspace) && __vite_ssr_import_2__.get(workspaceAvailable) && chatId()) $$render(consequent_22, 3); else $$render(alternate_3, -1);
								}),
								'if',
								ChatControls,
								477,
								4
							);
						}

						__vite_ssr_import_2__.reset(div_8);
						__vite_ssr_import_2__.reset(div_7);
						__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_class(div_8, 1, `w-full ${__vite_ssr_import_2__.get(specialPanel) && !$showCallOverlay() ? ' ' : 'bg-white dark:bg-gray-900'} z-40 pointer-events-auto ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(activeTab), 'files') ? '' : 'overflow-y-auto'} scrollbar-hidden`));
						__vite_ssr_import_2__.append($$anchor, div_7);
					}),
					$$slots: { default: true },
					$$legacy: true
				}),
				'component',
				ChatControls,
				458,
				1,
				{ componentTag: 'ResizableSidePanel' }
			);
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node_5, ($$render) => {
				if (!__vite_ssr_import_2__.get(largeScreen)) $$render(consequent_18); else $$render(alternate_4, -1);
			}),
			'if',
			ChatControls,
			323,
			0
		);
	}

	__vite_ssr_import_2__.append($$anchor, fragment);

	var $$pop = __vite_ssr_import_2__.pop($$exports);

	$$cleanup();

	return $$pop;
}
Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: ChatControls });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUttRDs7QUFlOUI7O0FBRTZCO0FBQ1U7QUFDZjtBQUN3QjtBQUMxQjtBQUNPO0FBQ1g7QUFDYztBQUNaO0FBQ1M7QUFDUztBQUNMO0FBQ21DO0FBSXJEOztBQXJDbkMsSUFBSSxRQUEyQyxHQUFHLFVBQVU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lDQUc3RCxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW9DQSxNQUFNLElBQXdCLEdBQUcsZ0NBQVUsQ0FBQyxNQUFNO0NBQ2xELE1BQU0sbUJBQTRDLEdBQUcsZ0NBQVUsQ0FBQywrQ0FBd0I7Q0FFakYsSUFBSSxPQUFPO0NBQ1gsSUFBSSxNQUFNO0NBRVYsSUFBSSxNQUFxQixvREFBRyxJQUFJO0NBQ2hDLElBQUksUUFBUSxzREFBRyxJQUFJO0NBRW5CLElBQUksU0FBUztDQUNiLElBQUksTUFBTTtDQUVWLElBQUksV0FBd0I7Q0FDNUIsSUFBSSxZQUFzQjtDQUMxQixJQUFJLFlBQXNCO0NBQzFCLElBQUksV0FBcUI7Q0FDekIsSUFBSSxlQUE2QztDQUNqRCxJQUFJLGdCQUFnQiw4REFBRyxLQUFLO0NBQzVCLElBQUksS0FBSztDQUNULElBQUksT0FBTztDQUVYLElBQUksc0JBQXNCLG9FQUFHLEtBQUs7Q0FFekMsSUFBSSxXQUFXLGtFQUFHLEtBQUs7Q0FDdkIsSUFBSSxPQUFPLGtFQUFHLEtBQUs7Q0FDbkIsSUFBSSxPQUFPLGtFQUFHLEtBQUs7Q0FDbkIsSUFBSSxhQUFhLGtFQUFHLEdBQUc7Q0FFdkIsSUFBSSxzQkFBc0Isa0VBQUcsS0FBSztDQUNsQyxJQUFJLGNBQWMsa0VBQUcsRUFBRTtDQUN2QixJQUFJLGVBQWUsa0VBQUcsS0FBSztDQUMzQixJQUFJLFdBQVcsa0VBQUcsQ0FBQztDQUNuQixJQUFJLFlBQVksa0VBQUcsTUFBTTtDQUN6QixJQUFJLGFBQWEsa0VBQUcsT0FBTzs7O0NBb0QzQixJQUFJLFNBQVMsa0VBQUcsUUFBUTs7O0NBU3hCLE1BQU0sV0FBVyxJQUFJLFFBQWEsS0FBSyxRQUFRLEVBQUUsUUFBUSxFQUFFLElBQUk7O0NBQy9ELE1BQU0sb0JBQW9CLElBQUksUUFBYSx5Q0FBSyxXQUFXLENBQUMsUUFBUSxHQUFNLEtBQUs7Q0FDL0UsTUFBTSx5QkFBeUIsSUFBSSxRQUFhLHlDQUMvQyxXQUFXLENBQUMsUUFBUSxHQUFHLFVBQVUsRUFBSyxTQUFTOzs7Ozs7O0NBcURoRCxNQUFNLGdCQUFnQixHQUFHLEtBQUssRUFBRSxDQUFDLEtBQUs7RUFDckMsRUFBRSxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUU7NkJBQ2QsV0FBVyxFQUFHLElBQUk7O0dBQ2xCLEVBQUUsRUFBRSxnQkFBZ0IsSUFBRTtJQUNyQixxQ0FBZSxDQUFDLEdBQUcsQ0FBQyxLQUFLO3VEQUNuQiwwQkFBSTtJQUNWLHFDQUFlLENBQUMsR0FBRyxDQUFDLElBQUk7R0FDekI7RUFDRCxDQUFDLENBQUMsSUFBSSxDQUFDOzZCQUNOLFdBQVcsRUFBRyxLQUFLOztHQUNuQixFQUFFLEVBQUUsZ0JBQWdCLElBQUU7SUFDckIscUNBQWUsQ0FBQyxHQUFHLENBQUMsS0FBSzt1REFDbkIsMEJBQUk7SUFDVixxQ0FBZSxDQUFDLEdBQUcsQ0FBQyxJQUFJO0dBQ3pCO0VBQ0Q7Q0FDRCxDQUFDOztDQUVELE1BQU0sV0FBVyxTQUFTOzRCQUN6QixPQUFPLEVBQUcsSUFBSTtDQUNmLENBQUM7O0NBQ0QsTUFBTSxTQUFTLFNBQVM7NEJBQ3ZCLE9BQU8sRUFBRyxLQUFLO0NBQ2hCLENBQUM7O0NBRUQsNkJBQU8sT0FBTztFQUNiLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMscUJBQXFCOztFQUMxRCxVQUFVLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLGdCQUFnQjtFQUN0RCxnQkFBZ0IsQ0FBQyxVQUFVOztFQUUzQixJQUFJLFdBQVcsR0FBRyxLQUFLOztFQUV2QixNQUFNLElBQUksR0FBRyxLQUFLLE9BQU87c0RBQ2xCLDBCQUFJOztHQUVWLEVBQUUsRUFBRSxXQUFXLEVBQUUsTUFBTTs7R0FFdkIsVUFBVTtVQUFPOytCQUNoQixPQUFPLEVBQUcsSUFBSTtJQUNmLENBQUM7SUFBRSxDQUFDOztFQUNMLENBQUM7O0VBQ0QsSUFBSTtFQUVKLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsV0FBVztFQUNsRCxRQUFRLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLFNBQVM7O0VBRTlDLE1BQU0sT0FBTztHQUNaLFdBQVcsR0FBRyxJQUFJOzZCQUNsQixPQUFPLEVBQUcsS0FBSzs7R0FDZixFQUFFLDZCQUFHLFdBQVcsR0FBRTtJQUNqQixrQ0FBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0dBQ3ZCOztHQUNBLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsZ0JBQWdCO0dBQ3pELFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxXQUFXLEVBQUUsV0FBVztHQUNyRCxRQUFRLENBQUMsbUJBQW1CLENBQUMsU0FBUyxFQUFFLFNBQVM7RUFDbEQsQ0FBQztDQUNGLENBQUM7O0NBRUQsTUFBTSxXQUFXLElBQUksRUFBVSxFQUFFLElBQWEsS0FBSztPQUM3QyxtQkFBbUIsQ0FBQyxVQUFVLENBQUMsRUFBRSxJQUFJLElBQUksSUFBSSxLQUFLLE9BQU87R0FDN0QsRUFBRSxzQ0FBRSxNQUFNLElBQUssRUFBRSw2QkFBRSxjQUFjLEVBQUcsS0FBSyxHQUFDLENBQUMsQ0FBQyx5Q0FBeUM7RUFDdEYsQ0FBQztDQUNGLENBQUM7O0NBRUQsTUFBTSxhQUFhLEdBQUcsS0FBSyxPQUFPO0VBQ2pDLEVBQUUsNkJBQUcsd0JBQXdCLEtBQUksZ0JBQWdCLGdDQUFJLHNCQUFzQixHQUFFLE1BQU07O0VBQ25GLE1BQU0sUUFBUSxHQUFHLE1BQU07RUFDdkIsTUFBTSxhQUFhLEdBQUcsT0FBTztFQUM3QixNQUFNLEtBQUssNkJBQUcsV0FBVzs7NEJBQ3pCLHNCQUFzQixFQUFHLElBQUk7NEJBQzdCLGNBQWMsRUFBRyxFQUFFOztFQUNuQixNQUFNLE9BQU8sc0RBQVMsZUFBZTs7RUFDckMsRUFBRSxnRUFBRSxXQUFXLEdBQUssS0FBSyw2QkFBRSxzQkFBc0IsRUFBRyxLQUFLOztFQUN6RCxFQUFFLEdBQUcsT0FBTyxFQUFFO0dBQ2IsRUFBRSxzQ0FBRSxNQUFNLElBQUssUUFBUSx5Q0FBSSxPQUFPLElBQUssYUFBYSxNQUFLLHFCQUFxQiw4QkFDN0UsY0FBYyxFQUFHLEtBQUssR0FBQyxDQUFDLENBQUMsbUNBQW1DOztHQUM3RCxNQUFNO0VBQ1A7O0VBQ0EsRUFBRSw2QkFBRyx3QkFBd0IseUNBQUksT0FBTyxJQUFLLGFBQWEsWUFBSyxNQUFNLDBDQUFJLE1BQU0sSUFBSyxPQUFPLFVBQzFGLE1BQU07O0VBQ1AsbUNBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSztFQUN2QixnQ0FBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0VBQ3BCLHFDQUFlLENBQUMsR0FBRyxDQUFDLEtBQUs7RUFDekIsa0NBQVksQ0FBQyxHQUFHLENBQUMsSUFBSTtFQUNyQix5Q0FBa0IsQ0FBQyxPQUFPO0VBQzFCLFdBQVcsQ0FBQyxPQUFPLEVBQUUsSUFBSTtDQUMxQixDQUFDOztDQUVELE1BQU0sWUFBWSxTQUFTO0VBQzFCLEVBQUUsNEJBQUUsYUFBYSxLQUFJLE1BQU0sSUFBRTtHQUM1QiwwQ0FBbUIsQ0FBQyxNQUFNO0dBQzFCLFdBQVcsQ0FBQyxNQUFNLElBQUUsS0FBSztFQUMxQjs7RUFDQSxFQUFFLDZCQUFHLFdBQVcsR0FBRSxrQ0FBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLOztFQUN4QyxtQ0FBYSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0VBQ3ZCLGdDQUFVLENBQUMsR0FBRyxDQUFDLEtBQUs7O0VBQ3BCLEVBQUUsRUFBRSxnQkFBZ0IsSUFBRSxxQ0FBZSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0NBQ2hELENBQUM7O0NBRUQsTUFBTSxjQUFjLFNBQVM7RUFDNUIsRUFBRSw0QkFBRSxhQUFhLEdBQUUsWUFBWTs7RUFDL0Isa0NBQVksQ0FBQyxHQUFHLENBQUMsS0FBSztDQUN2QixDQUFDOzs7Ozs7Ozs7OztHQTFORSxFQUFFLGdFQUFFLFlBQVksR0FBSyxNQUFNLDRFQUFJLGFBQWEsR0FBSyxPQUFPLFlBQUU7OEJBQzVELFlBQVksRUFBRyxNQUFNOzhCQUNyQixhQUFhLEVBQUcsT0FBTztpQ0FDdkIsV0FBVzs4QkFDWCxzQkFBc0IsRUFBRyxLQUFLOzhCQUM5QixjQUFjLEVBQUcsRUFBRTtHQUNwQjs7Ozs7Ozs7Ozs7Ozs2QkFDRyx3QkFBd0IsRUFDMUIsNENBQXFCLENBQUMsT0FBTyxRQUM1QixxQkFBcUIsUUFDcEIsTUFBTSxNQUFLLG9DQUFhLENBQUMsTUFBTSwyQ0FBSyxNQUFNLElBQUssU0FBUzs7Ozs7Ozs7Ozs7NkJBQ3hELGtCQUFrQiw0QkFBRyx3QkFBd0IsS0FBSSxvQ0FBYSxDQUFDLE1BQU07Ozs7OzRCQUNyRSxTQUFTLEVBQUcsTUFBTSxLQUFHLGNBQWMsR0FBQyxNQUFNLE1BQUksU0FBUzs7Ozs7Ozs7Ozs7Ozs2QkFDdkQsYUFBYSw0QkFDZixrQkFBa0IsK0JBQ2xCLFNBQVMsR0FBRSxJQUFJLElBQ2YsYUFBYSxPQUNaLGNBQWMsT0FDZCxXQUFXLE9BQ1gsZ0JBQWdCOzs7Ozs0QkFDZixnQkFBZ0IsOEJBQ2hCLFNBQVMsZ0NBQUssU0FBUyxFQUFDLElBQUksOEJBQUksU0FBUyxFQUFDLFFBQVEsNkJBQUcsU0FBUyxFQUFDLG9CQUFvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBRXJGLE1BQU0sWUFBWSxHQUFHLGFBQWE7O0dBQ2xDLEVBQUUsNEJBQUUsT0FBTyxLQUFJLE1BQU0sZ0NBQUksU0FBUyxHQUFFLElBQUksRUFBRTtJQUN6QyxFQUFFLDRCQUFFLGVBQWUsTUFBSyxZQUFZLEVBQUU7S0FDckMsMENBQW1CLENBQUMsTUFBTTtLQUMxQixXQUFXLENBQUMsTUFBTSxJQUFFLEtBQUs7SUFDMUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLDZCQUNQLGVBQWUsTUFDZixZQUFZLDhCQUNiLGtCQUFrQixNQUNqQixjQUFjLE9BQ2QsV0FBVyxPQUNYLGdCQUFDLElBQ0Q7S0FDRCxrQ0FBWSxDQUFDLEdBQUcsQ0FBQyxJQUFJO0lBQ3RCO0dBQ0Q7OzZCQUNBLGVBQWUsRUFBRyxZQUFZOzs7Ozs7Ozs7Ozs7Ozs7R0FFNUIsRUFBRSw0QkFDSixPQUFPLEtBQ1AsTUFBTSxnQ0FDTixTQUFTLEdBQUUsSUFBSSxLQUNkLGNBQWMsTUFBSSxXQUFXLE1BQUksZ0JBQWdCLEtBQ2pEO0lBQ0QsMENBQW1CLENBQUMsTUFBTTtJQUMxQixXQUFXLENBQUMsTUFBTSxJQUFFLEtBQUs7R0FDMUI7Ozs7OzRCQVFHLFdBQVcsRUFBRyxPQUFPLElBQUUsUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFDLFFBQVEsRUFBRSxNQUFNLEdBQUcsQ0FBQzs7Ozs0QkF1QjNFLGVBQWUsNEJBQUcsV0FBVzs7OztFQUc3QixFQUFFLDZCQUFHLGVBQWUsbUVBQUksU0FBUyxHQUFLLFVBQVUsNkJBQUUsU0FBUyxFQUFHLFVBQVU7Ozs7NEJBbkJ4RSxzQkFBc0IsR0FBSSxnQkFBZ0IsVUFBUSxJQUFJLEVBQ3ZELENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSx3Q0FBSSxDQUFDLENBQUMsRUFBRSxFQUFLLG1CQUFDOzs7Ozs7Ozs7OzZCQUV2QiwrQkFBK0IsNEJBQ2pDLHNCQUFzQixLQUN0QixvQkFBb0IsMkJBQUMsc0JBQXNCLFFBQ3pDLHlCQUF5QiwyQkFBQyxzQkFBc0IsT0FBTSxvQ0FBYSxDQUFDLE1BQU07Ozs7Ozs7Ozs7Ozs2QkFDMUUsc0JBQXNCLEtBQ3hCLG1CQUFtQixpQ0FDbEIsK0JBQStCLGdDQUM3QixzQkFBc0IsMENBQ3RCLEtBQUssSUFBRSxJQUFJLEVBQUssT0FBTyxNQUFLLEtBQUssSUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLG1CQUFtQixJQUFJLElBQUk7Ozs7Ozs7Ozs7OzZCQUV0RixZQUFZLDRCQUNkLHNCQUFzQixLQUNyQixzQkFBc0IsMENBQUksT0FBTyxJQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBSyxTQUFTOzs7OztFQUt4RSxFQUFFLDZCQUFHLFlBQVksbUVBQUksU0FBUyxHQUFLLE9BQU8sNkJBQUUsU0FBUyxFQUFHLFVBQVU7Ozs7NEJBekJsRSxlQUFlLHNDQUFHLEtBQUssSUFBRSxJQUFJLEVBQUssT0FBTyxNQUFLLEtBQUssSUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLFFBQVEsSUFBSSxJQUFJOzs7Ozs7Ozs7OztHQTBCeEYsRUFBRSw2QkFBRyxlQUFlLG1FQUFJLFNBQVMsR0FBSyxVQUFVLEdBQUU7SUFDcEQsRUFBRSw0QkFBRSxZQUFZLDZCQUFFLFNBQVMsRUFBRyxPQUFPLFFBQ2hDLEVBQUUsNEJBQUUsZUFBZSw2QkFBRSxTQUFTLEVBQUcsVUFBVTtHQUNqRDs7Ozs7Ozs7Ozs7R0FRRyxFQUFFLEVBQUUsZ0JBQWdCLGdDQUFJLHNCQUFzQixHQUFFOzhCQUNsRCxTQUFTLEVBQUcsT0FBTztJQUNuQixrQ0FBWSxDQUFDLEdBQUcsQ0FBQyxJQUFJO0dBQ3RCOzs7OztFQUdHLEVBQUUsRUFBRSxtQkFBbUIsZ0NBQUksc0JBQXNCLEdBQUU7NkJBQ3JELFNBQVMsRUFBRyxPQUFPO0VBQ3BCOzs7O0VBbERDLFFBQVEsNkJBQUcsU0FBUzs7Ozs7Ozs7Ozs7R0FxQ2xCLEVBQUUsNkJBQUcsZUFBZSxnQ0FBSyxZQUFZLGdDQUFLLGVBQWUsR0FBRTtJQUM3RCxrQ0FBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLO0dBQ3ZCOzs7Ozs7Ozs7Ozs7R0FjRyxFQUFFLEVBQ0osbUJBQW1CLDBDQUNuQixnQkFBZ0IsSUFBSyxJQUFJLGNBQ3ZCLGdCQUFnQixVQUFRLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsd0NBQUksQ0FBQyxDQUFDLEVBQUUsRUFBSyxtQkFBbUIsOENBQ3hFLEtBQUssSUFBRSxJQUFJLEVBQUssT0FBTyxNQUFLLEtBQUssSUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLG1CQUFtQixJQUFJLElBQUksSUFDdEY7SUFDRCx3Q0FBa0IsQ0FBQyxHQUFHLENBQUMsSUFBSTtHQUM1Qjs7Ozs7RUEwR0csRUFBRSw0QkFBRSxPQUFPLE1BQUssTUFBTSxJQUFFLFlBQVk7Ozs7Ozs7Ozs7OzZCQUdwQyxZQUFZLEVBQUcsZ0JBQWdCLE1BQUksY0FBYyxNQUFJLFdBQVcsZ0NBQUksYUFBYTs7Ozs7Ozs7Ozs7Ozs7O09BSW5GO09BR0MscUNBSEQ7MENBR0M7OytCQUFBOzs4Q0FBQTs7OztTQU9zQixJQUFJOzhDQUFKLElBQUk7O2lDQUFKLElBQUk7OzswREFBZ0IsS0FBSyxHQUFDLENBQUMsQ0FBQyxtQkFBbUI7Ozs0Q0FBL0MsSUFBSTs7Ozs7b0NBQXRCLGdCQUFnQjs7Ozs7Ozs7Ozs7OztTQUNFLE1BQUk7OENBQUosTUFBSTs7aUNBQUosTUFBSTs7Ozs7MkNBQWdCLEtBQUssR0FBQyxDQUFDLENBQUMsMEJBQTBCOzs7OzRDQUF0RCxNQUFJOzs7OztVQUF0QixnQkFBZ0I7Ozs7Ozs7OzsrQkFYckI7Ozs7S0FHQyxrQkFHVSxnQkFBZ0IsZ0NBQUksc0JBQXNCO3lDQUhwRDt5Q0FBQTs7Ozs7NENBdlBTLGdCQUFnQjs7MENBMlBsQixnQkFBZ0I7U0FBRyxLQUFLLEdBQUMsQ0FBQyxDQUFDLDBCQUEwQjtTQUFJLEtBQUssR0FBQyxDQUFDLENBQUMsaUJBQWlCOzt5REFDN0UsS0FBSyxHQUFDLENBQUMsQ0FBQyxpQkFBaUI7eURBQUksS0FBSyxHQUFDLENBQUMsQ0FBQyxpQkFBaUI7Ozs7d0NBTGxFLFFBRVUsYUFBYTswQ0FMeEI7Ozs7O2tDQURHLHdCQUF3QixPQUFNLGFBQWEsTUFBSSxjQUFjLE1BQUksV0FBVyxNQUFJLGdCQUFnQjs7Ozs7Ozs7Ozs7OztPQWVoRjs0Q0FBQTs7K0JBQUE7Z0hBSWxCLGNBQWM7MENBSkk7Ozs7O2tDQUFoQixjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O1lBU2hCOztlQUNNLGFBQWE7O2dCQUNWLGNBQWM7OztZQUd0QixLQUFHO2lEQUFILEtBQUc7Ozs7Y0FFRDttREFBQTs7Ozs7O2tCQUdDOztxQkFFQyxZQUFZOzs7O3FCQUNaLFlBQVk7Ozs7cUJBQ1osT0FBTzs7OztxQkFDUCxNQUFNOzs7O3FCQUNOLFdBQVc7OztpQkFMWixLQUFLOzs7O2lCQUFMLEtBQUs7OztzQ0FNVyxrQ0FBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLOzs7Ozs7Ozs7OztzQ0FWdkM7aURBQUE7Ozs7c0RBY0EsOEJBQU07Ozs7O2lCQUVOLDZCQUFTOztvQkFBRSxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7O21EQUViLE1BQU07O21CQUFFOztzQkFDWCxNQUFNOzs7O2dEQUNFLGtCQUFrQjs7dUJBQ2xCLGNBQWM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Y0FJeEIsS0FBRztjQUVGLEtBQUcsK0JBRkosS0FBRztjQUdELEtBQUcsK0JBREosS0FBRztvREFDRixLQUFHOzs7O2dCQUVEO3FEQUFBOzt3Q0FBQTs7Ozs4Q0FBQSwwSUFDb0UsU0FBUyxHQUM3RSxVQUFTO2lCQUNOLGlGQUFnRjtpQkFDaEYsOEhBQThIOzs7O2tFQUdoSSxLQUFLLEdBQUMsQ0FBQyxDQUFDLFVBQVU7OztpREFQbkI7OENBS2lCLFNBQVMsRUFBRyxVQUFVOzs7bURBTHZDOzs7OzsyQ0FERyxlQUFlOzs7Ozs7Ozs7Ozs7O2dCQVlsQjtxREFBQTs7d0NBQUE7Ozs7OENBQUEsMElBQ29FLFNBQVMsR0FDN0UsT0FBTTtpQkFDSCxpRkFBZ0Y7aUJBQ2hGLDhIQUE4SDs7OztrRUFHaEksS0FBSyxHQUFDLENBQUMsQ0FBQyxPQUFPOzs7aURBUGhCOzhDQUtpQixTQUFTLEVBQUcsT0FBTzs7O21EQUxwQzs7Ozs7MkNBREcsWUFBWTs7Ozs7Ozs7Ozs7OztnQkFZZjtxREFBQTs7d0NBQUE7Ozs7OENBQUEsMElBQ29FLFNBQVMsR0FDN0UsVUFBUztpQkFDTixpRkFBZ0Y7aUJBQ2hGLDhIQUE4SDs7OztrRUFHaEksS0FBSyxHQUFDLENBQUMsQ0FBQyxVQUFVOzs7aURBUG5COzhDQUtpQixTQUFTLEVBQUcsVUFBVTs7O21EQUx2Qzs7Ozs7MkNBREcsZUFBZTs7Ozs7Ozs7O3NDQXZCcEIsS0FBRzs7c0RBQUgsS0FBRzs7Ozs7Z0JBb0NGO3FEQUFBOzt3Q0FBQTs7d0RBQUE7Ozs7a0JBU3NCLE1BQUk7dURBQUosTUFBSTs7MENBQUosTUFBSTs7O21FQUFnQixLQUFLLEdBQUMsQ0FBQyxDQUFDLG1CQUFtQjs7O3FEQUEvQyxNQUFJOzs7Ozs2Q0FBdEIsZ0JBQWdCOzs7Ozs7Ozs7Ozs7O2tCQUNFLE1BQUk7dURBQUosTUFBSTs7MENBQUosTUFBSTs7Ozs7b0RBQ3ZCLEtBQUssR0FBQyxDQUFDLENBQUMsMEJBQTBCOzs7O3FEQURmLE1BQUk7Ozs7O21CQUF0QixnQkFBZ0I7Ozs7Ozs7Ozs7O2NBVnBCLG9CQUdVLGdCQUFnQixnQ0FBSSxzQkFBc0I7a0RBSHBEO2tEQUFBOzs7OztxREFsVkcsZ0JBQWdCOzttREFzVlo7a0JBQ0osS0FBSyxHQUFDLENBQUMsQ0FBQywwQkFBMEI7a0JBQ2xDLEtBQUssR0FBQyxDQUFDLENBQUMsaUJBQWlCOztrRUFDaEIsS0FBSyxHQUFDLENBQUMsQ0FBQyxpQkFBaUI7a0VBQUksS0FBSyxHQUFDLENBQUMsQ0FBQyxpQkFBaUI7Ozs7aURBUGxFLFVBRVUsYUFBYTs7Ozs7OzJDQUhwQix3QkFBd0I7Ozs7Ozs7OztjQWU1Qjs7c0NBbkRELEtBQUc7O2NBcUVILHNDQXJFQSxLQUFHO29EQXFFSDs7Ozs7bUJBUUU7O3NCQUNDLE9BQU87Ozs7c0JBQ1AsUUFBUTs7OzRCQUNLLENBQUMsS0FBSztlQUNuQixNQUFNLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSTs7ZUFDbkIsV0FBVyxHQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUk7Y0FDcEMsQ0FBQzs7Ozs7Ozs7Ozs7O21CQUdELDhCQUFPOztzQkFBRSxNQUFNOzs7Ozs7Ozs7Ozs7d0RBRWYsOEJBQWM7Ozs7Ozs7OztvQkFFZCw2QkFBUTtzQkFBUSxJQUFJOzt1QkFBRyxNQUFNOzs7bUJBQUUsU0FBYzs7OzttQkFBZCxTQUFjOzs7O21CQUFDLE1BQVc7Ozs7bUJBQVgsTUFBVzs7Ozs7Ozs7Ozs7Ozs7OzsrRUFkdEQsU0FBUyxHQUFLLFVBQVUsbUdBU25CLFNBQVMsR0FBSyxPQUFPLCtCQUFJLHNCQUFzQixLQUFJLG1CQUFtQix1R0FFdEUsU0FBUyxHQUFLLE9BQU8sS0FBSSxzQkFBc0I7Ozs7Ozs7OztzQ0FsQnpEO3NDQXZFRCxLQUFHOzs7O2dEQXFERDs7NENBa0JELDBGQUN1QixTQUFTLEdBQUssVUFBUztlQUMzQyxRQUFPOzZFQUNQLFNBQVMsR0FBSyxVQUFTLElBQ3RCLDJCQUEwQixHQUMxQixFQUFFOztnRUFwQk8sS0FBSyxHQUFDLENBQUMsQ0FBQyxPQUFPOzs7K0NBSDNCLFVBRVUsY0FBYztpREF2RDFCLEtBQUc7Ozs7O2VBMUJBLGdCQUFnQixxQ0FjWCxXQUFXLHdDQUVYLGNBQWMsa0VBRWQsYUFBYSwrQkFBSSxrQkFBa0IsS0FBSSxNQUFNOzs7Ozs7Ozs7b0NBbkJ2RCxLQUFHOytDQUFILEtBQUc7Ozs7Ozs7Ozs7Ozs7O1VBTkQsYUFBYTs7Ozs7Ozs7Ozs7Ozs7VUFzSWpCOzthQUNNLGFBQWE7O2VBRVQsR0FBRztzQkFDSSxHQUFHOztjQUVYLGNBQWM7OztTQUp2QixLQUFVO3VDQUFFLGFBQWE7OztTQUF6QixLQUFVO2dDQUFFLGFBQWE7Ozs7VUFReEIsS0FBRztVQUNGLG9DQURELEtBQUc7Z0RBQ0Y7Ozs7WUFTRSxLQUFHO2tEQUFILEtBQUc7Ozs7OztnQkFDRjs7bUJBRUMsWUFBWTs7OzttQkFDWixZQUFZOzs7O21CQUNaLE9BQU87Ozs7bUJBQ1AsTUFBTTs7OzttQkFDTixXQUFXOzs7ZUFMWixLQUFLOzs7O2VBQUwsS0FBSzs7O29DQU1XLGtDQUFZLENBQUMsR0FBRyxDQUFDLEtBQUs7Ozs7Ozs7Ozs7O29DQVJ2QyxLQUFHOytDQUFILEtBQUc7Ozs7O2VBWUgsOEJBQU07OzRDQUFVLE9BQU87Ozs7Ozs7Ozs7Ozs7ZUFFdkIsNkJBQVM7O2tCQUFFLE9BQU87Ozs7NENBQVcsT0FBTzs7Ozs7Ozs7Ozs7Ozs7OztrREFFL0IsTUFBTTs7aUJBQUU7O29CQUNYLE1BQU07Ozs7OENBQ0Usa0JBQWtCOztxQkFDbEIsY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQUl4QixNQUFHO1lBRUYsTUFBRywrQkFGSixNQUFHO1lBR0QsTUFBRywrQkFESixNQUFHO2tEQUNGLE1BQUc7Ozs7Y0FFRDtvREFBQTs7c0NBQUE7Ozs7NENBQUEsMElBQ29FLFNBQVMsR0FDN0UsVUFBUztlQUNOLGlGQUFnRjtlQUNoRiw4SEFBOEg7Ozs7Z0VBR2hJLEtBQUssR0FBQyxDQUFDLENBQUMsVUFBVTs7OytDQVBuQjs0Q0FLaUIsU0FBUyxFQUFHLFVBQVU7OztpREFMdkM7Ozs7O3lDQURHLGVBQWU7Ozs7Ozs7Ozs7Ozs7Y0FZbEI7b0RBQUE7O3NDQUFBOzs7OzRDQUFBLDBJQUNvRSxTQUFTLEdBQzdFLE9BQU07ZUFDSCxpRkFBZ0Y7ZUFDaEYsOEhBQThIOzs7O2dFQUdoSSxLQUFLLEdBQUMsQ0FBQyxDQUFDLE9BQU87OzsrQ0FQaEI7NENBS2lCLFNBQVMsRUFBRyxPQUFPOzs7aURBTHBDOzs7Ozt5Q0FERyxZQUFZOzs7Ozs7Ozs7Ozs7O2NBWWY7b0RBQUE7O3NDQUFBOzs7OzRDQUFBLDBJQUNvRSxTQUFTLEdBQzdFLFVBQVM7ZUFDTixpRkFBZ0Y7ZUFDaEYsOEhBQThIOzs7O2dFQUdoSSxLQUFLLEdBQUMsQ0FBQyxDQUFDLFVBQVU7OzsrQ0FQbkI7NENBS2lCLFNBQVMsRUFBRyxVQUFVOzs7aURBTHZDOzs7Ozt5Q0FERyxlQUFlOzs7Ozs7Ozs7b0NBdkJwQixNQUFHOztvREFBSCxNQUFHOzs7OztjQW9DRjtvREFBQTs7c0NBQUE7O3NEQUFBOzs7O2dCQVNzQixNQUFJO3NEQUFKLE1BQUk7O3dDQUFKLE1BQUk7OztpRUFBZ0IsS0FBSyxHQUFDLENBQUMsQ0FBQyxtQkFBbUI7OzttREFBL0MsTUFBSTs7Ozs7MkNBQXRCLGdCQUFnQjs7Ozs7Ozs7Ozs7OztnQkFDRSxNQUFJO3NEQUFKLE1BQUk7O3dDQUFKLE1BQUk7Ozs7O2tEQUN2QixLQUFLLEdBQUMsQ0FBQyxDQUFDLDBCQUEwQjs7OzttREFEZixNQUFJOzs7OztpQkFBdEIsZ0JBQWdCOzs7Ozs7Ozs7OztZQVZwQixvQkFHVSxnQkFBZ0IsZ0NBQUksc0JBQXNCO2dEQUhwRDtnREFBQTs7Ozs7bURBbGVHLGdCQUFnQjs7aURBc2VaO2dCQUNKLEtBQUssR0FBQyxDQUFDLENBQUMsMEJBQTBCO2dCQUNsQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLGlCQUFpQjs7Z0VBQ2hCLEtBQUssR0FBQyxDQUFDLENBQUMsaUJBQWlCO2dFQUFJLEtBQUssR0FBQyxDQUFDLENBQUMsaUJBQWlCOzs7OytDQVBsRSxVQUVVLGFBQWE7Ozs7Ozt5Q0FIcEIsd0JBQXdCOzs7Ozs7Ozs7WUFlNUI7O29DQW5ERCxNQUFHOztZQXFFSCx1Q0FyRUEsTUFBRztrREFxRUg7Ozs7O2lCQVFFOztvQkFDQyxPQUFPOzs7O29CQUNQLFFBQVE7OzswQkFDSyxDQUFDLEtBQUs7YUFDbkIsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUk7O2FBQ25CLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUU7Y0FDbEMsT0FBTyxDQUFQLE9BQU8sR0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLFFBQVEsR0FBRyxJQUFJO2FBQ3ZELENBQUMsQ0FBQyxJQUFJLENBQUM7Y0FDTixPQUFPLENBQVAsT0FBTyxHQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsUUFBUSxHQUFHLElBQUk7YUFDdkQ7O2FBQ0EsV0FBVyxHQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUk7WUFDcEMsQ0FBQzs7Ozs7Ozs7Ozs7O2lCQUdELDhCQUFPOzs4Q0FBVSxPQUFPOzs7O29CQUFHLE1BQU07Ozs7Ozs7Ozs7Ozs7aUJBRWpDLDhCQUFjOzs4Q0FBVSxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7OztrQkFFL0IsNkJBQVE7b0JBQVEsSUFBSTs7cUJBQUcsTUFBTTs7O2lCQUFFLFNBQWM7Ozs7aUJBQWQsU0FBYzs7OztpQkFBQyxNQUFXOzs7O2lCQUFYLE1BQVc7Ozs7Ozs7Ozs7Ozs7Ozs7NkVBbkJ0RCxTQUFTLEdBQUssVUFBVSxtR0FjbkIsU0FBUyxHQUFLLE9BQU8sK0JBQUksc0JBQXNCLEtBQUksbUJBQW1CLHVHQUV0RSxTQUFTLEdBQUssT0FBTyxLQUFJLHNCQUFzQjs7Ozs7Ozs7O29DQXZCekQ7b0NBdkVELE1BQUc7Ozs7OENBcUREOzswQ0FrQkQsMkZBQ3VCLFNBQVMsR0FBSyxVQUFTO2FBQzNDLFFBQU87MkVBQ1AsU0FBUyxHQUFLLFVBQVMsSUFDdEIsMkJBQTBCLEdBQzFCLEVBQUU7OzhEQXBCTyxLQUFLLEdBQUMsQ0FBQyxDQUFDLE9BQU87Ozs2Q0FIM0IsV0FFVSxjQUFjOytDQXZEMUIsTUFBRzs7Ozs7YUF4QkEsZ0JBQWdCLHNDQVlYLFdBQVcseUNBRVgsY0FBYyxtRUFFZCxhQUFhLCtCQUFJLGtCQUFrQixLQUFJLE1BQU07Ozs7Ozs7OztrQ0F4QnZEO2tDQURELEtBQUc7a0ZBQ0YsOENBQ2UsWUFBWSxNQUFLLGdCQUFDLEtBQzlCLEdBQUUsR0FDRiwyQkFBMkIsMkZBQTRCLFNBQVMsR0FBSyxPQUFNLElBQzNFLEVBQUMsR0FDRCxpQkFBaUI7NkNBTnJCLEtBQUc7Ozs7Ozs7Ozs7Ozs7OzttQ0FqSkEsV0FBVzs7Ozs7Ozs7Ozs7Ozs7OztBQXhCVCIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2hhdENvbnRyb2xzLnN2ZWx0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IGNvbnRleHQ9XCJtb2R1bGVcIiBsYW5nPVwidHNcIj5cblx0bGV0IHNhdmVkVGFiOiAnY29udHJvbHMnIHwgJ2ZpbGVzJyB8ICdvdmVydmlldycgPSAnY29udHJvbHMnO1xuPC9zY3JpcHQ+XG5cbjxzY3JpcHQgbGFuZz1cInRzXCI+XG5cdGltcG9ydCB7IG9uTW91bnQsIHRpY2ssIGdldENvbnRleHQgfSBmcm9tICdzdmVsdGUnO1xuXHRpbXBvcnQgdHlwZSB7IFdyaXRhYmxlIH0gZnJvbSAnc3ZlbHRlL3N0b3JlJztcblx0aW1wb3J0IHR5cGUgeyBpMThuIGFzIGkxOG5UeXBlIH0gZnJvbSAnaTE4bmV4dCc7XG5cdGltcG9ydCB7XG5cdFx0Y29uZmlnLFxuXHRcdHRlcm1pbmFsU2VydmVycyxcblx0XHRzaG93Q29udHJvbHMsXG5cdFx0c2hvd0NhbGxPdmVybGF5LFxuXHRcdHRlbXBvcmFyeUNoYXRFbmFibGVkLFxuXHRcdHNob3dBcnRpZmFjdHMsXG5cdFx0c2hvd0VtYmVkcyxcblx0XHRzZXR0aW5ncyxcblx0XHRzaG93RmlsZU5hdlBhdGgsXG5cdFx0c2VsZWN0ZWRUZXJtaW5hbElkLFxuXHRcdHVzZXJcblx0fSBmcm9tICckbGliL3N0b3Jlcyc7XG5cblx0aW1wb3J0IENvbnRyb2xzIGZyb20gJy4vQ29udHJvbHMvQ29udHJvbHMuc3ZlbHRlJztcblx0aW1wb3J0IENhbGxPdmVybGF5IGZyb20gJy4vTWVzc2FnZUlucHV0L0NhbGxPdmVybGF5LnN2ZWx0ZSc7XG5cdGltcG9ydCBEcmF3ZXIgZnJvbSAnLi4vY29tbW9uL0RyYXdlci5zdmVsdGUnO1xuXHRpbXBvcnQgUmVzaXphYmxlU2lkZVBhbmVsIGZyb20gJy4uL2NvbW1vbi9SZXNpemFibGVTaWRlUGFuZWwuc3ZlbHRlJztcblx0aW1wb3J0IEFydGlmYWN0cyBmcm9tICcuL0FydGlmYWN0cy5zdmVsdGUnO1xuXHRpbXBvcnQgRW1iZWRzIGZyb20gJy4vQ2hhdENvbnRyb2xzL0VtYmVkcy5zdmVsdGUnO1xuXHRpbXBvcnQgRmlsZU5hdiBmcm9tICcuL0ZpbGVOYXYuc3ZlbHRlJztcblx0aW1wb3J0IFB5b2RpZGVGaWxlTmF2IGZyb20gJy4vUHlvZGlkZUZpbGVOYXYuc3ZlbHRlJztcblx0aW1wb3J0IE92ZXJ2aWV3IGZyb20gJy4vT3ZlcnZpZXcuc3ZlbHRlJztcblx0aW1wb3J0IHsgaXNTYXZlZENoYXRJZCB9IGZyb20gJyRsaWIvdXRpbHMvY2hhdElkJztcblx0aW1wb3J0IFdvcmtzcGFjZUFydGlmYWN0IGZyb20gJy4vV29ya3NwYWNlQXJ0aWZhY3Quc3ZlbHRlJztcblx0aW1wb3J0IHsgd29ya3NwYWNlRmlsZXNFbmFibGVkIH0gZnJvbSAnJGxpYi9hcGlzL29jdSc7XG5cdGltcG9ydCB7IGNsb3NlV29ya3NwYWNlUGFuZWwsIG9jdVdvcmtzcGFjZXMsIG9wZW5Xb3Jrc3BhY2VQYW5lbCB9IGZyb20gJyRsaWIvc3RvcmVzL29jdSc7XG5cdGltcG9ydCB7XG5cdFx0V09SS1NQQUNFX1JFQ09OQ0lMSUFUSU9OLFxuXHRcdHR5cGUgV29ya3NwYWNlUmVjb25jaWxpYXRpb25cblx0fSBmcm9tICcuL3dvcmtzcGFjZS1yZWNvbmNpbGlhdGlvbic7XG5cblx0Y29uc3QgaTE4bjogV3JpdGFibGU8aTE4blR5cGU+ID0gZ2V0Q29udGV4dCgnaTE4bicpO1xuXHRjb25zdCB3b3Jrc3BhY2VDb250cm9sbGVyOiBXb3Jrc3BhY2VSZWNvbmNpbGlhdGlvbiA9IGdldENvbnRleHQoV09SS1NQQUNFX1JFQ09OQ0lMSUFUSU9OKTtcblxuXHRleHBvcnQgbGV0IGhpc3Rvcnk7XG5cdGV4cG9ydCBsZXQgbW9kZWxzID0gW107XG5cblx0ZXhwb3J0IGxldCBjaGF0SWQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuXHRleHBvcnQgbGV0IGNoYXRVc2VyID0gbnVsbDtcblxuXHRleHBvcnQgbGV0IGNoYXRGaWxlcyA9IFtdO1xuXHRleHBvcnQgbGV0IHBhcmFtcyA9IHt9O1xuXG5cdGV4cG9ydCBsZXQgZXZlbnRUYXJnZXQ6IEV2ZW50VGFyZ2V0O1xuXHRleHBvcnQgbGV0IHN1Ym1pdFByb21wdDogRnVuY3Rpb247XG5cdGV4cG9ydCBsZXQgc3RvcFJlc3BvbnNlOiBGdW5jdGlvbjtcblx0ZXhwb3J0IGxldCBzaG93TWVzc2FnZTogRnVuY3Rpb247XG5cdGV4cG9ydCBsZXQgZW5zdXJlU2F2ZWRDaGF0OiAoKSA9PiBQcm9taXNlPHN0cmluZyB8IG51bGw+O1xuXHRleHBvcnQgbGV0IGZpcnN0U2VuZFBlbmRpbmcgPSBmYWxzZTtcblx0ZXhwb3J0IGxldCBmaWxlcztcblx0ZXhwb3J0IGxldCBtb2RlbElkO1xuXG5cdGV4cG9ydCBsZXQgY29kZUludGVycHJldGVyRW5hYmxlZCA9IGZhbHNlO1xuXG5cdGxldCBsYXJnZVNjcmVlbiA9IGZhbHNlO1xuXHRsZXQgZHJhZ2dlZCA9IGZhbHNlO1xuXHRsZXQgbW91bnRlZCA9IGZhbHNlO1xuXHRsZXQgY29udHJvbHNXaWR0aCA9IDM1MDtcblxuXHRsZXQgd29ya3NwYWNlQWN0aW9uUGVuZGluZyA9IGZhbHNlO1xuXHRsZXQgd29ya3NwYWNlRXJyb3IgPSAnJztcblx0bGV0IGNvbnRyb2xzV2FzT3BlbiA9IGZhbHNlO1xuXHRsZXQgYWN0aW9uRXBvY2ggPSAwO1xuXHRsZXQgYWN0aW9uQ2hhdElkID0gY2hhdElkO1xuXHRsZXQgYWN0aW9uSGlzdG9yeSA9IGhpc3Rvcnk7XG5cdCQ6IGlmIChhY3Rpb25DaGF0SWQgIT09IGNoYXRJZCB8fCBhY3Rpb25IaXN0b3J5ICE9PSBoaXN0b3J5KSB7XG5cdFx0YWN0aW9uQ2hhdElkID0gY2hhdElkO1xuXHRcdGFjdGlvbkhpc3RvcnkgPSBoaXN0b3J5O1xuXHRcdGFjdGlvbkVwb2NoKys7XG5cdFx0d29ya3NwYWNlQWN0aW9uUGVuZGluZyA9IGZhbHNlO1xuXHRcdHdvcmtzcGFjZUVycm9yID0gJyc7XG5cdH1cblx0JDogd29ya3NwYWNlQWN0aW9uQXZhaWxhYmxlID1cblx0XHR3b3Jrc3BhY2VGaWxlc0VuYWJsZWQoJGNvbmZpZykgJiZcblx0XHQhJHRlbXBvcmFyeUNoYXRFbmFibGVkICYmXG5cdFx0KCFjaGF0SWQgfHwgKGlzU2F2ZWRDaGF0SWQoY2hhdElkKSAmJiBjaGF0SWQgIT09ICdkZWZhdWx0JykpO1xuXHQkOiB3b3Jrc3BhY2VBdmFpbGFibGUgPSB3b3Jrc3BhY2VBY3Rpb25BdmFpbGFibGUgJiYgaXNTYXZlZENoYXRJZChjaGF0SWQpO1xuXHQkOiB3b3Jrc3BhY2UgPSBjaGF0SWQgPyAkb2N1V29ya3NwYWNlc1tjaGF0SWRdIDogdW5kZWZpbmVkO1xuXHQkOiBzaG93V29ya3NwYWNlID1cblx0XHR3b3Jrc3BhY2VBdmFpbGFibGUgJiZcblx0XHR3b3Jrc3BhY2U/Lm9wZW4gJiZcblx0XHQkc2hvd0NvbnRyb2xzICYmXG5cdFx0ISRzaG93QXJ0aWZhY3RzICYmXG5cdFx0ISRzaG93RW1iZWRzICYmXG5cdFx0ISRzaG93Q2FsbE92ZXJsYXk7XG5cdCQ6IHdvcmtzcGFjZUNoYW5nZWQgPVxuXHRcdCEhd29ya3NwYWNlICYmICF3b3Jrc3BhY2Uub3BlbiAmJiB3b3Jrc3BhY2UucmV2aXNpb24gPiB3b3Jrc3BhY2UuYWNrbm93bGVkZ2VkUmV2aXNpb247XG5cdCQ6IHtcblx0XHRjb25zdCBjb250cm9sc09wZW4gPSAkc2hvd0NvbnRyb2xzO1xuXHRcdGlmIChtb3VudGVkICYmIGNoYXRJZCAmJiB3b3Jrc3BhY2U/Lm9wZW4pIHtcblx0XHRcdGlmIChjb250cm9sc1dhc09wZW4gJiYgIWNvbnRyb2xzT3Blbikge1xuXHRcdFx0XHRjbG9zZVdvcmtzcGFjZVBhbmVsKGNoYXRJZCk7XG5cdFx0XHRcdHBlcnNpc3RPcGVuKGNoYXRJZCwgZmFsc2UpO1xuXHRcdFx0fSBlbHNlIGlmIChcblx0XHRcdFx0IWNvbnRyb2xzV2FzT3BlbiAmJlxuXHRcdFx0XHQhY29udHJvbHNPcGVuICYmXG5cdFx0XHRcdHdvcmtzcGFjZUF2YWlsYWJsZSAmJlxuXHRcdFx0XHQhJHNob3dBcnRpZmFjdHMgJiZcblx0XHRcdFx0ISRzaG93RW1iZWRzICYmXG5cdFx0XHRcdCEkc2hvd0NhbGxPdmVybGF5XG5cdFx0XHQpIHtcblx0XHRcdFx0c2hvd0NvbnRyb2xzLnNldCh0cnVlKTtcblx0XHRcdH1cblx0XHR9XG5cdFx0Y29udHJvbHNXYXNPcGVuID0gY29udHJvbHNPcGVuO1xuXHR9XG5cdCQ6IGlmIChcblx0XHRtb3VudGVkICYmXG5cdFx0Y2hhdElkICYmXG5cdFx0d29ya3NwYWNlPy5vcGVuICYmXG5cdFx0KCRzaG93QXJ0aWZhY3RzIHx8ICRzaG93RW1iZWRzIHx8ICRzaG93Q2FsbE92ZXJsYXkpXG5cdCkge1xuXHRcdGNsb3NlV29ya3NwYWNlUGFuZWwoY2hhdElkKTtcblx0XHRwZXJzaXN0T3BlbihjaGF0SWQsIGZhbHNlKTtcblx0fVxuXHQvLyBUYWIgc3RhdGUgZm9yIENvbnRyb2xzK0ZpbGVzIHBhbmVsXG5cdGxldCBhY3RpdmVUYWIgPSBzYXZlZFRhYjtcblx0Ly8gc3ZlbHRlLWlnbm9yZSByZWFjdGl2ZV9kZWNsYXJhdGlvbl9tb2R1bGVfc2NyaXB0X2RlcGVuZGVuY3lcblx0JDoge1xuXHRcdHNhdmVkVGFiID0gYWN0aXZlVGFiO1xuXHR9XG5cblx0JDogaGFzTWVzc2FnZXMgPSBoaXN0b3J5Py5tZXNzYWdlcyAmJiBPYmplY3Qua2V5cyhoaXN0b3J5Lm1lc3NhZ2VzKS5sZW5ndGggPiAwO1xuXG5cdCQ6IHNob3dDb250cm9sc1RhYiA9ICR1c2VyPy5yb2xlID09PSAnYWRtaW4nIHx8ICgkdXNlcj8ucGVybWlzc2lvbnM/LmNoYXQ/LmNvbnRyb2xzID8/IHRydWUpO1xuXHRjb25zdCBjaGF0Q29udGV4dCA9ICh0ZXJtaW5hbDogYW55KSA9PiB0ZXJtaW5hbD8uY29udGV4dHM/LmNoYXQgPz8ge307XG5cdGNvbnN0IGNoYXRDb250ZXh0QXZhaWxhYmxlID0gKHRlcm1pbmFsOiBhbnkpID0+IGNoYXRDb250ZXh0KHRlcm1pbmFsKSAhPT0gZmFsc2U7XG5cdGNvbnN0IGNoYXRDb250ZXh0TmVlZHNTYXZlZENoYXQgPSAodGVybWluYWw6IGFueSkgPT5cblx0XHRjaGF0Q29udGV4dCh0ZXJtaW5hbCk/LmNvbnRleHRfaWQgPT09ICdjaGF0X2lkJztcblx0JDogc2VsZWN0ZWRTeXN0ZW1UZXJtaW5hbCA9ICgkdGVybWluYWxTZXJ2ZXJzID8/IFtdKS5maW5kKFxuXHRcdCh0KSA9PiB0LmlkICYmIHQuaWQgPT09ICRzZWxlY3RlZFRlcm1pbmFsSWRcblx0KTtcblx0JDogc2VsZWN0ZWRTeXN0ZW1UZXJtaW5hbEF2YWlsYWJsZSA9XG5cdFx0c2VsZWN0ZWRTeXN0ZW1UZXJtaW5hbCAmJlxuXHRcdGNoYXRDb250ZXh0QXZhaWxhYmxlKHNlbGVjdGVkU3lzdGVtVGVybWluYWwpICYmXG5cdFx0IShjaGF0Q29udGV4dE5lZWRzU2F2ZWRDaGF0KHNlbGVjdGVkU3lzdGVtVGVybWluYWwpICYmICFpc1NhdmVkQ2hhdElkKGNoYXRJZCkpO1xuXHQkOiB0ZXJtaW5hbEZpbGVzQXZhaWxhYmxlID0gISEoXG5cdFx0JHNlbGVjdGVkVGVybWluYWxJZCAmJlxuXHRcdChzZWxlY3RlZFN5c3RlbVRlcm1pbmFsQXZhaWxhYmxlIHx8XG5cdFx0XHQoIXNlbGVjdGVkU3lzdGVtVGVybWluYWwgJiZcblx0XHRcdFx0KCR1c2VyPy5yb2xlID09PSAnYWRtaW4nIHx8ICgkdXNlcj8ucGVybWlzc2lvbnM/LmZlYXR1cmVzPy5kaXJlY3RfdG9vbF9zZXJ2ZXJzID8/IHRydWUpKSkpXG5cdCk7XG5cdCQ6IHNob3dGaWxlc1RhYiA9XG5cdFx0dGVybWluYWxGaWxlc0F2YWlsYWJsZSB8fFxuXHRcdChjb2RlSW50ZXJwcmV0ZXJFbmFibGVkICYmICRjb25maWc/LmNvZGU/LmludGVycHJldGVyX2VuZ2luZSAhPT0gJ2p1cHl0ZXInKTtcblx0JDogc2hvd092ZXJ2aWV3VGFiID0gaGFzTWVzc2FnZXM7XG5cblx0Ly8gVGFiIGZhbGxiYWNrOiBpZiBhY3RpdmUgdGFiIGJlY29tZXMgaGlkZGVuLCBzd2l0Y2ggdG8gbmV4dCBhdmFpbGFibGVcblx0JDogaWYgKCFzaG93T3ZlcnZpZXdUYWIgJiYgYWN0aXZlVGFiID09PSAnb3ZlcnZpZXcnKSBhY3RpdmVUYWIgPSAnY29udHJvbHMnO1xuXHQkOiBpZiAoIXNob3dGaWxlc1RhYiAmJiBhY3RpdmVUYWIgPT09ICdmaWxlcycpIGFjdGl2ZVRhYiA9ICdjb250cm9scyc7XG5cdCQ6IGlmICghc2hvd0NvbnRyb2xzVGFiICYmIGFjdGl2ZVRhYiA9PT0gJ2NvbnRyb2xzJykge1xuXHRcdGlmIChzaG93RmlsZXNUYWIpIGFjdGl2ZVRhYiA9ICdmaWxlcyc7XG5cdFx0ZWxzZSBpZiAoc2hvd092ZXJ2aWV3VGFiKSBhY3RpdmVUYWIgPSAnb3ZlcnZpZXcnO1xuXHR9XG5cblx0Ly8gQXV0by1jbG9zZSBpZiB0aGVyZSBhcmUgbm8gdmlzaWJsZSB0YWJzXG5cdCQ6IGlmICghc2hvd0NvbnRyb2xzVGFiICYmICFzaG93RmlsZXNUYWIgJiYgIXNob3dPdmVydmlld1RhYikge1xuXHRcdHNob3dDb250cm9scy5zZXQoZmFsc2UpO1xuXHR9XG5cblx0Ly8gQXV0by1zd2l0Y2ggdG8gRmlsZXMgdGFiIHdoZW4gZGlzcGxheV9maWxlIGlzIHRyaWdnZXJlZFxuXHQkOiBpZiAoJHNob3dGaWxlTmF2UGF0aCAmJiB0ZXJtaW5hbEZpbGVzQXZhaWxhYmxlKSB7XG5cdFx0YWN0aXZlVGFiID0gJ2ZpbGVzJztcblx0XHRzaG93Q29udHJvbHMuc2V0KHRydWUpO1xuXHR9XG5cblx0Ly8gS2VlcCBGaWxlcyBzZWxlY3RlZCB3aGVuIGEgdGVybWluYWwgaXMgYWN0aXZlOyBvcGVuaW5nIHRoZSBwYW5lbCBpcyBoYW5kbGVkIGJ5IHNlbGVjdGlvbiBVSS5cblx0JDogaWYgKCRzZWxlY3RlZFRlcm1pbmFsSWQgJiYgdGVybWluYWxGaWxlc0F2YWlsYWJsZSkge1xuXHRcdGFjdGl2ZVRhYiA9ICdmaWxlcyc7XG5cdH1cblxuXHQvLyBDbGVhciBzZWxlY3RlZCBkaXJlY3QgdGVybWluYWwgaWYgdXNlciBsb3N0IHBlcm1pc3Npb25cblx0JDogaWYgKFxuXHRcdCRzZWxlY3RlZFRlcm1pbmFsSWQgJiZcblx0XHQkdGVybWluYWxTZXJ2ZXJzICE9PSBudWxsICYmXG5cdFx0ISgkdGVybWluYWxTZXJ2ZXJzID8/IFtdKS5zb21lKCh0KSA9PiB0LmlkICYmIHQuaWQgPT09ICRzZWxlY3RlZFRlcm1pbmFsSWQpICYmXG5cdFx0ISgkdXNlcj8ucm9sZSA9PT0gJ2FkbWluJyB8fCAoJHVzZXI/LnBlcm1pc3Npb25zPy5mZWF0dXJlcz8uZGlyZWN0X3Rvb2xfc2VydmVycyA/PyB0cnVlKSlcblx0KSB7XG5cdFx0c2VsZWN0ZWRUZXJtaW5hbElkLnNldChudWxsKTtcblx0fVxuXG5cdGNvbnN0IGhhbmRsZU1lZGlhUXVlcnkgPSBhc3luYyAoZSkgPT4ge1xuXHRcdGlmIChlLm1hdGNoZXMpIHtcblx0XHRcdGxhcmdlU2NyZWVuID0gdHJ1ZTtcblx0XHRcdGlmICgkc2hvd0NhbGxPdmVybGF5KSB7XG5cdFx0XHRcdHNob3dDYWxsT3ZlcmxheS5zZXQoZmFsc2UpO1xuXHRcdFx0XHRhd2FpdCB0aWNrKCk7XG5cdFx0XHRcdHNob3dDYWxsT3ZlcmxheS5zZXQodHJ1ZSk7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIHtcblx0XHRcdGxhcmdlU2NyZWVuID0gZmFsc2U7XG5cdFx0XHRpZiAoJHNob3dDYWxsT3ZlcmxheSkge1xuXHRcdFx0XHRzaG93Q2FsbE92ZXJsYXkuc2V0KGZhbHNlKTtcblx0XHRcdFx0YXdhaXQgdGljaygpO1xuXHRcdFx0XHRzaG93Q2FsbE92ZXJsYXkuc2V0KHRydWUpO1xuXHRcdFx0fVxuXHRcdH1cblx0fTtcblxuXHRjb25zdCBvbk1vdXNlRG93biA9ICgpID0+IHtcblx0XHRkcmFnZ2VkID0gdHJ1ZTtcblx0fTtcblx0Y29uc3Qgb25Nb3VzZVVwID0gKCkgPT4ge1xuXHRcdGRyYWdnZWQgPSBmYWxzZTtcblx0fTtcblxuXHRvbk1vdW50KCgpID0+IHtcblx0XHRjb25zdCBtZWRpYVF1ZXJ5ID0gd2luZG93Lm1hdGNoTWVkaWEoJyhtaW4td2lkdGg6IDEwMjRweCknKTtcblx0XHRtZWRpYVF1ZXJ5LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIGhhbmRsZU1lZGlhUXVlcnkpO1xuXHRcdGhhbmRsZU1lZGlhUXVlcnkobWVkaWFRdWVyeSk7XG5cblx0XHRsZXQgaXNEZXN0cm95ZWQgPSBmYWxzZTtcblxuXHRcdGNvbnN0IGluaXQgPSBhc3luYyAoKSA9PiB7XG5cdFx0XHRhd2FpdCB0aWNrKCk7XG5cblx0XHRcdGlmIChpc0Rlc3Ryb3llZCkgcmV0dXJuO1xuXG5cdFx0XHRzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0bW91bnRlZCA9IHRydWU7XG5cdFx0XHR9LCAwKTtcblx0XHR9O1xuXHRcdGluaXQoKTtcblxuXHRcdGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIG9uTW91c2VEb3duKTtcblx0XHRkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZXVwJywgb25Nb3VzZVVwKTtcblxuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRpc0Rlc3Ryb3llZCA9IHRydWU7XG5cdFx0XHRtb3VudGVkID0gZmFsc2U7XG5cdFx0XHRpZiAoIWxhcmdlU2NyZWVuKSB7XG5cdFx0XHRcdHNob3dDb250cm9scy5zZXQoZmFsc2UpO1xuXHRcdFx0fVxuXHRcdFx0bWVkaWFRdWVyeS5yZW1vdmVFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBoYW5kbGVNZWRpYVF1ZXJ5KTtcblx0XHRcdGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNlZG93bicsIG9uTW91c2VEb3duKTtcblx0XHRcdGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNldXAnLCBvbk1vdXNlVXApO1xuXHRcdH07XG5cdH0pO1xuXG5cdGNvbnN0IHBlcnNpc3RPcGVuID0gKGlkOiBzdHJpbmcsIG9wZW46IGJvb2xlYW4pID0+IHtcblx0XHR2b2lkIHdvcmtzcGFjZUNvbnRyb2xsZXIud3JpdGVQcmVmcyhpZCwgeyBvcGVuIH0pLmNhdGNoKCgpID0+IHtcblx0XHRcdGlmIChjaGF0SWQgPT09IGlkKSB3b3Jrc3BhY2VFcnJvciA9ICRpMThuLnQoJ1dvcmtzcGFjZSBwcmVmZXJlbmNlIGNvdWxkIG5vdCBiZSBzYXZlZCcpO1xuXHRcdH0pO1xuXHR9O1xuXG5cdGNvbnN0IG9wZW5Xb3Jrc3BhY2UgPSBhc3luYyAoKSA9PiB7XG5cdFx0aWYgKCF3b3Jrc3BhY2VBY3Rpb25BdmFpbGFibGUgfHwgZmlyc3RTZW5kUGVuZGluZyB8fCB3b3Jrc3BhY2VBY3Rpb25QZW5kaW5nKSByZXR1cm47XG5cdFx0Y29uc3Qgc291cmNlSWQgPSBjaGF0SWQ7XG5cdFx0Y29uc3Qgc291cmNlSGlzdG9yeSA9IGhpc3Rvcnk7XG5cdFx0Y29uc3QgZXBvY2ggPSBhY3Rpb25FcG9jaDtcblx0XHR3b3Jrc3BhY2VBY3Rpb25QZW5kaW5nID0gdHJ1ZTtcblx0XHR3b3Jrc3BhY2VFcnJvciA9ICcnO1xuXHRcdGNvbnN0IHNhdmVkSWQgPSBhd2FpdCBlbnN1cmVTYXZlZENoYXQoKTtcblx0XHRpZiAoYWN0aW9uRXBvY2ggPT09IGVwb2NoKSB3b3Jrc3BhY2VBY3Rpb25QZW5kaW5nID0gZmFsc2U7XG5cdFx0aWYgKCFzYXZlZElkKSB7XG5cdFx0XHRpZiAoY2hhdElkID09PSBzb3VyY2VJZCAmJiBoaXN0b3J5ID09PSBzb3VyY2VIaXN0b3J5ICYmICEkdGVtcG9yYXJ5Q2hhdEVuYWJsZWQpXG5cdFx0XHRcdHdvcmtzcGFjZUVycm9yID0gJGkxOG4udCgnV29ya3NwYWNlIGNoYXQgY291bGQgbm90IGJlIHNhdmVkJyk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmICghd29ya3NwYWNlQWN0aW9uQXZhaWxhYmxlIHx8IGhpc3RvcnkgIT09IHNvdXJjZUhpc3RvcnkgfHwgKGNoYXRJZCAmJiBjaGF0SWQgIT09IHNhdmVkSWQpKVxuXHRcdFx0cmV0dXJuO1xuXHRcdHNob3dBcnRpZmFjdHMuc2V0KGZhbHNlKTtcblx0XHRzaG93RW1iZWRzLnNldChmYWxzZSk7XG5cdFx0c2hvd0NhbGxPdmVybGF5LnNldChmYWxzZSk7XG5cdFx0c2hvd0NvbnRyb2xzLnNldCh0cnVlKTtcblx0XHRvcGVuV29ya3NwYWNlUGFuZWwoc2F2ZWRJZCk7XG5cdFx0cGVyc2lzdE9wZW4oc2F2ZWRJZCwgdHJ1ZSk7XG5cdH07XG5cblx0Y29uc3QgY2xvc2VIYW5kbGVyID0gKCkgPT4ge1xuXHRcdGlmIChzaG93V29ya3NwYWNlICYmIGNoYXRJZCkge1xuXHRcdFx0Y2xvc2VXb3Jrc3BhY2VQYW5lbChjaGF0SWQpO1xuXHRcdFx0cGVyc2lzdE9wZW4oY2hhdElkLCBmYWxzZSk7XG5cdFx0fVxuXHRcdGlmICghbGFyZ2VTY3JlZW4pIHNob3dDb250cm9scy5zZXQoZmFsc2UpO1xuXHRcdHNob3dBcnRpZmFjdHMuc2V0KGZhbHNlKTtcblx0XHRzaG93RW1iZWRzLnNldChmYWxzZSk7XG5cdFx0aWYgKCRzaG93Q2FsbE92ZXJsYXkpIHNob3dDYWxsT3ZlcmxheS5zZXQoZmFsc2UpO1xuXHR9O1xuXG5cdGNvbnN0IGNsb3NlV29ya3NwYWNlID0gKCkgPT4ge1xuXHRcdGlmIChzaG93V29ya3NwYWNlKSBjbG9zZUhhbmRsZXIoKTtcblx0XHRzaG93Q29udHJvbHMuc2V0KGZhbHNlKTtcblx0fTtcblxuXHQkOiBpZiAobW91bnRlZCAmJiAhY2hhdElkKSBjbG9zZUhhbmRsZXIoKTtcblxuXHQvLyBIZWxwZXI6IGlzIGEgXCJzcGVjaWFsXCIgZnVsbC1zY3JlZW4gcGFuZWwgYWN0aXZlP1xuXHQkOiBzcGVjaWFsUGFuZWwgPSAkc2hvd0NhbGxPdmVybGF5IHx8ICRzaG93QXJ0aWZhY3RzIHx8ICRzaG93RW1iZWRzIHx8IHNob3dXb3Jrc3BhY2U7XG48L3NjcmlwdD5cblxueyNpZiB3b3Jrc3BhY2VBY3Rpb25BdmFpbGFibGUgJiYgKCEkc2hvd0NvbnRyb2xzIHx8ICRzaG93QXJ0aWZhY3RzIHx8ICRzaG93RW1iZWRzIHx8ICRzaG93Q2FsbE92ZXJsYXkpfVxuXHQ8ZGl2XG5cdFx0Y2xhc3M9XCJmaXhlZCByaWdodC0zIHRvcC0xNCB6LTQwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQtbGcgYmctd2hpdGUgcC0yIHRleHQtc20gc2hhZG93LW1kIGRhcms6YmctZ3JheS05MDBcIlxuXHQ+XG5cdFx0PGJ1dHRvblxuXHRcdFx0dHlwZT1cImJ1dHRvblwiXG5cdFx0XHRvbjpjbGljaz17b3BlbldvcmtzcGFjZX1cblx0XHRcdGRpc2FibGVkPXtmaXJzdFNlbmRQZW5kaW5nIHx8IHdvcmtzcGFjZUFjdGlvblBlbmRpbmd9XG5cdFx0XHR0aXRsZT17Zmlyc3RTZW5kUGVuZGluZyA/ICRpMThuLnQoJ1dhaXRpbmcgZm9yIGNoYXQgdG8gc2F2ZScpIDogJGkxOG4udCgnV29ya3NwYWNlIEZpbGVzJyl9XG5cdFx0XHRhcmlhLWxhYmVsPXskaTE4bi50KCdXb3Jrc3BhY2UgRmlsZXMnKX0+eyRpMThuLnQoJ1dvcmtzcGFjZSBGaWxlcycpfTwvYnV0dG9uXG5cdFx0PlxuXHRcdHsjaWYgd29ya3NwYWNlQ2hhbmdlZH08c3BhbiByb2xlPVwic3RhdHVzXCI+eyRpMThuLnQoJ1dvcmtzcGFjZSBjaGFuZ2VkJyl9PC9zcGFuPnsvaWZ9XG5cdFx0eyNpZiBmaXJzdFNlbmRQZW5kaW5nfTxzcGFuIHJvbGU9XCJzdGF0dXNcIj57JGkxOG4udCgnV2FpdGluZyBmb3IgY2hhdCB0byBzYXZlJyl9PC9zcGFuPnsvaWZ9XG5cdDwvZGl2Plxuey9pZn1cbnsjaWYgd29ya3NwYWNlRXJyb3J9PHBcblx0XHRjbGFzcz1cImZpeGVkIHJpZ2h0LTMgdG9wLTI4IHotNDAgcm91bmRlZC1sZyBiZy13aGl0ZSBwLTIgdGV4dC1zbSBkYXJrOmJnLWdyYXktOTAwXCJcblx0XHRyb2xlPVwiYWxlcnRcIlxuXHQ+XG5cdFx0e3dvcmtzcGFjZUVycm9yfVxuXHQ8L3A+ey9pZn1cblxueyNpZiAhbGFyZ2VTY3JlZW59XG5cdHsjaWYgJHNob3dDb250cm9sc31cblx0XHQ8RHJhd2VyXG5cdFx0XHRzaG93PXskc2hvd0NvbnRyb2xzfVxuXHRcdFx0b25DbG9zZT17Y2xvc2VXb3Jrc3BhY2V9XG5cdFx0XHRjbGFzc05hbWU9XCJtaW4taC1bMTAwZHZoXSAhYmctd2hpdGUgZGFyazohYmctZ3JheS04NTBcIlxuXHRcdD5cblx0XHRcdDxkaXYgY2xhc3M9XCJoLVsxMDBkdmhdIGZsZXggZmxleC1jb2xcIj5cblx0XHRcdFx0eyNpZiAkc2hvd0NhbGxPdmVybGF5fVxuXHRcdFx0XHRcdDxkaXZcblx0XHRcdFx0XHRcdGNsYXNzPVwiaC1mdWxsIG1heC1oLVsxMDBkdmhdIGJnLXdoaXRlIHRleHQtZ3JheS03MDAgZGFyazpiZy1ibGFjayBkYXJrOnRleHQtZ3JheS0zMDAgZmxleCBqdXN0aWZ5LWNlbnRlclwiXG5cdFx0XHRcdFx0PlxuXHRcdFx0XHRcdFx0PENhbGxPdmVybGF5XG5cdFx0XHRcdFx0XHRcdGJpbmQ6ZmlsZXNcblx0XHRcdFx0XHRcdFx0e3N1Ym1pdFByb21wdH1cblx0XHRcdFx0XHRcdFx0e3N0b3BSZXNwb25zZX1cblx0XHRcdFx0XHRcdFx0e21vZGVsSWR9XG5cdFx0XHRcdFx0XHRcdHtjaGF0SWR9XG5cdFx0XHRcdFx0XHRcdHtldmVudFRhcmdldH1cblx0XHRcdFx0XHRcdFx0b246Y2xvc2U9eygpID0+IHNob3dDb250cm9scy5zZXQoZmFsc2UpfVxuXHRcdFx0XHRcdFx0Lz5cblx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0ezplbHNlIGlmICRzaG93RW1iZWRzfVxuXHRcdFx0XHRcdDxFbWJlZHMgLz5cblx0XHRcdFx0ezplbHNlIGlmICRzaG93QXJ0aWZhY3RzfVxuXHRcdFx0XHRcdDxBcnRpZmFjdHMge2hpc3Rvcnl9IC8+XG5cdFx0XHRcdHs6ZWxzZSBpZiBzaG93V29ya3NwYWNlICYmIHdvcmtzcGFjZUF2YWlsYWJsZSAmJiBjaGF0SWR9XG5cdFx0XHRcdFx0eyNrZXkgY2hhdElkfTxXb3Jrc3BhY2VBcnRpZmFjdFxuXHRcdFx0XHRcdFx0XHR7Y2hhdElkfVxuXHRcdFx0XHRcdFx0XHRlbmFibGVkPXt3b3Jrc3BhY2VBdmFpbGFibGV9XG5cdFx0XHRcdFx0XHRcdG9uQ2xvc2U9e2Nsb3NlV29ya3NwYWNlfVxuXHRcdFx0XHRcdFx0Lz57L2tleX1cblx0XHRcdFx0ezplbHNlfVxuXHRcdFx0XHRcdDwhLS0gQ29udHJvbHMgKyBGaWxlcyB0YWJzIC0tPlxuXHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGgtZnVsbCBtaW4taC0wXCI+XG5cdFx0XHRcdFx0XHQ8IS0tIFRhYiBiYXIgLS0+XG5cdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTIgcHQtMiBwYi0yIHNocmluay0wXCI+XG5cdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJmbGV4IGdhcC0xIG1pbi13LTAgb3ZlcmZsb3cteC1hdXRvIHNjcm9sbGJhci1oaWRkZW5cIj5cblx0XHRcdFx0XHRcdFx0XHR7I2lmIHNob3dDb250cm9sc1RhYn1cblx0XHRcdFx0XHRcdFx0XHRcdDxidXR0b25cblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3M9XCJweC0yLjUgcHktMSB0ZXh0LXNtIHJvdW5kZWQtbGcgdHJhbnNpdGlvbiB3aGl0ZXNwYWNlLW5vd3JhcCB7YWN0aXZlVGFiID09PVxuXHRcdFx0XHRcdFx0XHRcdFx0XHQnY29udHJvbHMnXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0PyAnYmctZ3JheS0xMDAvNDAgZGFyazpiZy1ncmF5LTgwMC8yNSBmb250LW5vcm1hbCB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTIwMCdcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHQ6ICd0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBob3ZlcjpiZy1ncmF5LTEwMC8zMCBkYXJrOmhvdmVyOmJnLWdyYXktODAwLzIwIGhvdmVyOnRleHQtZ3JheS02MDAgZGFyazpob3Zlcjp0ZXh0LWdyYXktMzAwJ31cIlxuXHRcdFx0XHRcdFx0XHRcdFx0XHRvbjpjbGljaz17KCkgPT4gKGFjdGl2ZVRhYiA9ICdjb250cm9scycpfVxuXHRcdFx0XHRcdFx0XHRcdFx0PlxuXHRcdFx0XHRcdFx0XHRcdFx0XHR7JGkxOG4udCgnQ29udHJvbHMnKX1cblx0XHRcdFx0XHRcdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHRcdFx0XHRcdHsvaWZ9XG5cdFx0XHRcdFx0XHRcdFx0eyNpZiBzaG93RmlsZXNUYWJ9XG5cdFx0XHRcdFx0XHRcdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzPVwicHgtMi41IHB5LTEgdGV4dC1zbSByb3VuZGVkLWxnIHRyYW5zaXRpb24gd2hpdGVzcGFjZS1ub3dyYXAge2FjdGl2ZVRhYiA9PT1cblx0XHRcdFx0XHRcdFx0XHRcdFx0J2ZpbGVzJ1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdD8gJ2JnLWdyYXktMTAwLzQwIGRhcms6YmctZ3JheS04MDAvMjUgZm9udC1ub3JtYWwgdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0yMDAnXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0OiAndGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgaG92ZXI6YmctZ3JheS0xMDAvMzAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMC8yMCBob3Zlcjp0ZXh0LWdyYXktNjAwIGRhcms6aG92ZXI6dGV4dC1ncmF5LTMwMCd9XCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0b246Y2xpY2s9eygpID0+IChhY3RpdmVUYWIgPSAnZmlsZXMnKX1cblx0XHRcdFx0XHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdFx0XHRcdFx0eyRpMThuLnQoJ0ZpbGVzJyl9XG5cdFx0XHRcdFx0XHRcdFx0XHQ8L2J1dHRvbj5cblx0XHRcdFx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHRcdFx0XHRcdHsjaWYgc2hvd092ZXJ2aWV3VGFifVxuXHRcdFx0XHRcdFx0XHRcdFx0PGJ1dHRvblxuXHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzcz1cInB4LTIuNSBweS0xIHRleHQtc20gcm91bmRlZC1sZyB0cmFuc2l0aW9uIHdoaXRlc3BhY2Utbm93cmFwIHthY3RpdmVUYWIgPT09XG5cdFx0XHRcdFx0XHRcdFx0XHRcdCdvdmVydmlldydcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHQ/ICdiZy1ncmF5LTEwMC80MCBkYXJrOmJnLWdyYXktODAwLzI1IGZvbnQtbm9ybWFsIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMjAwJ1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdDogJ3RleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMTAwLzMwIGRhcms6aG92ZXI6YmctZ3JheS04MDAvMjAgaG92ZXI6dGV4dC1ncmF5LTYwMCBkYXJrOmhvdmVyOnRleHQtZ3JheS0zMDAnfVwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdG9uOmNsaWNrPXsoKSA9PiAoYWN0aXZlVGFiID0gJ292ZXJ2aWV3Jyl9XG5cdFx0XHRcdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdFx0XHRcdHskaTE4bi50KCdPdmVydmlldycpfVxuXHRcdFx0XHRcdFx0XHRcdFx0PC9idXR0b24+XG5cdFx0XHRcdFx0XHRcdFx0ey9pZn1cblx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHRcdHsjaWYgd29ya3NwYWNlQWN0aW9uQXZhaWxhYmxlfVxuXHRcdFx0XHRcdFx0XHRcdDxidXR0b25cblx0XHRcdFx0XHRcdFx0XHRcdHR5cGU9XCJidXR0b25cIlxuXHRcdFx0XHRcdFx0XHRcdFx0b246Y2xpY2s9e29wZW5Xb3Jrc3BhY2V9XG5cdFx0XHRcdFx0XHRcdFx0XHRkaXNhYmxlZD17Zmlyc3RTZW5kUGVuZGluZyB8fCB3b3Jrc3BhY2VBY3Rpb25QZW5kaW5nfVxuXHRcdFx0XHRcdFx0XHRcdFx0dGl0bGU9e2ZpcnN0U2VuZFBlbmRpbmdcblx0XHRcdFx0XHRcdFx0XHRcdFx0PyAkaTE4bi50KCdXYWl0aW5nIGZvciBjaGF0IHRvIHNhdmUnKVxuXHRcdFx0XHRcdFx0XHRcdFx0XHQ6ICRpMThuLnQoJ1dvcmtzcGFjZSBGaWxlcycpfVxuXHRcdFx0XHRcdFx0XHRcdFx0YXJpYS1sYWJlbD17JGkxOG4udCgnV29ya3NwYWNlIEZpbGVzJyl9PnskaTE4bi50KCdXb3Jrc3BhY2UgRmlsZXMnKX08L2J1dHRvblxuXHRcdFx0XHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdFx0XHR7I2lmIHdvcmtzcGFjZUNoYW5nZWR9PHNwYW4gcm9sZT1cInN0YXR1c1wiPnskaTE4bi50KCdXb3Jrc3BhY2UgY2hhbmdlZCcpfTwvc3Bhbj57L2lmfVxuXHRcdFx0XHRcdFx0XHRcdHsjaWYgZmlyc3RTZW5kUGVuZGluZ308c3BhbiByb2xlPVwic3RhdHVzXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0PnskaTE4bi50KCdXYWl0aW5nIGZvciBjaGF0IHRvIHNhdmUnKX08L3NwYW5cblx0XHRcdFx0XHRcdFx0XHRcdD57L2lmfVxuXHRcdFx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHRcdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdFx0XHRcdFx0Y2xhc3M9XCJwLTEgcm91bmRlZC1sZyB0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMFwiXG5cdFx0XHRcdFx0XHRcdFx0b246Y2xpY2s9e2Nsb3NlV29ya3NwYWNlfVxuXHRcdFx0XHRcdFx0XHRcdGFyaWEtbGFiZWw9eyRpMThuLnQoJ0Nsb3NlJyl9XG5cdFx0XHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdFx0XHQ8c3ZnXG5cdFx0XHRcdFx0XHRcdFx0XHR4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcblx0XHRcdFx0XHRcdFx0XHRcdHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuXHRcdFx0XHRcdFx0XHRcdFx0ZmlsbD1cIm5vbmVcIlxuXHRcdFx0XHRcdFx0XHRcdFx0c3Ryb2tlPVwiY3VycmVudENvbG9yXCJcblx0XHRcdFx0XHRcdFx0XHRcdHN0cm9rZS13aWR0aD1cIjEuNVwiXG5cdFx0XHRcdFx0XHRcdFx0XHRjbGFzcz1cInNpemUtNFwiXG5cdFx0XHRcdFx0XHRcdFx0PlxuXHRcdFx0XHRcdFx0XHRcdFx0PHBhdGggc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgZD1cIk02IDE4IDE4IDZNNiA2bDEyIDEyXCIgLz5cblx0XHRcdFx0XHRcdFx0XHQ8L3N2Zz5cblx0XHRcdFx0XHRcdFx0PC9idXR0b24+XG5cdFx0XHRcdFx0XHQ8L2Rpdj5cblxuXHRcdFx0XHRcdFx0PGRpdlxuXHRcdFx0XHRcdFx0XHRjbGFzcz1cImZsZXgtMSBtaW4taC0wIHthY3RpdmVUYWIgPT09ICdvdmVydmlldydcblx0XHRcdFx0XHRcdFx0XHQ/ICdoLWZ1bGwnXG5cdFx0XHRcdFx0XHRcdFx0OiBhY3RpdmVUYWIgPT09ICdjb250cm9scydcblx0XHRcdFx0XHRcdFx0XHRcdD8gJ292ZXJmbG93LXktYXV0byBweC0zIHB0LTEnXG5cdFx0XHRcdFx0XHRcdFx0XHQ6ICcnfVwiXG5cdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdHsjaWYgYWN0aXZlVGFiID09PSAnb3ZlcnZpZXcnfVxuXHRcdFx0XHRcdFx0XHRcdDxPdmVydmlld1xuXHRcdFx0XHRcdFx0XHRcdFx0e2hpc3Rvcnl9XG5cdFx0XHRcdFx0XHRcdFx0XHR7Y2hhdFVzZXJ9XG5cdFx0XHRcdFx0XHRcdFx0XHRvbk5vZGVDbGljaz17KGUpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Y29uc3Qgbm9kZSA9IGUubm9kZTtcblx0XHRcdFx0XHRcdFx0XHRcdFx0c2hvd01lc3NhZ2Uobm9kZS5kYXRhLm1lc3NhZ2UsIHRydWUpO1xuXHRcdFx0XHRcdFx0XHRcdFx0fX1cblx0XHRcdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdFx0XHR7OmVsc2UgaWYgYWN0aXZlVGFiID09PSAnZmlsZXMnICYmIHRlcm1pbmFsRmlsZXNBdmFpbGFibGUgJiYgJHNlbGVjdGVkVGVybWluYWxJZH1cblx0XHRcdFx0XHRcdFx0XHQ8RmlsZU5hdiB7Y2hhdElkfSAvPlxuXHRcdFx0XHRcdFx0XHR7OmVsc2UgaWYgYWN0aXZlVGFiID09PSAnZmlsZXMnICYmIGNvZGVJbnRlcnByZXRlckVuYWJsZWR9XG5cdFx0XHRcdFx0XHRcdFx0PFB5b2RpZGVGaWxlTmF2IC8+XG5cdFx0XHRcdFx0XHRcdHs6ZWxzZX1cblx0XHRcdFx0XHRcdFx0XHQ8Q29udHJvbHMgZW1iZWQ9e3RydWV9IHttb2RlbHN9IGJpbmQ6Y2hhdEZpbGVzIGJpbmQ6cGFyYW1zIC8+XG5cdFx0XHRcdFx0XHRcdHsvaWZ9XG5cdFx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0ey9pZn1cblx0XHRcdDwvZGl2PlxuXHRcdDwvRHJhd2VyPlxuXHR7L2lmfVxuezplbHNlfVxuXHQ8UmVzaXphYmxlU2lkZVBhbmVsXG5cdFx0b3Blbj17JHNob3dDb250cm9sc31cblx0XHRiaW5kOndpZHRoPXtjb250cm9sc1dpZHRofVxuXHRcdG1pbldpZHRoPXszNTB9XG5cdFx0bWluU2libGluZ1dpZHRoPXszNjB9XG5cdFx0Y2xvc2VPbkRyYWdCZWxvd01pbldpZHRoXG5cdFx0b25DbG9zZT17Y2xvc2VXb3Jrc3BhY2V9XG5cdFx0c3RvcmFnZUtleT1cImNoYXRDb250cm9sc1NpemVcIlxuXHRcdGNsYXNzTmFtZT1cImgtZnVsbCB6LTEwIGJnLXdoaXRlIGRhcms6YmctZ3JheS05MDBcIlxuXHQ+XG5cdFx0PGRpdiBjbGFzcz1cImZsZXggaC1mdWxsIG1heC1oLWZ1bGwgbWluLWgtZnVsbFwiPlxuXHRcdFx0PGRpdlxuXHRcdFx0XHRjbGFzcz1cInctZnVsbCB7c3BlY2lhbFBhbmVsICYmICEkc2hvd0NhbGxPdmVybGF5XG5cdFx0XHRcdFx0PyAnICdcblx0XHRcdFx0XHQ6ICdiZy13aGl0ZSBkYXJrOmJnLWdyYXktOTAwJ30gei00MCBwb2ludGVyLWV2ZW50cy1hdXRvIHthY3RpdmVUYWIgPT09ICdmaWxlcydcblx0XHRcdFx0XHQ/ICcnXG5cdFx0XHRcdFx0OiAnb3ZlcmZsb3cteS1hdXRvJ30gc2Nyb2xsYmFyLWhpZGRlblwiXG5cdFx0XHRcdGlkPVwiY29udHJvbHMtY29udGFpbmVyXCJcblx0XHRcdD5cblx0XHRcdFx0eyNpZiAkc2hvd0NhbGxPdmVybGF5fVxuXHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJ3LWZ1bGwgaC1mdWxsIGZsZXgganVzdGlmeS1jZW50ZXJcIj5cblx0XHRcdFx0XHRcdDxDYWxsT3ZlcmxheVxuXHRcdFx0XHRcdFx0XHRiaW5kOmZpbGVzXG5cdFx0XHRcdFx0XHRcdHtzdWJtaXRQcm9tcHR9XG5cdFx0XHRcdFx0XHRcdHtzdG9wUmVzcG9uc2V9XG5cdFx0XHRcdFx0XHRcdHttb2RlbElkfVxuXHRcdFx0XHRcdFx0XHR7Y2hhdElkfVxuXHRcdFx0XHRcdFx0XHR7ZXZlbnRUYXJnZXR9XG5cdFx0XHRcdFx0XHRcdG9uOmNsb3NlPXsoKSA9PiBzaG93Q29udHJvbHMuc2V0KGZhbHNlKX1cblx0XHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdHs6ZWxzZSBpZiAkc2hvd0VtYmVkc31cblx0XHRcdFx0XHQ8RW1iZWRzIG92ZXJsYXk9e2RyYWdnZWR9IC8+XG5cdFx0XHRcdHs6ZWxzZSBpZiAkc2hvd0FydGlmYWN0c31cblx0XHRcdFx0XHQ8QXJ0aWZhY3RzIHtoaXN0b3J5fSBvdmVybGF5PXtkcmFnZ2VkfSAvPlxuXHRcdFx0XHR7OmVsc2UgaWYgc2hvd1dvcmtzcGFjZSAmJiB3b3Jrc3BhY2VBdmFpbGFibGUgJiYgY2hhdElkfVxuXHRcdFx0XHRcdHsja2V5IGNoYXRJZH08V29ya3NwYWNlQXJ0aWZhY3Rcblx0XHRcdFx0XHRcdFx0e2NoYXRJZH1cblx0XHRcdFx0XHRcdFx0ZW5hYmxlZD17d29ya3NwYWNlQXZhaWxhYmxlfVxuXHRcdFx0XHRcdFx0XHRvbkNsb3NlPXtjbG9zZVdvcmtzcGFjZX1cblx0XHRcdFx0XHRcdC8+ey9rZXl9XG5cdFx0XHRcdHs6ZWxzZX1cblx0XHRcdFx0XHQ8IS0tIENvbnRyb2xzICsgRmlsZXMgdGFicyAtLT5cblx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBoLWZ1bGwgbWluLWgtMFwiPlxuXHRcdFx0XHRcdFx0PCEtLSBUYWIgYmFyIC0tPlxuXHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC0yIHB0LTIgcGItMiBzaHJpbmstMFwiPlxuXHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwiZmxleCBnYXAtMSBtaW4tdy0wIG92ZXJmbG93LXgtYXV0byBzY3JvbGxiYXItaGlkZGVuXCI+XG5cdFx0XHRcdFx0XHRcdFx0eyNpZiBzaG93Q29udHJvbHNUYWJ9XG5cdFx0XHRcdFx0XHRcdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzPVwicHgtMi41IHB5LTEgdGV4dC1zbSByb3VuZGVkLWxnIHRyYW5zaXRpb24gd2hpdGVzcGFjZS1ub3dyYXAge2FjdGl2ZVRhYiA9PT1cblx0XHRcdFx0XHRcdFx0XHRcdFx0J2NvbnRyb2xzJ1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdD8gJ2JnLWdyYXktMTAwLzQwIGRhcms6YmctZ3JheS04MDAvMjUgZm9udC1ub3JtYWwgdGV4dC1ncmF5LTcwMCBkYXJrOnRleHQtZ3JheS0yMDAnXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0OiAndGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgaG92ZXI6YmctZ3JheS0xMDAvMzAgZGFyazpob3ZlcjpiZy1ncmF5LTgwMC8yMCBob3Zlcjp0ZXh0LWdyYXktNjAwIGRhcms6aG92ZXI6dGV4dC1ncmF5LTMwMCd9XCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0b246Y2xpY2s9eygpID0+IChhY3RpdmVUYWIgPSAnY29udHJvbHMnKX1cblx0XHRcdFx0XHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdFx0XHRcdFx0eyRpMThuLnQoJ0NvbnRyb2xzJyl9XG5cdFx0XHRcdFx0XHRcdFx0XHQ8L2J1dHRvbj5cblx0XHRcdFx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHRcdFx0XHRcdHsjaWYgc2hvd0ZpbGVzVGFifVxuXHRcdFx0XHRcdFx0XHRcdFx0PGJ1dHRvblxuXHRcdFx0XHRcdFx0XHRcdFx0XHRjbGFzcz1cInB4LTIuNSBweS0xIHRleHQtc20gcm91bmRlZC1sZyB0cmFuc2l0aW9uIHdoaXRlc3BhY2Utbm93cmFwIHthY3RpdmVUYWIgPT09XG5cdFx0XHRcdFx0XHRcdFx0XHRcdCdmaWxlcydcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHQ/ICdiZy1ncmF5LTEwMC80MCBkYXJrOmJnLWdyYXktODAwLzI1IGZvbnQtbm9ybWFsIHRleHQtZ3JheS03MDAgZGFyazp0ZXh0LWdyYXktMjAwJ1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdDogJ3RleHQtZ3JheS01MDAgZGFyazp0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMTAwLzMwIGRhcms6aG92ZXI6YmctZ3JheS04MDAvMjAgaG92ZXI6dGV4dC1ncmF5LTYwMCBkYXJrOmhvdmVyOnRleHQtZ3JheS0zMDAnfVwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdG9uOmNsaWNrPXsoKSA9PiAoYWN0aXZlVGFiID0gJ2ZpbGVzJyl9XG5cdFx0XHRcdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdFx0XHRcdHskaTE4bi50KCdGaWxlcycpfVxuXHRcdFx0XHRcdFx0XHRcdFx0PC9idXR0b24+XG5cdFx0XHRcdFx0XHRcdFx0ey9pZn1cblx0XHRcdFx0XHRcdFx0XHR7I2lmIHNob3dPdmVydmlld1RhYn1cblx0XHRcdFx0XHRcdFx0XHRcdDxidXR0b25cblx0XHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3M9XCJweC0yLjUgcHktMSB0ZXh0LXNtIHJvdW5kZWQtbGcgdHJhbnNpdGlvbiB3aGl0ZXNwYWNlLW5vd3JhcCB7YWN0aXZlVGFiID09PVxuXHRcdFx0XHRcdFx0XHRcdFx0XHQnb3ZlcnZpZXcnXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0PyAnYmctZ3JheS0xMDAvNDAgZGFyazpiZy1ncmF5LTgwMC8yNSBmb250LW5vcm1hbCB0ZXh0LWdyYXktNzAwIGRhcms6dGV4dC1ncmF5LTIwMCdcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHQ6ICd0ZXh0LWdyYXktNTAwIGRhcms6dGV4dC1ncmF5LTQwMCBob3ZlcjpiZy1ncmF5LTEwMC8zMCBkYXJrOmhvdmVyOmJnLWdyYXktODAwLzIwIGhvdmVyOnRleHQtZ3JheS02MDAgZGFyazpob3Zlcjp0ZXh0LWdyYXktMzAwJ31cIlxuXHRcdFx0XHRcdFx0XHRcdFx0XHRvbjpjbGljaz17KCkgPT4gKGFjdGl2ZVRhYiA9ICdvdmVydmlldycpfVxuXHRcdFx0XHRcdFx0XHRcdFx0PlxuXHRcdFx0XHRcdFx0XHRcdFx0XHR7JGkxOG4udCgnT3ZlcnZpZXcnKX1cblx0XHRcdFx0XHRcdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHRcdFx0XHRcdHsvaWZ9XG5cdFx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdFx0XHR7I2lmIHdvcmtzcGFjZUFjdGlvbkF2YWlsYWJsZX1cblx0XHRcdFx0XHRcdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdFx0XHRcdFx0XHR0eXBlPVwiYnV0dG9uXCJcblx0XHRcdFx0XHRcdFx0XHRcdG9uOmNsaWNrPXtvcGVuV29ya3NwYWNlfVxuXHRcdFx0XHRcdFx0XHRcdFx0ZGlzYWJsZWQ9e2ZpcnN0U2VuZFBlbmRpbmcgfHwgd29ya3NwYWNlQWN0aW9uUGVuZGluZ31cblx0XHRcdFx0XHRcdFx0XHRcdHRpdGxlPXtmaXJzdFNlbmRQZW5kaW5nXG5cdFx0XHRcdFx0XHRcdFx0XHRcdD8gJGkxOG4udCgnV2FpdGluZyBmb3IgY2hhdCB0byBzYXZlJylcblx0XHRcdFx0XHRcdFx0XHRcdFx0OiAkaTE4bi50KCdXb3Jrc3BhY2UgRmlsZXMnKX1cblx0XHRcdFx0XHRcdFx0XHRcdGFyaWEtbGFiZWw9eyRpMThuLnQoJ1dvcmtzcGFjZSBGaWxlcycpfT57JGkxOG4udCgnV29ya3NwYWNlIEZpbGVzJyl9PC9idXR0b25cblx0XHRcdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdFx0eyNpZiB3b3Jrc3BhY2VDaGFuZ2VkfTxzcGFuIHJvbGU9XCJzdGF0dXNcIj57JGkxOG4udCgnV29ya3NwYWNlIGNoYW5nZWQnKX08L3NwYW4+ey9pZn1cblx0XHRcdFx0XHRcdFx0XHR7I2lmIGZpcnN0U2VuZFBlbmRpbmd9PHNwYW4gcm9sZT1cInN0YXR1c1wiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdD57JGkxOG4udCgnV2FpdGluZyBmb3IgY2hhdCB0byBzYXZlJyl9PC9zcGFuXG5cdFx0XHRcdFx0XHRcdFx0XHQ+ey9pZn1cblx0XHRcdFx0XHRcdFx0ey9pZn1cblx0XHRcdFx0XHRcdFx0PGJ1dHRvblxuXHRcdFx0XHRcdFx0XHRcdGNsYXNzPVwicC0xIHJvdW5kZWQtbGcgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIlxuXHRcdFx0XHRcdFx0XHRcdG9uOmNsaWNrPXtjbG9zZVdvcmtzcGFjZX1cblx0XHRcdFx0XHRcdFx0XHRhcmlhLWxhYmVsPXskaTE4bi50KCdDbG9zZScpfVxuXHRcdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdFx0PHN2Z1xuXHRcdFx0XHRcdFx0XHRcdFx0eG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG5cdFx0XHRcdFx0XHRcdFx0XHR2aWV3Qm94PVwiMCAwIDI0IDI0XCJcblx0XHRcdFx0XHRcdFx0XHRcdGZpbGw9XCJub25lXCJcblx0XHRcdFx0XHRcdFx0XHRcdHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG5cdFx0XHRcdFx0XHRcdFx0XHRzdHJva2Utd2lkdGg9XCIxLjVcIlxuXHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3M9XCJzaXplLTRcIlxuXHRcdFx0XHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdFx0XHRcdDxwYXRoIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIGQ9XCJNNiAxOCAxOCA2TTYgNmwxMiAxMlwiIC8+XG5cdFx0XHRcdFx0XHRcdFx0PC9zdmc+XG5cdFx0XHRcdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHRcdFx0PC9kaXY+XG5cblx0XHRcdFx0XHRcdDxkaXZcblx0XHRcdFx0XHRcdFx0Y2xhc3M9XCJmbGV4LTEgbWluLWgtMCB7YWN0aXZlVGFiID09PSAnb3ZlcnZpZXcnXG5cdFx0XHRcdFx0XHRcdFx0PyAnaC1mdWxsJ1xuXHRcdFx0XHRcdFx0XHRcdDogYWN0aXZlVGFiID09PSAnY29udHJvbHMnXG5cdFx0XHRcdFx0XHRcdFx0XHQ/ICdvdmVyZmxvdy15LWF1dG8gcHgtMyBwdC0xJ1xuXHRcdFx0XHRcdFx0XHRcdFx0OiAnJ31cIlxuXHRcdFx0XHRcdFx0PlxuXHRcdFx0XHRcdFx0XHR7I2lmIGFjdGl2ZVRhYiA9PT0gJ292ZXJ2aWV3J31cblx0XHRcdFx0XHRcdFx0XHQ8T3ZlcnZpZXdcblx0XHRcdFx0XHRcdFx0XHRcdHtoaXN0b3J5fVxuXHRcdFx0XHRcdFx0XHRcdFx0e2NoYXRVc2VyfVxuXHRcdFx0XHRcdFx0XHRcdFx0b25Ob2RlQ2xpY2s9eyhlKSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNvbnN0IG5vZGUgPSBlLm5vZGU7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGlmIChub2RlPy5kYXRhPy5tZXNzYWdlPy5mYXZvcml0ZSkge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGhpc3RvcnkubWVzc2FnZXNbbm9kZS5kYXRhLm1lc3NhZ2UuaWRdLmZhdm9yaXRlID0gdHJ1ZTtcblx0XHRcdFx0XHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRoaXN0b3J5Lm1lc3NhZ2VzW25vZGUuZGF0YS5tZXNzYWdlLmlkXS5mYXZvcml0ZSA9IG51bGw7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0XHRcdFx0c2hvd01lc3NhZ2Uobm9kZS5kYXRhLm1lc3NhZ2UsIHRydWUpO1xuXHRcdFx0XHRcdFx0XHRcdFx0fX1cblx0XHRcdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdFx0XHR7OmVsc2UgaWYgYWN0aXZlVGFiID09PSAnZmlsZXMnICYmIHRlcm1pbmFsRmlsZXNBdmFpbGFibGUgJiYgJHNlbGVjdGVkVGVybWluYWxJZH1cblx0XHRcdFx0XHRcdFx0XHQ8RmlsZU5hdiBvdmVybGF5PXtkcmFnZ2VkfSB7Y2hhdElkfSAvPlxuXHRcdFx0XHRcdFx0XHR7OmVsc2UgaWYgYWN0aXZlVGFiID09PSAnZmlsZXMnICYmIGNvZGVJbnRlcnByZXRlckVuYWJsZWR9XG5cdFx0XHRcdFx0XHRcdFx0PFB5b2RpZGVGaWxlTmF2IG92ZXJsYXk9e2RyYWdnZWR9IC8+XG5cdFx0XHRcdFx0XHRcdHs6ZWxzZX1cblx0XHRcdFx0XHRcdFx0XHQ8Q29udHJvbHMgZW1iZWQ9e3RydWV9IHttb2RlbHN9IGJpbmQ6Y2hhdEZpbGVzIGJpbmQ6cGFyYW1zIC8+XG5cdFx0XHRcdFx0XHRcdHsvaWZ9XG5cdFx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0ey9pZn1cblx0XHRcdDwvZGl2PlxuXHRcdDwvZGl2PlxuXHQ8L1Jlc2l6YWJsZVNpZGVQYW5lbD5cbnsvaWZ9XG4iXSwiZmlsZSI6Ii9zcmMvbGliL2NvbXBvbmVudHMvY2hhdC9DaGF0Q29udHJvbHMuc3ZlbHRlIn0=
