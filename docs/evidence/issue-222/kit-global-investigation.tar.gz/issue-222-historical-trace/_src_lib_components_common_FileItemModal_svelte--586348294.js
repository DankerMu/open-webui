// /src/lib/components/common/FileItemModal.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_3__ = await __vite_ssr_import__("/node_modules/dompurify/dist/purify.es.mjs", {"importedNames":["default"]});
const __vite_ssr_import_4__ = await __vite_ssr_import__("/node_modules/svelte/src/index-client.js", {"importedNames":["getContext","onMount","tick"]});
const __vite_ssr_import_5__ = await __vite_ssr_import__("/src/lib/utils/index.ts", {"importedNames":["formatFileSize","getLineCount"]});
const __vite_ssr_import_6__ = await __vite_ssr_import__("/src/lib/constants.ts", {"importedNames":["WEBUI_API_BASE_URL"]});
const __vite_ssr_import_7__ = await __vite_ssr_import__("/src/lib/stores/index.ts", {"importedNames":["settings"]});
const __vite_ssr_import_8__ = await __vite_ssr_import__("/src/lib/apis/knowledge/index.ts", {"importedNames":["getKnowledgeById"]});
const __vite_ssr_import_9__ = await __vite_ssr_import__("/src/lib/apis/files/index.ts", {"importedNames":["getFileById","getFileContentById"]});
const __vite_ssr_import_10__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/CodeBlock.svelte", {"importedNames":["default"]});
const __vite_ssr_import_11__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown.svelte", {"importedNames":["default"]});
const __vite_ssr_import_12__ = await __vite_ssr_import__("/src/lib/components/common/Modal.svelte", {"importedNames":["default"]});
const __vite_ssr_import_13__ = await __vite_ssr_import__("/src/lib/components/icons/XMark.svelte", {"importedNames":["default"]});
const __vite_ssr_import_14__ = await __vite_ssr_import__("/src/lib/components/common/Switch.svelte", {"importedNames":["default"]});
const __vite_ssr_import_15__ = await __vite_ssr_import__("/src/lib/components/common/Tooltip.svelte", {"importedNames":["default"]});
const __vite_ssr_import_16__ = await __vite_ssr_import__("/node_modules/dayjs/dayjs.min.js", {"importedNames":["default"]});
const __vite_ssr_import_17__ = await __vite_ssr_import__("/src/lib/components/common/Spinner.svelte", {"importedNames":["default"]});
const __vite_ssr_import_18__ = await __vite_ssr_import__("/src/lib/components/common/PDFViewer.svelte", {"importedNames":["default"]});
const __vite_ssr_import_19__ = await __vite_ssr_import__("/src/lib/components/common/PanzoomContainer.svelte", {"importedNames":["default"]});
const __vite_ssr_import_20__ = await __vite_ssr_import__("/src/lib/components/common/DocxPreview.svelte", {"importedNames":["default"]});
const __vite_ssr_import_21__ = await __vite_ssr_import__("/src/lib/components/common/PptxPreview.svelte", {"importedNames":["default"]});
const __vite_ssr_import_22__ = await __vite_ssr_import__("/src/lib/components/icons/Reset.svelte", {"importedNames":["default"]});
const __vite_ssr_import_23__ = await __vite_ssr_import__("/src/lib/components/common/FileItemModal.svelte?svelte&type=style&lang.css");



FileItemModal[__vite_ssr_import_2__.FILENAME] = 'src/lib/components/common/FileItemModal.svelte';























var root = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="capitalize shrink-0"> </div> •`, 1), FileItemModal[__vite_ssr_import_2__.FILENAME], [[301, 8]]);
var root_1 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="line-clamp-1"> </div> •`, 1), FileItemModal[__vite_ssr_import_2__.FILENAME], [[306, 8]]);
var root_2 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="capitalize shrink-0"> </div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[311, 8]]);
var root_3 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<!> <!> <!>`, 1), FileItemModal[__vite_ssr_import_2__.FILENAME], []);
var root_4 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="capitalize shrink-0"> </div> •`, 1), FileItemModal[__vite_ssr_import_2__.FILENAME], [[318, 7]]);
var root_5 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="capitalize shrink-0"><!></div> <div class="flex items-center gap-1 shrink-0"> </div>`, 1), FileItemModal[__vite_ssr_import_2__.FILENAME], [[323, 7], [335, 7]]);
var root_6 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="capitalize shrink-0"> </div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[341, 7]]);
var root_7 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="flex items-center gap-1.5 text-xs"><!> <!></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[358, 8]]);
var root_8 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class=" self-end"><!></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[348, 6]]);
var root_9 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="flex items-center gap-2 mb-2"><div class="flex-shrink-0 text-xs"> </div></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[383, 7, [[384, 8]]]]);
var root_10 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[381, 5]]);
var root_11 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="flex mb-2.5 scrollbar-none overflow-x-auto w-full border-b border-gray-50 dark:border-gray-850/30 text-center text-sm font-normal bg-transparent dark:text-gray-200"><button type="button"> </button> <button type="button"> </button></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[393, 5, [[396, 6], [406, 6]]]]);
var root_12 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button class="p-1.5 rounded-lg bg-white/80 dark:bg-gray-850/80 backdrop-blur-sm shadow-sm hover:bg-gray-100 dark:hover:bg-gray-800 transition text-gray-500 dark:text-gray-400"><!></button>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[422, 8]]);
var root_13 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<img class="w-full object-contain rounded-lg" loading="lazy" draggable="false"/>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[431, 7]]);
var root_14 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="relative w-full max-h-[70vh] overflow-hidden"><div class="absolute top-2 right-2 z-10"><!></div> <!></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[419, 5, [[420, 6]]]]);
var root_15 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button class="mt-1 text-xs text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition"> </button>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[457, 8]]);
var root_16 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="max-h-96 overflow-scroll scrollbar-hidden text-sm prose dark:prose-invert max-w-full"><!></div> <!>`, 1), FileItemModal[__vite_ssr_import_2__.FILENAME], [[448, 7]]);
var root_17 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="max-h-96 overflow-scroll scrollbar-hidden text-xs whitespace-pre-wrap"> </div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[469, 7]]);
var root_18 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button class="mt-1 text-xs text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition"> </button>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[489, 8]]);
var root_19 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="max-h-96 overflow-scroll scrollbar-hidden text-sm prose dark:prose-invert max-w-full"><!></div> <!>`, 1), FileItemModal[__vite_ssr_import_2__.FILENAME], [[480, 7]]);
var root_20 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="max-h-96 overflow-scroll scrollbar-hidden text-xs whitespace-pre-wrap"> </div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[501, 7]]);
var root_21 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<audio class="w-full border-0 rounded-lg mb-2" controls="" playsinline=""></audio>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[508, 6]]);
var root_22 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="text-red-500 text-sm p-4"> </div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[521, 7]]);
var root_23 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button type="button"> </button>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[530, 10]]);
var root_24 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="flex mb-2.5 scrollbar-none overflow-x-auto w-full border-b border-gray-50 dark:border-gray-850/30 text-center text-sm font-normal bg-transparent dark:text-gray-200"></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[526, 8]]);
var root_25 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="office-preview overflow-auto max-h-[60vh]"></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[544, 8]]);
var root_26 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="text-gray-500 text-sm p-4">No content available</div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[548, 8]]);
var root_27 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<!> <!>`, 1), FileItemModal[__vite_ssr_import_2__.FILENAME], []);
var root_28 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="max-h-[60vh] overflow-scroll scrollbar-hidden text-sm relative"><!></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[552, 6]]);
var root_29 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="max-h-[60vh] overflow-scroll scrollbar-hidden text-sm prose dark:prose-invert max-w-full"><!></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[563, 6]]);
var root_30 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="text-red-500 text-sm p-4"> </div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[570, 7]]);
var root_31 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="text-gray-500 text-sm p-4">No content available</div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[574, 7]]);
var root_32 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="text-red-500 text-sm p-4"> </div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[578, 7]]);
var root_33 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="text-gray-500 text-sm p-4">No content available</div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[586, 7]]);
var root_34 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="max-h-96 overflow-scroll scrollbar-hidden text-xs whitespace-pre-wrap"> </div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[589, 6]]);
var root_35 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<!> <!> <!>`, 1), FileItemModal[__vite_ssr_import_2__.FILENAME], []);
var root_36 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="flex items-center justify-center py-6"><!></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [[595, 4]]);

var root_37 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class=" px-4.5 py-3.5 w-full flex flex-col justify-center dark:text-gray-400"><div class=" pb-2"><div class="flex items-start justify-between"><div><div class=" font-normal text-lg dark:text-gray-100"><a href="#" class="hover:underline line-clamp-1"> </a></div></div> <div><button><!></button></div></div> <div><div class="flex flex-col items-center md:flex-row gap-1 justify-between w-full"><div class=" flex flex-wrap text-xs gap-1 text-gray-500"><!> <!> <!> <!></div> <!></div></div></div> <div class="max-h-[75vh] overflow-auto"><!></div></div>`), FileItemModal[__vite_ssr_import_2__.FILENAME], [
	[
		258,
		1,
		[
			[
				259,
				2,
				[
					[
						260,
						3,
						[[261, 4, [[262, 5, [[263, 6]]]]], [285, 4, [[286, 5]]]]
					],
					[296, 3, [[297, 4, [[298, 5]]]]]
				]
			],
			[378, 2]
		]
	]
]);

function FileItemModal($$anchor, $$props) {
	__vite_ssr_import_2__.check_target(new.target);
	__vite_ssr_import_2__.push($$props, false, FileItemModal);

	var $$ownership_validator = __vite_ssr_import_2__.create_ownership_validator($$props);

	const $i18n = () => (
		__vite_ssr_import_2__.validate_store(i18n, 'i18n'),
		__vite_ssr_import_2__.store_get(i18n, '$i18n', $$stores)
	);

	const $settings = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_7__.settings, 'settings'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_7__.settings, '$settings', $$stores)
	);

	const [$$stores, $$cleanup] = __vite_ssr_import_2__.setup_stores();
	const isMarkdown = __vite_ssr_import_2__.mutable_source();
	const isCode = __vite_ssr_import_2__.mutable_source();
	const i18n = __vite_ssr_import_4__.getContext('i18n');
	const CONTENT_PREVIEW_LIMIT = 10000;
	let expandedContent = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'expandedContent');
	let item = __vite_ssr_import_2__.prop($$props, 'item', 12);
	let show = __vite_ssr_import_2__.prop($$props, 'show', 12, false);
	let edit = __vite_ssr_import_2__.prop($$props, 'edit', 8, false);
	let enableFullContent = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'enableFullContent');
	let loading = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'loading');
	let isPDF = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'isPDF');
	let isAudio = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'isAudio');
	let isImage = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'isImage');
	let isExcel = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'isExcel');
	let isDocx = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'isDocx');
	let isPptx = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'isPptx');
	let selectedTab = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'selectedTab');
	let excelWorkbook = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(null), 'excelWorkbook');
	let excelSheetNames = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source([]), 'excelSheetNames');
	let selectedSheet = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'selectedSheet');
	let excelHtml = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'excelHtml');
	let excelError = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'excelError');
	let rowCount = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(0), 'rowCount');

	// DOCX state
	let docxData = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(null), 'docxData');

	let docxError = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'docxError');

	// PPTX state
	let pptxSlides = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source([]), 'pptxSlides');

	let pptxCurrentSlide = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(0), 'pptxCurrentSlide');
	let pptxError = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'pptxError');
	let panzoomRef = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(), 'panzoomRef');

	const resetImageView = () => {
		__vite_ssr_import_2__.get(panzoomRef)?.reset();
	};

	const loadExcelContent = async () => {
		try {
			__vite_ssr_import_2__.set(excelError, '');

			const [arrayBuffer, { read }] = (await __vite_ssr_import_2__.track_reactivity_loss(Promise.all([__vite_ssr_import_9__.getFileContentById(item().id), __vite_ssr_dynamic_import__("/node_modules/xlsx/xlsx.mjs")])))();

			__vite_ssr_import_2__.set(excelWorkbook, read(arrayBuffer, { type: 'array' }));
			__vite_ssr_import_2__.set(excelSheetNames, __vite_ssr_import_2__.get(excelWorkbook).SheetNames);

			if (__vite_ssr_import_2__.get(excelSheetNames).length > 0) {
				__vite_ssr_import_2__.set(selectedSheet, __vite_ssr_import_2__.get(excelSheetNames)[0]);
				(await __vite_ssr_import_2__.track_reactivity_loss(renderExcelSheet()))();
			}
		} catch(error) {
			console.error(...__vite_ssr_import_2__.log_if_contains_state('error', 'Error loading Excel/CSV file:', error));
			__vite_ssr_import_2__.set(excelError, $i18n().t('Failed to load Excel/CSV file. Please try downloading it instead.'));
		}
	};

	const renderExcelSheet = async () => {
		if (!__vite_ssr_import_2__.get(excelWorkbook) || !__vite_ssr_import_2__.get(selectedSheet)) return;

		const { excelToTable } = (await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_dynamic_import__("/src/lib/utils/excelToTable.ts")))();
		const worksheet = __vite_ssr_import_2__.get(excelWorkbook).Sheets[__vite_ssr_import_2__.get(selectedSheet)];
		const result = (await __vite_ssr_import_2__.track_reactivity_loss(excelToTable(worksheet)))();

		__vite_ssr_import_2__.set(excelHtml, __vite_ssr_import_3__.default.sanitize(result.html));
		__vite_ssr_import_2__.set(rowCount, result.rowCount);
	};

	const loadDocxContent = async () => {
		try {
			__vite_ssr_import_2__.set(docxError, '');
			__vite_ssr_import_2__.set(docxData, (await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_9__.getFileContentById(item().id)))());
		} catch(error) {
			console.error(...__vite_ssr_import_2__.log_if_contains_state('error', 'Error loading DOCX file:', error));
			__vite_ssr_import_2__.set(docxError, $i18n().t('Failed to load DOCX file. Please try downloading it instead.'));
		}
	};

	const loadPptxContent = async () => {
		try {
			__vite_ssr_import_2__.set(pptxError, '');

			const [arrayBuffer, { pptxToImages }] = (await __vite_ssr_import_2__.track_reactivity_loss(Promise.all([
				__vite_ssr_import_9__.getFileContentById(item().id),
				__vite_ssr_dynamic_import__("/src/lib/utils/pptxToHtml.ts")
			])))();

			const result = (await __vite_ssr_import_2__.track_reactivity_loss(pptxToImages(arrayBuffer)))();

			__vite_ssr_import_2__.set(pptxSlides, result.images);
			__vite_ssr_import_2__.set(pptxCurrentSlide, 0);
		} catch(error) {
			console.error(...__vite_ssr_import_2__.log_if_contains_state('error', 'Error loading PPTX file:', error));
			__vite_ssr_import_2__.set(pptxError, $i18n().t('Failed to load PPTX file. Please try downloading it instead.'));
		}
	};

	const loadContent = async () => {
		__vite_ssr_import_2__.set(selectedTab, '');
		__vite_ssr_import_2__.set(expandedContent, false);
		__vite_ssr_import_2__.set(docxData, null);

		if (__vite_ssr_import_2__.strict_equals(item()?.type, 'collection')) {
			__vite_ssr_import_2__.set(loading, true);

			const knowledge = (await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_8__.getKnowledgeById(localStorage.token, item().id).catch((e) => {
				console.error(...__vite_ssr_import_2__.log_if_contains_state('error', 'Error fetching knowledge base:', e));

				return null;
			})))();

			if (knowledge) {
				$$ownership_validator.mutation(null, ['item', 'files'], item(item().files = knowledge.files || [], true), 213, 4);
			}

			__vite_ssr_import_2__.set(loading, false);
		} else if (__vite_ssr_import_2__.strict_equals(item()?.type, 'file')) {
			__vite_ssr_import_2__.set(loading, true);

			const file = (await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_9__.getFileById(localStorage.token, item().id).catch((e) => {
				console.error(...__vite_ssr_import_2__.log_if_contains_state('error', 'Error fetching file:', e));

				return null;
			})))();

			if (file) {
				$$ownership_validator.mutation(null, ['item', 'file'], item(item().file = file || {}, true), 225, 4);
			}

			// Load Excel content if it's an Excel file
			if (__vite_ssr_import_2__.get(isExcel)) {
				(await __vite_ssr_import_2__.track_reactivity_loss(loadExcelContent()))();
			}

			if (__vite_ssr_import_2__.get(isDocx)) {
				(await __vite_ssr_import_2__.track_reactivity_loss(loadDocxContent()))();
			}

			if (__vite_ssr_import_2__.get(isPptx)) {
				(await __vite_ssr_import_2__.track_reactivity_loss(loadPptxContent()))();
			}

			__vite_ssr_import_2__.set(loading, false);
		}

		(await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_4__.tick()))();
	};

	__vite_ssr_import_4__.onMount(() => {
		console.log(...__vite_ssr_import_2__.log_if_contains_state('log', item()));

		if (__vite_ssr_import_2__.strict_equals(item()?.context, 'full')) {
			__vite_ssr_import_2__.set(enableFullContent, true);
		}
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(item())), () => {
		__vite_ssr_import_2__.set(isPDF, __vite_ssr_import_2__.strict_equals(item()?.meta?.content_type, 'application/pdf') || item()?.name && item()?.name.toLowerCase().endsWith('.pdf'));
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(item())), () => {
		__vite_ssr_import_2__.set(isMarkdown, __vite_ssr_import_2__.strict_equals(item()?.meta?.content_type, 'text/markdown') || item()?.name && item()?.name.toLowerCase().endsWith('.md'));
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(item())), () => {
		__vite_ssr_import_2__.set(isCode, item()?.name && (item().name.toLowerCase().endsWith('.py') || item().name.toLowerCase().endsWith('.js') || item().name.toLowerCase().endsWith('.ts') || item().name.toLowerCase().endsWith('.java') || item().name.toLowerCase().endsWith('.html') || item().name.toLowerCase().endsWith('.css') || item().name.toLowerCase().endsWith('.json') || item().name.toLowerCase().endsWith('.cpp') || item().name.toLowerCase().endsWith('.c') || item().name.toLowerCase().endsWith('.h') || item().name.toLowerCase().endsWith('.sh') || item().name.toLowerCase().endsWith('.bash') || item().name.toLowerCase().endsWith('.yaml') || item().name.toLowerCase().endsWith('.yml') || item().name.toLowerCase().endsWith('.xml') || item().name.toLowerCase().endsWith('.sql') || item().name.toLowerCase().endsWith('.go') || item().name.toLowerCase().endsWith('.rs') || item().name.toLowerCase().endsWith('.php') || item().name.toLowerCase().endsWith('.rb')));
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(item())), () => {
		__vite_ssr_import_2__.set(isAudio, (item()?.meta?.content_type ?? '').startsWith('audio/') || item()?.name && item()?.name.toLowerCase().endsWith('.mp3') || item()?.name && item()?.name.toLowerCase().endsWith('.wav') || item()?.name && item()?.name.toLowerCase().endsWith('.ogg') || item()?.name && item()?.name.toLowerCase().endsWith('.m4a') || item()?.name && item()?.name.toLowerCase().endsWith('.webm'));
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(item())), () => {
		__vite_ssr_import_2__.set(isImage, (item()?.meta?.content_type ?? '').startsWith('image/') || item()?.name && (item().name.toLowerCase().endsWith('.png') || item().name.toLowerCase().endsWith('.jpg') || item().name.toLowerCase().endsWith('.jpeg') || item().name.toLowerCase().endsWith('.gif') || item().name.toLowerCase().endsWith('.webp') || item().name.toLowerCase().endsWith('.svg') || item().name.toLowerCase().endsWith('.bmp') || item().name.toLowerCase().endsWith('.ico')));
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(item())), () => {
		__vite_ssr_import_2__.set(isExcel, __vite_ssr_import_2__.strict_equals(item()?.meta?.content_type, 'application/vnd.ms-excel') || __vite_ssr_import_2__.strict_equals(item()?.meta?.content_type, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') || __vite_ssr_import_2__.strict_equals(item()?.meta?.content_type, 'text/csv') || __vite_ssr_import_2__.strict_equals(item()?.meta?.content_type, 'application/csv') || item()?.name && (item().name.toLowerCase().endsWith('.xls') || item().name.toLowerCase().endsWith('.xlsx') || item().name.toLowerCase().endsWith('.csv')));
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(item())), () => {
		__vite_ssr_import_2__.set(isDocx, __vite_ssr_import_2__.strict_equals(item()?.meta?.content_type, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') || item()?.name && item().name.toLowerCase().endsWith('.docx'));
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(item())), () => {
		__vite_ssr_import_2__.set(isPptx, __vite_ssr_import_2__.strict_equals(item()?.meta?.content_type, 'application/vnd.openxmlformats-officedocument.presentationml.presentation') || item()?.name && item().name.toLowerCase().endsWith('.pptx'));
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.get(selectedSheet), __vite_ssr_import_2__.get(excelWorkbook)), () => {
		if (__vite_ssr_import_2__.get(selectedSheet) && __vite_ssr_import_2__.get(excelWorkbook)) {
			renderExcelSheet();
		}
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(show())), () => {
		if (show()) {
			loadContent();
		}
	});

	__vite_ssr_import_2__.legacy_pre_effect_reset();

	var $$exports = { ...__vite_ssr_import_2__.legacy_api() };

	__vite_ssr_import_2__.init();

	{
		$$ownership_validator.binding('show', __vite_ssr_import_12__.default, show);

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_12__.default($$anchor, {
				size: 'lg',
				get show() {
					return show();
				},

				set show($$value) {
					show($$value);
				},

				children: __vite_ssr_import_2__.wrap_snippet(FileItemModal, ($$anchor, $$slotProps) => {
					var div = root_37();
					var div_1 = __vite_ssr_import_2__.child(div);
					var div_2 = __vite_ssr_import_2__.child(div_1);
					var div_3 = __vite_ssr_import_2__.child(div_2);
					var div_4 = __vite_ssr_import_2__.child(div_3);
					var a = __vite_ssr_import_2__.child(div_4);
					var text = __vite_ssr_import_2__.child(a, true);

					__vite_ssr_import_2__.reset(a);
					__vite_ssr_import_2__.reset(div_4);
					__vite_ssr_import_2__.reset(div_3);

					var div_5 = __vite_ssr_import_2__.sibling(div_3, 2);
					var button = __vite_ssr_import_2__.child(div_5);
					var node = __vite_ssr_import_2__.child(button);

					__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_13__.default(node, {}), 'component', FileItemModal, 291, 6, { componentTag: 'XMark' });
					__vite_ssr_import_2__.reset(button);
					__vite_ssr_import_2__.reset(div_5);
					__vite_ssr_import_2__.reset(div_2);

					var div_6 = __vite_ssr_import_2__.sibling(div_2, 2);
					var div_7 = __vite_ssr_import_2__.child(div_6);
					var div_8 = __vite_ssr_import_2__.child(div_7);
					var node_1 = __vite_ssr_import_2__.child(div_8);

					{
						var consequent_3 = ($$anchor) => {
							var fragment_1 = root_3();
							var node_2 = __vite_ssr_import_2__.first_child(fragment_1);

							{
								var consequent = ($$anchor) => {
									var fragment_2 = root();
									var div_9 = __vite_ssr_import_2__.first_child(fragment_2);
									var text_1 = __vite_ssr_import_2__.child(div_9, true);

									__vite_ssr_import_2__.reset(div_9);
									__vite_ssr_import_2__.next();
									__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_1, (__vite_ssr_import_2__.deep_read_state(item()), __vite_ssr_import_2__.untrack(() => item().type))));
									__vite_ssr_import_2__.append($$anchor, fragment_2);
								};

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_2__.if(node_2, ($$render) => {
										if ((__vite_ssr_import_2__.deep_read_state(item()), __vite_ssr_import_2__.untrack(() => item()?.type))) $$render(consequent);
									}),
									'if',
									FileItemModal,
									300,
									7
								);
							}

							var node_3 = __vite_ssr_import_2__.sibling(node_2, 2);

							{
								var consequent_1 = ($$anchor) => {
									var fragment_3 = root_1();
									var div_10 = __vite_ssr_import_2__.first_child(fragment_3);
									var text_2 = __vite_ssr_import_2__.child(div_10, true);

									__vite_ssr_import_2__.reset(div_10);
									__vite_ssr_import_2__.next();

									__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_2, (
										__vite_ssr_import_2__.deep_read_state(item()),
										__vite_ssr_import_2__.untrack(() => item().description)
									)));

									__vite_ssr_import_2__.append($$anchor, fragment_3);
								};

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_2__.if(node_3, ($$render) => {
										if ((
											__vite_ssr_import_2__.deep_read_state(item()),
											__vite_ssr_import_2__.untrack(() => item()?.description)
										)) $$render(consequent_1);
									}),
									'if',
									FileItemModal,
									305,
									7
								);
							}

							var node_4 = __vite_ssr_import_2__.sibling(node_3, 2);

							{
								var consequent_2 = ($$anchor) => {
									var div_11 = root_2();
									var text_3 = __vite_ssr_import_2__.child(div_11, true);

									__vite_ssr_import_2__.reset(div_11);

									__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_3, $0), [
										() => (
											__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_16__.default),
											__vite_ssr_import_2__.deep_read_state(item()),
											__vite_ssr_import_2__.untrack(() => __vite_ssr_import_16__.default(item().created_at * 1000).format('LL'))
										)
									]);

									__vite_ssr_import_2__.append($$anchor, div_11);
								};

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_2__.if(node_4, ($$render) => {
										if ((
											__vite_ssr_import_2__.deep_read_state(item()),
											__vite_ssr_import_2__.untrack(() => item()?.created_at)
										)) $$render(consequent_2);
									}),
									'if',
									FileItemModal,
									310,
									7
								);
							}

							__vite_ssr_import_2__.append($$anchor, fragment_1);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_1, ($$render) => {
								if ((
									__vite_ssr_import_2__.deep_read_state(item()),
									__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(item()?.type, 'collection'))
								)) $$render(consequent_3);
							}),
							'if',
							FileItemModal,
							299,
							6
						);
					}

					var node_5 = __vite_ssr_import_2__.sibling(node_1, 2);

					{
						var consequent_4 = ($$anchor) => {
							var fragment_4 = root_4();
							var div_12 = __vite_ssr_import_2__.first_child(fragment_4);
							var text_4 = __vite_ssr_import_2__.child(div_12, true);

							__vite_ssr_import_2__.reset(div_12);
							__vite_ssr_import_2__.next();

							__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_4, $0), [
								() => (
									__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_5__.formatFileSize),
									__vite_ssr_import_2__.deep_read_state(item()),
									__vite_ssr_import_2__.untrack(() => __vite_ssr_import_5__.formatFileSize(item().size))
								)
							]);

							__vite_ssr_import_2__.append($$anchor, fragment_4);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_5, ($$render) => {
								if ((__vite_ssr_import_2__.deep_read_state(item()), __vite_ssr_import_2__.untrack(() => item().size))) $$render(consequent_4);
							}),
							'if',
							FileItemModal,
							317,
							6
						);
					}

					var node_6 = __vite_ssr_import_2__.sibling(node_5, 2);

					{
						var consequent_6 = ($$anchor) => {
							var fragment_5 = root_5();
							var div_13 = __vite_ssr_import_2__.first_child(fragment_5);
							var node_7 = __vite_ssr_import_2__.child(div_13);

							{
								var consequent_5 = ($$anchor) => {
									var text_5 = __vite_ssr_import_2__.text();

									__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_5, $0), [
										() => (
											$i18n(),
											__vite_ssr_import_2__.get(rowCount),
											__vite_ssr_import_2__.untrack(() => $i18n().t('{{COUNT}} Rows', { COUNT: __vite_ssr_import_2__.get(rowCount) }))
										)
									]);

									__vite_ssr_import_2__.append($$anchor, text_5);
								};

								var alternate = ($$anchor) => {
									var text_6 = __vite_ssr_import_2__.text();

									__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_6, $0), [
										() => (
											$i18n(),
											__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_5__.getLineCount),
											__vite_ssr_import_2__.deep_read_state(item()),
											__vite_ssr_import_2__.untrack(() => $i18n().t('{{COUNT}} extracted lines', { COUNT: __vite_ssr_import_5__.getLineCount(item()?.file?.data?.content ?? '') }))
										)
									]);

									__vite_ssr_import_2__.append($$anchor, text_6);
								};

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_2__.if(node_7, ($$render) => {
										if (__vite_ssr_import_2__.get(isExcel) && __vite_ssr_import_2__.get(rowCount) > 0 && __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(selectedTab), 'preview')) $$render(consequent_5); else $$render(alternate, -1);
									}),
									'if',
									FileItemModal,
									324,
									8
								);
							}

							__vite_ssr_import_2__.reset(div_13);

							var div_14 = __vite_ssr_import_2__.sibling(div_13, 2);
							var text_7 = __vite_ssr_import_2__.child(div_14);

							__vite_ssr_import_2__.reset(div_14);

							__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_7, `• ${$0 ?? ''}`), [
								() => (
									$i18n(),
									__vite_ssr_import_2__.untrack(() => $i18n().t('Formatting may be inconsistent from source.'))
								)
							]);

							__vite_ssr_import_2__.append($$anchor, fragment_5);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_6, ($$render) => {
								if ((
									__vite_ssr_import_2__.deep_read_state(item()),
									__vite_ssr_import_2__.untrack(() => item()?.file?.data?.content)
								)) $$render(consequent_6);
							}),
							'if',
							FileItemModal,
							322,
							6
						);
					}

					var node_8 = __vite_ssr_import_2__.sibling(node_6, 2);

					{
						var consequent_7 = ($$anchor) => {
							var div_15 = root_6();
							var text_8 = __vite_ssr_import_2__.child(div_15, true);

							__vite_ssr_import_2__.reset(div_15);

							__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_8, $0), [
								() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Knowledge Base')))
							]);

							__vite_ssr_import_2__.append($$anchor, div_15);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_8, ($$render) => {
								if ((
									__vite_ssr_import_2__.deep_read_state(item()),
									__vite_ssr_import_2__.untrack(() => item()?.knowledge)
								)) $$render(consequent_7);
							}),
							'if',
							FileItemModal,
							340,
							6
						);
					}

					__vite_ssr_import_2__.reset(div_8);

					var node_9 = __vite_ssr_import_2__.sibling(div_8, 2);

					{
						var consequent_9 = ($$anchor) => {
							var div_16 = root_8();
							var node_10 = __vite_ssr_import_2__.child(div_16);

							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
									__vite_ssr_import_2__.get(enableFullContent),
									$i18n(),
									__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(enableFullContent)
										? $i18n().t('Inject the entire content as context for comprehensive processing, this is recommended for complex queries.')
										: $i18n().t('Default to segmented retrieval for focused and relevant content extraction, this is recommended for most cases.'))
								));

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_15__.default(node_10, {
										get content() {
											return __vite_ssr_import_2__.get($0);
										},

										children: __vite_ssr_import_2__.wrap_snippet(FileItemModal, ($$anchor, $$slotProps) => {
											var div_17 = root_7();
											var node_11 = __vite_ssr_import_2__.child(div_17);

											{
												var consequent_8 = ($$anchor) => {
													var text_9 = __vite_ssr_import_2__.text();

													__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_9, $0), [
														() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Using Entire Document')))
													]);

													__vite_ssr_import_2__.append($$anchor, text_9);
												};

												var alternate_1 = ($$anchor) => {
													var text_10 = __vite_ssr_import_2__.text();

													__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_10, $0), [
														() => (
															$i18n(),
															__vite_ssr_import_2__.untrack(() => $i18n().t('Using Focused Retrieval'))
														)
													]);

													__vite_ssr_import_2__.append($$anchor, text_10);
												};

												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_2__.if(node_11, ($$render) => {
														if (__vite_ssr_import_2__.get(enableFullContent)) $$render(consequent_8); else $$render(alternate_1, -1);
													}),
													'if',
													FileItemModal,
													359,
													9
												);
											}

											var node_12 = __vite_ssr_import_2__.sibling(node_11, 2);

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_14__.default(node_12, {
													get state() {
														return __vite_ssr_import_2__.get(enableFullContent);
													},

													set state($$value) {
														__vite_ssr_import_2__.set(enableFullContent, $$value);
													},

													$$events: {
														change: (e) => {
															$$ownership_validator.mutation(null, ['item', 'context'], item(item().context = e.detail ? 'full' : undefined, true), 367, 11);
														}
													},
													$$legacy: true
												}),
												'component',
												FileItemModal,
												364,
												9,
												{ componentTag: 'Switch' }
											);

											__vite_ssr_import_2__.reset(div_17);
											__vite_ssr_import_2__.append($$anchor, div_17);
										}),
										$$slots: { default: true }
									}),
									'component',
									FileItemModal,
									349,
									7,
									{ componentTag: 'Tooltip' }
								);
							}

							__vite_ssr_import_2__.reset(div_16);
							__vite_ssr_import_2__.append($$anchor, div_16);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_9, ($$render) => {
								if (edit()) $$render(consequent_9);
							}),
							'if',
							FileItemModal,
							347,
							5
						);
					}

					__vite_ssr_import_2__.reset(div_7);
					__vite_ssr_import_2__.reset(div_6);
					__vite_ssr_import_2__.reset(div_1);

					var div_18 = __vite_ssr_import_2__.sibling(div_1, 2);
					var node_13 = __vite_ssr_import_2__.child(div_18);

					{
						var consequent_35 = ($$anchor) => {
							var fragment_10 = root_35();
							var node_14 = __vite_ssr_import_2__.first_child(fragment_10);

							{
								var consequent_10 = ($$anchor) => {
									var div_19 = root_10();

									__vite_ssr_import_2__.add_svelte_meta(
										() => __vite_ssr_import_2__.each(div_19, 5, () => (__vite_ssr_import_2__.deep_read_state(item()), __vite_ssr_import_2__.untrack(() => item()?.files)), __vite_ssr_import_2__.index, ($$anchor, file) => {
											var div_20 = root_9();
											var div_21 = __vite_ssr_import_2__.child(div_20);
											var text_11 = __vite_ssr_import_2__.child(div_21, true);

											__vite_ssr_import_2__.reset(div_21);
											__vite_ssr_import_2__.reset(div_20);
											__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_11, (__vite_ssr_import_2__.get(file), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(file)?.meta?.name))));
											__vite_ssr_import_2__.append($$anchor, div_20);
										}),
										'each',
										FileItemModal,
										382,
										6
									);

									__vite_ssr_import_2__.reset(div_19);
									__vite_ssr_import_2__.append($$anchor, div_19);
								};

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_2__.if(node_14, ($$render) => {
										if ((
											__vite_ssr_import_2__.deep_read_state(item()),
											__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(item()?.type, 'collection'))
										)) $$render(consequent_10);
									}),
									'if',
									FileItemModal,
									380,
									4
								);
							}

							var node_15 = __vite_ssr_import_2__.sibling(node_14, 2);

							{
								var consequent_11 = ($$anchor) => {
									var div_22 = root_11();
									var button_1 = __vite_ssr_import_2__.child(div_22);
									var text_12 = __vite_ssr_import_2__.child(button_1, true);

									__vite_ssr_import_2__.reset(button_1);

									var button_2 = __vite_ssr_import_2__.sibling(button_1, 2);
									var text_13 = __vite_ssr_import_2__.child(button_2, true);

									__vite_ssr_import_2__.reset(button_2);
									__vite_ssr_import_2__.reset(div_22);

									__vite_ssr_import_2__.template_effect(
										($0, $1) => {
											__vite_ssr_import_2__.set_class(button_1, 1, `min-w-fit py-1.5 px-4 border-b ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(selectedTab), '')
												? ' '
												: ' border-transparent text-gray-300 dark:text-gray-600 hover:text-gray-700 dark:hover:text-white'} transition`);

											__vite_ssr_import_2__.set_text(text_12, $0);

											__vite_ssr_import_2__.set_class(button_2, 1, `min-w-fit py-1.5 px-4 border-b ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(selectedTab), 'preview')
												? ' '
												: ' border-transparent text-gray-300 dark:text-gray-600 hover:text-gray-700 dark:hover:text-white'} transition`);

											__vite_ssr_import_2__.set_text(text_13, $1);
										},
										[
											() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Content'))),
											() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Preview')))
										]
									);

									__vite_ssr_import_2__.event('click', button_1, function click_1() {
										__vite_ssr_import_2__.set(selectedTab, '');
									});

									__vite_ssr_import_2__.event('click', button_2, function click_2() {
										__vite_ssr_import_2__.set(selectedTab, 'preview');
									});

									__vite_ssr_import_2__.append($$anchor, div_22);
								};

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_2__.if(node_15, ($$render) => {
										if (__vite_ssr_import_2__.get(isAudio) || __vite_ssr_import_2__.get(isPDF) || __vite_ssr_import_2__.get(isExcel) || __vite_ssr_import_2__.get(isCode) || __vite_ssr_import_2__.get(isMarkdown) || __vite_ssr_import_2__.get(isDocx) || __vite_ssr_import_2__.get(isPptx)) $$render(consequent_11);
									}),
									'if',
									FileItemModal,
									392,
									4
								);
							}

							var node_16 = __vite_ssr_import_2__.sibling(node_15, 2);

							{
								var consequent_12 = ($$anchor) => {
									var div_23 = root_14();
									var div_24 = __vite_ssr_import_2__.child(div_23);
									var node_17 = __vite_ssr_import_2__.child(div_24);

									{
										let $0 = __vite_ssr_import_2__.derived_safe_equal(() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Reset view'))));

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_15__.default(node_17, {
												get content() {
													return __vite_ssr_import_2__.get($0);
												},

												children: __vite_ssr_import_2__.wrap_snippet(FileItemModal, ($$anchor, $$slotProps) => {
													var button_3 = root_12();
													var node_18 = __vite_ssr_import_2__.child(button_3);

													__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_22__.default(node_18, { className: 'size-4' }), 'component', FileItemModal, 426, 9, { componentTag: 'Reset' });
													__vite_ssr_import_2__.reset(button_3);
													__vite_ssr_import_2__.event('click', button_3, resetImageView);
													__vite_ssr_import_2__.append($$anchor, button_3);
												}),
												$$slots: { default: true }
											}),
											'component',
											FileItemModal,
											421,
											7,
											{ componentTag: 'Tooltip' }
										);
									}

									__vite_ssr_import_2__.reset(div_24);

									var node_19 = __vite_ssr_import_2__.sibling(div_24, 2);

									__vite_ssr_import_2__.add_svelte_meta(
										() => __vite_ssr_import_2__.bind_this(
											__vite_ssr_import_19__.default(node_19, {
												children: __vite_ssr_import_2__.wrap_snippet(FileItemModal, ($$anchor, $$slotProps) => {
													var img = root_13();

													__vite_ssr_import_2__.template_effect(() => {
														__vite_ssr_import_2__.set_attribute(img, 'src', (
															__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_6__.WEBUI_API_BASE_URL),
															__vite_ssr_import_2__.deep_read_state(item()),
															__vite_ssr_import_2__.untrack(() => `${__vite_ssr_import_6__.WEBUI_API_BASE_URL}/files/${item().id}/content`)
														));

														__vite_ssr_import_2__.set_attribute(img, 'alt', (
															__vite_ssr_import_2__.deep_read_state(item()),
															__vite_ssr_import_2__.untrack(() => item()?.name ?? 'Image')
														));
													});

													__vite_ssr_import_2__.append($$anchor, img);
												}),
												$$slots: { default: true },
												$$legacy: true
											}),
											($$value) => __vite_ssr_import_2__.set(panzoomRef, $$value),
											() => __vite_ssr_import_2__.get(panzoomRef)
										),
										'component',
										FileItemModal,
										430,
										6,
										{ componentTag: 'PanzoomContainer' }
									);

									__vite_ssr_import_2__.reset(div_23);
									__vite_ssr_import_2__.append($$anchor, div_23);
								};

								var consequent_19 = ($$anchor) => {
									var fragment_11 = __vite_ssr_import_2__.comment();
									var node_20 = __vite_ssr_import_2__.first_child(fragment_11);

									{
										var consequent_15 = ($$anchor) => {
											const rawContent = __vite_ssr_import_2__.tag(
												__vite_ssr_import_2__.derived_safe_equal(() => (
													__vite_ssr_import_2__.deep_read_state(item()),
													__vite_ssr_import_2__.untrack(() => (item()?.file?.data?.content ?? '').trim() || 'No content')
												)),
												'rawContent'
											);

											__vite_ssr_import_2__.get(rawContent);

											const isTruncated = __vite_ssr_import_2__.tag(
												__vite_ssr_import_2__.derived_safe_equal(() => (
													$settings(),
													__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_2__.get(rawContent)),
													__vite_ssr_import_2__.get(expandedContent),
													__vite_ssr_import_2__.untrack(() => ($settings()?.renderMarkdownInPreviews ?? true) && __vite_ssr_import_2__.get(rawContent).length > CONTENT_PREVIEW_LIMIT && !__vite_ssr_import_2__.get(expandedContent))
												)),
												'isTruncated'
											);

											__vite_ssr_import_2__.get(isTruncated);

											var fragment_12 = __vite_ssr_import_2__.comment();
											var node_21 = __vite_ssr_import_2__.first_child(fragment_12);

											{
												var consequent_14 = ($$anchor) => {
													var fragment_13 = root_16();
													var div_25 = __vite_ssr_import_2__.first_child(fragment_13);
													var node_22 = __vite_ssr_import_2__.child(div_25);

													{
														let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
															__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_2__.get(isTruncated)),
															__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_2__.get(rawContent)),
															__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(isTruncated)
																? __vite_ssr_import_2__.get(rawContent).slice(0, CONTENT_PREVIEW_LIMIT)
																: __vite_ssr_import_2__.get(rawContent))
														));

														__vite_ssr_import_2__.add_svelte_meta(
															() => __vite_ssr_import_11__.default(node_22, {
																get content() {
																	return __vite_ssr_import_2__.get($0);
																},
																id: 'file-preview'
															}),
															'component',
															FileItemModal,
															451,
															8,
															{ componentTag: 'Markdown' }
														);
													}

													__vite_ssr_import_2__.reset(div_25);

													var node_23 = __vite_ssr_import_2__.sibling(div_25, 2);

													{
														var consequent_13 = ($$anchor) => {
															var button_4 = root_15();
															var text_14 = __vite_ssr_import_2__.child(button_4, true);

															__vite_ssr_import_2__.reset(button_4);

															__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_14, $0), [
																() => (
																	$i18n(),
																	__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_2__.get(rawContent)),
																	__vite_ssr_import_2__.untrack(() => $i18n().t('Show all ({{COUNT}} characters)', { COUNT: __vite_ssr_import_2__.get(rawContent).length.toLocaleString() }))
																)
															]);

															__vite_ssr_import_2__.event('click', button_4, function click_3() {
																__vite_ssr_import_2__.set(expandedContent, true);
															});

															__vite_ssr_import_2__.append($$anchor, button_4);
														};

														__vite_ssr_import_2__.add_svelte_meta(
															() => __vite_ssr_import_2__.if(node_23, ($$render) => {
																if (__vite_ssr_import_2__.get(isTruncated)) $$render(consequent_13);
															}),
															'if',
															FileItemModal,
															456,
															7
														);
													}

													__vite_ssr_import_2__.append($$anchor, fragment_13);
												};

												var alternate_2 = ($$anchor) => {
													var div_26 = root_17();
													var text_15 = __vite_ssr_import_2__.child(div_26, true);

													__vite_ssr_import_2__.reset(div_26);
													__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_15, __vite_ssr_import_2__.get(rawContent)));
													__vite_ssr_import_2__.append($$anchor, div_26);
												};

												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_2__.if(node_21, ($$render) => {
														if ((
															$settings(),
															__vite_ssr_import_2__.untrack(() => $settings()?.renderMarkdownInPreviews ?? true)
														)) $$render(consequent_14); else $$render(alternate_2, -1);
													}),
													'if',
													FileItemModal,
													447,
													6
												);
											}

											__vite_ssr_import_2__.append($$anchor, fragment_12);
										};

										var consequent_18 = ($$anchor) => {
											const rawContent = __vite_ssr_import_2__.tag(
												__vite_ssr_import_2__.derived_safe_equal(() => (
													__vite_ssr_import_2__.deep_read_state(item()),
													__vite_ssr_import_2__.untrack(() => (item()?.content ?? '').trim() || 'No content')
												)),
												'rawContent'
											);

											__vite_ssr_import_2__.get(rawContent);

											const isTruncated = __vite_ssr_import_2__.tag(
												__vite_ssr_import_2__.derived_safe_equal(() => (
													$settings(),
													__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_2__.get(rawContent)),
													__vite_ssr_import_2__.get(expandedContent),
													__vite_ssr_import_2__.untrack(() => ($settings()?.renderMarkdownInPreviews ?? true) && __vite_ssr_import_2__.get(rawContent).length > CONTENT_PREVIEW_LIMIT && !__vite_ssr_import_2__.get(expandedContent))
												)),
												'isTruncated'
											);

											__vite_ssr_import_2__.get(isTruncated);

											var fragment_14 = __vite_ssr_import_2__.comment();
											var node_24 = __vite_ssr_import_2__.first_child(fragment_14);

											{
												var consequent_17 = ($$anchor) => {
													var fragment_15 = root_19();
													var div_27 = __vite_ssr_import_2__.first_child(fragment_15);
													var node_25 = __vite_ssr_import_2__.child(div_27);

													{
														let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
															__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_2__.get(isTruncated)),
															__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_2__.get(rawContent)),
															__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(isTruncated)
																? __vite_ssr_import_2__.get(rawContent).slice(0, CONTENT_PREVIEW_LIMIT)
																: __vite_ssr_import_2__.get(rawContent))
														));

														__vite_ssr_import_2__.add_svelte_meta(
															() => __vite_ssr_import_11__.default(node_25, {
																get content() {
																	return __vite_ssr_import_2__.get($0);
																},
																id: 'file-preview-content'
															}),
															'component',
															FileItemModal,
															483,
															8,
															{ componentTag: 'Markdown' }
														);
													}

													__vite_ssr_import_2__.reset(div_27);

													var node_26 = __vite_ssr_import_2__.sibling(div_27, 2);

													{
														var consequent_16 = ($$anchor) => {
															var button_5 = root_18();
															var text_16 = __vite_ssr_import_2__.child(button_5, true);

															__vite_ssr_import_2__.reset(button_5);

															__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_16, $0), [
																() => (
																	$i18n(),
																	__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_2__.get(rawContent)),
																	__vite_ssr_import_2__.untrack(() => $i18n().t('Show all ({{COUNT}} characters)', { COUNT: __vite_ssr_import_2__.get(rawContent).length.toLocaleString() }))
																)
															]);

															__vite_ssr_import_2__.event('click', button_5, function click_4() {
																__vite_ssr_import_2__.set(expandedContent, true);
															});

															__vite_ssr_import_2__.append($$anchor, button_5);
														};

														__vite_ssr_import_2__.add_svelte_meta(
															() => __vite_ssr_import_2__.if(node_26, ($$render) => {
																if (__vite_ssr_import_2__.get(isTruncated)) $$render(consequent_16);
															}),
															'if',
															FileItemModal,
															488,
															7
														);
													}

													__vite_ssr_import_2__.append($$anchor, fragment_15);
												};

												var alternate_3 = ($$anchor) => {
													var div_28 = root_20();
													var text_17 = __vite_ssr_import_2__.child(div_28, true);

													__vite_ssr_import_2__.reset(div_28);
													__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_17, __vite_ssr_import_2__.get(rawContent)));
													__vite_ssr_import_2__.append($$anchor, div_28);
												};

												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_2__.if(node_24, ($$render) => {
														if ((
															$settings(),
															__vite_ssr_import_2__.untrack(() => $settings()?.renderMarkdownInPreviews ?? true)
														)) $$render(consequent_17); else $$render(alternate_3, -1);
													}),
													'if',
													FileItemModal,
													479,
													6
												);
											}

											__vite_ssr_import_2__.append($$anchor, fragment_14);
										};

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_2__.if(node_20, ($$render) => {
												if ((
													__vite_ssr_import_2__.deep_read_state(item()),
													__vite_ssr_import_2__.untrack(() => item()?.file?.data)
												)) $$render(consequent_15); else if ((__vite_ssr_import_2__.deep_read_state(item()), __vite_ssr_import_2__.untrack(() => item()?.content))) $$render(consequent_18, 1);
											}),
											'if',
											FileItemModal,
											441,
											5
										);
									}

									__vite_ssr_import_2__.append($$anchor, fragment_11);
								};

								var consequent_34 = ($$anchor) => {
									var fragment_16 = __vite_ssr_import_2__.comment();
									var node_27 = __vite_ssr_import_2__.first_child(fragment_16);

									{
										var consequent_20 = ($$anchor) => {
											var audio = root_21();

											__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_attribute(audio, 'src', (
												__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_6__.WEBUI_API_BASE_URL),
												__vite_ssr_import_2__.deep_read_state(item()),
												__vite_ssr_import_2__.untrack(() => `${__vite_ssr_import_6__.WEBUI_API_BASE_URL}/files/${item().id}/content`)
											)));

											__vite_ssr_import_2__.append($$anchor, audio);
										};

										var consequent_21 = ($$anchor) => {
											{
												let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
													__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_6__.WEBUI_API_BASE_URL),
													__vite_ssr_import_2__.deep_read_state(item()),
													__vite_ssr_import_2__.untrack(() => `${__vite_ssr_import_6__.WEBUI_API_BASE_URL}/files/${item().id}/content`)
												));

												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_18__.default($$anchor, {
														get url() {
															return __vite_ssr_import_2__.get($0);
														},
														className: 'w-full h-[70vh] border-0 rounded-lg'
													}),
													'component',
													FileItemModal,
													515,
													6,
													{ componentTag: 'PDFViewer' }
												);
											}
										};

										var consequent_25 = ($$anchor) => {
											var fragment_18 = __vite_ssr_import_2__.comment();
											var node_28 = __vite_ssr_import_2__.first_child(fragment_18);

											{
												var consequent_22 = ($$anchor) => {
													var div_29 = root_22();
													var text_18 = __vite_ssr_import_2__.child(div_29, true);

													__vite_ssr_import_2__.reset(div_29);
													__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_18, __vite_ssr_import_2__.get(excelError)));
													__vite_ssr_import_2__.append($$anchor, div_29);
												};

												var alternate_5 = ($$anchor) => {
													var fragment_19 = root_27();
													var node_29 = __vite_ssr_import_2__.first_child(fragment_19);

													{
														var consequent_23 = ($$anchor) => {
															var div_30 = root_24();

															__vite_ssr_import_2__.add_svelte_meta(
																() => __vite_ssr_import_2__.each(div_30, 5, () => __vite_ssr_import_2__.get(excelSheetNames), __vite_ssr_import_2__.index, ($$anchor, sheetName) => {
																	var button_6 = root_23();
																	var text_19 = __vite_ssr_import_2__.child(button_6, true);

																	__vite_ssr_import_2__.reset(button_6);

																	__vite_ssr_import_2__.template_effect(() => {
																		__vite_ssr_import_2__.set_class(button_6, 1, `min-w-fit py-1.5 px-4 border-b ${__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(selectedSheet), __vite_ssr_import_2__.get(sheetName))
																			? ' '
																			: ' border-transparent text-gray-300 dark:text-gray-600 hover:text-gray-700 dark:hover:text-white'} transition`);

																		__vite_ssr_import_2__.set_text(text_19, __vite_ssr_import_2__.get(sheetName));
																	});

																	__vite_ssr_import_2__.event('click', button_6, function click_5() {
																		__vite_ssr_import_2__.set(selectedSheet, __vite_ssr_import_2__.get(sheetName));
																	});

																	__vite_ssr_import_2__.append($$anchor, button_6);
																}),
																'each',
																FileItemModal,
																529,
																9
															);

															__vite_ssr_import_2__.reset(div_30);
															__vite_ssr_import_2__.append($$anchor, div_30);
														};

														__vite_ssr_import_2__.add_svelte_meta(
															() => __vite_ssr_import_2__.if(node_29, ($$render) => {
																if ((
																	__vite_ssr_import_2__.get(excelSheetNames),
																	__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(excelSheetNames).length > 1)
																)) $$render(consequent_23);
															}),
															'if',
															FileItemModal,
															525,
															7
														);
													}

													var node_30 = __vite_ssr_import_2__.sibling(node_29, 2);

													{
														var consequent_24 = ($$anchor) => {
															var div_31 = root_25();

															__vite_ssr_import_2__.html(div_31, () => __vite_ssr_import_2__.get(excelHtml), true);
															__vite_ssr_import_2__.reset(div_31);
															__vite_ssr_import_2__.append($$anchor, div_31);
														};

														var alternate_4 = ($$anchor) => {
															var div_32 = root_26();

															__vite_ssr_import_2__.append($$anchor, div_32);
														};

														__vite_ssr_import_2__.add_svelte_meta(
															() => __vite_ssr_import_2__.if(node_30, ($$render) => {
																if (__vite_ssr_import_2__.get(excelHtml)) $$render(consequent_24); else $$render(alternate_4, -1);
															}),
															'if',
															FileItemModal,
															543,
															7
														);
													}

													__vite_ssr_import_2__.append($$anchor, fragment_19);
												};

												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_2__.if(node_28, ($$render) => {
														if (__vite_ssr_import_2__.get(excelError)) $$render(consequent_22); else $$render(alternate_5, -1);
													}),
													'if',
													FileItemModal,
													520,
													6
												);
											}

											__vite_ssr_import_2__.append($$anchor, fragment_18);
										};

										var consequent_26 = ($$anchor) => {
											var div_33 = root_28();
											var node_31 = __vite_ssr_import_2__.child(div_33);

											{
												let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
													__vite_ssr_import_2__.deep_read_state(item()),
													__vite_ssr_import_2__.untrack(() => item().name.split('.').pop())
												));

												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_10__.default(node_31, {
														get code() {
															return (
																__vite_ssr_import_2__.deep_read_state(item()),
																__vite_ssr_import_2__.untrack(() => item().file.data.content)
															);
														},

														get lang() {
															return __vite_ssr_import_2__.get($0);
														},
														token: null,
														edit: false,
														run: false,
														save: false
													}),
													'component',
													FileItemModal,
													553,
													7,
													{ componentTag: 'CodeBlock' }
												);
											}

											__vite_ssr_import_2__.reset(div_33);
											__vite_ssr_import_2__.append($$anchor, div_33);
										};

										var consequent_27 = ($$anchor) => {
											var div_34 = root_29();
											var node_32 = __vite_ssr_import_2__.child(div_34);

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_11__.default(node_32, {
													get content() {
														return (
															__vite_ssr_import_2__.deep_read_state(item()),
															__vite_ssr_import_2__.untrack(() => item().file.data.content)
														);
													},
													id: 'markdown-viewer'
												}),
												'component',
												FileItemModal,
												566,
												7,
												{ componentTag: 'Markdown' }
											);

											__vite_ssr_import_2__.reset(div_34);
											__vite_ssr_import_2__.append($$anchor, div_34);
										};

										var consequent_30 = ($$anchor) => {
											var fragment_20 = __vite_ssr_import_2__.comment();
											var node_33 = __vite_ssr_import_2__.first_child(fragment_20);

											{
												var consequent_28 = ($$anchor) => {
													var div_35 = root_30();
													var text_20 = __vite_ssr_import_2__.child(div_35, true);

													__vite_ssr_import_2__.reset(div_35);
													__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_20, __vite_ssr_import_2__.get(docxError)));
													__vite_ssr_import_2__.append($$anchor, div_35);
												};

												var consequent_29 = ($$anchor) => {
													__vite_ssr_import_2__.add_svelte_meta(
														() => __vite_ssr_import_20__.default($$anchor, {
															get data() {
																return __vite_ssr_import_2__.get(docxData);
															},
															className: 'h-[60vh]'
														}),
														'component',
														FileItemModal,
														572,
														7,
														{ componentTag: 'DocxPreview' }
													);
												};

												var alternate_6 = ($$anchor) => {
													var div_36 = root_31();

													__vite_ssr_import_2__.append($$anchor, div_36);
												};

												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_2__.if(node_33, ($$render) => {
														if (__vite_ssr_import_2__.get(docxError)) $$render(consequent_28); else if (__vite_ssr_import_2__.get(docxData)) $$render(consequent_29, 1); else $$render(alternate_6, -1);
													}),
													'if',
													FileItemModal,
													569,
													6
												);
											}

											__vite_ssr_import_2__.append($$anchor, fragment_20);
										};

										var consequent_33 = ($$anchor) => {
											var fragment_22 = __vite_ssr_import_2__.comment();
											var node_34 = __vite_ssr_import_2__.first_child(fragment_22);

											{
												var consequent_31 = ($$anchor) => {
													var div_37 = root_32();
													var text_21 = __vite_ssr_import_2__.child(div_37, true);

													__vite_ssr_import_2__.reset(div_37);
													__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_21, __vite_ssr_import_2__.get(pptxError)));
													__vite_ssr_import_2__.append($$anchor, div_37);
												};

												var consequent_32 = ($$anchor) => {
													__vite_ssr_import_2__.add_svelte_meta(
														() => __vite_ssr_import_21__.default($$anchor, {
															get slides() {
																return __vite_ssr_import_2__.get(pptxSlides);
															},
															className: 'h-[60vh]',
															get currentSlide() {
																return __vite_ssr_import_2__.get(pptxCurrentSlide);
															},

															set currentSlide($$value) {
																__vite_ssr_import_2__.set(pptxCurrentSlide, $$value);
															},
															$$legacy: true
														}),
														'component',
														FileItemModal,
														580,
														7,
														{ componentTag: 'PptxPreview' }
													);
												};

												var alternate_7 = ($$anchor) => {
													var div_38 = root_33();

													__vite_ssr_import_2__.append($$anchor, div_38);
												};

												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_2__.if(node_34, ($$render) => {
														if (__vite_ssr_import_2__.get(pptxError)) $$render(consequent_31); else if ((
															__vite_ssr_import_2__.get(pptxSlides),
															__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(pptxSlides).length > 0)
														)) $$render(consequent_32, 1); else $$render(alternate_7, -1);
													}),
													'if',
													FileItemModal,
													577,
													6
												);
											}

											__vite_ssr_import_2__.append($$anchor, fragment_22);
										};

										var alternate_8 = ($$anchor) => {
											var div_39 = root_34();
											var text_22 = __vite_ssr_import_2__.child(div_39, true);

											__vite_ssr_import_2__.reset(div_39);

											__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_22, $0), [
												() => (
													__vite_ssr_import_2__.deep_read_state(item()),
													__vite_ssr_import_2__.untrack(() => (item()?.file?.data?.content ?? '').trim() || 'No content')
												)
											]);

											__vite_ssr_import_2__.append($$anchor, div_39);
										};

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_2__.if(node_27, ($$render) => {
												if (__vite_ssr_import_2__.get(isAudio)) $$render(consequent_20); else if (__vite_ssr_import_2__.get(isPDF)) $$render(consequent_21, 1); else if (__vite_ssr_import_2__.get(isExcel)) $$render(consequent_25, 2); else if (__vite_ssr_import_2__.get(isCode)) $$render(consequent_26, 3); else if (__vite_ssr_import_2__.get(isMarkdown)) $$render(consequent_27, 4); else if (__vite_ssr_import_2__.get(isDocx)) $$render(consequent_30, 5); else if (__vite_ssr_import_2__.get(isPptx)) $$render(consequent_33, 6); else $$render(alternate_8, -1);
											}),
											'if',
											FileItemModal,
											507,
											5
										);
									}

									__vite_ssr_import_2__.append($$anchor, fragment_16);
								};

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_2__.if(node_16, ($$render) => {
										if (__vite_ssr_import_2__.get(isImage)) $$render(consequent_12); else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(selectedTab), '')) $$render(consequent_19, 1); else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(selectedTab), 'preview')) $$render(consequent_34, 2);
									}),
									'if',
									FileItemModal,
									418,
									4
								);
							}

							__vite_ssr_import_2__.append($$anchor, fragment_10);
						};

						var alternate_9 = ($$anchor) => {
							var div_40 = root_36();
							var node_35 = __vite_ssr_import_2__.child(div_40);

							__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_17__.default(node_35, { className: 'size-5' }), 'component', FileItemModal, 596, 5, { componentTag: 'Spinner' });
							__vite_ssr_import_2__.reset(div_40);
							__vite_ssr_import_2__.append($$anchor, div_40);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_13, ($$render) => {
								if (!__vite_ssr_import_2__.get(loading)) $$render(consequent_35); else $$render(alternate_9, -1);
							}),
							'if',
							FileItemModal,
							379,
							3
						);
					}

					__vite_ssr_import_2__.reset(div_18);
					__vite_ssr_import_2__.reset(div);

					__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text, (
						__vite_ssr_import_2__.deep_read_state(item()),
						__vite_ssr_import_2__.untrack(() => item()?.name ?? 'File')
					)));

					__vite_ssr_import_2__.event('click', a, __vite_ssr_import_2__.preventDefault(() => {
						if (__vite_ssr_import_2__.strict_equals(item().type, 'file') || item().url) {
							let fileId = item()?.id ?? item()?.tempId;

							window.open(
								__vite_ssr_import_2__.strict_equals(item().type, 'file')
									? item()?.url?.startsWith('http')
										? item().url
										: `${__vite_ssr_import_6__.WEBUI_API_BASE_URL}/files/${fileId}/content`
									: item().url,
								'_blank'
							);
						}
					}));

					__vite_ssr_import_2__.event('click', button, function click() {
						show(false);
					});

					__vite_ssr_import_2__.append($$anchor, div);
				}),
				$$slots: { default: true },
				$$legacy: true
			}),
			'component',
			FileItemModal,
			257,
			0,
			{ componentTag: 'Modal' }
		);
	}

	var $$pop = __vite_ssr_import_2__.pop($$exports);

	$$cleanup();

	return $$pop;
}


Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: FileItemModal });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRWtDO0FBRWlCO0FBRU87QUFDTjtBQUNiO0FBQ2dCO0FBQ1c7QUFFSztBQUNGO0FBT2xDO0FBQ087QUFDTDtBQUNFO0FBQ2I7QUFDYTtBQUNJO0FBQ2M7QUFDVjtBQUNBO0FBQ0w7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBDQTlCMUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWVBLE1BQU0sSUFBSSxHQUFHLGdDQUFVLENBQUMsTUFBTTtDQUU5QixNQUFNLHFCQUFxQixHQUFHLEtBQUs7Q0FDbkMsSUFBSSxlQUFlLGtFQUFHLEtBQUs7Q0FjcEIsSUFBSSxJQUFJO0NBQ1IsSUFBSSxJQUFJLG1EQUFHLEtBQUs7Q0FDaEIsSUFBSSxJQUFJLGtEQUFHLEtBQUs7Q0FFdkIsSUFBSSxpQkFBaUIsa0VBQUcsS0FBSztDQUM3QixJQUFJLE9BQU8sa0VBQUcsS0FBSztDQUVuQixJQUFJLEtBQUssa0VBQUcsS0FBSztDQUNqQixJQUFJLE9BQU8sa0VBQUcsS0FBSztDQUNuQixJQUFJLE9BQU8sa0VBQUcsS0FBSztDQUNuQixJQUFJLE9BQU8sa0VBQUcsS0FBSztDQUNuQixJQUFJLE1BQU0sa0VBQUcsS0FBSztDQUNsQixJQUFJLE1BQU0sa0VBQUcsS0FBSztDQUVsQixJQUFJLFdBQVcsa0VBQUcsRUFBRTtDQUNwQixJQUFJLGFBQThCLGtFQUFHLElBQUk7Q0FDekMsSUFBSSxlQUF5QjtDQUM3QixJQUFJLGFBQWEsa0VBQUcsRUFBRTtDQUN0QixJQUFJLFNBQVMsa0VBQUcsRUFBRTtDQUNsQixJQUFJLFVBQVUsa0VBQUcsRUFBRTtDQUNuQixJQUFJLFFBQVEsa0VBQUcsQ0FBQzs7O0NBR2hCLElBQUksUUFBNEIsa0VBQUcsSUFBSTs7Q0FDdkMsSUFBSSxTQUFTLGtFQUFHLEVBQUU7OztDQUdsQixJQUFJLFVBQW9COztDQUN4QixJQUFJLGdCQUFnQixrRUFBRyxDQUFDO0NBQ3hCLElBQUksU0FBUyxrRUFBRyxFQUFFO0NBRWxCLElBQUksVUFBNEI7O0NBQ2hDLE1BQU0sY0FBYyxTQUFTOzRCQUM1QixVQUFVLEdBQUUsS0FBSztDQUNsQixDQUFDOztDQTBFRCxNQUFNLGdCQUFnQixHQUFHLEtBQUssT0FBTztFQUNwQyxHQUFHLENBQUM7NkJBQ0gsVUFBVSxFQUFHLEVBQUU7O0dBQ2YsTUFBTSxDQUFDLFdBQVcsSUFBSSxJQUFJLHlEQUFZLE9BQU8sQ0FBQyxHQUFHLEVBQ2hELHdDQUFrQixDQUFDLElBQUksR0FBQyxFQUFFLEdBQzFCLDJCQUFNLENBQUMsY0FBTTs7NkJBRWQsYUFBYSxFQUFHLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxFQUFFLE9BQU87NkJBQ2pELGVBQWUsNEJBQUcsYUFBYSxFQUFDLFVBQVU7O0dBRTFDLEVBQUUsNEJBQUUsZUFBZSxFQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7OEJBQy9CLGFBQWEsNEJBQUcsZUFBZSxFQUFDLENBQUM7dURBQzNCLGdCQUFnQjtHQUN2QjtFQUNELENBQUMsQ0FBQyxLQUFLLENBQUUsS0FBSyxFQUFFO0dBQ2YsT0FBTyxDQUFDLEtBQUsseURBQUMsK0JBQStCLEVBQUUsS0FBSzs2QkFDcEQsVUFBVSxFQUFHLEtBQUssR0FBQyxDQUFDLENBQUMsbUVBQW1FO0VBQ3pGO0NBQ0QsQ0FBQzs7Q0FFRCxNQUFNLGdCQUFnQixHQUFHLEtBQUssT0FBTztFQUNwQyxFQUFFLDZCQUFHLGFBQWEsZ0NBQUssYUFBYSxHQUFFLE1BQU07O0VBQzVDLE1BQU0sRUFBRSxZQUFZLHdEQUFXLDJCQUFNLENBQUMsNEJBQXlCO0VBQy9ELE1BQU0sU0FBUyw2QkFBRyxhQUFhLEVBQUMsTUFBTSwyQkFBQyxhQUFhO0VBQ3BELE1BQU0sTUFBTSxzREFBUyxZQUFZLENBQUMsU0FBUzs7NEJBQzNDLFNBQVMsRUFBRyw2QkFBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSTs0QkFDMUMsUUFBUSxFQUFHLE1BQU0sQ0FBQyxRQUFRO0NBQzNCLENBQUM7O0NBTUQsTUFBTSxlQUFlLEdBQUcsS0FBSyxPQUFPO0VBQ25DLEdBQUcsQ0FBQzs2QkFDSCxTQUFTLEVBQUcsRUFBRTs2QkFDZCxRQUFRLHFEQUFTLHdDQUFrQixDQUFDLElBQUksR0FBQyxFQUFFO0VBQzVDLENBQUMsQ0FBQyxLQUFLLENBQUUsS0FBSyxFQUFFO0dBQ2YsT0FBTyxDQUFDLEtBQUsseURBQUMsMEJBQTBCLEVBQUUsS0FBSzs2QkFDL0MsU0FBUyxFQUFHLEtBQUssR0FBQyxDQUFDLENBQUMsOERBQThEO0VBQ25GO0NBQ0QsQ0FBQzs7Q0FFRCxNQUFNLGVBQWUsR0FBRyxLQUFLLE9BQU87RUFDbkMsR0FBRyxDQUFDOzZCQUNILFNBQVMsRUFBRyxFQUFFOztHQUNkLE1BQU0sQ0FBQyxXQUFXLElBQUksWUFBWSx5REFBWSxPQUFPLENBQUMsR0FBRztJQUN4RCx3Q0FBa0IsQ0FBQyxJQUFJLEdBQUMsRUFBRTtJQUMxQiwyQkFBTSxDQUFDLDBCQUF1Qjs7O0dBRS9CLE1BQU0sTUFBTSxzREFBUyxZQUFZLENBQUMsV0FBVzs7NkJBQzdDLFVBQVUsRUFBRyxNQUFNLENBQUMsTUFBTTs2QkFDMUIsZ0JBQWdCLEVBQUcsQ0FBQztFQUNyQixDQUFDLENBQUMsS0FBSyxDQUFFLEtBQUssRUFBRTtHQUNmLE9BQU8sQ0FBQyxLQUFLLHlEQUFDLDBCQUEwQixFQUFFLEtBQUs7NkJBQy9DLFNBQVMsRUFBRyxLQUFLLEdBQUMsQ0FBQyxDQUFDLDhEQUE4RDtFQUNuRjtDQUNELENBQUM7O0NBRUQsTUFBTSxXQUFXLEdBQUcsS0FBSyxPQUFPOzRCQUMvQixXQUFXLEVBQUcsRUFBRTs0QkFDaEIsZUFBZSxFQUFHLEtBQUs7NEJBQ3ZCLFFBQVEsRUFBRyxJQUFJOztFQUNmLEVBQUUsc0NBQUUsSUFBSSxJQUFFLElBQUksRUFBSyxZQUFZLEdBQUU7NkJBQ2hDLE9BQU8sRUFBRyxJQUFJOztHQUVkLE1BQU0sU0FBUyxzREFBUyxzQ0FBZ0IsQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLElBQUksR0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsS0FBSztJQUNsRixPQUFPLENBQUMsS0FBSyx5REFBQyxnQ0FBZ0MsRUFBRSxDQUFDOztJQUNqRCxNQUFNLENBQUMsSUFBSTtHQUNaLENBQUM7O0dBRUQsRUFBRSxFQUFFLFNBQVMsRUFBRTs0REFDZCxJQUFJLENBQUosSUFBSSxHQUFDLEtBQUssR0FBRyxTQUFTLENBQUMsS0FBSztHQUM3Qjs7NkJBQ0EsT0FBTyxFQUFHLEtBQUs7RUFDaEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLHNDQUFFLElBQUksSUFBRSxJQUFJLEVBQUssTUFBTSxHQUFFOzZCQUNqQyxPQUFPLEVBQUcsSUFBSTs7R0FFZCxNQUFNLElBQUksc0RBQVMsaUNBQVcsQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLElBQUksR0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUMsS0FBSztJQUN4RSxPQUFPLENBQUMsS0FBSyx5REFBQyxzQkFBc0IsRUFBRSxDQUFDOztJQUN2QyxNQUFNLENBQUMsSUFBSTtHQUNaLENBQUM7O0dBRUQsRUFBRSxFQUFFLElBQUksRUFBRTsyREFDVCxJQUFJLENBQUosSUFBSSxHQUFDLElBQUksR0FBRyxJQUFJO0dBQ2pCOzs7R0FHQSxFQUFFLDRCQUFFLE9BQU8sR0FBRTt1REFDTixnQkFBZ0I7R0FDdkI7O0dBQ0EsRUFBRSw0QkFBRSxNQUFNLEdBQUU7dURBQ0wsZUFBZTtHQUN0Qjs7R0FDQSxFQUFFLDRCQUFFLE1BQU0sR0FBRTt1REFDTCxlQUFlO0dBQ3RCOzs2QkFFQSxPQUFPLEVBQUcsS0FBSztFQUNoQjs7cURBRU0sMEJBQUk7Q0FDWCxDQUFDOztDQU1ELDZCQUFPLE9BQU87RUFDYixPQUFPLENBQUMsR0FBRyx1REFBQyxJQUFJOztFQUNoQixFQUFFLHNDQUFFLElBQUksSUFBRSxPQUFPLEVBQUssTUFBTSxHQUFFOzZCQUM3QixpQkFBaUIsRUFBRyxJQUFJO0VBQ3pCO0NBQ0QsQ0FBQzs7OzRCQXpMRSxLQUFLLHNDQUNQLElBQUksSUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFLLGlCQUFpQixLQUM3QyxJQUFJLElBQUUsSUFBSSxJQUFJLElBQUksSUFBRSxJQUFJLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxNQUFNOzs7OzRCQUVyRCxVQUFVLHNDQUNaLElBQUksSUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFLLGVBQWUsS0FDM0MsSUFBSSxJQUFFLElBQUksSUFBSSxJQUFJLElBQUUsSUFBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsS0FBSzs7Ozs0QkFFcEQsTUFBTSxFQUNSLElBQUksSUFBRSxJQUFJLEtBQ1QsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLEtBQUssS0FDdEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLEtBQUssS0FDdEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLEtBQUssS0FDdEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE9BQU8sS0FDeEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE9BQU8sS0FDeEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdkMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE9BQU8sS0FDeEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdkMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLElBQUksS0FDckMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLElBQUksS0FDckMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLEtBQUssS0FDdEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE9BQU8sS0FDeEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE9BQU8sS0FDeEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdkMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdkMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdkMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLEtBQUssS0FDdEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLEtBQUssS0FDdEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdkMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLEtBQUs7Ozs7NEJBRXJDLE9BQU8sR0FDUixJQUFJLElBQUUsSUFBSSxFQUFFLFlBQVksSUFBSSxFQUFFLEVBQUUsVUFBVSxDQUFDLFFBQVEsS0FDbkQsSUFBSSxJQUFFLElBQUksSUFBSSxJQUFJLElBQUUsSUFBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxLQUN0RCxJQUFJLElBQUUsSUFBSSxJQUFJLElBQUksSUFBRSxJQUFJLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEtBQ3RELElBQUksSUFBRSxJQUFJLElBQUksSUFBSSxJQUFFLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdEQsSUFBSSxJQUFFLElBQUksSUFBSSxJQUFJLElBQUUsSUFBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxLQUN0RCxJQUFJLElBQUUsSUFBSSxJQUFJLElBQUksSUFBRSxJQUFJLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxPQUFPOzs7OzRCQUV0RCxPQUFPLEdBQ1IsSUFBSSxJQUFFLElBQUksRUFBRSxZQUFZLElBQUksRUFBRSxFQUFFLFVBQVUsQ0FBQyxRQUFRLEtBQ25ELElBQUksSUFBRSxJQUFJLEtBQ1QsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdkMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdkMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE9BQU8sS0FDeEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdkMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE9BQU8sS0FDeEMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdkMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sS0FDdkMsSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU07Ozs7NEJBRXZDLE9BQU8sc0NBQ1QsSUFBSSxJQUFFLElBQUksRUFBRSxZQUFZLEVBQUssMEJBQTBCLHlDQUN2RCxJQUFJLElBQUUsSUFBSSxFQUFFLFlBQVksRUFDdkIsbUVBQW1FLHlDQUNwRSxJQUFJLElBQUUsSUFBSSxFQUFFLFlBQVksRUFBSyxVQUFVLHlDQUN2QyxJQUFJLElBQUUsSUFBSSxFQUFFLFlBQVksRUFBSyxpQkFBaUIsS0FDN0MsSUFBSSxJQUFFLElBQUksS0FDVCxJQUFJLEdBQUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxLQUN2QyxJQUFJLEdBQUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsT0FBTyxLQUN4QyxJQUFJLEdBQUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTTs7Ozs0QkFFdkMsTUFBTSxzQ0FDUixJQUFJLElBQUUsSUFBSSxFQUFFLFlBQVksRUFDdkIseUVBQXlFLEtBQ3pFLElBQUksSUFBRSxJQUFJLElBQUksSUFBSSxHQUFDLElBQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLE9BQU87Ozs7NEJBRXJELE1BQU0sc0NBQ1IsSUFBSSxJQUFFLElBQUksRUFBRSxZQUFZLEVBQ3ZCLDJFQUEyRSxLQUMzRSxJQUFJLElBQUUsSUFBSSxJQUFJLElBQUksR0FBQyxJQUFJLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxPQUFPOzs7O0VBK0JyRCxFQUFFLDRCQUFFLGFBQWEsK0JBQUksYUFBYSxHQUFFO0dBQ3RDLGdCQUFnQjtFQUNqQjs7OztFQXlFRyxFQUFFLEVBQUUsSUFBSSxJQUFFO0dBQ1osV0FBVztFQUNaOzs7Ozs7Ozs7Ozs7O1NBVUEsOEJBQUs7O1FBQUMsSUFBUzs7OztRQUFULElBQVM7Ozs7O1NBQ2QsR0FBRztTQUNGLEtBQUcsK0JBREosR0FBRztTQUVELEtBQUcsK0JBREosS0FBRztTQUVELEtBQUcsK0JBREosS0FBRztTQUVELEtBQUcsK0JBREosS0FBRztTQUVELGdDQURELEtBQUc7NENBQ0Y7O2lDQUFBO2lDQURELEtBQUc7aUNBREosS0FBRzs7U0F3QkgsS0FBRyxpQ0F4QkgsS0FBRztTQXlCRixxQ0FERCxLQUFHOzRDQUNGOztpREFLQyw4QkFBSztpQ0FMTjtpQ0FERCxLQUFHO2lDQXpCSixLQUFHOztTQW9DSCxLQUFHLGlDQXBDSCxLQUFHO1NBcUNGLEtBQUcsK0JBREosS0FBRztTQUVELEtBQUcsK0JBREosS0FBRzs4Q0FDRixLQUFHOzs7Ozs7Ozs7O2FBR0EsS0FBRztrREFBSCxLQUFHOztxQ0FBSCxLQUFHOzttSUE1UUEsSUFBSSx5Q0E0UTBCLElBQUksR0FBQyxJQUFJOzs7Ozs7cURBNVF2QyxJQUFJLHlDQTJRSixJQUFJLElBQUUsSUFBSTs7Ozs7Ozs7Ozs7Ozs7YUFNYixNQUFHO2tEQUFILE1BQUc7O3FDQUFILE1BQUc7Ozs7Z0RBalJBLElBQUk7OENBaVJtQixJQUFJLEdBQUMsV0FBVzs7Ozs7Ozs7O2lEQWpSdkMsSUFBSTsrQ0FnUkosSUFBSSxJQUFFLFdBQVc7Ozs7Ozs7Ozs7Ozs7O2FBTXBCLE1BQUc7a0RBQUgsTUFBRzs7cUNBQUgsTUFBRzs7OztpREE5UkosOEJBQUs7aURBUUQsSUFBSTsrQ0F1Uk4sOEJBQUssQ0FBQyxJQUFJLEdBQUMsVUFBVSxHQUFHLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTs7OztnREFEMUMsTUFBRzs7Ozs7O2lEQXRSQSxJQUFJOytDQXFSSixJQUFJLElBQUUsVUFBVTs7Ozs7Ozs7Ozs7Ozs7OzsrQ0FyUmhCLElBQUk7aUZBMFFMLElBQUksSUFBRSxJQUFJLEVBQUssWUFBWTs7Ozs7Ozs7Ozs7Ozs7O1dBbUI5QixNQUFHO2dEQUFILE1BQUc7O21DQUFILE1BQUc7Ozs7OytDQXZURCxvQ0FBYzsrQ0EwQlosSUFBSTs2Q0E2UnlCLG9DQUFjLENBQUMsSUFBSSxHQUFDLElBQUk7Ozs7Ozs7OzttREE3UnJELElBQUkseUNBNFJMLElBQUksR0FBQyxJQUFJOzs7Ozs7Ozs7Ozs7OztXQU1aLE1BQUc7Z0RBQUgsTUFBRzs7Ozs7Ozs7O3FDQTlRTixRQUFROytDQWdSSCxLQUFLLEdBQUMsQ0FBQyxDQUFDLGdCQUFnQixJQUN4QixLQUFLLDRCQUFFOzs7Ozs7Ozs7Ozs7O2lEQS9UUyxrQ0FBWTtpREEwQjFCLElBQUk7K0NBd1NOLEtBQUssR0FBQyxDQUFDLENBQUMsMkJBQTJCLElBQ25DLEtBQUssRUFBRSxrQ0FBWSxDQUFDLElBQUksSUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFOzs7Ozs7Ozs7d0NBTmhELE9BQU8sK0JBQUksUUFBUSxJQUFHLENBQUMsa0VBQUksV0FBVyxHQUFLLFNBQVM7Ozs7Ozs7OzttQ0FEekQsTUFBRzs7V0FZSCxNQUFHLGlDQVpILE1BQUc7Z0RBWUgsTUFBRzs7bUNBQUgsTUFBRzs7Ozs7NkNBQ0EsS0FBSyxHQUFDLENBQUMsQ0FBQyw2Q0FBNkM7Ozs7Ozs7Ozs7K0NBL1NwRCxJQUFJOzZDQWlTTCxJQUFJLElBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPOzs7Ozs7Ozs7Ozs7OztXQW1CNUIsTUFBRztnREFBSCxNQUFHOzttQ0FBSCxNQUFHOzs7NERBQ0YsS0FBSyxHQUFDLENBQUMsQ0FBQyxnQkFBZ0I7Ozs4Q0FEekIsTUFBRzs7Ozs7OytDQXBUQyxJQUFJOzZDQW1UTCxJQUFJLElBQUUsU0FBUzs7Ozs7Ozs7OztpQ0ExQ3BCLEtBQUc7O2dEQUFILEtBQUc7Ozs7V0FrREYsTUFBRztpREFBSCxNQUFHOzs7O21DQXZUTCxpQkFBaUI7O3VFQXlUTDtZQUNOLEtBQUssR0FBQyxDQUFDLENBQ1AsNkdBQTRHO1lBRTVHLEtBQUssR0FBQyxDQUFDLENBQ1AsaUhBQWdIOzs7O2VBTm5IOzs7Ozs7ZUFTQyxNQUFHO3FEQUFILE1BQUc7Ozs7Ozs7a0VBRUQsS0FBSyxHQUFDLENBQUMsQ0FBQyx1QkFBdUI7Ozs7Ozs7Ozs7OzttREFFL0IsS0FBSyxHQUFDLENBQUMsQ0FBQyx5QkFBeUI7Ozs7Ozs7Ozs0Q0FIOUIsaUJBQWlCOzs7Ozs7Ozs7Ozs7a0JBS3JCO2lCQUNBLEtBQVU7K0NBQUUsaUJBQWlCOzs7aUJBQTdCLEtBQVU7d0NBQUUsaUJBQWlCOzs7O3VCQUNqQixDQUFDLEtBQUs7eUVBQ2pCLElBQUksQ0FBSixJQUFJLEdBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxHQUFHLFNBQVM7Y0FDN0MsQ0FBQzs7Ozs7Ozs7Ozs7dUNBVkYsTUFBRztrREFBSCxNQUFHOzs7Ozs7Ozs7Ozs7bUNBVkwsTUFBRzs4Q0FBSCxNQUFHOzs7OztZQURBLElBQUk7Ozs7Ozs7OztpQ0FsRFQsS0FBRztpQ0FESixLQUFHO2lDQXJDSixLQUFHOztTQXVISCxNQUFHLGlDQXZISCxLQUFHOytDQXVISCxNQUFHOzs7Ozs7Ozs7YUFHQSxNQUFHOzs7MkNBQUgsTUFBRyxrREE1VkcsSUFBSSx5Q0E2VkgsSUFBSSxJQUFFLEtBQUssNENBQUksSUFBSTtlQUN4QixNQUFHO2VBQ0YsTUFBRywrQkFESixNQUFHO3FEQUNGLE1BQUc7O3VDQUFILE1BQUc7dUNBREosTUFBRzswSEFEaUIsSUFBSSxpRUFHdEIsSUFBSSxHQUFFLElBQUksRUFBRSxJQUFJO2tEQUZsQixNQUFHOzs7Ozs7OztxQ0FGTCxNQUFHO2dEQUFILE1BQUc7Ozs7OztpREE1VkcsSUFBSTttRkEyVlAsSUFBSSxJQUFFLElBQUksRUFBSyxZQUFZOzs7Ozs7Ozs7Ozs7OzthQWE5QjthQUdDLHVDQUhEO21EQUdDOztxQ0FBQTs7YUFVQSx5Q0FWQTttREFVQTs7cUNBQUE7cUNBYkQ7Ozs7MkNBR0MsNkdBQ3VDLFdBQVcsR0FBSyxFQUFDO2NBQ3JELEdBQUU7Y0FDRixnR0FBZ0c7Ozs7MkNBT25HLDZHQUN1QyxXQUFXLEdBQUssU0FBUTtjQUM1RCxHQUFFO2NBQ0YsZ0dBQWdHOzs7OzsrREFOL0YsS0FBSyxHQUFDLENBQUMsQ0FBQyxTQUFTOytEQVVqQixLQUFLLEdBQUMsQ0FBQyxDQUFDLFNBQVM7Ozs7OENBakJyQiw2QkFLZ0I7b0NBQ2YsV0FBVyxFQUFHLEVBQUU7U0FDakIsQ0FBQzs7OENBR0QsNkJBS2dCO29DQUNmLFdBQVcsRUFBRyxTQUFTO1NBQ3hCLENBQUM7O2dEQXBCRjs7Ozs7d0NBREcsT0FBTywrQkFBSSxLQUFLLCtCQUFJLE9BQU8sK0JBQUksTUFBTSwrQkFBSSxVQUFVLCtCQUFJLE1BQU0sK0JBQUksTUFBTTs7Ozs7Ozs7Ozs7OzthQTJCMUUsTUFBRzthQUNGLE1BQUcsK0JBREosTUFBRzttREFDRixNQUFHOzs7Z0hBQ2UsS0FBSyxHQUFDLENBQUMsQ0FBQyxZQUFZOzs7aUJBQXJDLDhCQUFPOzs7Ozs7aUJBQ047dURBQUE7O3lEQUlDLDhCQUFLO3lDQUpOO2tEQUFBLFVBRVUsY0FBYztvREFGeEI7Ozs7Ozs7Ozs7OztxQ0FGRixNQUFHOztxREFBSCxNQUFHOzs7O1dBVUgsOEJBQWdCOztpQkFDZjs7O2tEQUFBO3FEQXZhRSx3Q0FBa0I7cURBeUJoQixJQUFJO3NEQStZQSx3Q0FBa0IsVUFBVSxJQUFJLEdBQUMsRUFBRTs7O2tEQUQzQztxREE5WUksSUFBSTttREFnWkgsSUFBSSxJQUFFLElBQUksSUFBSSxPQUFPOzs7O29EQUYxQjs7Ozs7a0RBRDJCLFVBQVU7MkNBQVYsVUFBVTs7Ozs7Ozs7O3FDQVh2QyxNQUFHO2dEQUFILE1BQUc7Ozs7Ozs7OztpQkF1QkssVUFBVTs7bURBelpaLElBQUk7a0RBeVpZLElBQUksSUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE9BQU8sSUFBSSxFQUFFLEVBQUUsSUFBSSxNQUFNLFlBQVk7Ozs7O3FDQUFyRSxVQUFVOztpQkFDVixXQUFXOzs7NkVBRFgsVUFBVTt1Q0F2YW5CLGVBQWU7a0RBeWFaLFNBQVMsSUFBRSx3QkFBd0IsSUFBSSxJQUFJLCtCQUM1QyxVQUFVLEVBQUMsTUFBTSxHQUFHLHFCQUFxQiwrQkFDeEMsZUFBZTs7Ozs7cUNBSFQsV0FBVzs7Ozs7Ozs7aUJBS2pCO3VEQUFBOzs7OytFQUxNLFdBQVc7K0VBRFgsVUFBVTs2RUFVTixXQUFXOzRDQUFHLFVBQVUsRUFBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLHFCQUFxQjs0Q0FBSSxVQUFVOzs7O3FCQUQ5RTs7Ozs7Ozs7Ozs7Ozs7eUNBSEQ7O3lEQUFBOzs7O21CQVNDO3lEQUFBOzsyQ0FBQTs7Ozs7aUZBZkssVUFBVTtxREFxQmQsS0FBSyxHQUFDLENBQUMsQ0FBQyxpQ0FBaUMsSUFDekMsS0FBSyw0QkFBRSxVQUFVLEVBQUMsTUFBTSxDQUFDLGNBQWM7Ozs7b0RBUHhDLDZCQUVnQjswQ0FDZixlQUFlLEVBQUcsSUFBSTtlQUN2QixDQUFDOztzREFKRDs7Ozs7OENBREcsV0FBVzs7Ozs7Ozs7Ozs7OztpQkFhZixNQUFHO3VEQUFILE1BQUc7O3lDQUFILE1BQUc7MkhBQ0YsVUFBVTtvREFEWCxNQUFHOzs7Ozs7O21EQXRCQSxTQUFTLElBQUUsd0JBQXdCLElBQUksSUFBSTs7Ozs7Ozs7Ozs7Ozs7aUJBMkJ4QyxVQUFVOzttREF6YlosSUFBSTtrREF5YlksSUFBSSxJQUFFLE9BQU8sSUFBSSxFQUFFLEVBQUUsSUFBSSxNQUFNLFlBQVk7Ozs7O3FDQUF6RCxVQUFVOztpQkFDVixXQUFXOzs7NkVBRFgsVUFBVTt1Q0F2Y25CLGVBQWU7a0RBeWNaLFNBQVMsSUFBRSx3QkFBd0IsSUFBSSxJQUFJLCtCQUM1QyxVQUFVLEVBQUMsTUFBTSxHQUFHLHFCQUFxQiwrQkFDeEMsZUFBZTs7Ozs7cUNBSFQsV0FBVzs7Ozs7Ozs7aUJBS2pCO3VEQUFBOzs7OytFQUxNLFdBQVc7K0VBRFgsVUFBVTs2RUFVTixXQUFXOzRDQUFHLFVBQVUsRUFBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLHFCQUFxQjs0Q0FBSSxVQUFVOzs7O3FCQUQ5RTs7Ozs7Ozs7Ozs7Ozs7eUNBSEQ7O3lEQUFBOzs7O21CQVNDO3lEQUFBOzsyQ0FBQTs7Ozs7aUZBZkssVUFBVTtxREFxQmQsS0FBSyxHQUFDLENBQUMsQ0FBQyxpQ0FBaUMsSUFDekMsS0FBSyw0QkFBRSxVQUFVLEVBQUMsTUFBTSxDQUFDLGNBQWM7Ozs7b0RBUHhDLDZCQUVnQjswQ0FDZixlQUFlLEVBQUcsSUFBSTtlQUN2QixDQUFDOztzREFKRDs7Ozs7OENBREcsV0FBVzs7Ozs7Ozs7Ozs7OztpQkFhZixNQUFHO3VEQUFILE1BQUc7O3lDQUFILE1BQUc7MkhBQ0YsVUFBVTtvREFEWCxNQUFHOzs7Ozs7O21EQXRCQSxTQUFTLElBQUUsd0JBQXdCLElBQUksSUFBSTs7Ozs7Ozs7Ozs7Ozs7OzttREE5YjFDLElBQUk7aURBd1pOLElBQUksSUFBRSxJQUFJLEVBQUUsSUFBSTt3RkF4WmQsSUFBSSx5Q0F3YkQsSUFBSSxJQUFFLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7OztlQW1DckI7OzJGQUFBO2tEQXBmRyx3Q0FBa0I7a0RBeUJoQixJQUFJO21EQTRkRCx3Q0FBa0IsVUFBVSxJQUFJLEdBQUMsRUFBRTs7O2tEQUQzQzs7Ozs7O21EQXBmRyx3Q0FBa0I7bURBeUJoQixJQUFJO29EQW1lRCx3Q0FBa0IsVUFBVSxJQUFJLEdBQUMsRUFBRTs7OzttQkFEM0M7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQkFNQyxNQUFHO3VEQUFILE1BQUc7O3lDQUFILE1BQUc7MkhBQ0YsVUFBVTtvREFEWCxNQUFHOzs7Ozs7Ozs7bUJBS0Y7OztpREFBQSwyQ0FHTyxlQUFlLDJDQUFJLFNBQVM7cUJBQ2pDOzJEQUFBOzs2Q0FBQTs7O2tEQUFBLDZHQUN1QyxhQUFhLDZCQUFLO3FCQUN0RCxHQUFFO3FCQUNGLGdHQUFnRzs7b0ZBSS9GLFNBQVM7OztzREFQYiw2QkFLZ0I7NENBQ2YsYUFBYSw0QkFBRyxTQUFTO2lCQUMxQixDQUFDOzt3REFQRDs7Ozs7Ozs7MkNBSkY7c0RBQUE7Ozs7OzsyQ0E3ZEosZUFBeUI7K0VBNGRsQixlQUFlLEVBQUMsTUFBTSxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7O21CQW1CN0IsTUFBRzs7MENBQUgsTUFBRyxrQ0FDSSxTQUFTOzJDQURoQixNQUFHO3NEQUFILE1BQUc7Ozs7bUJBSUgsTUFBRzs7c0RBQUgsTUFBRzs7Ozs7OENBTEEsU0FBUzs7Ozs7Ozs7Ozs7Ozs7NENBdkJWLFVBQVU7Ozs7Ozs7Ozs7Ozs7ZUFnQ2QsTUFBRztxREFBSCxNQUFHOzs7O21EQXZnQkUsSUFBSTtpREEwZ0JGLElBQUksR0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxHQUFHOzs7O21CQUY5Qjs7O3NEQXhnQkksSUFBSTtvREF5Z0JGLElBQUksR0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU87Ozs7Ozs7cUJBRXJCLElBQUk7b0JBQ0wsS0FBSzttQkFDTixLQUFLO29CQUNKLEtBQUs7Ozs7Ozs7Ozs7dUNBUFosTUFBRztrREFBSCxNQUFHOzs7O2VBV0g7cURBQUE7OztrQkFHQyw4QkFBUTs7O3FEQXJoQkosSUFBSTttREFxaEJVLElBQUksR0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU87Ozs7Ozs7Ozs7Ozt1Q0FIekM7a0RBQUE7Ozs7Ozs7OztpQkFPQyxNQUFHO3VEQUFILE1BQUc7O3lDQUFILE1BQUc7MkhBQW1DLFNBQVM7b0RBQS9DLE1BQUc7Ozs7O29CQUVILDhCQUFXOztpREFBTyxRQUFROzs7Ozs7Ozs7Ozs7O2lCQUUxQixNQUFHOztvREFBSCxNQUFHOzs7Ozs0Q0FMQSxTQUFTLCtEQUVKLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQkFPaEIsTUFBRzt1REFBSCxNQUFHOzt5Q0FBSCxNQUFHOzJIQUFtQyxTQUFTO29EQUEvQyxNQUFHOzs7OztvQkFFSDs7aURBQ1EsVUFBVTs7O21CQUNsQixZQUFpQjtpREFBRSxnQkFBZ0I7OzttQkFBbkMsWUFBaUI7MENBQUUsZ0JBQWdCOzs7Ozs7Ozs7Ozs7O2lCQUluQyxNQUFHOztvREFBSCxNQUFHOzs7Ozs0Q0FUQSxTQUFTO3lDQXJnQmYsVUFBb0I7NkVBdWdCVCxVQUFVLEVBQUMsTUFBTSxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7O2VBVTlCLE1BQUc7cURBQUgsTUFBRzs7dUNBQUgsTUFBRzs7OzttREE1aUJFLElBQUk7a0RBNmlCUCxJQUFJLElBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLElBQUksRUFBRSxFQUFFLElBQUksTUFBTSxZQUFZOzs7O2tEQUR6RCxNQUFHOzs7OzswQ0FsRkEsT0FBTywrREFPRixLQUFLLGtFQUtMLE9BQU8sa0VBZ0NQLE1BQU0sa0VBV04sVUFBVSxrRUFNVixNQUFNLGtFQVFOLE1BQU07Ozs7Ozs7Ozs7Ozs7O3dDQTlKWixPQUFPLG1HQXNCRixXQUFXLEdBQUssRUFBRSxzR0FrRWxCLFdBQVcsR0FBSyxTQUFTOzs7Ozs7Ozs7Ozs7O1dBeUZsQyxNQUFHO2lEQUFILE1BQUc7O21EQUNGLDhCQUFPO21DQURSLE1BQUc7OENBQUgsTUFBRzs7Ozs7dUNBeE5DLE9BQU87Ozs7Ozs7OztpQ0FEYixNQUFHO2lDQXhISixHQUFHOzs7NENBak9PLElBQUk7MENBdVBSLElBQUksSUFBRSxJQUFJLElBQUksTUFBTTs7OzBDQWpCckIsOENBRytCO01BQzlCLEVBQUUsc0NBQUUsSUFBSSxHQUFDLElBQUksRUFBSyxNQUFNLEtBQUksSUFBSSxHQUFDLEdBQUcsRUFBRTtPQUNyQyxJQUFJLE1BQU0sR0FBRyxJQUFJLElBQUUsRUFBRSxJQUFJLElBQUksSUFBRSxNQUFNOztPQUNyQyxNQUFNLENBQUMsSUFBSTs0Q0FDVixJQUFJLEdBQUMsSUFBSSxFQUFLLE1BQUs7V0FDaEIsSUFBSSxJQUFFLEdBQUcsRUFBRSxVQUFVLENBQUMsTUFBTTtZQUMzQixJQUFJLEdBQUM7ZUFDRix3Q0FBa0IsVUFBVSxNQUFNO1dBQ3RDLElBQUksR0FBQyxHQUFHO1FBQ1gsUUFBTzs7TUFFVDtLQUNELENBQUM7OzBDQVFGLHlCQUNnQjtNQUNmLElBQUksQ0FBRyxLQUFLO0tBQ2IsQ0FBQzs7NENBL0JMLEdBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUhHIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGaWxlSXRlbU1vZGFsLnN2ZWx0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IGxhbmc9XCJ0c1wiPlxuXHRpbXBvcnQgdHlwZSB7IFdvcmtCb29rIH0gZnJvbSAneGxzeCc7XG5cdGltcG9ydCBET01QdXJpZnkgZnJvbSAnZG9tcHVyaWZ5JztcblxuXHRpbXBvcnQgeyBnZXRDb250ZXh0LCBvbk1vdW50LCB0aWNrIH0gZnJvbSAnc3ZlbHRlJztcblxuXHRpbXBvcnQgeyBmb3JtYXRGaWxlU2l6ZSwgZ2V0TGluZUNvdW50IH0gZnJvbSAnJGxpYi91dGlscyc7XG5cdGltcG9ydCB7IFdFQlVJX0FQSV9CQVNFX1VSTCB9IGZyb20gJyRsaWIvY29uc3RhbnRzJztcblx0aW1wb3J0IHsgc2V0dGluZ3MgfSBmcm9tICckbGliL3N0b3Jlcyc7XG5cdGltcG9ydCB7IGdldEtub3dsZWRnZUJ5SWQgfSBmcm9tICckbGliL2FwaXMva25vd2xlZGdlJztcblx0aW1wb3J0IHsgZ2V0RmlsZUJ5SWQsIGdldEZpbGVDb250ZW50QnlJZCB9IGZyb20gJyRsaWIvYXBpcy9maWxlcyc7XG5cblx0aW1wb3J0IENvZGVCbG9jayBmcm9tICckbGliL2NvbXBvbmVudHMvY2hhdC9NZXNzYWdlcy9Db2RlQmxvY2suc3ZlbHRlJztcblx0aW1wb3J0IE1hcmtkb3duIGZyb20gJyRsaWIvY29tcG9uZW50cy9jaGF0L01lc3NhZ2VzL01hcmtkb3duLnN2ZWx0ZSc7XG5cblx0Y29uc3QgaTE4biA9IGdldENvbnRleHQoJ2kxOG4nKTtcblxuXHRjb25zdCBDT05URU5UX1BSRVZJRVdfTElNSVQgPSAxMDAwMDtcblx0bGV0IGV4cGFuZGVkQ29udGVudCA9IGZhbHNlO1xuXG5cdGltcG9ydCBNb2RhbCBmcm9tICcuL01vZGFsLnN2ZWx0ZSc7XG5cdGltcG9ydCBYTWFyayBmcm9tICcuLi9pY29ucy9YTWFyay5zdmVsdGUnO1xuXHRpbXBvcnQgU3dpdGNoIGZyb20gJy4vU3dpdGNoLnN2ZWx0ZSc7XG5cdGltcG9ydCBUb29sdGlwIGZyb20gJy4vVG9vbHRpcC5zdmVsdGUnO1xuXHRpbXBvcnQgZGF5anMgZnJvbSAnZGF5anMnO1xuXHRpbXBvcnQgU3Bpbm5lciBmcm9tICcuL1NwaW5uZXIuc3ZlbHRlJztcblx0aW1wb3J0IFBERlZpZXdlciBmcm9tICcuL1BERlZpZXdlci5zdmVsdGUnO1xuXHRpbXBvcnQgUGFuem9vbUNvbnRhaW5lciBmcm9tICcuL1Bhbnpvb21Db250YWluZXIuc3ZlbHRlJztcblx0aW1wb3J0IERvY3hQcmV2aWV3IGZyb20gJy4vRG9jeFByZXZpZXcuc3ZlbHRlJztcblx0aW1wb3J0IFBwdHhQcmV2aWV3IGZyb20gJy4vUHB0eFByZXZpZXcuc3ZlbHRlJztcblx0aW1wb3J0IFJlc2V0IGZyb20gJy4uL2ljb25zL1Jlc2V0LnN2ZWx0ZSc7XG5cblx0ZXhwb3J0IGxldCBpdGVtO1xuXHRleHBvcnQgbGV0IHNob3cgPSBmYWxzZTtcblx0ZXhwb3J0IGxldCBlZGl0ID0gZmFsc2U7XG5cblx0bGV0IGVuYWJsZUZ1bGxDb250ZW50ID0gZmFsc2U7XG5cdGxldCBsb2FkaW5nID0gZmFsc2U7XG5cblx0bGV0IGlzUERGID0gZmFsc2U7XG5cdGxldCBpc0F1ZGlvID0gZmFsc2U7XG5cdGxldCBpc0ltYWdlID0gZmFsc2U7XG5cdGxldCBpc0V4Y2VsID0gZmFsc2U7XG5cdGxldCBpc0RvY3ggPSBmYWxzZTtcblx0bGV0IGlzUHB0eCA9IGZhbHNlO1xuXG5cdGxldCBzZWxlY3RlZFRhYiA9ICcnO1xuXHRsZXQgZXhjZWxXb3JrYm9vazogV29ya0Jvb2sgfCBudWxsID0gbnVsbDtcblx0bGV0IGV4Y2VsU2hlZXROYW1lczogc3RyaW5nW10gPSBbXTtcblx0bGV0IHNlbGVjdGVkU2hlZXQgPSAnJztcblx0bGV0IGV4Y2VsSHRtbCA9ICcnO1xuXHRsZXQgZXhjZWxFcnJvciA9ICcnO1xuXHRsZXQgcm93Q291bnQgPSAwO1xuXG5cdC8vIERPQ1ggc3RhdGVcblx0bGV0IGRvY3hEYXRhOiBBcnJheUJ1ZmZlciB8IG51bGwgPSBudWxsO1xuXHRsZXQgZG9jeEVycm9yID0gJyc7XG5cblx0Ly8gUFBUWCBzdGF0ZVxuXHRsZXQgcHB0eFNsaWRlczogc3RyaW5nW10gPSBbXTtcblx0bGV0IHBwdHhDdXJyZW50U2xpZGUgPSAwO1xuXHRsZXQgcHB0eEVycm9yID0gJyc7XG5cblx0bGV0IHBhbnpvb21SZWY6IFBhbnpvb21Db250YWluZXI7XG5cdGNvbnN0IHJlc2V0SW1hZ2VWaWV3ID0gKCkgPT4ge1xuXHRcdHBhbnpvb21SZWY/LnJlc2V0KCk7XG5cdH07XG5cblx0JDogaXNQREYgPVxuXHRcdGl0ZW0/Lm1ldGE/LmNvbnRlbnRfdHlwZSA9PT0gJ2FwcGxpY2F0aW9uL3BkZicgfHxcblx0XHQoaXRlbT8ubmFtZSAmJiBpdGVtPy5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5wZGYnKSk7XG5cblx0JDogaXNNYXJrZG93biA9XG5cdFx0aXRlbT8ubWV0YT8uY29udGVudF90eXBlID09PSAndGV4dC9tYXJrZG93bicgfHxcblx0XHQoaXRlbT8ubmFtZSAmJiBpdGVtPy5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5tZCcpKTtcblxuXHQkOiBpc0NvZGUgPVxuXHRcdGl0ZW0/Lm5hbWUgJiZcblx0XHQoaXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5weScpIHx8XG5cdFx0XHRpdGVtLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLmpzJykgfHxcblx0XHRcdGl0ZW0ubmFtZS50b0xvd2VyQ2FzZSgpLmVuZHNXaXRoKCcudHMnKSB8fFxuXHRcdFx0aXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5qYXZhJykgfHxcblx0XHRcdGl0ZW0ubmFtZS50b0xvd2VyQ2FzZSgpLmVuZHNXaXRoKCcuaHRtbCcpIHx8XG5cdFx0XHRpdGVtLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLmNzcycpIHx8XG5cdFx0XHRpdGVtLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLmpzb24nKSB8fFxuXHRcdFx0aXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5jcHAnKSB8fFxuXHRcdFx0aXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5jJykgfHxcblx0XHRcdGl0ZW0ubmFtZS50b0xvd2VyQ2FzZSgpLmVuZHNXaXRoKCcuaCcpIHx8XG5cdFx0XHRpdGVtLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLnNoJykgfHxcblx0XHRcdGl0ZW0ubmFtZS50b0xvd2VyQ2FzZSgpLmVuZHNXaXRoKCcuYmFzaCcpIHx8XG5cdFx0XHRpdGVtLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLnlhbWwnKSB8fFxuXHRcdFx0aXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy55bWwnKSB8fFxuXHRcdFx0aXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy54bWwnKSB8fFxuXHRcdFx0aXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5zcWwnKSB8fFxuXHRcdFx0aXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5nbycpIHx8XG5cdFx0XHRpdGVtLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLnJzJykgfHxcblx0XHRcdGl0ZW0ubmFtZS50b0xvd2VyQ2FzZSgpLmVuZHNXaXRoKCcucGhwJykgfHxcblx0XHRcdGl0ZW0ubmFtZS50b0xvd2VyQ2FzZSgpLmVuZHNXaXRoKCcucmInKSk7XG5cblx0JDogaXNBdWRpbyA9XG5cdFx0KGl0ZW0/Lm1ldGE/LmNvbnRlbnRfdHlwZSA/PyAnJykuc3RhcnRzV2l0aCgnYXVkaW8vJykgfHxcblx0XHQoaXRlbT8ubmFtZSAmJiBpdGVtPy5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5tcDMnKSkgfHxcblx0XHQoaXRlbT8ubmFtZSAmJiBpdGVtPy5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy53YXYnKSkgfHxcblx0XHQoaXRlbT8ubmFtZSAmJiBpdGVtPy5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5vZ2cnKSkgfHxcblx0XHQoaXRlbT8ubmFtZSAmJiBpdGVtPy5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5tNGEnKSkgfHxcblx0XHQoaXRlbT8ubmFtZSAmJiBpdGVtPy5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy53ZWJtJykpO1xuXG5cdCQ6IGlzSW1hZ2UgPVxuXHRcdChpdGVtPy5tZXRhPy5jb250ZW50X3R5cGUgPz8gJycpLnN0YXJ0c1dpdGgoJ2ltYWdlLycpIHx8XG5cdFx0KGl0ZW0/Lm5hbWUgJiZcblx0XHRcdChpdGVtLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLnBuZycpIHx8XG5cdFx0XHRcdGl0ZW0ubmFtZS50b0xvd2VyQ2FzZSgpLmVuZHNXaXRoKCcuanBnJykgfHxcblx0XHRcdFx0aXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5qcGVnJykgfHxcblx0XHRcdFx0aXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5naWYnKSB8fFxuXHRcdFx0XHRpdGVtLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLndlYnAnKSB8fFxuXHRcdFx0XHRpdGVtLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLnN2ZycpIHx8XG5cdFx0XHRcdGl0ZW0ubmFtZS50b0xvd2VyQ2FzZSgpLmVuZHNXaXRoKCcuYm1wJykgfHxcblx0XHRcdFx0aXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5pY28nKSkpO1xuXG5cdCQ6IGlzRXhjZWwgPVxuXHRcdGl0ZW0/Lm1ldGE/LmNvbnRlbnRfdHlwZSA9PT0gJ2FwcGxpY2F0aW9uL3ZuZC5tcy1leGNlbCcgfHxcblx0XHRpdGVtPy5tZXRhPy5jb250ZW50X3R5cGUgPT09XG5cdFx0XHQnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LnNwcmVhZHNoZWV0bWwuc2hlZXQnIHx8XG5cdFx0aXRlbT8ubWV0YT8uY29udGVudF90eXBlID09PSAndGV4dC9jc3YnIHx8XG5cdFx0aXRlbT8ubWV0YT8uY29udGVudF90eXBlID09PSAnYXBwbGljYXRpb24vY3N2JyB8fFxuXHRcdChpdGVtPy5uYW1lICYmXG5cdFx0XHQoaXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy54bHMnKSB8fFxuXHRcdFx0XHRpdGVtLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLnhsc3gnKSB8fFxuXHRcdFx0XHRpdGVtLm5hbWUudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLmNzdicpKSk7XG5cblx0JDogaXNEb2N4ID1cblx0XHRpdGVtPy5tZXRhPy5jb250ZW50X3R5cGUgPT09XG5cdFx0XHQnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LndvcmRwcm9jZXNzaW5nbWwuZG9jdW1lbnQnIHx8XG5cdFx0KGl0ZW0/Lm5hbWUgJiYgaXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5kb2N4JykpO1xuXG5cdCQ6IGlzUHB0eCA9XG5cdFx0aXRlbT8ubWV0YT8uY29udGVudF90eXBlID09PVxuXHRcdFx0J2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5wcmVzZW50YXRpb25tbC5wcmVzZW50YXRpb24nIHx8XG5cdFx0KGl0ZW0/Lm5hbWUgJiYgaXRlbS5uYW1lLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5wcHR4JykpO1xuXG5cdGNvbnN0IGxvYWRFeGNlbENvbnRlbnQgPSBhc3luYyAoKSA9PiB7XG5cdFx0dHJ5IHtcblx0XHRcdGV4Y2VsRXJyb3IgPSAnJztcblx0XHRcdGNvbnN0IFthcnJheUJ1ZmZlciwgeyByZWFkIH1dID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuXHRcdFx0XHRnZXRGaWxlQ29udGVudEJ5SWQoaXRlbS5pZCksXG5cdFx0XHRcdGltcG9ydCgneGxzeCcpXG5cdFx0XHRdKTtcblx0XHRcdGV4Y2VsV29ya2Jvb2sgPSByZWFkKGFycmF5QnVmZmVyLCB7IHR5cGU6ICdhcnJheScgfSk7XG5cdFx0XHRleGNlbFNoZWV0TmFtZXMgPSBleGNlbFdvcmtib29rLlNoZWV0TmFtZXM7XG5cblx0XHRcdGlmIChleGNlbFNoZWV0TmFtZXMubGVuZ3RoID4gMCkge1xuXHRcdFx0XHRzZWxlY3RlZFNoZWV0ID0gZXhjZWxTaGVldE5hbWVzWzBdO1xuXHRcdFx0XHRhd2FpdCByZW5kZXJFeGNlbFNoZWV0KCk7XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGxvYWRpbmcgRXhjZWwvQ1NWIGZpbGU6JywgZXJyb3IpO1xuXHRcdFx0ZXhjZWxFcnJvciA9ICRpMThuLnQoJ0ZhaWxlZCB0byBsb2FkIEV4Y2VsL0NTViBmaWxlLiBQbGVhc2UgdHJ5IGRvd25sb2FkaW5nIGl0IGluc3RlYWQuJyk7XG5cdFx0fVxuXHR9O1xuXG5cdGNvbnN0IHJlbmRlckV4Y2VsU2hlZXQgPSBhc3luYyAoKSA9PiB7XG5cdFx0aWYgKCFleGNlbFdvcmtib29rIHx8ICFzZWxlY3RlZFNoZWV0KSByZXR1cm47XG5cdFx0Y29uc3QgeyBleGNlbFRvVGFibGUgfSA9IGF3YWl0IGltcG9ydCgnJGxpYi91dGlscy9leGNlbFRvVGFibGUnKTtcblx0XHRjb25zdCB3b3Jrc2hlZXQgPSBleGNlbFdvcmtib29rLlNoZWV0c1tzZWxlY3RlZFNoZWV0XTtcblx0XHRjb25zdCByZXN1bHQgPSBhd2FpdCBleGNlbFRvVGFibGUod29ya3NoZWV0KTtcblx0XHRleGNlbEh0bWwgPSBET01QdXJpZnkuc2FuaXRpemUocmVzdWx0Lmh0bWwpO1xuXHRcdHJvd0NvdW50ID0gcmVzdWx0LnJvd0NvdW50O1xuXHR9O1xuXG5cdCQ6IGlmIChzZWxlY3RlZFNoZWV0ICYmIGV4Y2VsV29ya2Jvb2spIHtcblx0XHRyZW5kZXJFeGNlbFNoZWV0KCk7XG5cdH1cblxuXHRjb25zdCBsb2FkRG9jeENvbnRlbnQgPSBhc3luYyAoKSA9PiB7XG5cdFx0dHJ5IHtcblx0XHRcdGRvY3hFcnJvciA9ICcnO1xuXHRcdFx0ZG9jeERhdGEgPSBhd2FpdCBnZXRGaWxlQ29udGVudEJ5SWQoaXRlbS5pZCk7XG5cdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGxvYWRpbmcgRE9DWCBmaWxlOicsIGVycm9yKTtcblx0XHRcdGRvY3hFcnJvciA9ICRpMThuLnQoJ0ZhaWxlZCB0byBsb2FkIERPQ1ggZmlsZS4gUGxlYXNlIHRyeSBkb3dubG9hZGluZyBpdCBpbnN0ZWFkLicpO1xuXHRcdH1cblx0fTtcblxuXHRjb25zdCBsb2FkUHB0eENvbnRlbnQgPSBhc3luYyAoKSA9PiB7XG5cdFx0dHJ5IHtcblx0XHRcdHBwdHhFcnJvciA9ICcnO1xuXHRcdFx0Y29uc3QgW2FycmF5QnVmZmVyLCB7IHBwdHhUb0ltYWdlcyB9XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcblx0XHRcdFx0Z2V0RmlsZUNvbnRlbnRCeUlkKGl0ZW0uaWQpLFxuXHRcdFx0XHRpbXBvcnQoJyRsaWIvdXRpbHMvcHB0eFRvSHRtbCcpXG5cdFx0XHRdKTtcblx0XHRcdGNvbnN0IHJlc3VsdCA9IGF3YWl0IHBwdHhUb0ltYWdlcyhhcnJheUJ1ZmZlcik7XG5cdFx0XHRwcHR4U2xpZGVzID0gcmVzdWx0LmltYWdlcztcblx0XHRcdHBwdHhDdXJyZW50U2xpZGUgPSAwO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRjb25zb2xlLmVycm9yKCdFcnJvciBsb2FkaW5nIFBQVFggZmlsZTonLCBlcnJvcik7XG5cdFx0XHRwcHR4RXJyb3IgPSAkaTE4bi50KCdGYWlsZWQgdG8gbG9hZCBQUFRYIGZpbGUuIFBsZWFzZSB0cnkgZG93bmxvYWRpbmcgaXQgaW5zdGVhZC4nKTtcblx0XHR9XG5cdH07XG5cblx0Y29uc3QgbG9hZENvbnRlbnQgPSBhc3luYyAoKSA9PiB7XG5cdFx0c2VsZWN0ZWRUYWIgPSAnJztcblx0XHRleHBhbmRlZENvbnRlbnQgPSBmYWxzZTtcblx0XHRkb2N4RGF0YSA9IG51bGw7XG5cdFx0aWYgKGl0ZW0/LnR5cGUgPT09ICdjb2xsZWN0aW9uJykge1xuXHRcdFx0bG9hZGluZyA9IHRydWU7XG5cblx0XHRcdGNvbnN0IGtub3dsZWRnZSA9IGF3YWl0IGdldEtub3dsZWRnZUJ5SWQobG9jYWxTdG9yYWdlLnRva2VuLCBpdGVtLmlkKS5jYXRjaCgoZSkgPT4ge1xuXHRcdFx0XHRjb25zb2xlLmVycm9yKCdFcnJvciBmZXRjaGluZyBrbm93bGVkZ2UgYmFzZTonLCBlKTtcblx0XHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0XHR9KTtcblxuXHRcdFx0aWYgKGtub3dsZWRnZSkge1xuXHRcdFx0XHRpdGVtLmZpbGVzID0ga25vd2xlZGdlLmZpbGVzIHx8IFtdO1xuXHRcdFx0fVxuXHRcdFx0bG9hZGluZyA9IGZhbHNlO1xuXHRcdH0gZWxzZSBpZiAoaXRlbT8udHlwZSA9PT0gJ2ZpbGUnKSB7XG5cdFx0XHRsb2FkaW5nID0gdHJ1ZTtcblxuXHRcdFx0Y29uc3QgZmlsZSA9IGF3YWl0IGdldEZpbGVCeUlkKGxvY2FsU3RvcmFnZS50b2tlbiwgaXRlbS5pZCkuY2F0Y2goKGUpID0+IHtcblx0XHRcdFx0Y29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgZmlsZTonLCBlKTtcblx0XHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0XHR9KTtcblxuXHRcdFx0aWYgKGZpbGUpIHtcblx0XHRcdFx0aXRlbS5maWxlID0gZmlsZSB8fCB7fTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gTG9hZCBFeGNlbCBjb250ZW50IGlmIGl0J3MgYW4gRXhjZWwgZmlsZVxuXHRcdFx0aWYgKGlzRXhjZWwpIHtcblx0XHRcdFx0YXdhaXQgbG9hZEV4Y2VsQ29udGVudCgpO1xuXHRcdFx0fVxuXHRcdFx0aWYgKGlzRG9jeCkge1xuXHRcdFx0XHRhd2FpdCBsb2FkRG9jeENvbnRlbnQoKTtcblx0XHRcdH1cblx0XHRcdGlmIChpc1BwdHgpIHtcblx0XHRcdFx0YXdhaXQgbG9hZFBwdHhDb250ZW50KCk7XG5cdFx0XHR9XG5cblx0XHRcdGxvYWRpbmcgPSBmYWxzZTtcblx0XHR9XG5cblx0XHRhd2FpdCB0aWNrKCk7XG5cdH07XG5cblx0JDogaWYgKHNob3cpIHtcblx0XHRsb2FkQ29udGVudCgpO1xuXHR9XG5cblx0b25Nb3VudCgoKSA9PiB7XG5cdFx0Y29uc29sZS5sb2coaXRlbSk7XG5cdFx0aWYgKGl0ZW0/LmNvbnRleHQgPT09ICdmdWxsJykge1xuXHRcdFx0ZW5hYmxlRnVsbENvbnRlbnQgPSB0cnVlO1xuXHRcdH1cblx0fSk7XG48L3NjcmlwdD5cblxuPE1vZGFsIGJpbmQ6c2hvdyBzaXplPVwibGdcIj5cblx0PGRpdiBjbGFzcz1cIiBweC00LjUgcHktMy41IHctZnVsbCBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIGRhcms6dGV4dC1ncmF5LTQwMFwiPlxuXHRcdDxkaXYgY2xhc3M9XCIgcGItMlwiPlxuXHRcdFx0PGRpdiBjbGFzcz1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuXCI+XG5cdFx0XHRcdDxkaXY+XG5cdFx0XHRcdFx0PGRpdiBjbGFzcz1cIiBmb250LW5vcm1hbCB0ZXh0LWxnIGRhcms6dGV4dC1ncmF5LTEwMFwiPlxuXHRcdFx0XHRcdFx0PGFcblx0XHRcdFx0XHRcdFx0aHJlZj1cIiNcIlxuXHRcdFx0XHRcdFx0XHRjbGFzcz1cImhvdmVyOnVuZGVybGluZSBsaW5lLWNsYW1wLTFcIlxuXHRcdFx0XHRcdFx0XHRvbjpjbGlja3xwcmV2ZW50RGVmYXVsdD17KCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdGlmIChpdGVtLnR5cGUgPT09ICdmaWxlJyB8fCBpdGVtLnVybCkge1xuXHRcdFx0XHRcdFx0XHRcdFx0bGV0IGZpbGVJZCA9IGl0ZW0/LmlkID8/IGl0ZW0/LnRlbXBJZDtcblx0XHRcdFx0XHRcdFx0XHRcdHdpbmRvdy5vcGVuKFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRpdGVtLnR5cGUgPT09ICdmaWxlJ1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdD8gaXRlbT8udXJsPy5zdGFydHNXaXRoKCdodHRwJylcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdD8gaXRlbS51cmxcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdDogYCR7V0VCVUlfQVBJX0JBU0VfVVJMfS9maWxlcy8ke2ZpbGVJZH0vY29udGVudGBcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHQ6IGl0ZW0udXJsLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHQnX2JsYW5rJ1xuXHRcdFx0XHRcdFx0XHRcdFx0KTtcblx0XHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRcdH19XG5cdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdHtpdGVtPy5uYW1lID8/ICdGaWxlJ31cblx0XHRcdFx0XHRcdDwvYT5cblx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0PC9kaXY+XG5cblx0XHRcdFx0PGRpdj5cblx0XHRcdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdFx0XHRvbjpjbGljaz17KCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRzaG93ID0gZmFsc2U7XG5cdFx0XHRcdFx0XHR9fVxuXHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdDxYTWFyayAvPlxuXHRcdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHQ8L2Rpdj5cblx0XHRcdDwvZGl2PlxuXG5cdFx0XHQ8ZGl2PlxuXHRcdFx0XHQ8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgbWQ6ZmxleC1yb3cgZ2FwLTEganVzdGlmeS1iZXR3ZWVuIHctZnVsbFwiPlxuXHRcdFx0XHRcdDxkaXYgY2xhc3M9XCIgZmxleCBmbGV4LXdyYXAgdGV4dC14cyBnYXAtMSB0ZXh0LWdyYXktNTAwXCI+XG5cdFx0XHRcdFx0XHR7I2lmIGl0ZW0/LnR5cGUgPT09ICdjb2xsZWN0aW9uJ31cblx0XHRcdFx0XHRcdFx0eyNpZiBpdGVtPy50eXBlfVxuXHRcdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJjYXBpdGFsaXplIHNocmluay0wXCI+e2l0ZW0udHlwZX08L2Rpdj5cblx0XHRcdFx0XHRcdFx0XHTigKJcblx0XHRcdFx0XHRcdFx0ey9pZn1cblxuXHRcdFx0XHRcdFx0XHR7I2lmIGl0ZW0/LmRlc2NyaXB0aW9ufVxuXHRcdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJsaW5lLWNsYW1wLTFcIj57aXRlbS5kZXNjcmlwdGlvbn08L2Rpdj5cblx0XHRcdFx0XHRcdFx0XHTigKJcblx0XHRcdFx0XHRcdFx0ey9pZn1cblxuXHRcdFx0XHRcdFx0XHR7I2lmIGl0ZW0/LmNyZWF0ZWRfYXR9XG5cdFx0XHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cImNhcGl0YWxpemUgc2hyaW5rLTBcIj5cblx0XHRcdFx0XHRcdFx0XHRcdHtkYXlqcyhpdGVtLmNyZWF0ZWRfYXQgKiAxMDAwKS5mb3JtYXQoJ0xMJyl9XG5cdFx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHRcdHsvaWZ9XG5cdFx0XHRcdFx0XHR7L2lmfVxuXG5cdFx0XHRcdFx0XHR7I2lmIGl0ZW0uc2l6ZX1cblx0XHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cImNhcGl0YWxpemUgc2hyaW5rLTBcIj57Zm9ybWF0RmlsZVNpemUoaXRlbS5zaXplKX08L2Rpdj5cblx0XHRcdFx0XHRcdFx04oCiXG5cdFx0XHRcdFx0XHR7L2lmfVxuXG5cdFx0XHRcdFx0XHR7I2lmIGl0ZW0/LmZpbGU/LmRhdGE/LmNvbnRlbnR9XG5cdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJjYXBpdGFsaXplIHNocmluay0wXCI+XG5cdFx0XHRcdFx0XHRcdFx0eyNpZiBpc0V4Y2VsICYmIHJvd0NvdW50ID4gMCAmJiBzZWxlY3RlZFRhYiA9PT0gJ3ByZXZpZXcnfVxuXHRcdFx0XHRcdFx0XHRcdFx0eyRpMThuLnQoJ3t7Q09VTlR9fSBSb3dzJywge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRDT1VOVDogcm93Q291bnRcblx0XHRcdFx0XHRcdFx0XHRcdH0pfVxuXHRcdFx0XHRcdFx0XHRcdHs6ZWxzZX1cblx0XHRcdFx0XHRcdFx0XHRcdHskaTE4bi50KCd7e0NPVU5UfX0gZXh0cmFjdGVkIGxpbmVzJywge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRDT1VOVDogZ2V0TGluZUNvdW50KGl0ZW0/LmZpbGU/LmRhdGE/LmNvbnRlbnQgPz8gJycpXG5cdFx0XHRcdFx0XHRcdFx0XHR9KX1cblx0XHRcdFx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHRcdFx0XHQ8L2Rpdj5cblxuXHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgc2hyaW5rLTBcIj5cblx0XHRcdFx0XHRcdFx0XHTigKIgeyRpMThuLnQoJ0Zvcm1hdHRpbmcgbWF5IGJlIGluY29uc2lzdGVudCBmcm9tIHNvdXJjZS4nKX1cblx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHR7L2lmfVxuXG5cdFx0XHRcdFx0XHR7I2lmIGl0ZW0/Lmtub3dsZWRnZX1cblx0XHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cImNhcGl0YWxpemUgc2hyaW5rLTBcIj5cblx0XHRcdFx0XHRcdFx0XHR7JGkxOG4udCgnS25vd2xlZGdlIEJhc2UnKX1cblx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHRcdDwvZGl2PlxuXG5cdFx0XHRcdFx0eyNpZiBlZGl0fVxuXHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cIiBzZWxmLWVuZFwiPlxuXHRcdFx0XHRcdFx0XHQ8VG9vbHRpcFxuXHRcdFx0XHRcdFx0XHRcdGNvbnRlbnQ9e2VuYWJsZUZ1bGxDb250ZW50XG5cdFx0XHRcdFx0XHRcdFx0XHQ/ICRpMThuLnQoXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0J0luamVjdCB0aGUgZW50aXJlIGNvbnRlbnQgYXMgY29udGV4dCBmb3IgY29tcHJlaGVuc2l2ZSBwcm9jZXNzaW5nLCB0aGlzIGlzIHJlY29tbWVuZGVkIGZvciBjb21wbGV4IHF1ZXJpZXMuJ1xuXHRcdFx0XHRcdFx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0XHRcdFx0XHQ6ICRpMThuLnQoXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0J0RlZmF1bHQgdG8gc2VnbWVudGVkIHJldHJpZXZhbCBmb3IgZm9jdXNlZCBhbmQgcmVsZXZhbnQgY29udGVudCBleHRyYWN0aW9uLCB0aGlzIGlzIHJlY29tbWVuZGVkIGZvciBtb3N0IGNhc2VzLidcblx0XHRcdFx0XHRcdFx0XHRcdFx0KX1cblx0XHRcdFx0XHRcdFx0PlxuXHRcdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHNcIj5cblx0XHRcdFx0XHRcdFx0XHRcdHsjaWYgZW5hYmxlRnVsbENvbnRlbnR9XG5cdFx0XHRcdFx0XHRcdFx0XHRcdHskaTE4bi50KCdVc2luZyBFbnRpcmUgRG9jdW1lbnQnKX1cblx0XHRcdFx0XHRcdFx0XHRcdHs6ZWxzZX1cblx0XHRcdFx0XHRcdFx0XHRcdFx0eyRpMThuLnQoJ1VzaW5nIEZvY3VzZWQgUmV0cmlldmFsJyl9XG5cdFx0XHRcdFx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHRcdFx0XHRcdFx0PFN3aXRjaFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRiaW5kOnN0YXRlPXtlbmFibGVGdWxsQ29udGVudH1cblx0XHRcdFx0XHRcdFx0XHRcdFx0b246Y2hhbmdlPXsoZSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGl0ZW0uY29udGV4dCA9IGUuZGV0YWlsID8gJ2Z1bGwnIDogdW5kZWZpbmVkO1xuXHRcdFx0XHRcdFx0XHRcdFx0XHR9fVxuXHRcdFx0XHRcdFx0XHRcdFx0Lz5cblx0XHRcdFx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHRcdFx0PC9Ub29sdGlwPlxuXHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0ey9pZn1cblx0XHRcdFx0PC9kaXY+XG5cdFx0XHQ8L2Rpdj5cblx0XHQ8L2Rpdj5cblxuXHRcdDxkaXYgY2xhc3M9XCJtYXgtaC1bNzV2aF0gb3ZlcmZsb3ctYXV0b1wiPlxuXHRcdFx0eyNpZiAhbG9hZGluZ31cblx0XHRcdFx0eyNpZiBpdGVtPy50eXBlID09PSAnY29sbGVjdGlvbid9XG5cdFx0XHRcdFx0PGRpdj5cblx0XHRcdFx0XHRcdHsjZWFjaCBpdGVtPy5maWxlcyBhcyBmaWxlfVxuXHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMlwiPlxuXHRcdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJmbGV4LXNocmluay0wIHRleHQteHNcIj5cblx0XHRcdFx0XHRcdFx0XHRcdHtmaWxlPy5tZXRhPy5uYW1lfVxuXHRcdFx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHRcdHsvZWFjaH1cblx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0ey9pZn1cblxuXHRcdFx0XHR7I2lmIGlzQXVkaW8gfHwgaXNQREYgfHwgaXNFeGNlbCB8fCBpc0NvZGUgfHwgaXNNYXJrZG93biB8fCBpc0RvY3ggfHwgaXNQcHR4fVxuXHRcdFx0XHRcdDxkaXZcblx0XHRcdFx0XHRcdGNsYXNzPVwiZmxleCBtYi0yLjUgc2Nyb2xsYmFyLW5vbmUgb3ZlcmZsb3cteC1hdXRvIHctZnVsbCBib3JkZXItYiBib3JkZXItZ3JheS01MCBkYXJrOmJvcmRlci1ncmF5LTg1MC8zMCB0ZXh0LWNlbnRlciB0ZXh0LXNtIGZvbnQtbm9ybWFsIGJnLXRyYW5zcGFyZW50IGRhcms6dGV4dC1ncmF5LTIwMFwiXG5cdFx0XHRcdFx0PlxuXHRcdFx0XHRcdFx0PGJ1dHRvblxuXHRcdFx0XHRcdFx0XHRjbGFzcz1cIm1pbi13LWZpdCBweS0xLjUgcHgtNCBib3JkZXItYiB7c2VsZWN0ZWRUYWIgPT09ICcnXG5cdFx0XHRcdFx0XHRcdFx0PyAnICdcblx0XHRcdFx0XHRcdFx0XHQ6ICcgYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtZ3JheS0zMDAgZGFyazp0ZXh0LWdyYXktNjAwIGhvdmVyOnRleHQtZ3JheS03MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ30gdHJhbnNpdGlvblwiXG5cdFx0XHRcdFx0XHRcdHR5cGU9XCJidXR0b25cIlxuXHRcdFx0XHRcdFx0XHRvbjpjbGljaz17KCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdHNlbGVjdGVkVGFiID0gJyc7XG5cdFx0XHRcdFx0XHRcdH19PnskaTE4bi50KCdDb250ZW50Jyl9PC9idXR0b25cblx0XHRcdFx0XHRcdD5cblxuXHRcdFx0XHRcdFx0PGJ1dHRvblxuXHRcdFx0XHRcdFx0XHRjbGFzcz1cIm1pbi13LWZpdCBweS0xLjUgcHgtNCBib3JkZXItYiB7c2VsZWN0ZWRUYWIgPT09ICdwcmV2aWV3J1xuXHRcdFx0XHRcdFx0XHRcdD8gJyAnXG5cdFx0XHRcdFx0XHRcdFx0OiAnIGJvcmRlci10cmFuc3BhcmVudCB0ZXh0LWdyYXktMzAwIGRhcms6dGV4dC1ncmF5LTYwMCBob3Zlcjp0ZXh0LWdyYXktNzAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSd9IHRyYW5zaXRpb25cIlxuXHRcdFx0XHRcdFx0XHR0eXBlPVwiYnV0dG9uXCJcblx0XHRcdFx0XHRcdFx0b246Y2xpY2s9eygpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRzZWxlY3RlZFRhYiA9ICdwcmV2aWV3Jztcblx0XHRcdFx0XHRcdFx0fX0+eyRpMThuLnQoJ1ByZXZpZXcnKX08L2J1dHRvblxuXHRcdFx0XHRcdFx0PlxuXHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHR7L2lmfVxuXG5cdFx0XHRcdHsjaWYgaXNJbWFnZX1cblx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwicmVsYXRpdmUgdy1mdWxsIG1heC1oLVs3MHZoXSBvdmVyZmxvdy1oaWRkZW5cIj5cblx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSB0b3AtMiByaWdodC0yIHotMTBcIj5cblx0XHRcdFx0XHRcdFx0PFRvb2x0aXAgY29udGVudD17JGkxOG4udCgnUmVzZXQgdmlldycpfT5cblx0XHRcdFx0XHRcdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdFx0XHRcdFx0XHRjbGFzcz1cInAtMS41IHJvdW5kZWQtbGcgYmctd2hpdGUvODAgZGFyazpiZy1ncmF5LTg1MC84MCBiYWNrZHJvcC1ibHVyLXNtIHNoYWRvdy1zbSBob3ZlcjpiZy1ncmF5LTEwMCBkYXJrOmhvdmVyOmJnLWdyYXktODAwIHRyYW5zaXRpb24gdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIlxuXHRcdFx0XHRcdFx0XHRcdFx0b246Y2xpY2s9e3Jlc2V0SW1hZ2VWaWV3fVxuXHRcdFx0XHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdFx0XHRcdDxSZXNldCBjbGFzc05hbWU9XCJzaXplLTRcIiAvPlxuXHRcdFx0XHRcdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHRcdFx0XHQ8L1Rvb2x0aXA+XG5cdFx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHRcdDxQYW56b29tQ29udGFpbmVyIGJpbmQ6dGhpcz17cGFuem9vbVJlZn0+XG5cdFx0XHRcdFx0XHRcdDxpbWdcblx0XHRcdFx0XHRcdFx0XHRzcmM9e2Ake1dFQlVJX0FQSV9CQVNFX1VSTH0vZmlsZXMvJHtpdGVtLmlkfS9jb250ZW50YH1cblx0XHRcdFx0XHRcdFx0XHRhbHQ9e2l0ZW0/Lm5hbWUgPz8gJ0ltYWdlJ31cblx0XHRcdFx0XHRcdFx0XHRjbGFzcz1cInctZnVsbCBvYmplY3QtY29udGFpbiByb3VuZGVkLWxnXCJcblx0XHRcdFx0XHRcdFx0XHRsb2FkaW5nPVwibGF6eVwiXG5cdFx0XHRcdFx0XHRcdFx0ZHJhZ2dhYmxlPVwiZmFsc2VcIlxuXHRcdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdFx0PC9QYW56b29tQ29udGFpbmVyPlxuXHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHR7OmVsc2UgaWYgc2VsZWN0ZWRUYWIgPT09ICcnfVxuXHRcdFx0XHRcdHsjaWYgaXRlbT8uZmlsZT8uZGF0YX1cblx0XHRcdFx0XHRcdHtAY29uc3QgcmF3Q29udGVudCA9IChpdGVtPy5maWxlPy5kYXRhPy5jb250ZW50ID8/ICcnKS50cmltKCkgfHwgJ05vIGNvbnRlbnQnfVxuXHRcdFx0XHRcdFx0e0Bjb25zdCBpc1RydW5jYXRlZCA9XG5cdFx0XHRcdFx0XHRcdCgkc2V0dGluZ3M/LnJlbmRlck1hcmtkb3duSW5QcmV2aWV3cyA/PyB0cnVlKSAmJlxuXHRcdFx0XHRcdFx0XHRyYXdDb250ZW50Lmxlbmd0aCA+IENPTlRFTlRfUFJFVklFV19MSU1JVCAmJlxuXHRcdFx0XHRcdFx0XHQhZXhwYW5kZWRDb250ZW50fVxuXHRcdFx0XHRcdFx0eyNpZiAkc2V0dGluZ3M/LnJlbmRlck1hcmtkb3duSW5QcmV2aWV3cyA/PyB0cnVlfVxuXHRcdFx0XHRcdFx0XHQ8ZGl2XG5cdFx0XHRcdFx0XHRcdFx0Y2xhc3M9XCJtYXgtaC05NiBvdmVyZmxvdy1zY3JvbGwgc2Nyb2xsYmFyLWhpZGRlbiB0ZXh0LXNtIHByb3NlIGRhcms6cHJvc2UtaW52ZXJ0IG1heC13LWZ1bGxcIlxuXHRcdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdFx0PE1hcmtkb3duXG5cdFx0XHRcdFx0XHRcdFx0XHRjb250ZW50PXtpc1RydW5jYXRlZCA/IHJhd0NvbnRlbnQuc2xpY2UoMCwgQ09OVEVOVF9QUkVWSUVXX0xJTUlUKSA6IHJhd0NvbnRlbnR9XG5cdFx0XHRcdFx0XHRcdFx0XHRpZD1cImZpbGUtcHJldmlld1wiXG5cdFx0XHRcdFx0XHRcdFx0Lz5cblx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHRcdHsjaWYgaXNUcnVuY2F0ZWR9XG5cdFx0XHRcdFx0XHRcdFx0PGJ1dHRvblxuXHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3M9XCJtdC0xIHRleHQteHMgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktNzAwIGRhcms6aG92ZXI6dGV4dC1ncmF5LTMwMCB0cmFuc2l0aW9uXCJcblx0XHRcdFx0XHRcdFx0XHRcdG9uOmNsaWNrPXsoKSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGV4cGFuZGVkQ29udGVudCA9IHRydWU7XG5cdFx0XHRcdFx0XHRcdFx0XHR9fVxuXHRcdFx0XHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdFx0XHRcdHskaTE4bi50KCdTaG93IGFsbCAoe3tDT1VOVH19IGNoYXJhY3RlcnMpJywge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRDT1VOVDogcmF3Q29udGVudC5sZW5ndGgudG9Mb2NhbGVTdHJpbmcoKVxuXHRcdFx0XHRcdFx0XHRcdFx0fSl9XG5cdFx0XHRcdFx0XHRcdFx0PC9idXR0b24+XG5cdFx0XHRcdFx0XHRcdHsvaWZ9XG5cdFx0XHRcdFx0XHR7OmVsc2V9XG5cdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJtYXgtaC05NiBvdmVyZmxvdy1zY3JvbGwgc2Nyb2xsYmFyLWhpZGRlbiB0ZXh0LXhzIHdoaXRlc3BhY2UtcHJlLXdyYXBcIj5cblx0XHRcdFx0XHRcdFx0XHR7cmF3Q29udGVudH1cblx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHRcdHs6ZWxzZSBpZiBpdGVtPy5jb250ZW50fVxuXHRcdFx0XHRcdFx0e0Bjb25zdCByYXdDb250ZW50ID0gKGl0ZW0/LmNvbnRlbnQgPz8gJycpLnRyaW0oKSB8fCAnTm8gY29udGVudCd9XG5cdFx0XHRcdFx0XHR7QGNvbnN0IGlzVHJ1bmNhdGVkID1cblx0XHRcdFx0XHRcdFx0KCRzZXR0aW5ncz8ucmVuZGVyTWFya2Rvd25JblByZXZpZXdzID8/IHRydWUpICYmXG5cdFx0XHRcdFx0XHRcdHJhd0NvbnRlbnQubGVuZ3RoID4gQ09OVEVOVF9QUkVWSUVXX0xJTUlUICYmXG5cdFx0XHRcdFx0XHRcdCFleHBhbmRlZENvbnRlbnR9XG5cdFx0XHRcdFx0XHR7I2lmICRzZXR0aW5ncz8ucmVuZGVyTWFya2Rvd25JblByZXZpZXdzID8/IHRydWV9XG5cdFx0XHRcdFx0XHRcdDxkaXZcblx0XHRcdFx0XHRcdFx0XHRjbGFzcz1cIm1heC1oLTk2IG92ZXJmbG93LXNjcm9sbCBzY3JvbGxiYXItaGlkZGVuIHRleHQtc20gcHJvc2UgZGFyazpwcm9zZS1pbnZlcnQgbWF4LXctZnVsbFwiXG5cdFx0XHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdFx0XHQ8TWFya2Rvd25cblx0XHRcdFx0XHRcdFx0XHRcdGNvbnRlbnQ9e2lzVHJ1bmNhdGVkID8gcmF3Q29udGVudC5zbGljZSgwLCBDT05URU5UX1BSRVZJRVdfTElNSVQpIDogcmF3Q29udGVudH1cblx0XHRcdFx0XHRcdFx0XHRcdGlkPVwiZmlsZS1wcmV2aWV3LWNvbnRlbnRcIlxuXHRcdFx0XHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdFx0XHR7I2lmIGlzVHJ1bmNhdGVkfVxuXHRcdFx0XHRcdFx0XHRcdDxidXR0b25cblx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTcwMCBkYXJrOmhvdmVyOnRleHQtZ3JheS0zMDAgdHJhbnNpdGlvblwiXG5cdFx0XHRcdFx0XHRcdFx0XHRvbjpjbGljaz17KCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRleHBhbmRlZENvbnRlbnQgPSB0cnVlO1xuXHRcdFx0XHRcdFx0XHRcdFx0fX1cblx0XHRcdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdFx0XHR7JGkxOG4udCgnU2hvdyBhbGwgKHt7Q09VTlR9fSBjaGFyYWN0ZXJzKScsIHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0Q09VTlQ6IHJhd0NvbnRlbnQubGVuZ3RoLnRvTG9jYWxlU3RyaW5nKClcblx0XHRcdFx0XHRcdFx0XHRcdH0pfVxuXHRcdFx0XHRcdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHRcdFx0ezplbHNlfVxuXHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwibWF4LWgtOTYgb3ZlcmZsb3ctc2Nyb2xsIHNjcm9sbGJhci1oaWRkZW4gdGV4dC14cyB3aGl0ZXNwYWNlLXByZS13cmFwXCI+XG5cdFx0XHRcdFx0XHRcdFx0e3Jhd0NvbnRlbnR9XG5cdFx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdFx0ey9pZn1cblx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHR7OmVsc2UgaWYgc2VsZWN0ZWRUYWIgPT09ICdwcmV2aWV3J31cblx0XHRcdFx0XHR7I2lmIGlzQXVkaW99XG5cdFx0XHRcdFx0XHQ8YXVkaW9cblx0XHRcdFx0XHRcdFx0c3JjPXtgJHtXRUJVSV9BUElfQkFTRV9VUkx9L2ZpbGVzLyR7aXRlbS5pZH0vY29udGVudGB9XG5cdFx0XHRcdFx0XHRcdGNsYXNzPVwidy1mdWxsIGJvcmRlci0wIHJvdW5kZWQtbGcgbWItMlwiXG5cdFx0XHRcdFx0XHRcdGNvbnRyb2xzXG5cdFx0XHRcdFx0XHRcdHBsYXlzaW5saW5lXG5cdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdHs6ZWxzZSBpZiBpc1BERn1cblx0XHRcdFx0XHRcdDxQREZWaWV3ZXJcblx0XHRcdFx0XHRcdFx0dXJsPXtgJHtXRUJVSV9BUElfQkFTRV9VUkx9L2ZpbGVzLyR7aXRlbS5pZH0vY29udGVudGB9XG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZT1cInctZnVsbCBoLVs3MHZoXSBib3JkZXItMCByb3VuZGVkLWxnXCJcblx0XHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0ezplbHNlIGlmIGlzRXhjZWx9XG5cdFx0XHRcdFx0XHR7I2lmIGV4Y2VsRXJyb3J9XG5cdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBwLTRcIj5cblx0XHRcdFx0XHRcdFx0XHR7ZXhjZWxFcnJvcn1cblx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHR7OmVsc2V9XG5cdFx0XHRcdFx0XHRcdHsjaWYgZXhjZWxTaGVldE5hbWVzLmxlbmd0aCA+IDF9XG5cdFx0XHRcdFx0XHRcdFx0PGRpdlxuXHRcdFx0XHRcdFx0XHRcdFx0Y2xhc3M9XCJmbGV4IG1iLTIuNSBzY3JvbGxiYXItbm9uZSBvdmVyZmxvdy14LWF1dG8gdy1mdWxsIGJvcmRlci1iIGJvcmRlci1ncmF5LTUwIGRhcms6Ym9yZGVyLWdyYXktODUwLzMwIHRleHQtY2VudGVyIHRleHQtc20gZm9udC1ub3JtYWwgYmctdHJhbnNwYXJlbnQgZGFyazp0ZXh0LWdyYXktMjAwXCJcblx0XHRcdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdFx0XHR7I2VhY2ggZXhjZWxTaGVldE5hbWVzIGFzIHNoZWV0TmFtZX1cblx0XHRcdFx0XHRcdFx0XHRcdFx0PGJ1dHRvblxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzPVwibWluLXctZml0IHB5LTEuNSBweC00IGJvcmRlci1iIHtzZWxlY3RlZFNoZWV0ID09PSBzaGVldE5hbWVcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdD8gJyAnXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQ6ICcgYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtZ3JheS0zMDAgZGFyazp0ZXh0LWdyYXktNjAwIGhvdmVyOnRleHQtZ3JheS03MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlJ30gdHJhbnNpdGlvblwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0dHlwZT1cImJ1dHRvblwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0b246Y2xpY2s9eygpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHNlbGVjdGVkU2hlZXQgPSBzaGVldE5hbWU7XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0fX0+e3NoZWV0TmFtZX08L2J1dHRvblxuXHRcdFx0XHRcdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdFx0XHR7L2VhY2h9XG5cdFx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHRcdHsvaWZ9XG5cblx0XHRcdFx0XHRcdFx0eyNpZiBleGNlbEh0bWx9XG5cdFx0XHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cIm9mZmljZS1wcmV2aWV3IG92ZXJmbG93LWF1dG8gbWF4LWgtWzYwdmhdXCI+XG5cdFx0XHRcdFx0XHRcdFx0XHR7QGh0bWwgZXhjZWxIdG1sfVxuXHRcdFx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdFx0XHR7OmVsc2V9XG5cdFx0XHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cInRleHQtZ3JheS01MDAgdGV4dC1zbSBwLTRcIj5ObyBjb250ZW50IGF2YWlsYWJsZTwvZGl2PlxuXHRcdFx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHRcdFx0ey9pZn1cblx0XHRcdFx0XHR7OmVsc2UgaWYgaXNDb2RlfVxuXHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cIm1heC1oLVs2MHZoXSBvdmVyZmxvdy1zY3JvbGwgc2Nyb2xsYmFyLWhpZGRlbiB0ZXh0LXNtIHJlbGF0aXZlXCI+XG5cdFx0XHRcdFx0XHRcdDxDb2RlQmxvY2tcblx0XHRcdFx0XHRcdFx0XHRjb2RlPXtpdGVtLmZpbGUuZGF0YS5jb250ZW50fVxuXHRcdFx0XHRcdFx0XHRcdGxhbmc9e2l0ZW0ubmFtZS5zcGxpdCgnLicpLnBvcCgpfVxuXHRcdFx0XHRcdFx0XHRcdHRva2VuPXtudWxsfVxuXHRcdFx0XHRcdFx0XHRcdGVkaXQ9e2ZhbHNlfVxuXHRcdFx0XHRcdFx0XHRcdHJ1bj17ZmFsc2V9XG5cdFx0XHRcdFx0XHRcdFx0c2F2ZT17ZmFsc2V9XG5cdFx0XHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHR7OmVsc2UgaWYgaXNNYXJrZG93bn1cblx0XHRcdFx0XHRcdDxkaXZcblx0XHRcdFx0XHRcdFx0Y2xhc3M9XCJtYXgtaC1bNjB2aF0gb3ZlcmZsb3ctc2Nyb2xsIHNjcm9sbGJhci1oaWRkZW4gdGV4dC1zbSBwcm9zZSBkYXJrOnByb3NlLWludmVydCBtYXgtdy1mdWxsXCJcblx0XHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdFx0PE1hcmtkb3duIGNvbnRlbnQ9e2l0ZW0uZmlsZS5kYXRhLmNvbnRlbnR9IGlkPVwibWFya2Rvd24tdmlld2VyXCIgLz5cblx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdHs6ZWxzZSBpZiBpc0RvY3h9XG5cdFx0XHRcdFx0XHR7I2lmIGRvY3hFcnJvcn1cblx0XHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIHAtNFwiPntkb2N4RXJyb3J9PC9kaXY+XG5cdFx0XHRcdFx0XHR7OmVsc2UgaWYgZG9jeERhdGF9XG5cdFx0XHRcdFx0XHRcdDxEb2N4UHJldmlldyBkYXRhPXtkb2N4RGF0YX0gY2xhc3NOYW1lPVwiaC1bNjB2aF1cIiAvPlxuXHRcdFx0XHRcdFx0ezplbHNlfVxuXHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtIHAtNFwiPk5vIGNvbnRlbnQgYXZhaWxhYmxlPC9kaXY+XG5cdFx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHRcdHs6ZWxzZSBpZiBpc1BwdHh9XG5cdFx0XHRcdFx0XHR7I2lmIHBwdHhFcnJvcn1cblx0XHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIHAtNFwiPntwcHR4RXJyb3J9PC9kaXY+XG5cdFx0XHRcdFx0XHR7OmVsc2UgaWYgcHB0eFNsaWRlcy5sZW5ndGggPiAwfVxuXHRcdFx0XHRcdFx0XHQ8UHB0eFByZXZpZXdcblx0XHRcdFx0XHRcdFx0XHRzbGlkZXM9e3BwdHhTbGlkZXN9XG5cdFx0XHRcdFx0XHRcdFx0YmluZDpjdXJyZW50U2xpZGU9e3BwdHhDdXJyZW50U2xpZGV9XG5cdFx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lPVwiaC1bNjB2aF1cIlxuXHRcdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdFx0ezplbHNlfVxuXHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtIHAtNFwiPk5vIGNvbnRlbnQgYXZhaWxhYmxlPC9kaXY+XG5cdFx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHRcdHs6ZWxzZX1cblx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJtYXgtaC05NiBvdmVyZmxvdy1zY3JvbGwgc2Nyb2xsYmFyLWhpZGRlbiB0ZXh0LXhzIHdoaXRlc3BhY2UtcHJlLXdyYXBcIj5cblx0XHRcdFx0XHRcdFx0eyhpdGVtPy5maWxlPy5kYXRhPy5jb250ZW50ID8/ICcnKS50cmltKCkgfHwgJ05vIGNvbnRlbnQnfVxuXHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0ey9pZn1cblx0XHRcdFx0ey9pZn1cblx0XHRcdHs6ZWxzZX1cblx0XHRcdFx0PGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTZcIj5cblx0XHRcdFx0XHQ8U3Bpbm5lciBjbGFzc05hbWU9XCJzaXplLTVcIiAvPlxuXHRcdFx0XHQ8L2Rpdj5cblx0XHRcdHsvaWZ9XG5cdFx0PC9kaXY+XG5cdDwvZGl2PlxuPC9Nb2RhbD5cblxuPHN0eWxlPlxuXHQ6Z2xvYmFsKC5leGNlbC10YWJsZS1jb250YWluZXIgdGFibGUpIHtcblx0XHR3aWR0aDogMTAwJTtcblx0XHRib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xuXHRcdGZvbnQtc2l6ZTogMC44NzVyZW07XG5cdFx0bGluZS1oZWlnaHQ6IDEuMjVyZW07XG5cdH1cblxuXHQ6Z2xvYmFsKC5leGNlbC10YWJsZS1jb250YWluZXIgdGFibGUgdGQpLFxuXHQ6Z2xvYmFsKC5leGNlbC10YWJsZS1jb250YWluZXIgdGFibGUgdGgpIHtcblx0XHRib3JkZXItd2lkdGg6IDFweDtcblx0XHRib3JkZXItc3R5bGU6IHNvbGlkO1xuXHRcdGJvcmRlci1jb2xvcjogdmFyKC0tY29sb3ItZ3JheS0zMDAsICNjZGNkY2QpO1xuXHRcdHBhZGRpbmc6IDAuNXJlbSAwLjc1cmVtO1xuXHRcdHRleHQtYWxpZ246IGxlZnQ7XG5cdH1cblxuXHQ6Z2xvYmFsKC5kYXJrIC5leGNlbC10YWJsZS1jb250YWluZXIgdGFibGUgdGQpLFxuXHQ6Z2xvYmFsKC5kYXJrIC5leGNlbC10YWJsZS1jb250YWluZXIgdGFibGUgdGgpIHtcblx0XHRib3JkZXItY29sb3I6IHZhcigtLWNvbG9yLWdyYXktNjAwLCAjNjc2NzY3KTtcblx0fVxuXG5cdDpnbG9iYWwoLmV4Y2VsLXRhYmxlLWNvbnRhaW5lciB0YWJsZSB0aCkge1xuXHRcdGJhY2tncm91bmQtY29sb3I6IHZhcigtLWNvbG9yLWdyYXktMTAwLCAjZWNlY2VjKTtcblx0XHRmb250LXdlaWdodDogNjAwO1xuXHR9XG5cblx0Omdsb2JhbCguZGFyayAuZXhjZWwtdGFibGUtY29udGFpbmVyIHRhYmxlIHRoKSB7XG5cdFx0YmFja2dyb3VuZC1jb2xvcjogdmFyKC0tY29sb3ItZ3JheS04MDAsICMzMzMpO1xuXHRcdGNvbG9yOiB2YXIoLS1jb2xvci1ncmF5LTEwMCwgI2VjZWNlYyk7XG5cdH1cblxuXHQ6Z2xvYmFsKC5leGNlbC10YWJsZS1jb250YWluZXIgdGFibGUgdHI6bnRoLWNoaWxkKGV2ZW4pKSB7XG5cdFx0YmFja2dyb3VuZC1jb2xvcjogdmFyKC0tY29sb3ItZ3JheS01MCwgI2Y5ZjlmOSk7XG5cdH1cblxuXHQ6Z2xvYmFsKC5kYXJrIC5leGNlbC10YWJsZS1jb250YWluZXIgdGFibGUgdHI6bnRoLWNoaWxkKGV2ZW4pKSB7XG5cdFx0YmFja2dyb3VuZC1jb2xvcjogcmdiYSgzOCwgMzgsIDM4LCAwLjUpO1xuXHR9XG5cblx0Omdsb2JhbCguZXhjZWwtdGFibGUtY29udGFpbmVyIHRhYmxlIHRyOmhvdmVyKSB7XG5cdFx0YmFja2dyb3VuZC1jb2xvcjogdmFyKC0tY29sb3ItZ3JheS0xMDAsICNlY2VjZWMpO1xuXHR9XG5cblx0Omdsb2JhbCguZGFyayAuZXhjZWwtdGFibGUtY29udGFpbmVyIHRhYmxlIHRyOmhvdmVyKSB7XG5cdFx0YmFja2dyb3VuZC1jb2xvcjogcmdiYSg1MSwgNTEsIDUxLCAwLjUpO1xuXHR9XG48L3N0eWxlPlxuIl0sImZpbGUiOiIvc3JjL2xpYi9jb21wb25lbnRzL2NvbW1vbi9GaWxlSXRlbU1vZGFsLnN2ZWx0ZSJ9
