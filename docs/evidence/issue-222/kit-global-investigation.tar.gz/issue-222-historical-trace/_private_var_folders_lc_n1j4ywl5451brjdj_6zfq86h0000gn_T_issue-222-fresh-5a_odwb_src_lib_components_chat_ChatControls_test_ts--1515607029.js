// /private/var/folders/lc/n1j4ywl5451brjdj_6zfq86h0000gn/T/issue-222-fresh-5a__odwb/src/lib/components/chat/ChatControls.test.ts
const { afterEach, beforeEach, describe, expect, it, vi } = await __vite_ssr_dynamic_import__("/node_modules/vitest/dist/index.js")
vi.mock("@xterm/xterm", () => ({ Terminal: vi.fn() }));
const __vi_import_0__ = await __vite_ssr_dynamic_import__("/node_modules/svelte/src/index-client.js")
const __vi_import_1__ = await __vite_ssr_dynamic_import__("/node_modules/svelte/src/store/index-client.js")
const __vi_import_2__ = await __vite_ssr_dynamic_import__("/src/lib/stores/index.ts")
const __vi_import_3__ = await __vite_ssr_dynamic_import__("/src/lib/stores/ocu.ts")
const __vi_import_4__ = await __vite_ssr_dynamic_import__("/src/lib/components/chat/ChatControls.svelte")
const __vi_import_5__ = await __vite_ssr_dynamic_import__("/src/lib/components/chat/workspace-reconciliation.ts")







const id = "owner-chat";
const file = {
  file_id: "fixture-page.html",
  name: "page.html",
  path: "page.html",
  url: `/ocu/files/${id}/page.html`,
  type: "html",
  mime: "text/html",
  revision: 1,
  size: 128
};
const json = (body) => new Response(JSON.stringify(body), {
  headers: { "Content-Type": "application/json" }
});
const i18n = __vi_import_1__.writable({ t: (key) => key });
let component;
let controller;
let prior;
beforeEach(() => {
  prior = {
    chatId: __vi_import_1__.get(__vi_import_2__.chatId),
    config: __vi_import_1__.get(__vi_import_2__.config),
    settings: __vi_import_1__.get(__vi_import_2__.settings),
    temporary: __vi_import_1__.get(__vi_import_2__.temporaryChatEnabled),
    showControls: __vi_import_1__.get(__vi_import_2__.showControls),
    showArtifacts: __vi_import_1__.get(__vi_import_2__.showArtifacts),
    showEmbeds: __vi_import_1__.get(__vi_import_2__.showEmbeds),
    showCallOverlay: __vi_import_1__.get(__vi_import_2__.showCallOverlay),
    token: localStorage.getItem("token")
  };
  __vi_import_2__.chatId.set(id);
  __vi_import_2__.config.set({ features: { enable_ocu_workspace: true } });
  __vi_import_2__.settings.set({});
  __vi_import_2__.temporaryChatEnabled.set(false);
  __vi_import_2__.showControls.set(false);
  __vi_import_2__.showArtifacts.set(false);
  __vi_import_2__.showEmbeds.set(false);
  __vi_import_2__.showCallOverlay.set(false);
  __vi_import_3__.ocuWorkspaces.set({});
  localStorage.setItem("token", "owner-fixture");
  vi.stubGlobal(
    "matchMedia",
    vi.fn((query) => ({
      matches: true,
      media: query,
      addEventListener: () => {
      },
      removeEventListener: () => {
      }
    }))
  );
  vi.stubGlobal(
    "fetch",
    vi.fn((input, init) => {
      const url = String(input);
      if (url.endsWith("/prefs") && init?.method === "PUT")
        return Promise.resolve(json({ prefs: JSON.parse(String(init.body)) }));
      if (url.includes(`/workspaces/${id}`))
        return Promise.resolve(
          json({
            chat_id: id,
            status: "running",
            revision: 1,
            capabilities: ["prefs"],
            views: ["files"],
            base_url: "/ocu"
          })
        );
      if (url.includes(`/api/outputs/${id}`))
        return Promise.resolve(
          json({
            chat_id: id,
            revision: 1,
            files: [file],
            total: 1,
            next_cursor: null
          })
        );
      throw new Error(`Unexpected workspace request ${url}`);
    })
  );
  controller = __vi_import_5__.createWorkspaceReconciliation({
    token: () => localStorage.token,
    available: () => true,
    translate: (key) => __vi_import_1__.get(i18n).t(key)
  });
  controller.observe(id, true);
});
afterEach(async () => {
  if (component) await __vi_import_0__.unmount(component);
  const generation = __vi_import_1__.get(__vi_import_3__.ocuWorkspaces)[id]?.generation;
  if (generation !== void 0) __vi_import_3__.hydrateWorkspacePrefs(id, generation, {});
  controller.retire();
  await __vi_import_3__.queueWorkspacePrefs(id, async () => {
  });
  component = void 0;
  __vi_import_2__.chatId.set(prior.chatId);
  __vi_import_2__.config.set(prior.config);
  __vi_import_2__.settings.set(prior.settings);
  __vi_import_2__.temporaryChatEnabled.set(prior.temporary);
  __vi_import_2__.showControls.set(prior.showControls);
  __vi_import_2__.showArtifacts.set(prior.showArtifacts);
  __vi_import_2__.showEmbeds.set(prior.showEmbeds);
  __vi_import_2__.showCallOverlay.set(prior.showCallOverlay);
  __vi_import_3__.ocuWorkspaces.set({});
  if (prior.token === null) localStorage.removeItem("token");
  else localStorage.setItem("token", prior.token);
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
  document.body.replaceChildren();
});
describe("mounted chat workspace policy", () => {
  it("auto-opens first output, keeps a user-closed panel closed with a change badge, then acknowledges explicit open", async () => {
    component = __vi_import_0__.mount(__vi_import_4__.default, {
      target: document.body,
      context: /* @__PURE__ */ new Map([
        ["i18n", i18n],
        [__vi_import_5__.WORKSPACE_RECONCILIATION, controller]
      ]),
      props: {
        chatId: id,
        history: { messages: {}, currentId: null },
        files: [],
        modelId: null,
        eventTarget: new EventTarget(),
        submitPrompt: () => {
        },
        stopResponse: () => {
        },
        showMessage: () => {
        },
        ensureSavedChat: async () => id
      }
    });
    await __vi_import_0__.tick();
    const first = __vi_import_3__.beginGeneration(id);
    __vi_import_3__.applyWorkspaceListing(id, first, [file], 1, null);
    await vi.waitFor(() => expect(__vi_import_1__.get(__vi_import_2__.showControls)).toBe(true));
    await vi.waitFor(
      () => expect(document.querySelector('section[aria-label="Workspace Files"]')).not.toBeNull()
    );
    expect(document.body.textContent).not.toContain("Workspace changed");
    const close = document.querySelector('button[aria-label="Close workspace"]');
    expect(close).not.toBeNull();
    close.click();
    await vi.waitFor(() => expect(__vi_import_1__.get(__vi_import_2__.showControls)).toBe(false));
    const next = __vi_import_3__.beginGeneration(id);
    __vi_import_3__.applyWorkspaceListing(id, next, [{ ...file, revision: 2 }], 2, null);
    await vi.waitFor(() => expect(document.body.textContent).toContain("Workspace changed"));
    expect(__vi_import_1__.get(__vi_import_2__.showControls)).toBe(false);
    expect(document.querySelector('section[aria-label="Workspace Files"]')).toBeNull();
    const action = document.querySelector(
      'button[aria-label="Workspace Files"]'
    );
    expect(action).not.toBeNull();
    action.click();
    await vi.waitFor(() => expect(__vi_import_1__.get(__vi_import_2__.showControls)).toBe(true));
    await vi.waitFor(() => expect(document.body.textContent).not.toContain("Workspace changed"));
  });
});

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7O0FBOEJBLE1BQU0sS0FBSztBQUNYLE1BQU0sT0FBTztBQUFBLEVBQ1osU0FBUztBQUFBLEVBQ1QsTUFBTTtBQUFBLEVBQ04sTUFBTTtBQUFBLEVBQ04sS0FBSyxjQUFjLEVBQUU7QUFBQSxFQUNyQixNQUFNO0FBQUEsRUFDTixNQUFNO0FBQUEsRUFDTixVQUFVO0FBQUEsRUFDVixNQUFNO0FBQ1A7QUFDQSxNQUFNLE9BQU8sQ0FBQyxTQUNiLElBQUksU0FBUyxLQUFLLFVBQVUsSUFBSSxHQUFHO0FBQUEsRUFDbEMsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7QUFDL0MsQ0FBQztBQUNGLE1BQU0sT0FBTyx5QkFBUyxFQUFFLEdBQUcsQ0FBQyxRQUFnQixJQUFJLENBQUM7QUFDakQsSUFBSTtBQUNKLElBQUk7QUFDSixJQUFJO0FBWUosV0FBVyxNQUFNO0FBQ2hCLFVBQVE7QUFBQSxJQUNQLFFBQVEsb0JBQUksc0JBQU07QUFBQSxJQUNsQixRQUFRLG9CQUFJLHNCQUFNO0FBQUEsSUFDbEIsVUFBVSxvQkFBSSx3QkFBUTtBQUFBLElBQ3RCLFdBQVcsb0JBQUksb0NBQW9CO0FBQUEsSUFDbkMsY0FBYyxvQkFBSSw0QkFBWTtBQUFBLElBQzlCLGVBQWUsb0JBQUksNkJBQWE7QUFBQSxJQUNoQyxZQUFZLG9CQUFJLDBCQUFVO0FBQUEsSUFDMUIsaUJBQWlCLG9CQUFJLCtCQUFlO0FBQUEsSUFDcEMsT0FBTyxhQUFhLFFBQVEsT0FBTztBQUFBLEVBQ3BDO0FBQ0EseUJBQU8sSUFBSSxFQUFFO0FBQ2IseUJBQU8sSUFBSSxFQUFFLFVBQVUsRUFBRSxzQkFBc0IsS0FBSyxFQUFFLENBRWxEO0FBQ0osMkJBQVMsSUFBSSxDQUFDLENBQUM7QUFDZix1Q0FBcUIsSUFBSSxLQUFLO0FBQzlCLCtCQUFhLElBQUksS0FBSztBQUN0QixnQ0FBYyxJQUFJLEtBQUs7QUFDdkIsNkJBQVcsSUFBSSxLQUFLO0FBQ3BCLGtDQUFnQixJQUFJLEtBQUs7QUFDekIsZ0NBQWMsSUFBSSxDQUFDLENBQUM7QUFDcEIsZUFBYSxRQUFRLFNBQVMsZUFBZTtBQUM3QyxLQUFHO0FBQUEsSUFDRjtBQUFBLElBQ0EsR0FBRyxHQUFHLENBQUMsV0FBbUI7QUFBQSxNQUN6QixTQUFTO0FBQUEsTUFDVCxPQUFPO0FBQUEsTUFDUCxrQkFBa0IsTUFBTTtBQUFBLE1BQUM7QUFBQSxNQUN6QixxQkFBcUIsTUFBTTtBQUFBLE1BQUM7QUFBQSxJQUM3QixFQUFFO0FBQUEsRUFDSDtBQUNBLEtBQUc7QUFBQSxJQUNGO0FBQUEsSUFDQSxHQUFHLEdBQUcsQ0FBQyxPQUEwQixTQUF1QjtBQUN2RCxZQUFNLE1BQU0sT0FBTyxLQUFLO0FBQ3hCLFVBQUksSUFBSSxTQUFTLFFBQVEsS0FBSyxNQUFNLFdBQVc7QUFDOUMsZUFBTyxRQUFRLFFBQVEsS0FBSyxFQUFFLE9BQU8sS0FBSyxNQUFNLE9BQU8sS0FBSyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDdEUsVUFBSSxJQUFJLFNBQVMsZUFBZSxFQUFFLEVBQUU7QUFDbkMsZUFBTyxRQUFRO0FBQUEsVUFDZCxLQUFLO0FBQUEsWUFDSixTQUFTO0FBQUEsWUFDVCxRQUFRO0FBQUEsWUFDUixVQUFVO0FBQUEsWUFDVixjQUFjLENBQUMsT0FBTztBQUFBLFlBQ3RCLE9BQU8sQ0FBQyxPQUFPO0FBQUEsWUFDZixVQUFVO0FBQUEsVUFDWCxDQUFDO0FBQUEsUUFDRjtBQUNELFVBQUksSUFBSSxTQUFTLGdCQUFnQixFQUFFLEVBQUU7QUFDcEMsZUFBTyxRQUFRO0FBQUEsVUFDZCxLQUFLO0FBQUEsWUFDSixTQUFTO0FBQUEsWUFDVCxVQUFVO0FBQUEsWUFDVixPQUFPLENBQUMsSUFBSTtBQUFBLFlBQ1osT0FBTztBQUFBLFlBQ1AsYUFBYTtBQUFBLFVBQ2QsQ0FBQztBQUFBLFFBQ0Y7QUFDRCxZQUFNLElBQUksTUFBTSxnQ0FBZ0MsR0FBRyxFQUFFO0FBQUEsSUFDdEQsQ0FBQztBQUFBLEVBQ0Y7QUFDQSxlQUFhLDhDQUE4QjtBQUFBLElBQzFDLE9BQU8sTUFBTSxhQUFhO0FBQUEsSUFDMUIsV0FBVyxNQUFNO0FBQUEsSUFDakIsV0FBVyxDQUFDLFFBQVEsb0JBQUksSUFBSSxFQUFFLEVBQUUsR0FBRztBQUFBLEVBQ3BDLENBQUM7QUFDRCxhQUFXLFFBQVEsSUFBSSxJQUFJO0FBQzVCLENBQUM7QUFFRCxVQUFVLFlBQVk7QUFDckIsTUFBSSxVQUFXLE9BQU0sd0JBQVEsU0FBUztBQUN0QyxRQUFNLGFBQWEsb0JBQUksNkJBQWEsRUFBRSxFQUFFLEdBQUc7QUFDM0MsTUFBSSxlQUFlLE9BQVcsdUNBQXNCLElBQUksWUFBWSxDQUFDLENBQUM7QUFDdEUsYUFBVyxPQUFPO0FBQ2xCLFFBQU0sb0NBQW9CLElBQUksWUFBWTtBQUFBLEVBQUMsQ0FBQztBQUM1QyxjQUFZO0FBQ1oseUJBQU8sSUFBSSxNQUFNLE1BQU07QUFDdkIseUJBQU8sSUFBSSxNQUFNLE1BQU07QUFDdkIsMkJBQVMsSUFBSSxNQUFNLFFBQVE7QUFDM0IsdUNBQXFCLElBQUksTUFBTSxTQUFTO0FBQ3hDLCtCQUFhLElBQUksTUFBTSxZQUFZO0FBQ25DLGdDQUFjLElBQUksTUFBTSxhQUFhO0FBQ3JDLDZCQUFXLElBQUksTUFBTSxVQUFVO0FBQy9CLGtDQUFnQixJQUFJLE1BQU0sZUFBZTtBQUN6QyxnQ0FBYyxJQUFJLENBQUMsQ0FBQztBQUNwQixNQUFJLE1BQU0sVUFBVSxLQUFNLGNBQWEsV0FBVyxPQUFPO0FBQUEsTUFDcEQsY0FBYSxRQUFRLFNBQVMsTUFBTSxLQUFLO0FBQzlDLEtBQUcsaUJBQWlCO0FBQ3BCLEtBQUcsZ0JBQWdCO0FBQ25CLFdBQVMsS0FBSyxnQkFBZ0I7QUFDL0IsQ0FBQztBQUVELFNBQVMsaUNBQWlDLE1BQU07QUFDL0MsS0FBRyxrSEFBa0gsWUFBWTtBQUNoSSxnQkFBWSxzQkFBTSx5QkFBYztBQUFBLE1BQy9CLFFBQVEsU0FBUztBQUFBLE1BQ2pCLFNBQVMsb0JBQUksSUFBc0I7QUFBQSxRQUNsQyxDQUFDLFFBQVEsSUFBSTtBQUFBLFFBQ2IsQ0FBQywwQ0FBMEIsVUFBVTtBQUFBLE1BQ3RDLENBQUM7QUFBQSxNQUNELE9BQU87QUFBQSxRQUNOLFFBQVE7QUFBQSxRQUNSLFNBQVMsRUFBRSxVQUFVLENBQUMsR0FBRyxXQUFXLEtBQUs7QUFBQSxRQUN6QyxPQUFPLENBQUM7QUFBQSxRQUNSLFNBQVM7QUFBQSxRQUNULGFBQWEsSUFBSSxZQUFZO0FBQUEsUUFDN0IsY0FBYyxNQUFNO0FBQUEsUUFBQztBQUFBLFFBQ3JCLGNBQWMsTUFBTTtBQUFBLFFBQUM7QUFBQSxRQUNyQixhQUFhLE1BQU07QUFBQSxRQUFDO0FBQUEsUUFDcEIsaUJBQWlCLFlBQVk7QUFBQSxNQUM5QjtBQUFBLElBQ0QsQ0FBQztBQUNELFVBQU0scUJBQUs7QUFDWCxVQUFNLFFBQVEsZ0NBQWdCLEVBQUU7QUFDaEMsMENBQXNCLElBQUksT0FBTyxDQUFDLElBQUksR0FBRyxHQUFHLElBQUk7QUFDaEQsVUFBTSxHQUFHLFFBQVEsTUFBTSxPQUFPLG9CQUFJLDRCQUFZLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQztBQUMzRCxVQUFNLEdBQUc7QUFBQSxNQUFRLE1BQ2hCLE9BQU8sU0FBUyxjQUFjLHVDQUF1QyxDQUFDLEVBQUUsSUFBSSxTQUFTO0FBQUEsSUFDdEY7QUFDQSxXQUFPLFNBQVMsS0FBSyxXQUFXLEVBQUUsSUFBSSxVQUFVLG1CQUFtQjtBQUVuRSxVQUFNLFFBQVEsU0FBUyxjQUFpQyxzQ0FBc0M7QUFDOUYsV0FBTyxLQUFLLEVBQUUsSUFBSSxTQUFTO0FBQzNCLFVBQU8sTUFBTTtBQUNiLFVBQU0sR0FBRyxRQUFRLE1BQU0sT0FBTyxvQkFBSSw0QkFBWSxDQUFDLEVBQUUsS0FBSyxLQUFLLENBQUM7QUFDNUQsVUFBTSxPQUFPLGdDQUFnQixFQUFFO0FBQy9CLDBDQUFzQixJQUFJLE1BQU0sQ0FBQyxFQUFFLEdBQUcsTUFBTSxVQUFVLEVBQUUsQ0FBQyxHQUFHLEdBQUcsSUFBSTtBQUNuRSxVQUFNLEdBQUcsUUFBUSxNQUFNLE9BQU8sU0FBUyxLQUFLLFdBQVcsRUFBRSxVQUFVLG1CQUFtQixDQUFDO0FBQ3ZGLFdBQU8sb0JBQUksNEJBQVksQ0FBQyxFQUFFLEtBQUssS0FBSztBQUNwQyxXQUFPLFNBQVMsY0FBYyx1Q0FBdUMsQ0FBQyxFQUFFLFNBQVM7QUFFakYsVUFBTSxTQUFTLFNBQVM7QUFBQSxNQUN2QjtBQUFBLElBQ0Q7QUFDQSxXQUFPLE1BQU0sRUFBRSxJQUFJLFNBQVM7QUFDNUIsV0FBUSxNQUFNO0FBQ2QsVUFBTSxHQUFHLFFBQVEsTUFBTSxPQUFPLG9CQUFJLDRCQUFZLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQztBQUMzRCxVQUFNLEdBQUcsUUFBUSxNQUFNLE9BQU8sU0FBUyxLQUFLLFdBQVcsRUFBRSxJQUFJLFVBQVUsbUJBQW1CLENBQUM7QUFBQSxFQUM1RixDQUFDO0FBQ0YsQ0FBQyIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2hhdENvbnRyb2xzLnRlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQHZpdGVzdC1lbnZpcm9ubWVudCBqc2RvbVxuaW1wb3J0IHsgYWZ0ZXJFYWNoLCBiZWZvcmVFYWNoLCBkZXNjcmliZSwgZXhwZWN0LCBpdCwgdmkgfSBmcm9tICd2aXRlc3QnO1xuaW1wb3J0IHsgbW91bnQsIHRpY2ssIHVubW91bnQgfSBmcm9tICdzdmVsdGUnO1xuaW1wb3J0IHsgZ2V0LCB3cml0YWJsZSB9IGZyb20gJ3N2ZWx0ZS9zdG9yZSc7XG5pbXBvcnQge1xuXHRjaGF0SWQsXG5cdGNvbmZpZyxcblx0c2V0dGluZ3MsXG5cdHNob3dBcnRpZmFjdHMsXG5cdHNob3dDYWxsT3ZlcmxheSxcblx0c2hvd0NvbnRyb2xzLFxuXHRzaG93RW1iZWRzLFxuXHR0ZW1wb3JhcnlDaGF0RW5hYmxlZFxufSBmcm9tICckbGliL3N0b3Jlcyc7XG5pbXBvcnQge1xuXHRhcHBseVdvcmtzcGFjZUxpc3RpbmcsXG5cdGJlZ2luR2VuZXJhdGlvbixcblx0aHlkcmF0ZVdvcmtzcGFjZVByZWZzLFxuXHRvY3VXb3Jrc3BhY2VzLFxuXHRxdWV1ZVdvcmtzcGFjZVByZWZzXG59IGZyb20gJyRsaWIvc3RvcmVzL29jdSc7XG5pbXBvcnQgQ2hhdENvbnRyb2xzIGZyb20gJy4vQ2hhdENvbnRyb2xzLnN2ZWx0ZSc7XG5pbXBvcnQge1xuXHRjcmVhdGVXb3Jrc3BhY2VSZWNvbmNpbGlhdGlvbixcblx0V09SS1NQQUNFX1JFQ09OQ0lMSUFUSU9OLFxuXHR0eXBlIFdvcmtzcGFjZVJlY29uY2lsaWF0aW9uXG59IGZyb20gJy4vd29ya3NwYWNlLXJlY29uY2lsaWF0aW9uJztcbi8vIFRoaXMgcG9saWN5IGNhc2UgbmV2ZXIgbW91bnRzIFhUZXJtaW5hbDsgaXRzIGVhZ2VyIHh0ZXJtIGltcG9ydCBuZWVkcyBjYW52YXMgaW4ganNkb20uXG52aS5tb2NrKCdAeHRlcm0veHRlcm0nLCAoKSA9PiAoeyBUZXJtaW5hbDogdmkuZm4oKSB9KSk7XG5cbmNvbnN0IGlkID0gJ293bmVyLWNoYXQnO1xuY29uc3QgZmlsZSA9IHtcblx0ZmlsZV9pZDogJ2ZpeHR1cmUtcGFnZS5odG1sJyxcblx0bmFtZTogJ3BhZ2UuaHRtbCcsXG5cdHBhdGg6ICdwYWdlLmh0bWwnLFxuXHR1cmw6IGAvb2N1L2ZpbGVzLyR7aWR9L3BhZ2UuaHRtbGAsXG5cdHR5cGU6ICdodG1sJyxcblx0bWltZTogJ3RleHQvaHRtbCcsXG5cdHJldmlzaW9uOiAxLFxuXHRzaXplOiAxMjhcbn07XG5jb25zdCBqc29uID0gKGJvZHk6IG9iamVjdCkgPT5cblx0bmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KGJvZHkpLCB7XG5cdFx0aGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH1cblx0fSk7XG5jb25zdCBpMThuID0gd3JpdGFibGUoeyB0OiAoa2V5OiBzdHJpbmcpID0+IGtleSB9KTtcbmxldCBjb21wb25lbnQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgdW5kZWZpbmVkO1xubGV0IGNvbnRyb2xsZXI6IFdvcmtzcGFjZVJlY29uY2lsaWF0aW9uO1xubGV0IHByaW9yOiB7XG5cdGNoYXRJZDogc3RyaW5nO1xuXHRjb25maWc6IFBhcmFtZXRlcnM8dHlwZW9mIGNvbmZpZy5zZXQ+WzBdO1xuXHRzZXR0aW5nczogUGFyYW1ldGVyczx0eXBlb2Ygc2V0dGluZ3Muc2V0PlswXTtcblx0dGVtcG9yYXJ5OiBib29sZWFuO1xuXHRzaG93Q29udHJvbHM6IGJvb2xlYW47XG5cdHNob3dBcnRpZmFjdHM6IGJvb2xlYW47XG5cdHNob3dFbWJlZHM6IGJvb2xlYW47XG5cdHNob3dDYWxsT3ZlcmxheTogYm9vbGVhbjtcblx0dG9rZW46IHN0cmluZyB8IG51bGw7XG59O1xuXG5iZWZvcmVFYWNoKCgpID0+IHtcblx0cHJpb3IgPSB7XG5cdFx0Y2hhdElkOiBnZXQoY2hhdElkKSxcblx0XHRjb25maWc6IGdldChjb25maWcpLFxuXHRcdHNldHRpbmdzOiBnZXQoc2V0dGluZ3MpLFxuXHRcdHRlbXBvcmFyeTogZ2V0KHRlbXBvcmFyeUNoYXRFbmFibGVkKSxcblx0XHRzaG93Q29udHJvbHM6IGdldChzaG93Q29udHJvbHMpLFxuXHRcdHNob3dBcnRpZmFjdHM6IGdldChzaG93QXJ0aWZhY3RzKSxcblx0XHRzaG93RW1iZWRzOiBnZXQoc2hvd0VtYmVkcyksXG5cdFx0c2hvd0NhbGxPdmVybGF5OiBnZXQoc2hvd0NhbGxPdmVybGF5KSxcblx0XHR0b2tlbjogbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Rva2VuJylcblx0fTtcblx0Y2hhdElkLnNldChpZCk7XG5cdGNvbmZpZy5zZXQoeyBmZWF0dXJlczogeyBlbmFibGVfb2N1X3dvcmtzcGFjZTogdHJ1ZSB9IH0gYXMgdW5rbm93biBhcyBQYXJhbWV0ZXJzPFxuXHRcdHR5cGVvZiBjb25maWcuc2V0XG5cdD5bMF0pO1xuXHRzZXR0aW5ncy5zZXQoe30pO1xuXHR0ZW1wb3JhcnlDaGF0RW5hYmxlZC5zZXQoZmFsc2UpO1xuXHRzaG93Q29udHJvbHMuc2V0KGZhbHNlKTtcblx0c2hvd0FydGlmYWN0cy5zZXQoZmFsc2UpO1xuXHRzaG93RW1iZWRzLnNldChmYWxzZSk7XG5cdHNob3dDYWxsT3ZlcmxheS5zZXQoZmFsc2UpO1xuXHRvY3VXb3Jrc3BhY2VzLnNldCh7fSk7XG5cdGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd0b2tlbicsICdvd25lci1maXh0dXJlJyk7XG5cdHZpLnN0dWJHbG9iYWwoXG5cdFx0J21hdGNoTWVkaWEnLFxuXHRcdHZpLmZuKChxdWVyeTogc3RyaW5nKSA9PiAoe1xuXHRcdFx0bWF0Y2hlczogdHJ1ZSxcblx0XHRcdG1lZGlhOiBxdWVyeSxcblx0XHRcdGFkZEV2ZW50TGlzdGVuZXI6ICgpID0+IHt9LFxuXHRcdFx0cmVtb3ZlRXZlbnRMaXN0ZW5lcjogKCkgPT4ge31cblx0XHR9KSlcblx0KTtcblx0dmkuc3R1Ykdsb2JhbChcblx0XHQnZmV0Y2gnLFxuXHRcdHZpLmZuKChpbnB1dDogUmVxdWVzdEluZm8gfCBVUkwsIGluaXQ/OiBSZXF1ZXN0SW5pdCkgPT4ge1xuXHRcdFx0Y29uc3QgdXJsID0gU3RyaW5nKGlucHV0KTtcblx0XHRcdGlmICh1cmwuZW5kc1dpdGgoJy9wcmVmcycpICYmIGluaXQ/Lm1ldGhvZCA9PT0gJ1BVVCcpXG5cdFx0XHRcdHJldHVybiBQcm9taXNlLnJlc29sdmUoanNvbih7IHByZWZzOiBKU09OLnBhcnNlKFN0cmluZyhpbml0LmJvZHkpKSB9KSk7XG5cdFx0XHRpZiAodXJsLmluY2x1ZGVzKGAvd29ya3NwYWNlcy8ke2lkfWApKVxuXHRcdFx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKFxuXHRcdFx0XHRcdGpzb24oe1xuXHRcdFx0XHRcdFx0Y2hhdF9pZDogaWQsXG5cdFx0XHRcdFx0XHRzdGF0dXM6ICdydW5uaW5nJyxcblx0XHRcdFx0XHRcdHJldmlzaW9uOiAxLFxuXHRcdFx0XHRcdFx0Y2FwYWJpbGl0aWVzOiBbJ3ByZWZzJ10sXG5cdFx0XHRcdFx0XHR2aWV3czogWydmaWxlcyddLFxuXHRcdFx0XHRcdFx0YmFzZV91cmw6ICcvb2N1J1xuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdCk7XG5cdFx0XHRpZiAodXJsLmluY2x1ZGVzKGAvYXBpL291dHB1dHMvJHtpZH1gKSlcblx0XHRcdFx0cmV0dXJuIFByb21pc2UucmVzb2x2ZShcblx0XHRcdFx0XHRqc29uKHtcblx0XHRcdFx0XHRcdGNoYXRfaWQ6IGlkLFxuXHRcdFx0XHRcdFx0cmV2aXNpb246IDEsXG5cdFx0XHRcdFx0XHRmaWxlczogW2ZpbGVdLFxuXHRcdFx0XHRcdFx0dG90YWw6IDEsXG5cdFx0XHRcdFx0XHRuZXh0X2N1cnNvcjogbnVsbFxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdCk7XG5cdFx0XHR0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWQgd29ya3NwYWNlIHJlcXVlc3QgJHt1cmx9YCk7XG5cdFx0fSlcblx0KTtcblx0Y29udHJvbGxlciA9IGNyZWF0ZVdvcmtzcGFjZVJlY29uY2lsaWF0aW9uKHtcblx0XHR0b2tlbjogKCkgPT4gbG9jYWxTdG9yYWdlLnRva2VuLFxuXHRcdGF2YWlsYWJsZTogKCkgPT4gdHJ1ZSxcblx0XHR0cmFuc2xhdGU6IChrZXkpID0+IGdldChpMThuKS50KGtleSlcblx0fSk7XG5cdGNvbnRyb2xsZXIub2JzZXJ2ZShpZCwgdHJ1ZSk7XG59KTtcblxuYWZ0ZXJFYWNoKGFzeW5jICgpID0+IHtcblx0aWYgKGNvbXBvbmVudCkgYXdhaXQgdW5tb3VudChjb21wb25lbnQpO1xuXHRjb25zdCBnZW5lcmF0aW9uID0gZ2V0KG9jdVdvcmtzcGFjZXMpW2lkXT8uZ2VuZXJhdGlvbjtcblx0aWYgKGdlbmVyYXRpb24gIT09IHVuZGVmaW5lZCkgaHlkcmF0ZVdvcmtzcGFjZVByZWZzKGlkLCBnZW5lcmF0aW9uLCB7fSk7XG5cdGNvbnRyb2xsZXIucmV0aXJlKCk7XG5cdGF3YWl0IHF1ZXVlV29ya3NwYWNlUHJlZnMoaWQsIGFzeW5jICgpID0+IHt9KTtcblx0Y29tcG9uZW50ID0gdW5kZWZpbmVkO1xuXHRjaGF0SWQuc2V0KHByaW9yLmNoYXRJZCk7XG5cdGNvbmZpZy5zZXQocHJpb3IuY29uZmlnKTtcblx0c2V0dGluZ3Muc2V0KHByaW9yLnNldHRpbmdzKTtcblx0dGVtcG9yYXJ5Q2hhdEVuYWJsZWQuc2V0KHByaW9yLnRlbXBvcmFyeSk7XG5cdHNob3dDb250cm9scy5zZXQocHJpb3Iuc2hvd0NvbnRyb2xzKTtcblx0c2hvd0FydGlmYWN0cy5zZXQocHJpb3Iuc2hvd0FydGlmYWN0cyk7XG5cdHNob3dFbWJlZHMuc2V0KHByaW9yLnNob3dFbWJlZHMpO1xuXHRzaG93Q2FsbE92ZXJsYXkuc2V0KHByaW9yLnNob3dDYWxsT3ZlcmxheSk7XG5cdG9jdVdvcmtzcGFjZXMuc2V0KHt9KTtcblx0aWYgKHByaW9yLnRva2VuID09PSBudWxsKSBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndG9rZW4nKTtcblx0ZWxzZSBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndG9rZW4nLCBwcmlvci50b2tlbik7XG5cdHZpLnVuc3R1YkFsbEdsb2JhbHMoKTtcblx0dmkucmVzdG9yZUFsbE1vY2tzKCk7XG5cdGRvY3VtZW50LmJvZHkucmVwbGFjZUNoaWxkcmVuKCk7XG59KTtcblxuZGVzY3JpYmUoJ21vdW50ZWQgY2hhdCB3b3Jrc3BhY2UgcG9saWN5JywgKCkgPT4ge1xuXHRpdCgnYXV0by1vcGVucyBmaXJzdCBvdXRwdXQsIGtlZXBzIGEgdXNlci1jbG9zZWQgcGFuZWwgY2xvc2VkIHdpdGggYSBjaGFuZ2UgYmFkZ2UsIHRoZW4gYWNrbm93bGVkZ2VzIGV4cGxpY2l0IG9wZW4nLCBhc3luYyAoKSA9PiB7XG5cdFx0Y29tcG9uZW50ID0gbW91bnQoQ2hhdENvbnRyb2xzLCB7XG5cdFx0XHR0YXJnZXQ6IGRvY3VtZW50LmJvZHksXG5cdFx0XHRjb250ZXh0OiBuZXcgTWFwPHVua25vd24sIHVua25vd24+KFtcblx0XHRcdFx0WydpMThuJywgaTE4bl0sXG5cdFx0XHRcdFtXT1JLU1BBQ0VfUkVDT05DSUxJQVRJT04sIGNvbnRyb2xsZXJdXG5cdFx0XHRdKSxcblx0XHRcdHByb3BzOiB7XG5cdFx0XHRcdGNoYXRJZDogaWQsXG5cdFx0XHRcdGhpc3Rvcnk6IHsgbWVzc2FnZXM6IHt9LCBjdXJyZW50SWQ6IG51bGwgfSxcblx0XHRcdFx0ZmlsZXM6IFtdLFxuXHRcdFx0XHRtb2RlbElkOiBudWxsLFxuXHRcdFx0XHRldmVudFRhcmdldDogbmV3IEV2ZW50VGFyZ2V0KCksXG5cdFx0XHRcdHN1Ym1pdFByb21wdDogKCkgPT4ge30sXG5cdFx0XHRcdHN0b3BSZXNwb25zZTogKCkgPT4ge30sXG5cdFx0XHRcdHNob3dNZXNzYWdlOiAoKSA9PiB7fSxcblx0XHRcdFx0ZW5zdXJlU2F2ZWRDaGF0OiBhc3luYyAoKSA9PiBpZFxuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGF3YWl0IHRpY2soKTtcblx0XHRjb25zdCBmaXJzdCA9IGJlZ2luR2VuZXJhdGlvbihpZCk7XG5cdFx0YXBwbHlXb3Jrc3BhY2VMaXN0aW5nKGlkLCBmaXJzdCwgW2ZpbGVdLCAxLCBudWxsKTtcblx0XHRhd2FpdCB2aS53YWl0Rm9yKCgpID0+IGV4cGVjdChnZXQoc2hvd0NvbnRyb2xzKSkudG9CZSh0cnVlKSk7XG5cdFx0YXdhaXQgdmkud2FpdEZvcigoKSA9PlxuXHRcdFx0ZXhwZWN0KGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ3NlY3Rpb25bYXJpYS1sYWJlbD1cIldvcmtzcGFjZSBGaWxlc1wiXScpKS5ub3QudG9CZU51bGwoKVxuXHRcdCk7XG5cdFx0ZXhwZWN0KGRvY3VtZW50LmJvZHkudGV4dENvbnRlbnQpLm5vdC50b0NvbnRhaW4oJ1dvcmtzcGFjZSBjaGFuZ2VkJyk7XG5cblx0XHRjb25zdCBjbG9zZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3I8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdidXR0b25bYXJpYS1sYWJlbD1cIkNsb3NlIHdvcmtzcGFjZVwiXScpO1xuXHRcdGV4cGVjdChjbG9zZSkubm90LnRvQmVOdWxsKCk7XG5cdFx0Y2xvc2UhLmNsaWNrKCk7XG5cdFx0YXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoZ2V0KHNob3dDb250cm9scykpLnRvQmUoZmFsc2UpKTtcblx0XHRjb25zdCBuZXh0ID0gYmVnaW5HZW5lcmF0aW9uKGlkKTtcblx0XHRhcHBseVdvcmtzcGFjZUxpc3RpbmcoaWQsIG5leHQsIFt7IC4uLmZpbGUsIHJldmlzaW9uOiAyIH1dLCAyLCBudWxsKTtcblx0XHRhd2FpdCB2aS53YWl0Rm9yKCgpID0+IGV4cGVjdChkb2N1bWVudC5ib2R5LnRleHRDb250ZW50KS50b0NvbnRhaW4oJ1dvcmtzcGFjZSBjaGFuZ2VkJykpO1xuXHRcdGV4cGVjdChnZXQoc2hvd0NvbnRyb2xzKSkudG9CZShmYWxzZSk7XG5cdFx0ZXhwZWN0KGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ3NlY3Rpb25bYXJpYS1sYWJlbD1cIldvcmtzcGFjZSBGaWxlc1wiXScpKS50b0JlTnVsbCgpO1xuXG5cdFx0Y29uc3QgYWN0aW9uID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcjxIVE1MQnV0dG9uRWxlbWVudD4oXG5cdFx0XHQnYnV0dG9uW2FyaWEtbGFiZWw9XCJXb3Jrc3BhY2UgRmlsZXNcIl0nXG5cdFx0KTtcblx0XHRleHBlY3QoYWN0aW9uKS5ub3QudG9CZU51bGwoKTtcblx0XHRhY3Rpb24hLmNsaWNrKCk7XG5cdFx0YXdhaXQgdmkud2FpdEZvcigoKSA9PiBleHBlY3QoZ2V0KHNob3dDb250cm9scykpLnRvQmUodHJ1ZSkpO1xuXHRcdGF3YWl0IHZpLndhaXRGb3IoKCkgPT4gZXhwZWN0KGRvY3VtZW50LmJvZHkudGV4dENvbnRlbnQpLm5vdC50b0NvbnRhaW4oJ1dvcmtzcGFjZSBjaGFuZ2VkJykpO1xuXHR9KTtcbn0pO1xuIl0sImZpbGUiOiIvcHJpdmF0ZS92YXIvZm9sZGVycy9sYy9uMWo0eXdsNTQ1MWJyamRqXzZ6ZnE4NmgwMDAwZ24vVC9pc3N1ZS0yMjItZnJlc2gtNWFfX29kd2Ivc3JjL2xpYi9jb21wb25lbnRzL2NoYXQvQ2hhdENvbnRyb2xzLnRlc3QudHMifQ==
