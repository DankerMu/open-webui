// /src/lib/components/common/FileItem.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_3__ = await __vite_ssr_import__("/node_modules/svelte/src/index-client.js", {"importedNames":["createEventDispatcher","getContext"]});
const __vite_ssr_import_4__ = await __vite_ssr_import__("/src/lib/constants.ts", {"importedNames":["WEBUI_API_BASE_URL"]});
const __vite_ssr_import_5__ = await __vite_ssr_import__("/src/lib/utils/index.ts", {"importedNames":["formatFileSize"]});
const __vite_ssr_import_6__ = await __vite_ssr_import__("/src/lib/stores/index.ts", {"importedNames":["settings","showFileNavPath"]});
const __vite_ssr_import_7__ = await __vite_ssr_import__("/src/lib/components/common/FileItemModal.svelte", {"importedNames":["default"]});
const __vite_ssr_import_8__ = await __vite_ssr_import__("/src/lib/components/icons/GarbageBin.svelte", {"importedNames":["default"]});
const __vite_ssr_import_9__ = await __vite_ssr_import__("/src/lib/components/common/Spinner.svelte", {"importedNames":["default"]});
const __vite_ssr_import_10__ = await __vite_ssr_import__("/src/lib/components/common/Tooltip.svelte", {"importedNames":["default"]});
const __vite_ssr_import_11__ = await __vite_ssr_import__("/src/lib/components/icons/XMark.svelte", {"importedNames":["default"]});
const __vite_ssr_import_12__ = await __vite_ssr_import__("/src/lib/components/icons/DocumentPage.svelte", {"importedNames":["default"]});
const __vite_ssr_import_13__ = await __vite_ssr_import__("/src/lib/components/icons/Database.svelte", {"importedNames":["default"]});
const __vite_ssr_import_14__ = await __vite_ssr_import__("/src/lib/components/icons/PageEdit.svelte", {"importedNames":["default"]});
const __vite_ssr_import_15__ = await __vite_ssr_import__("/src/lib/components/icons/ChatBubble.svelte", {"importedNames":["default"]});
const __vite_ssr_import_16__ = await __vite_ssr_import__("/src/lib/components/icons/Folder.svelte", {"importedNames":["default"]});



FileItem[__vite_ssr_import_2__.FILENAME] = 'src/lib/components/common/FileItem.svelte';

















var root = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_svg(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" class=" size-4.5"><path fill-rule="evenodd" d="M5.625 1.5c-1.036 0-1.875.84-1.875 1.875v17.25c0 1.035.84 1.875 1.875 1.875h12.75c1.035 0 1.875-.84 1.875-1.875V12.75A3.75 3.75 0 0 0 16.5 9h-1.875a1.875 1.875 0 0 1-1.875-1.875V5.25A3.75 3.75 0 0 0 9 1.5H5.625ZM7.5 15a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 7.5 15Zm.75 2.25a.75.75 0 0 0 0 1.5H12a.75.75 0 0 0 0-1.5H8.25Z" clip-rule="evenodd"></path><path d="M12.971 1.816A5.23 5.23 0 0 1 14.25 5.25v1.875c0 .207.168.375.375.375H16.5a5.23 5.23 0 0 1 3.434 1.279 9.768 9.768 0 0 0-6.963-6.963Z"></path></svg>`), FileItem[__vite_ssr_import_2__.FILENAME], [[88, 4, [[95, 5], [100, 5]]]]);
var root_1 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="size-10 shrink-0 flex justify-center items-center bg-black/20 dark:bg-white/10 text-white rounded-xl"><!></div>`), FileItem[__vite_ssr_import_2__.FILENAME], [[84, 2]]);
var root_2 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="shrink-0 text-gray-500 dark:text-gray-400"><!></div>`), FileItem[__vite_ssr_import_2__.FILENAME], [[109, 2]]);
var root_3 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span class=" capitalize line-clamp-1"> </span>`), FileItem[__vite_ssr_import_2__.FILENAME], [[161, 5]]);
var root_4 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span class="capitalize"> </span>`), FileItem[__vite_ssr_import_2__.FILENAME], [[164, 5]]);
var root_5 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="flex flex-col justify-center -space-y-0.5 px-2.5 w-full"><div class=" dark:text-gray-100 text-sm font-normal line-clamp-1 mb-1"> </div> <div><!> <!></div></div>`), FileItem[__vite_ssr_import_2__.FILENAME], [[142, 2, [[143, 3], [147, 3]]]]);
var root_6 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="max-w-[35%] shrink-0 truncate text-[0.6875rem] capitalize text-gray-500"> </div>`), FileItem[__vite_ssr_import_2__.FILENAME], [[178, 6]]);
var root_7 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="max-w-[35%] shrink-0 truncate text-[0.6875rem] capitalize text-gray-500"> </div>`), FileItem[__vite_ssr_import_2__.FILENAME], [[182, 6]]);
var root_8 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="flex min-w-0 flex-1 items-center overflow-hidden"><div class="flex min-w-0 flex-1 items-center justify-between dark:text-gray-100"><div class="min-w-0 flex-1 truncate pr-1 font-normal"> </div> <!></div></div>`), FileItem[__vite_ssr_import_2__.FILENAME], [[174, 3, [[175, 4, [[176, 5]]]]]]);
var root_9 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class=" absolute -top-1 -right-1"><button type="button"><!></button></div>`), FileItem[__vite_ssr_import_2__.FILENAME], [[192, 2, [[193, 3]]]]);
var root_10 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<!> <button type="button"><!> <!> <!></button>`, 1), FileItem[__vite_ssr_import_2__.FILENAME], [[54, 0]]);

function FileItem($$anchor, $$props) {
	__vite_ssr_import_2__.check_target(new.target);
	__vite_ssr_import_2__.push($$props, false, FileItem);

	var $$ownership_validator = __vite_ssr_import_2__.create_ownership_validator($$props);

	const $i18n = () => (
		__vite_ssr_import_2__.validate_store(i18n, 'i18n'),
		__vite_ssr_import_2__.store_get(i18n, '$i18n', $$stores)
	);

	const $settings = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_6__.settings, 'settings'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_6__.settings, '$settings', $$stores)
	);

	const [$$stores, $$cleanup] = __vite_ssr_import_2__.setup_stores();
	const i18n = __vite_ssr_import_3__.getContext('i18n');
	const dispatch = __vite_ssr_import_3__.createEventDispatcher();
	let className = __vite_ssr_import_2__.prop($$props, 'className', 8, 'w-60');
	let colorClassName = __vite_ssr_import_2__.prop($$props, 'colorClassName', 8, 'bg-white dark:bg-gray-850 border border-gray-50/30 dark:border-gray-800/30');
	let url = __vite_ssr_import_2__.prop($$props, 'url', 8, null);
	let dismissible = __vite_ssr_import_2__.prop($$props, 'dismissible', 8, false);
	let modal = __vite_ssr_import_2__.prop($$props, 'modal', 8, false);
	let loading = __vite_ssr_import_2__.prop($$props, 'loading', 8, false);
	let item = __vite_ssr_import_2__.prop($$props, 'item', 12, null);
	let edit = __vite_ssr_import_2__.prop($$props, 'edit', 8, false);
	let small = __vite_ssr_import_2__.prop($$props, 'small', 8, false);
	let name = __vite_ssr_import_2__.prop($$props, 'name', 8);
	let type = __vite_ssr_import_2__.prop($$props, 'type', 8);
	let size = __vite_ssr_import_2__.prop($$props, 'size', 8);
	let showModal = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(false), 'showModal');

	const decodeString = (str) => {
		try {
			return decodeURIComponent(str);
		} catch(e) {
			return str;
		}
	};

	var $$exports = { ...__vite_ssr_import_2__.legacy_api() };

	__vite_ssr_import_2__.init();

	var fragment = root_10();
	var node = __vite_ssr_import_2__.first_child(fragment);

	{
		var consequent = ($$anchor) => {
			{
				$$ownership_validator.binding('item', __vite_ssr_import_7__.default, item);

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_7__.default($$anchor, {
						get edit() {
							return edit();
						},

						get show() {
							return __vite_ssr_import_2__.get(showModal);
						},

						set show($$value) {
							__vite_ssr_import_2__.set(showModal, $$value);
						},

						get item() {
							return item();
						},

						set item($$value) {
							item($$value);
						},
						$$legacy: true
					}),
					'component',
					FileItem,
					51,
					1,
					{ componentTag: 'FileItemModal' }
				);
			}
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node, ($$render) => {
				if (item()) $$render(consequent);
			}),
			'if',
			FileItem,
			50,
			0
		);
	}

	var button = __vite_ssr_import_2__.sibling(node, 2);
	var node_1 = __vite_ssr_import_2__.child(button);

	{
		var consequent_2 = ($$anchor) => {
			var div = root_1();
			var node_2 = __vite_ssr_import_2__.child(div);

			{
				var consequent_1 = ($$anchor) => {
					var svg = root();

					__vite_ssr_import_2__.append($$anchor, svg);
				};

				var alternate = ($$anchor) => {
					__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_9__.default($$anchor, {}), 'component', FileItem, 105, 4, { componentTag: 'Spinner' });
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_2, ($$render) => {
						if (!loading()) $$render(consequent_1); else $$render(alternate, -1);
					}),
					'if',
					FileItem,
					87,
					3
				);
			}

			__vite_ssr_import_2__.reset(div);
			__vite_ssr_import_2__.append($$anchor, div);
		};

		var alternate_3 = ($$anchor) => {
			var div_1 = root_2();
			var node_3 = __vite_ssr_import_2__.child(div_1);

			{
				var consequent_7 = ($$anchor) => {
					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
							__vite_ssr_import_2__.deep_read_state(type()),
							$i18n(),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(type(), 'collection')
								? $i18n().t('Collection')
								: __vite_ssr_import_2__.strict_equals(type(), 'note')
									? $i18n().t('Note')
									: __vite_ssr_import_2__.strict_equals(type(), 'chat')
										? $i18n().t('Chat')
										: __vite_ssr_import_2__.strict_equals(type(), 'file') || __vite_ssr_import_2__.strict_equals(type(), 'filesystem') ? $i18n().t('File') : $i18n().t('Document'))
						));

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_10__.default($$anchor, {
								get content() {
									return __vite_ssr_import_2__.get($0);
								},
								placement: 'top',
								children: __vite_ssr_import_2__.wrap_snippet(FileItem, ($$anchor, $$slotProps) => {
									var fragment_4 = __vite_ssr_import_2__.comment();
									var node_4 = __vite_ssr_import_2__.first_child(fragment_4);

									{
										var consequent_3 = ($$anchor) => {
											__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_13__.default($$anchor, { className: 'size-3.5' }), 'component', FileItem, 124, 6, { componentTag: 'Database' });
										};

										var consequent_4 = ($$anchor) => {
											__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_14__.default($$anchor, { className: 'size-3.5' }), 'component', FileItem, 126, 6, { componentTag: 'PageEdit' });
										};

										var consequent_5 = ($$anchor) => {
											__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_15__.default($$anchor, { className: 'size-3.5' }), 'component', FileItem, 128, 6, { componentTag: 'ChatBubble' });
										};

										var consequent_6 = ($$anchor) => {
											__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_16__.default($$anchor, { className: 'size-3.5' }), 'component', FileItem, 130, 6, { componentTag: 'Folder' });
										};

										var alternate_1 = ($$anchor) => {
											__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_12__.default($$anchor, { className: 'size-3.5' }), 'component', FileItem, 132, 6, { componentTag: 'DocumentPage' });
										};

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_2__.if(node_4, ($$render) => {
												if (__vite_ssr_import_2__.strict_equals(type(), 'collection')) $$render(consequent_3); else if (__vite_ssr_import_2__.strict_equals(type(), 'note')) $$render(consequent_4, 1); else if (__vite_ssr_import_2__.strict_equals(type(), 'chat')) $$render(consequent_5, 2); else if (__vite_ssr_import_2__.strict_equals(type(), 'folder')) $$render(consequent_6, 3); else $$render(alternate_1, -1);
											}),
											'if',
											FileItem,
											123,
											5
										);
									}

									__vite_ssr_import_2__.append($$anchor, fragment_4);
								}),
								$$slots: { default: true }
							}),
							'component',
							FileItem,
							111,
							4,
							{ componentTag: 'Tooltip' }
						);
					}
				};

				var alternate_2 = ($$anchor) => {
					__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_9__.default($$anchor, { className: 'size-3.5' }), 'component', FileItem, 136, 4, { componentTag: 'Spinner' });
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_3, ($$render) => {
						if (!loading()) $$render(consequent_7); else $$render(alternate_2, -1);
					}),
					'if',
					FileItem,
					110,
					3
				);
			}

			__vite_ssr_import_2__.reset(div_1);
			__vite_ssr_import_2__.append($$anchor, div_1);
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node_1, ($$render) => {
				if (!small()) $$render(consequent_2); else $$render(alternate_3, -1);
			}),
			'if',
			FileItem,
			83,
			1
		);
	}

	var node_5 = __vite_ssr_import_2__.sibling(node_1, 2);

	{
		var consequent_13 = ($$anchor) => {
			var div_2 = root_5();
			var div_3 = __vite_ssr_import_2__.child(div_2);
			var text = __vite_ssr_import_2__.child(div_3, true);

			__vite_ssr_import_2__.reset(div_3);

			var div_4 = __vite_ssr_import_2__.sibling(div_3, 2);
			var node_6 = __vite_ssr_import_2__.child(div_4);

			{
				var consequent_8 = ($$anchor) => {
					var text_1 = __vite_ssr_import_2__.text();

					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_1, $0), [() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('File')))]);
					__vite_ssr_import_2__.append($$anchor, text_1);
				};

				var consequent_9 = ($$anchor) => {
					var text_2 = __vite_ssr_import_2__.text();

					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_2, $0), [() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Note')))]);
					__vite_ssr_import_2__.append($$anchor, text_2);
				};

				var consequent_10 = ($$anchor) => {
					var text_3 = __vite_ssr_import_2__.text();

					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_3, $0), [() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Document')))]);
					__vite_ssr_import_2__.append($$anchor, text_3);
				};

				var consequent_11 = ($$anchor) => {
					var text_4 = __vite_ssr_import_2__.text();

					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_4, $0), [() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Collection')))]);
					__vite_ssr_import_2__.append($$anchor, text_4);
				};

				var alternate_4 = ($$anchor) => {
					var span = root_3();
					var text_5 = __vite_ssr_import_2__.child(span, true);

					__vite_ssr_import_2__.reset(span);
					__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_5, type()));
					__vite_ssr_import_2__.append($$anchor, span);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_6, ($$render) => {
						if (__vite_ssr_import_2__.strict_equals(type(), 'file') || __vite_ssr_import_2__.strict_equals(type(), 'filesystem')) $$render(consequent_8); else if (__vite_ssr_import_2__.strict_equals(type(), 'note')) $$render(consequent_9, 1); else if (__vite_ssr_import_2__.strict_equals(type(), 'doc')) $$render(consequent_10, 2); else if (__vite_ssr_import_2__.strict_equals(type(), 'collection')) $$render(consequent_11, 3); else $$render(alternate_4, -1);
					}),
					'if',
					FileItem,
					152,
					4
				);
			}

			var node_7 = __vite_ssr_import_2__.sibling(node_6, 2);

			{
				var consequent_12 = ($$anchor) => {
					var span_1 = root_4();
					var text_6 = __vite_ssr_import_2__.child(span_1, true);

					__vite_ssr_import_2__.reset(span_1);

					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_6, $0), [
						() => (
							__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_5__.formatFileSize),
							__vite_ssr_import_2__.deep_read_state(size()),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_5__.formatFileSize(size()))
						)
					]);

					__vite_ssr_import_2__.append($$anchor, span_1);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_7, ($$render) => {
						if (size()) $$render(consequent_12);
					}),
					'if',
					FileItem,
					163,
					4
				);
			}

			__vite_ssr_import_2__.reset(div_4);
			__vite_ssr_import_2__.reset(div_2);

			__vite_ssr_import_2__.template_effect(
				($0) => {
					__vite_ssr_import_2__.set_text(text, $0);

					__vite_ssr_import_2__.set_class(div_4, 1, ` flex justify-between text-xs line-clamp-1 ${(
						$settings(),
						__vite_ssr_import_2__.untrack(() => $settings()?.highContrastMode ?? false ? 'text-gray-800 dark:text-gray-100' : 'text-gray-500')
					) ?? ''}`);
				},
				[
					() => (
						__vite_ssr_import_2__.deep_read_state(name()),
						__vite_ssr_import_2__.untrack(() => decodeString(name()))
					)
				]
			);

			__vite_ssr_import_2__.append($$anchor, div_2);
		};

		var alternate_6 = ($$anchor) => {
			{
				let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
					__vite_ssr_import_2__.deep_read_state(name()),
					__vite_ssr_import_2__.untrack(() => decodeString(name()))
				));

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_10__.default($$anchor, {
						get content() {
							return __vite_ssr_import_2__.get($0);
						},
						className: 'flex min-w-0 flex-1 overflow-hidden',
						placement: 'top-start',
						children: __vite_ssr_import_2__.wrap_snippet(FileItem, ($$anchor, $$slotProps) => {
							var div_5 = root_8();
							var div_6 = __vite_ssr_import_2__.child(div_5);
							var div_7 = __vite_ssr_import_2__.child(div_6);
							var text_7 = __vite_ssr_import_2__.child(div_7, true);

							__vite_ssr_import_2__.reset(div_7);

							var node_8 = __vite_ssr_import_2__.sibling(div_7, 2);

							{
								var consequent_14 = ($$anchor) => {
									var div_8 = root_6();
									var text_8 = __vite_ssr_import_2__.child(div_8, true);

									__vite_ssr_import_2__.reset(div_8);

									__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_8, $0), [
										() => (
											__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_5__.formatFileSize),
											__vite_ssr_import_2__.deep_read_state(size()),
											__vite_ssr_import_2__.untrack(() => __vite_ssr_import_5__.formatFileSize(size()))
										)
									]);

									__vite_ssr_import_2__.append($$anchor, div_8);
								};

								var alternate_5 = ($$anchor) => {
									var div_9 = root_7();
									var text_9 = __vite_ssr_import_2__.child(div_9, true);

									__vite_ssr_import_2__.reset(div_9);
									__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_9, type()));
									__vite_ssr_import_2__.append($$anchor, div_9);
								};

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_2__.if(node_8, ($$render) => {
										if (size()) $$render(consequent_14); else $$render(alternate_5, -1);
									}),
									'if',
									FileItem,
									177,
									5
								);
							}

							__vite_ssr_import_2__.reset(div_6);
							__vite_ssr_import_2__.reset(div_5);

							__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_7, $0), [
								() => (
									__vite_ssr_import_2__.deep_read_state(name()),
									__vite_ssr_import_2__.untrack(() => decodeString(name()))
								)
							]);

							__vite_ssr_import_2__.append($$anchor, div_5);
						}),
						$$slots: { default: true }
					}),
					'component',
					FileItem,
					169,
					2,
					{ componentTag: 'Tooltip' }
				);
			}
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node_5, ($$render) => {
				if (!small()) $$render(consequent_13); else $$render(alternate_6, -1);
			}),
			'if',
			FileItem,
			141,
			1
		);
	}

	var node_9 = __vite_ssr_import_2__.sibling(node_5, 2);

	{
		var consequent_15 = ($$anchor) => {
			var div_10 = root_9();
			var button_1 = __vite_ssr_import_2__.child(div_10);
			var node_10 = __vite_ssr_import_2__.child(button_1);

			__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_11__.default(node_10, { className: 'size-4' }), 'component', FileItem, 204, 4, { componentTag: 'XMark' });
			__vite_ssr_import_2__.reset(button_1);
			__vite_ssr_import_2__.reset(div_10);

			__vite_ssr_import_2__.template_effect(
				($0) => {
					__vite_ssr_import_2__.set_attribute(button_1, 'aria-label', $0);

					__vite_ssr_import_2__.set_class(button_1, 1, ` bg-white text-black border border-gray-50 rounded-full ${(
						$settings(),
						__vite_ssr_import_2__.untrack(() => $settings()?.highContrastMode ?? false ? '' : 'hover-reveal transition')
					) ?? ''}`);
				},
				[() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Remove File')))]
			);

			__vite_ssr_import_2__.event('click', button_1, __vite_ssr_import_2__.stopPropagation(() => {
				dispatch('dismiss');
			}));

			__vite_ssr_import_2__.append($$anchor, div_10);
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node_9, ($$render) => {
				if (dismissible()) $$render(consequent_15);
			}),
			'if',
			FileItem,
			191,
			1
		);
	}

	__vite_ssr_import_2__.reset(button);

	__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_class(button, 1, `relative group ${className() ?? ''} flex items-center ${colorClassName() ?? ''} ${small()
		? 'h-8 gap-1.5 rounded-xl px-2.5 text-[0.8125rem] leading-5'
		: 'gap-1 rounded-2xl p-1.5'} text-left`));

	__vite_ssr_import_2__.event('click', button, async function click() {
		const filesystemPath = __vite_ssr_import_2__.strict_equals(item()?.type, 'filesystem') ? item().path ?? item().url ?? item().id : null;

		if (filesystemPath) {
			__vite_ssr_import_6__.showFileNavPath.set(filesystemPath);
		} else if (item()?.file?.data?.content || __vite_ssr_import_2__.strict_equals(item()?.type, 'file') || item()?.content || modal()) {
			__vite_ssr_import_2__.set(showModal, !__vite_ssr_import_2__.get(showModal));
		} else {
			if (url()) {
				if (__vite_ssr_import_2__.strict_equals(type(), 'file')) {
					if (url().startsWith('http')) {
						window.open(`${url()}/content`, '_blank').focus();
					} else {
						window.open(`${__vite_ssr_import_4__.WEBUI_API_BASE_URL}/files/${url()}/content`, '_blank').focus();
					}
				} else {
					window.open(`${url()}`, '_blank').focus();
				}
			}
		}

		dispatch('click');
	});

	__vite_ssr_import_2__.append($$anchor, fragment);

	var $$pop = __vite_ssr_import_2__.pop($$exports);

	$$cleanup();

	return $$pop;
}
Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: FileItem });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDMkQ7QUFDUDtBQUVSO0FBQ1k7QUFFTDtBQUNDO0FBQ2I7QUFDQTtBQUNnQjtBQXNCQztBQUNSO0FBQ0E7QUFDSTtBQUNSOzs7Ozs7Ozs7Ozs7OztxQ0FyQzVDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBYUEsTUFBTSxJQUFJLEdBQUcsZ0NBQVUsQ0FBQyxNQUFNO0NBQzlCLE1BQU0sUUFBUSxHQUFHLDJDQUFxQjtDQUUvQixJQUFJLFNBQVMsdURBQUcsTUFBTTtDQUN0QixJQUFJLGNBQWMsNERBQ3hCLDRFQUE0RTtDQUN0RSxJQUFJLEdBQWtCLGlEQUFHLElBQUk7Q0FFN0IsSUFBSSxXQUFXLHlEQUFHLEtBQUs7Q0FDdkIsSUFBSSxLQUFLLG1EQUFHLEtBQUs7Q0FDakIsSUFBSSxPQUFPLHFEQUFHLEtBQUs7Q0FFbkIsSUFBSSxJQUFJLG1EQUFHLElBQUk7Q0FDZixJQUFJLElBQUksa0RBQUcsS0FBSztDQUNoQixJQUFJLEtBQUssbURBQUcsS0FBSztDQUVqQixJQUFJLElBQVk7Q0FDaEIsSUFBSSxJQUFZO0NBQ2hCLElBQUksSUFBWTtDQU92QixJQUFJLFNBQVMsa0VBQUcsS0FBSzs7Q0FFckIsTUFBTSxZQUFZLElBQUksR0FBVyxLQUFLO0VBQ3JDLEdBQUcsQ0FBQztHQUNILE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHO0VBQzlCLENBQUMsQ0FBQyxLQUFLLENBQUUsQ0FBQyxFQUFFO0dBQ1gsTUFBTSxDQUFDLEdBQUc7RUFDWDtDQUNELENBQUM7Ozs7Ozs7Ozs7Ozs7OztXQUlBLDZCQUFhOztjQUFrQyxJQUFJOzs7VUFBckMsSUFBUzt3Q0FBRSxTQUFTOzs7VUFBcEIsSUFBUztpQ0FBRSxTQUFTOzs7VUFBRSxJQUFTOzs7O1VBQVQsSUFBUzs7Ozs7Ozs7Ozs7Ozs7OztRQUQxQyxJQUFJOzs7Ozs7Ozs7S0FJUjswQ0FBQTs7OztPQThCRTs0Q0FBQTs7OztTQUlFOzs0Q0FBQTs7OztpREFpQkEsNkJBQU87Ozs7O1dBbEJILE9BQU87Ozs7Ozs7OzsrQkFIYjswQ0FBQTs7OztPQXlCQSxLQUFHOzRDQUFILEtBQUc7Ozs7Ozs2Q0E5RU0sSUFBWTs7K0VBaUZWLElBQUksSUFBSyxZQUFXO1VBQzFCLEtBQUssR0FBQyxDQUFDLENBQUMsWUFBWTs4Q0FDcEIsSUFBSSxJQUFLLE1BQUs7V0FDYixLQUFLLEdBQUMsQ0FBQyxDQUFDLE1BQU07K0NBQ2QsSUFBSSxJQUFLLE1BQUs7WUFDYixLQUFLLEdBQUMsQ0FBQyxDQUFDLE1BQU07Z0RBQ2QsSUFBSSxJQUFLLE1BQU0seUNBQUksSUFBSSxJQUFLLFlBQVcsSUFDdEMsS0FBSyxHQUFDLENBQUMsQ0FBQyxNQUFNLElBQ2QsS0FBSyxHQUFDLENBQUMsQ0FBQyxVQUFVOzs7O2FBVHhCOzs7Ozs7Ozs7Ozt1REFhRSw4QkFBUTs7Ozt1REFFUiw4QkFBUTs7Ozt1REFFUiw4QkFBVTs7Ozt1REFFViw4QkFBTTs7Ozt1REFFTiw4QkFBWTs7Ozs7b0RBVFQsSUFBSSxJQUFLLFlBQVksd0VBRWhCLElBQUksSUFBSyxNQUFNLDJFQUVmLElBQUksSUFBSyxNQUFNLDJFQUVmLElBQUksSUFBSyxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpREFPM0IsNkJBQU87Ozs7O1dBMUJILE9BQU87Ozs7Ozs7OzsrQkFEYixLQUFHOzBDQUFILEtBQUc7Ozs7O1NBMUJDLEtBQUs7Ozs7Ozs7Ozs7Ozs7T0EyRFQsS0FBRztPQUNGLEtBQUcsK0JBREosS0FBRzswQ0FDRixLQUFHOzsrQkFBSCxLQUFHOztPQUlILHNDQUpBLEtBQUc7NENBSUg7Ozs7OztvSkFNRSxLQUFLLEdBQUMsQ0FBQyxDQUFDLE1BQU07Ozs7Ozs7b0pBRWQsS0FBSyxHQUFDLENBQUMsQ0FBQyxNQUFNOzs7Ozs7O29KQUVkLEtBQUssR0FBQyxDQUFDLENBQUMsVUFBVTs7Ozs7OztvSkFFbEIsS0FBSyxHQUFDLENBQUMsQ0FBQyxZQUFZOzs7OztTQUVwQixJQUFJOzhDQUFKLElBQUk7O2lDQUFKLElBQUk7d0ZBQW1DLElBQUk7NENBQTNDLElBQUk7Ozs7OzhDQVRELElBQUksSUFBSyxNQUFNLHlDQUFJLElBQUksSUFBSyxZQUFZLHdFQUVuQyxJQUFJLElBQUssTUFBTSwyRUFFZixJQUFJLElBQUssS0FBSyw0RUFFZCxJQUFJLElBQUssWUFBWTs7Ozs7Ozs7Ozs7OztTQU03QixNQUFJOzhDQUFKLE1BQUk7O2lDQUFKLE1BQUk7Ozs7NkNBL0pBLG9DQUFjOzZDQTJCWixJQUFZOzJDQW9JTyxvQ0FBYyxDQUFDLElBQUk7Ozs7NENBQTVDLE1BQUk7Ozs7O1VBREQsSUFBSTs7Ozs7Ozs7OytCQWhCVDsrQkFMRCxLQUFHOzs7Ozs7cUNBS0Y7OzBDQUNvRCxTQUFTLElBQUUsZ0JBQWdCLElBQUksS0FBSyxHQUNyRixrQ0FBaUMsR0FDakMsZUFBZTs7Ozs7NENBeEhWLElBQVk7MENBa0huQixZQUFZLENBQUMsSUFBSTs7Ozs7MENBRm5CLEtBQUc7Ozs7OzsyQ0FoSE0sSUFBWTt5Q0E0SVosWUFBWSxDQUFDLElBQUk7Ozs7V0FEMUI7Ozs7Ozs7V0FLQyxLQUFHO1dBQ0YsS0FBRywrQkFESixLQUFHO1dBRUQsS0FBRywrQkFESixLQUFHO2dEQUNGLEtBQUc7O21DQUFILEtBQUc7O2tEQUFILEtBQUc7Ozs7YUFFRixLQUFHO2tEQUFILEtBQUc7O3FDQUFILEtBQUc7Ozs7aURBN0tBLG9DQUFjO2lEQTJCWixJQUFZOytDQW1KaEIsb0NBQWMsQ0FBQyxJQUFJOzs7O2dEQURwQixLQUFHOzs7O2FBSUgsS0FBRztrREFBSCxLQUFHOztxQ0FBSCxLQUFHOzRGQUNGLElBQUk7Z0RBREwsS0FBRzs7Ozs7Y0FMQSxJQUFJOzs7Ozs7Ozs7bUNBRlQsS0FBRzttQ0FESixLQUFHOzs7OytDQWhKSyxJQUFZOzZDQWtKb0MsWUFBWSxDQUFDLElBQUk7Ozs7OENBRnpFLEtBQUc7Ozs7Ozs7Ozs7Ozs7OztTQWpDQSxLQUFLOzs7Ozs7Ozs7Ozs7O09BbURULE1BQUc7T0FDRix1Q0FERCxNQUFHOzZDQUNGOzsrQ0FXQyw4QkFBSyx1QkFBWSxRQUFROytCQVgxQjsrQkFERCxNQUFHOzs7O3lDQUNGOztxQ0FBQTs7MENBRWlFLFNBQVMsSUFBRSxnQkFBZ0IsSUFDNUYsS0FBSyxHQUNGLEVBQUMsR0FDRCx5QkFBeUI7Ozt5REFKaEIsS0FBSyxHQUFDLENBQUMsQ0FBQyxhQUFhOzs7d0NBRGpDLHNEQU9nQztJQUMvQixRQUFRLENBQUMsU0FBUztHQUNuQixDQUFDOzswQ0FWRixNQUFHOzs7OztRQURBLFdBQVc7Ozs7Ozs7Ozs2QkF6SWhCOzs2RUFBQSw2QkFDdUIsU0FBUyw4QkFBcUIsY0FBYyxZQUFHO0lBQ25FLDBEQUF5RDtJQUN6RCx5QkFBeUI7O3NDQUg1QiwrQkFLc0I7RUFDckIsTUFBTSxjQUFjLHVDQUFHLElBQUksSUFBRSxJQUFJLEVBQUssWUFBWSxJQUFJLElBQUksR0FBQyxJQUFJLElBQUksSUFBSSxHQUFDLEdBQUcsSUFBSSxJQUFJLEdBQUMsRUFBRSxHQUFJLElBQUk7O0VBRTlGLEVBQUUsRUFBRSxjQUFjLEVBQUU7R0FDbkIscUNBQWUsQ0FBQyxHQUFHLENBQUMsY0FBYztFQUNuQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxJQUFJLElBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxPQUFPLHdDQUFJLElBQUksSUFBRSxJQUFJLEVBQUssTUFBTSxLQUFJLElBQUksSUFBRSxPQUFPLElBQUksS0FBSyxJQUFFOzZCQUN4RixTQUFTLDZCQUFJLFNBQVM7RUFDdkIsQ0FBQyxDQUFDLElBQUksQ0FBQztHQUNOLEVBQUUsRUFBRSxHQUFHLElBQUU7SUFDUixFQUFFLHNDQUFFLElBQUksSUFBSyxNQUFNLEdBQUU7S0FDcEIsRUFBRSxFQUFFLEdBQUcsR0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHO01BQzNCLE1BQU0sQ0FBQyxJQUFJLElBQUksR0FBRyxjQUFZLFFBQVEsRUFBRSxLQUFLO0tBQzlDLENBQUMsQ0FBQyxJQUFJLENBQUM7TUFDTixNQUFNLENBQUMsSUFBSSxJQUFJLHdDQUFrQixVQUFVLEdBQUcsY0FBWSxRQUFRLEVBQUUsS0FBSztLQUMxRTtJQUNELENBQUMsQ0FBQyxJQUFJLENBQUM7S0FDTixNQUFNLENBQUMsSUFBSSxJQUFJLEdBQUcsTUFBSSxRQUFRLEVBQUUsS0FBSztJQUN0QztHQUNEO0VBQ0Q7O0VBRUEsUUFBUSxDQUFDLE9BQU87Q0FDakIsQ0FBQzs7Ozs7Ozs7O0FBakNNIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJGaWxlSXRlbS5zdmVsdGUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBsYW5nPVwidHNcIj5cblx0aW1wb3J0IHsgY3JlYXRlRXZlbnREaXNwYXRjaGVyLCBnZXRDb250ZXh0IH0gZnJvbSAnc3ZlbHRlJztcblx0aW1wb3J0IHsgV0VCVUlfQVBJX0JBU0VfVVJMIH0gZnJvbSAnJGxpYi9jb25zdGFudHMnO1xuXG5cdGltcG9ydCB7IGZvcm1hdEZpbGVTaXplIH0gZnJvbSAnJGxpYi91dGlscyc7XG5cdGltcG9ydCB7IHNldHRpbmdzLCBzaG93RmlsZU5hdlBhdGggfSBmcm9tICckbGliL3N0b3Jlcyc7XG5cblx0aW1wb3J0IEZpbGVJdGVtTW9kYWwgZnJvbSAnLi9GaWxlSXRlbU1vZGFsLnN2ZWx0ZSc7XG5cdGltcG9ydCBHYXJiYWdlQmluIGZyb20gJy4uL2ljb25zL0dhcmJhZ2VCaW4uc3ZlbHRlJztcblx0aW1wb3J0IFNwaW5uZXIgZnJvbSAnLi9TcGlubmVyLnN2ZWx0ZSc7XG5cdGltcG9ydCBUb29sdGlwIGZyb20gJy4vVG9vbHRpcC5zdmVsdGUnO1xuXHRpbXBvcnQgWE1hcmsgZnJvbSAnJGxpYi9jb21wb25lbnRzL2ljb25zL1hNYXJrLnN2ZWx0ZSc7XG5cblx0Y29uc3QgaTE4biA9IGdldENvbnRleHQoJ2kxOG4nKTtcblx0Y29uc3QgZGlzcGF0Y2ggPSBjcmVhdGVFdmVudERpc3BhdGNoZXIoKTtcblxuXHRleHBvcnQgbGV0IGNsYXNzTmFtZSA9ICd3LTYwJztcblx0ZXhwb3J0IGxldCBjb2xvckNsYXNzTmFtZSA9XG5cdFx0J2JnLXdoaXRlIGRhcms6YmctZ3JheS04NTAgYm9yZGVyIGJvcmRlci1ncmF5LTUwLzMwIGRhcms6Ym9yZGVyLWdyYXktODAwLzMwJztcblx0ZXhwb3J0IGxldCB1cmw6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuXG5cdGV4cG9ydCBsZXQgZGlzbWlzc2libGUgPSBmYWxzZTtcblx0ZXhwb3J0IGxldCBtb2RhbCA9IGZhbHNlO1xuXHRleHBvcnQgbGV0IGxvYWRpbmcgPSBmYWxzZTtcblxuXHRleHBvcnQgbGV0IGl0ZW0gPSBudWxsO1xuXHRleHBvcnQgbGV0IGVkaXQgPSBmYWxzZTtcblx0ZXhwb3J0IGxldCBzbWFsbCA9IGZhbHNlO1xuXG5cdGV4cG9ydCBsZXQgbmFtZTogc3RyaW5nO1xuXHRleHBvcnQgbGV0IHR5cGU6IHN0cmluZztcblx0ZXhwb3J0IGxldCBzaXplOiBudW1iZXI7XG5cblx0aW1wb3J0IERvY3VtZW50UGFnZSBmcm9tICcuLi9pY29ucy9Eb2N1bWVudFBhZ2Uuc3ZlbHRlJztcblx0aW1wb3J0IERhdGFiYXNlIGZyb20gJy4uL2ljb25zL0RhdGFiYXNlLnN2ZWx0ZSc7XG5cdGltcG9ydCBQYWdlRWRpdCBmcm9tICcuLi9pY29ucy9QYWdlRWRpdC5zdmVsdGUnO1xuXHRpbXBvcnQgQ2hhdEJ1YmJsZSBmcm9tICcuLi9pY29ucy9DaGF0QnViYmxlLnN2ZWx0ZSc7XG5cdGltcG9ydCBGb2xkZXIgZnJvbSAnLi4vaWNvbnMvRm9sZGVyLnN2ZWx0ZSc7XG5cdGxldCBzaG93TW9kYWwgPSBmYWxzZTtcblxuXHRjb25zdCBkZWNvZGVTdHJpbmcgPSAoc3RyOiBzdHJpbmcpID0+IHtcblx0XHR0cnkge1xuXHRcdFx0cmV0dXJuIGRlY29kZVVSSUNvbXBvbmVudChzdHIpO1xuXHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdHJldHVybiBzdHI7XG5cdFx0fVxuXHR9O1xuPC9zY3JpcHQ+XG5cbnsjaWYgaXRlbX1cblx0PEZpbGVJdGVtTW9kYWwgYmluZDpzaG93PXtzaG93TW9kYWx9IGJpbmQ6aXRlbSB7ZWRpdH0gLz5cbnsvaWZ9XG5cbjxidXR0b25cblx0Y2xhc3M9XCJyZWxhdGl2ZSBncm91cCB7Y2xhc3NOYW1lfSBmbGV4IGl0ZW1zLWNlbnRlciB7Y29sb3JDbGFzc05hbWV9IHtzbWFsbFxuXHRcdD8gJ2gtOCBnYXAtMS41IHJvdW5kZWQteGwgcHgtMi41IHRleHQtWzAuODEyNXJlbV0gbGVhZGluZy01J1xuXHRcdDogJ2dhcC0xIHJvdW5kZWQtMnhsIHAtMS41J30gdGV4dC1sZWZ0XCJcblx0dHlwZT1cImJ1dHRvblwiXG5cdG9uOmNsaWNrPXthc3luYyAoKSA9PiB7XG5cdFx0Y29uc3QgZmlsZXN5c3RlbVBhdGggPSBpdGVtPy50eXBlID09PSAnZmlsZXN5c3RlbScgPyAoaXRlbS5wYXRoID8/IGl0ZW0udXJsID8/IGl0ZW0uaWQpIDogbnVsbDtcblxuXHRcdGlmIChmaWxlc3lzdGVtUGF0aCkge1xuXHRcdFx0c2hvd0ZpbGVOYXZQYXRoLnNldChmaWxlc3lzdGVtUGF0aCk7XG5cdFx0fSBlbHNlIGlmIChpdGVtPy5maWxlPy5kYXRhPy5jb250ZW50IHx8IGl0ZW0/LnR5cGUgPT09ICdmaWxlJyB8fCBpdGVtPy5jb250ZW50IHx8IG1vZGFsKSB7XG5cdFx0XHRzaG93TW9kYWwgPSAhc2hvd01vZGFsO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRpZiAodXJsKSB7XG5cdFx0XHRcdGlmICh0eXBlID09PSAnZmlsZScpIHtcblx0XHRcdFx0XHRpZiAodXJsLnN0YXJ0c1dpdGgoJ2h0dHAnKSkge1xuXHRcdFx0XHRcdFx0d2luZG93Lm9wZW4oYCR7dXJsfS9jb250ZW50YCwgJ19ibGFuaycpLmZvY3VzKCk7XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdHdpbmRvdy5vcGVuKGAke1dFQlVJX0FQSV9CQVNFX1VSTH0vZmlsZXMvJHt1cmx9L2NvbnRlbnRgLCAnX2JsYW5rJykuZm9jdXMoKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0d2luZG93Lm9wZW4oYCR7dXJsfWAsICdfYmxhbmsnKS5mb2N1cygpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0ZGlzcGF0Y2goJ2NsaWNrJyk7XG5cdH19XG4+XG5cdHsjaWYgIXNtYWxsfVxuXHRcdDxkaXZcblx0XHRcdGNsYXNzPVwic2l6ZS0xMCBzaHJpbmstMCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBiZy1ibGFjay8yMCBkYXJrOmJnLXdoaXRlLzEwIHRleHQtd2hpdGUgcm91bmRlZC14bFwiXG5cdFx0PlxuXHRcdFx0eyNpZiAhbG9hZGluZ31cblx0XHRcdFx0PHN2Z1xuXHRcdFx0XHRcdHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuXHRcdFx0XHRcdHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuXHRcdFx0XHRcdGZpbGw9XCJjdXJyZW50Q29sb3JcIlxuXHRcdFx0XHRcdGFyaWEtaGlkZGVuPVwidHJ1ZVwiXG5cdFx0XHRcdFx0Y2xhc3M9XCIgc2l6ZS00LjVcIlxuXHRcdFx0XHQ+XG5cdFx0XHRcdFx0PHBhdGhcblx0XHRcdFx0XHRcdGZpbGwtcnVsZT1cImV2ZW5vZGRcIlxuXHRcdFx0XHRcdFx0ZD1cIk01LjYyNSAxLjVjLTEuMDM2IDAtMS44NzUuODQtMS44NzUgMS44NzV2MTcuMjVjMCAxLjAzNS44NCAxLjg3NSAxLjg3NSAxLjg3NWgxMi43NWMxLjAzNSAwIDEuODc1LS44NCAxLjg3NS0xLjg3NVYxMi43NUEzLjc1IDMuNzUgMCAwIDAgMTYuNSA5aC0xLjg3NWExLjg3NSAxLjg3NSAwIDAgMS0xLjg3NS0xLjg3NVY1LjI1QTMuNzUgMy43NSAwIDAgMCA5IDEuNUg1LjYyNVpNNy41IDE1YS43NS43NSAwIDAgMSAuNzUtLjc1aDcuNWEuNzUuNzUgMCAwIDEgMCAxLjVoLTcuNUEuNzUuNzUgMCAwIDEgNy41IDE1Wm0uNzUgMi4yNWEuNzUuNzUgMCAwIDAgMCAxLjVIMTJhLjc1Ljc1IDAgMCAwIDAtMS41SDguMjVaXCJcblx0XHRcdFx0XHRcdGNsaXAtcnVsZT1cImV2ZW5vZGRcIlxuXHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0PHBhdGhcblx0XHRcdFx0XHRcdGQ9XCJNMTIuOTcxIDEuODE2QTUuMjMgNS4yMyAwIDAgMSAxNC4yNSA1LjI1djEuODc1YzAgLjIwNy4xNjguMzc1LjM3NS4zNzVIMTYuNWE1LjIzIDUuMjMgMCAwIDEgMy40MzQgMS4yNzkgOS43NjggOS43NjggMCAwIDAtNi45NjMtNi45NjNaXCJcblx0XHRcdFx0XHQvPlxuXHRcdFx0XHQ8L3N2Zz5cblx0XHRcdHs6ZWxzZX1cblx0XHRcdFx0PFNwaW5uZXIgLz5cblx0XHRcdHsvaWZ9XG5cdFx0PC9kaXY+XG5cdHs6ZWxzZX1cblx0XHQ8ZGl2IGNsYXNzPVwic2hyaW5rLTAgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDBcIj5cblx0XHRcdHsjaWYgIWxvYWRpbmd9XG5cdFx0XHRcdDxUb29sdGlwXG5cdFx0XHRcdFx0Y29udGVudD17dHlwZSA9PT0gJ2NvbGxlY3Rpb24nXG5cdFx0XHRcdFx0XHQ/ICRpMThuLnQoJ0NvbGxlY3Rpb24nKVxuXHRcdFx0XHRcdFx0OiB0eXBlID09PSAnbm90ZSdcblx0XHRcdFx0XHRcdFx0PyAkaTE4bi50KCdOb3RlJylcblx0XHRcdFx0XHRcdFx0OiB0eXBlID09PSAnY2hhdCdcblx0XHRcdFx0XHRcdFx0XHQ/ICRpMThuLnQoJ0NoYXQnKVxuXHRcdFx0XHRcdFx0XHRcdDogdHlwZSA9PT0gJ2ZpbGUnIHx8IHR5cGUgPT09ICdmaWxlc3lzdGVtJ1xuXHRcdFx0XHRcdFx0XHRcdFx0PyAkaTE4bi50KCdGaWxlJylcblx0XHRcdFx0XHRcdFx0XHRcdDogJGkxOG4udCgnRG9jdW1lbnQnKX1cblx0XHRcdFx0XHRwbGFjZW1lbnQ9XCJ0b3BcIlxuXHRcdFx0XHQ+XG5cdFx0XHRcdFx0eyNpZiB0eXBlID09PSAnY29sbGVjdGlvbid9XG5cdFx0XHRcdFx0XHQ8RGF0YWJhc2UgY2xhc3NOYW1lPVwic2l6ZS0zLjVcIiAvPlxuXHRcdFx0XHRcdHs6ZWxzZSBpZiB0eXBlID09PSAnbm90ZSd9XG5cdFx0XHRcdFx0XHQ8UGFnZUVkaXQgY2xhc3NOYW1lPVwic2l6ZS0zLjVcIiAvPlxuXHRcdFx0XHRcdHs6ZWxzZSBpZiB0eXBlID09PSAnY2hhdCd9XG5cdFx0XHRcdFx0XHQ8Q2hhdEJ1YmJsZSBjbGFzc05hbWU9XCJzaXplLTMuNVwiIC8+XG5cdFx0XHRcdFx0ezplbHNlIGlmIHR5cGUgPT09ICdmb2xkZXInfVxuXHRcdFx0XHRcdFx0PEZvbGRlciBjbGFzc05hbWU9XCJzaXplLTMuNVwiIC8+XG5cdFx0XHRcdFx0ezplbHNlfVxuXHRcdFx0XHRcdFx0PERvY3VtZW50UGFnZSBjbGFzc05hbWU9XCJzaXplLTMuNVwiIC8+XG5cdFx0XHRcdFx0ey9pZn1cblx0XHRcdFx0PC9Ub29sdGlwPlxuXHRcdFx0ezplbHNlfVxuXHRcdFx0XHQ8U3Bpbm5lciBjbGFzc05hbWU9XCJzaXplLTMuNVwiIC8+XG5cdFx0XHR7L2lmfVxuXHRcdDwvZGl2PlxuXHR7L2lmfVxuXG5cdHsjaWYgIXNtYWxsfVxuXHRcdDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIC1zcGFjZS15LTAuNSBweC0yLjUgdy1mdWxsXCI+XG5cdFx0XHQ8ZGl2IGNsYXNzPVwiIGRhcms6dGV4dC1ncmF5LTEwMCB0ZXh0LXNtIGZvbnQtbm9ybWFsIGxpbmUtY2xhbXAtMSBtYi0xXCI+XG5cdFx0XHRcdHtkZWNvZGVTdHJpbmcobmFtZSl9XG5cdFx0XHQ8L2Rpdj5cblxuXHRcdFx0PGRpdlxuXHRcdFx0XHRjbGFzcz1cIiBmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIGxpbmUtY2xhbXAtMSB7KCRzZXR0aW5ncz8uaGlnaENvbnRyYXN0TW9kZSA/PyBmYWxzZSlcblx0XHRcdFx0XHQ/ICd0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTEwMCdcblx0XHRcdFx0XHQ6ICd0ZXh0LWdyYXktNTAwJ31cIlxuXHRcdFx0PlxuXHRcdFx0XHR7I2lmIHR5cGUgPT09ICdmaWxlJyB8fCB0eXBlID09PSAnZmlsZXN5c3RlbSd9XG5cdFx0XHRcdFx0eyRpMThuLnQoJ0ZpbGUnKX1cblx0XHRcdFx0ezplbHNlIGlmIHR5cGUgPT09ICdub3RlJ31cblx0XHRcdFx0XHR7JGkxOG4udCgnTm90ZScpfVxuXHRcdFx0XHR7OmVsc2UgaWYgdHlwZSA9PT0gJ2RvYyd9XG5cdFx0XHRcdFx0eyRpMThuLnQoJ0RvY3VtZW50Jyl9XG5cdFx0XHRcdHs6ZWxzZSBpZiB0eXBlID09PSAnY29sbGVjdGlvbid9XG5cdFx0XHRcdFx0eyRpMThuLnQoJ0NvbGxlY3Rpb24nKX1cblx0XHRcdFx0ezplbHNlfVxuXHRcdFx0XHRcdDxzcGFuIGNsYXNzPVwiIGNhcGl0YWxpemUgbGluZS1jbGFtcC0xXCI+e3R5cGV9PC9zcGFuPlxuXHRcdFx0XHR7L2lmfVxuXHRcdFx0XHR7I2lmIHNpemV9XG5cdFx0XHRcdFx0PHNwYW4gY2xhc3M9XCJjYXBpdGFsaXplXCI+e2Zvcm1hdEZpbGVTaXplKHNpemUpfTwvc3Bhbj5cblx0XHRcdFx0ey9pZn1cblx0XHRcdDwvZGl2PlxuXHRcdDwvZGl2PlxuXHR7OmVsc2V9XG5cdFx0PFRvb2x0aXBcblx0XHRcdGNvbnRlbnQ9e2RlY29kZVN0cmluZyhuYW1lKX1cblx0XHRcdGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBmbGV4LTEgb3ZlcmZsb3ctaGlkZGVuXCJcblx0XHRcdHBsYWNlbWVudD1cInRvcC1zdGFydFwiXG5cdFx0PlxuXHRcdFx0PGRpdiBjbGFzcz1cImZsZXggbWluLXctMCBmbGV4LTEgaXRlbXMtY2VudGVyIG92ZXJmbG93LWhpZGRlblwiPlxuXHRcdFx0XHQ8ZGl2IGNsYXNzPVwiZmxleCBtaW4tdy0wIGZsZXgtMSBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGRhcms6dGV4dC1ncmF5LTEwMFwiPlxuXHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJtaW4tdy0wIGZsZXgtMSB0cnVuY2F0ZSBwci0xIGZvbnQtbm9ybWFsXCI+e2RlY29kZVN0cmluZyhuYW1lKX08L2Rpdj5cblx0XHRcdFx0XHR7I2lmIHNpemV9XG5cdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwibWF4LXctWzM1JV0gc2hyaW5rLTAgdHJ1bmNhdGUgdGV4dC1bMC42ODc1cmVtXSBjYXBpdGFsaXplIHRleHQtZ3JheS01MDBcIj5cblx0XHRcdFx0XHRcdFx0e2Zvcm1hdEZpbGVTaXplKHNpemUpfVxuXHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0ezplbHNlfVxuXHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cIm1heC13LVszNSVdIHNocmluay0wIHRydW5jYXRlIHRleHQtWzAuNjg3NXJlbV0gY2FwaXRhbGl6ZSB0ZXh0LWdyYXktNTAwXCI+XG5cdFx0XHRcdFx0XHRcdHt0eXBlfVxuXHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0ey9pZn1cblx0XHRcdFx0PC9kaXY+XG5cdFx0XHQ8L2Rpdj5cblx0XHQ8L1Rvb2x0aXA+XG5cdHsvaWZ9XG5cblx0eyNpZiBkaXNtaXNzaWJsZX1cblx0XHQ8ZGl2IGNsYXNzPVwiIGFic29sdXRlIC10b3AtMSAtcmlnaHQtMVwiPlxuXHRcdFx0PGJ1dHRvblxuXHRcdFx0XHRhcmlhLWxhYmVsPXskaTE4bi50KCdSZW1vdmUgRmlsZScpfVxuXHRcdFx0XHRjbGFzcz1cIiBiZy13aGl0ZSB0ZXh0LWJsYWNrIGJvcmRlciBib3JkZXItZ3JheS01MCByb3VuZGVkLWZ1bGwgeygkc2V0dGluZ3M/LmhpZ2hDb250cmFzdE1vZGUgPz9cblx0XHRcdFx0ZmFsc2UpXG5cdFx0XHRcdFx0PyAnJ1xuXHRcdFx0XHRcdDogJ2hvdmVyLXJldmVhbCB0cmFuc2l0aW9uJ31cIlxuXHRcdFx0XHR0eXBlPVwiYnV0dG9uXCJcblx0XHRcdFx0b246Y2xpY2t8c3RvcFByb3BhZ2F0aW9uPXsoKSA9PiB7XG5cdFx0XHRcdFx0ZGlzcGF0Y2goJ2Rpc21pc3MnKTtcblx0XHRcdFx0fX1cblx0XHRcdD5cblx0XHRcdFx0PFhNYXJrIGNsYXNzTmFtZT17J3NpemUtNCd9IC8+XG5cdFx0XHQ8L2J1dHRvbj5cblxuXHRcdFx0PCEtLSA8YnV0dG9uXG5cdFx0XHRcdGNsYXNzPVwiIHAtMSBkYXJrOnRleHQtZ3JheS0zMDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLWJsYWNrLzUgZGFyazpob3ZlcjpiZy13aGl0ZS81IHJvdW5kZWQtZnVsbCBncm91cC1ob3Zlcjp2aXNpYmxlIGludmlzaWJsZSB0cmFuc2l0aW9uXCJcblx0XHRcdFx0dHlwZT1cImJ1dHRvblwiXG5cdFx0XHRcdG9uOmNsaWNrPXsoKSA9PiB7XG5cdFx0XHRcdH19XG5cdFx0XHQ+XG5cdFx0XHRcdDxHYXJiYWdlQmluIC8+XG5cdFx0XHQ8L2J1dHRvbj4gLS0+XG5cdFx0PC9kaXY+XG5cdHsvaWZ9XG48L2J1dHRvbj5cbiJdLCJmaWxlIjoiL3NyYy9saWIvY29tcG9uZW50cy9jb21tb24vRmlsZUl0ZW0uc3ZlbHRlIn0=
