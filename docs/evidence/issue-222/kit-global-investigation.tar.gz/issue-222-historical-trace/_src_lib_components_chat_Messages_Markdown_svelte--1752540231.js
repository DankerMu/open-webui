// /src/lib/components/chat/Messages/Markdown.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/marked/lib/marked.esm.js", {"importedNames":["marked"]});
const __vite_ssr_import_3__ = await __vite_ssr_import__("/src/lib/utils/marked/extension.ts", {"importedNames":["default"]});
const __vite_ssr_import_4__ = await __vite_ssr_import__("/src/lib/utils/marked/katex-extension.ts", {"importedNames":["default"]});
const __vite_ssr_import_5__ = await __vite_ssr_import__("/src/lib/utils/marked/strikethrough-extension.ts", {"importedNames":["disableSingleTilde"]});
const __vite_ssr_import_6__ = await __vite_ssr_import__("/src/lib/utils/marked/mention-extension.ts", {"importedNames":["mentionExtension"]});
const __vite_ssr_import_7__ = await __vite_ssr_import__("/src/lib/utils/marked/colon-fence-extension.ts", {"importedNames":["default"]});
const __vite_ssr_import_8__ = await __vite_ssr_import__("/src/lib/utils/marked/footnote-extension.ts", {"importedNames":["default"]});
const __vite_ssr_import_9__ = await __vite_ssr_import__("/src/lib/utils/marked/citation-extension.ts", {"importedNames":["default"]});
const __vite_ssr_import_10__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_11__ = await __vite_ssr_import__("/node_modules/svelte/src/index-client.js", {"importedNames":["onDestroy"]});
const __vite_ssr_import_12__ = await __vite_ssr_import__("/src/lib/utils/index.ts", {"importedNames":["replaceTokens","processResponseContent"]});
const __vite_ssr_import_13__ = await __vite_ssr_import__("/src/lib/stores/index.ts", {"importedNames":["user"]});
const __vite_ssr_import_14__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/MarkdownTokens.svelte", {"importedNames":["default"]});



Markdown[__vite_ssr_import_10__.FILENAME] = 'src/lib/components/chat/Messages/Markdown.svelte';















const options = { throwOnError: false };

__vite_ssr_import_2__.marked.use(__vite_ssr_import_4__.default(options));
__vite_ssr_import_2__.marked.use(__vite_ssr_import_3__.default(options));
__vite_ssr_import_2__.marked.use(__vite_ssr_import_9__.default(options));
__vite_ssr_import_2__.marked.use(__vite_ssr_import_8__.default(options));
__vite_ssr_import_2__.marked.use(__vite_ssr_import_7__.default(options));
__vite_ssr_import_2__.marked.use(__vite_ssr_import_5__.disableSingleTilde);

__vite_ssr_import_2__.marked.use({
	extensions: [
		__vite_ssr_import_6__.mentionExtension({ triggerChar: '@' }),
		__vite_ssr_import_6__.mentionExtension({ triggerChar: '#' }),
		__vite_ssr_import_6__.mentionExtension({ triggerChar: '$' })
	]
});

function Markdown($$anchor, $$props) {
	__vite_ssr_import_10__.check_target(new.target);
	__vite_ssr_import_10__.push($$props, false, Markdown);

	const $user = () => (
		__vite_ssr_import_10__.validate_store(__vite_ssr_import_13__.user, 'user'),
		__vite_ssr_import_10__.store_get(__vite_ssr_import_13__.user, '$user', $$stores)
	);

	const [$$stores, $$cleanup] = __vite_ssr_import_10__.setup_stores();
	let id = __vite_ssr_import_10__.prop($$props, 'id', 8, '');
	let chatId = __vite_ssr_import_10__.prop($$props, 'chatId', 8, '');
	let messageId = __vite_ssr_import_10__.prop($$props, 'messageId', 8, '');
	let content = __vite_ssr_import_10__.prop($$props, 'content', 8);
	let done = __vite_ssr_import_10__.prop($$props, 'done', 8, true);
	let model = __vite_ssr_import_10__.prop($$props, 'model', 8, null);
	let save = __vite_ssr_import_10__.prop($$props, 'save', 8, false);
	let preview = __vite_ssr_import_10__.prop($$props, 'preview', 8, false);
	let compactPreview = __vite_ssr_import_10__.prop($$props, 'compactPreview', 8, false);
	let paragraphTag = __vite_ssr_import_10__.prop($$props, 'paragraphTag', 8, 'p');
	let editCodeBlock = __vite_ssr_import_10__.prop($$props, 'editCodeBlock', 8, true);
	let topPadding = __vite_ssr_import_10__.prop($$props, 'topPadding', 8, false);
	let allowEmbeds = __vite_ssr_import_10__.prop($$props, 'allowEmbeds', 8, true);
	let sourceIds = __vite_ssr_import_10__.prop($$props, 'sourceIds', 24, () => []);
	let onSave = __vite_ssr_import_10__.prop($$props, 'onSave', 8, () => {});
	let onUpdate = __vite_ssr_import_10__.prop($$props, 'onUpdate', 8, () => {});
	let onPreview = __vite_ssr_import_10__.prop($$props, 'onPreview', 8, () => {});
	let onSourceClick = __vite_ssr_import_10__.prop($$props, 'onSourceClick', 8, () => {});
	let onTaskClick = __vite_ssr_import_10__.prop($$props, 'onTaskClick', 8, () => {});
	let onToolCallResolved = __vite_ssr_import_10__.prop($$props, 'onToolCallResolved', 8, () => {});
	let tokens = __vite_ssr_import_10__.tag(__vite_ssr_import_10__.mutable_source([]), 'tokens');
	let pendingUpdate = null;
	let lastContent = '';
	let lastParsedContent = '';

	const parseTokens = () => {
		if (__vite_ssr_import_10__.strict_equals(content(), lastContent)) return;

		lastContent = content();

		const processed = __vite_ssr_import_12__.replaceTokens(__vite_ssr_import_12__.processResponseContent(content()), model()?.name, $user()?.name);

		if (__vite_ssr_import_10__.strict_equals(processed, lastParsedContent)) return;

		lastParsedContent = processed;
		__vite_ssr_import_10__.set(tokens, __vite_ssr_import_2__.marked.lexer(processed));
	};

	const updateHandler = (content) => {
		if (content) {
			if (done()) {
				cancelAnimationFrame(pendingUpdate);
				pendingUpdate = null;
				parseTokens();
			} else if (!pendingUpdate) {
				pendingUpdate = requestAnimationFrame(() => {
					pendingUpdate = null;
					parseTokens();
				});
			}
		}
	};

	// Throttle parsing to once per animation frame while streaming
	__vite_ssr_import_11__.onDestroy(() => {
		cancelAnimationFrame(pendingUpdate);
	});

	__vite_ssr_import_10__.legacy_pre_effect(() => (__vite_ssr_import_10__.deep_read_state(content())), () => {
		updateHandler(content());
	});

	__vite_ssr_import_10__.legacy_pre_effect_reset();

	var $$exports = { ...__vite_ssr_import_10__.legacy_api() };

	__vite_ssr_import_10__.init();

	var fragment = __vite_ssr_import_10__.comment();
	var node = __vite_ssr_import_10__.first_child(fragment);

	__vite_ssr_import_10__.add_svelte_meta(
		() => __vite_ssr_import_10__.key(node, id, ($$anchor) => {
			__vite_ssr_import_10__.add_svelte_meta(
				() => __vite_ssr_import_14__.default($$anchor, {
					get tokens() {
						return __vite_ssr_import_10__.get(tokens);
					},

					get id() {
						return id();
					},

					get chatId() {
						return chatId();
					},

					get messageId() {
						return messageId();
					},

					get done() {
						return done();
					},

					get save() {
						return save();
					},

					get preview() {
						return preview();
					},

					get compactPreview() {
						return compactPreview();
					},

					get paragraphTag() {
						return paragraphTag();
					},

					get editCodeBlock() {
						return editCodeBlock();
					},

					get sourceIds() {
						return sourceIds();
					},

					get topPadding() {
						return topPadding();
					},

					get allowEmbeds() {
						return allowEmbeds();
					},

					get onTaskClick() {
						return onTaskClick();
					},

					get onSourceClick() {
						return onSourceClick();
					},

					get onToolCallResolved() {
						return onToolCallResolved();
					},

					get onSave() {
						return onSave();
					},

					get onUpdate() {
						return onUpdate();
					},

					get onPreview() {
						return onPreview();
					}
				}),
				'component',
				Markdown,
				104,
				1,
				{ componentTag: 'MarkdownTokens' }
			);
		}),
		'key',
		Markdown,
		103,
		0
	);

	__vite_ssr_import_10__.append($$anchor, fragment);

	var $$pop = __vite_ssr_import_10__.pop($$exports);

	$$cleanup();

	return $$pop;
}
Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: Markdown });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDZ0M7QUFFMEI7QUFDVztBQUNVO0FBQ1I7QUFDRztBQUNMO0FBQ0E7O0FBc0JsQztBQUNnQztBQUNoQztBQUUyQjs7QUF4QjdELE1BQU0sT0FBTyxLQUNaLFlBQVksRUFBRTs7QUFHZiw0QkFBTSxDQUFDLEdBQUcsQ0FBQyw2QkFBb0IsQ0FBQyxPQUFPO0FBQ3ZDLDRCQUFNLENBQUMsR0FBRyxDQUFDLDZCQUFlLENBQUMsT0FBTztBQUNsQyw0QkFBTSxDQUFDLEdBQUcsQ0FBQyw2QkFBaUIsQ0FBQyxPQUFPO0FBQ3BDLDRCQUFNLENBQUMsR0FBRyxDQUFDLDZCQUFpQixDQUFDLE9BQU87QUFDcEMsNEJBQU0sQ0FBQyxHQUFHLENBQUMsNkJBQW1CLENBQUMsT0FBTztBQUN0Qyw0QkFBTSxDQUFDLEdBQUcsQ0FBQyx3Q0FBa0I7O0FBQzdCLDRCQUFNLENBQUMsR0FBRztDQUNULFVBQVU7RUFDVCxzQ0FBZ0IsR0FBRyxXQUFXLEVBQUUsR0FBRztFQUNuQyxzQ0FBZ0IsR0FBRyxXQUFXLEVBQUUsR0FBRztFQUNuQyxzQ0FBZ0IsR0FBRyxXQUFXLEVBQUUsR0FBRzs7OztxQ0FLdEMsQ0FBQzs7Ozs7Ozs7OztDQU9PLElBQUksRUFBRSxpREFBRyxFQUFFO0NBQ1gsSUFBSSxNQUFNLHFEQUFHLEVBQUU7Q0FDZixJQUFJLFNBQVMsd0RBQUcsRUFBRTtDQUNsQixJQUFJLE9BQU87Q0FDWCxJQUFJLElBQUksbURBQUcsSUFBSTtDQUNmLElBQUksS0FBSyxvREFBRyxJQUFJO0NBQ2hCLElBQUksSUFBSSxtREFBRyxLQUFLO0NBQ2hCLElBQUksT0FBTyxzREFBRyxLQUFLO0NBQ25CLElBQUksY0FBYyw2REFBRyxLQUFLO0NBRTFCLElBQUksWUFBWSwyREFBRyxHQUFHO0NBQ3RCLElBQUksYUFBYSw0REFBRyxJQUFJO0NBQ3hCLElBQUksVUFBVSx5REFBRyxLQUFLO0NBQ3RCLElBQUksV0FBVywwREFBRyxJQUFJO0NBRXRCLElBQUksU0FBUztDQUViLElBQUksTUFBTSwyREFBUyxDQUFDLENBQUM7Q0FDckIsSUFBSSxRQUFRLDZEQUFTLENBQUMsQ0FBQztDQUV2QixJQUFJLFNBQVMsOERBQVMsQ0FBQyxDQUFDO0NBRXhCLElBQUksYUFBYSxrRUFBUyxDQUFDLENBQUM7Q0FDNUIsSUFBSSxXQUFXLGdFQUFTLENBQUMsQ0FBQztDQUMxQixJQUFJLGtCQUFrQix1RUFBUyxDQUFDLENBQUM7Q0FFeEMsSUFBSSxNQUFNO0NBQ1YsSUFBSSxhQUFhLEdBQUcsSUFBSTtDQUN4QixJQUFJLFdBQVcsR0FBRyxFQUFFO0NBQ3BCLElBQUksaUJBQWlCLEdBQUcsRUFBRTs7Q0FFMUIsTUFBTSxXQUFXLFNBQVM7RUFDekIsRUFBRSx1Q0FBRSxPQUFPLElBQUssV0FBVyxHQUFFLE1BQU07O0VBQ25DLFdBQVcsR0FBRyxPQUFPOztFQUVyQixNQUFNLFNBQVMsR0FBRyxvQ0FBYSxDQUFDLDZDQUFzQixDQUFDLE9BQU8sS0FBRyxLQUFLLElBQUUsSUFBSSxFQUFFLEtBQUssSUFBRSxJQUFJOztFQUN6RixFQUFFLHVDQUFFLFNBQVMsRUFBSyxpQkFBaUIsR0FBRSxNQUFNOztFQUMzQyxpQkFBaUIsR0FBRyxTQUFTOzZCQUU3QixNQUFNLEVBQUcsNEJBQU0sQ0FBQyxLQUFLLENBQUMsU0FBUztDQUNoQyxDQUFDOztDQUVELE1BQU0sYUFBYSxJQUFJLE9BQU8sS0FBSztFQUNsQyxFQUFFLEVBQUUsT0FBTyxFQUFFO0dBQ1osRUFBRSxFQUFFLElBQUksSUFBRTtJQUNULG9CQUFvQixDQUFDLGFBQWE7SUFDbEMsYUFBYSxHQUFHLElBQUk7SUFDcEIsV0FBVztHQUNaLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLGFBQWEsRUFBRTtJQUMxQixhQUFhLEdBQUcscUJBQXFCLE9BQU87S0FDM0MsYUFBYSxHQUFHLElBQUk7S0FDcEIsV0FBVztJQUNaLENBQUM7R0FDRjtFQUNEO0NBQ0QsQ0FBQzs7O0NBS0QsZ0NBQVMsT0FBTztFQUNmLG9CQUFvQixDQUFDLGFBQWE7Q0FDbkMsQ0FBQzs7O0VBTEUsYUFBYSxDQUFDLE9BQU87Ozs7Ozs7Ozs7Ozs7eUNBUW5CLEVBQUU7O1VBQ047O3dDQUNDLE1BQU07Ozs7YUFDTixFQUFFOzs7O2FBQ0YsTUFBTTs7OzthQUNOLFNBQVM7Ozs7YUFDVCxJQUFJOzs7O2FBQ0osSUFBSTs7OzthQUNKLE9BQU87Ozs7YUFDUCxjQUFjOzs7O2FBQ2QsWUFBWTs7OzthQUNaLGFBQWE7Ozs7YUFDYixTQUFTOzs7O2FBQ1QsVUFBVTs7OzthQUNWLFdBQVc7Ozs7YUFDWCxXQUFXOzs7O2FBQ1gsYUFBYTs7OzthQUNiLGtCQUFrQjs7OzthQUNsQixNQUFNOzs7O2FBQ04sUUFBUTs7OzthQUNSLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdEJKIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJNYXJrZG93bi5zdmVsdGUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBjb250ZXh0PVwibW9kdWxlXCI+XG5cdGltcG9ydCB7IG1hcmtlZCB9IGZyb20gJ21hcmtlZCc7XG5cblx0aW1wb3J0IG1hcmtlZEV4dGVuc2lvbiBmcm9tICckbGliL3V0aWxzL21hcmtlZC9leHRlbnNpb24nO1xuXHRpbXBvcnQgbWFya2VkS2F0ZXhFeHRlbnNpb24gZnJvbSAnJGxpYi91dGlscy9tYXJrZWQva2F0ZXgtZXh0ZW5zaW9uJztcblx0aW1wb3J0IHsgZGlzYWJsZVNpbmdsZVRpbGRlIH0gZnJvbSAnJGxpYi91dGlscy9tYXJrZWQvc3RyaWtldGhyb3VnaC1leHRlbnNpb24nO1xuXHRpbXBvcnQgeyBtZW50aW9uRXh0ZW5zaW9uIH0gZnJvbSAnJGxpYi91dGlscy9tYXJrZWQvbWVudGlvbi1leHRlbnNpb24nO1xuXHRpbXBvcnQgY29sb25GZW5jZUV4dGVuc2lvbiBmcm9tICckbGliL3V0aWxzL21hcmtlZC9jb2xvbi1mZW5jZS1leHRlbnNpb24nO1xuXHRpbXBvcnQgZm9vdG5vdGVFeHRlbnNpb24gZnJvbSAnJGxpYi91dGlscy9tYXJrZWQvZm9vdG5vdGUtZXh0ZW5zaW9uJztcblx0aW1wb3J0IGNpdGF0aW9uRXh0ZW5zaW9uIGZyb20gJyRsaWIvdXRpbHMvbWFya2VkL2NpdGF0aW9uLWV4dGVuc2lvbic7XG5cblx0Y29uc3Qgb3B0aW9ucyA9IHtcblx0XHR0aHJvd09uRXJyb3I6IGZhbHNlXG5cdH07XG5cblx0bWFya2VkLnVzZShtYXJrZWRLYXRleEV4dGVuc2lvbihvcHRpb25zKSk7XG5cdG1hcmtlZC51c2UobWFya2VkRXh0ZW5zaW9uKG9wdGlvbnMpKTtcblx0bWFya2VkLnVzZShjaXRhdGlvbkV4dGVuc2lvbihvcHRpb25zKSk7XG5cdG1hcmtlZC51c2UoZm9vdG5vdGVFeHRlbnNpb24ob3B0aW9ucykpO1xuXHRtYXJrZWQudXNlKGNvbG9uRmVuY2VFeHRlbnNpb24ob3B0aW9ucykpO1xuXHRtYXJrZWQudXNlKGRpc2FibGVTaW5nbGVUaWxkZSk7XG5cdG1hcmtlZC51c2Uoe1xuXHRcdGV4dGVuc2lvbnM6IFtcblx0XHRcdG1lbnRpb25FeHRlbnNpb24oeyB0cmlnZ2VyQ2hhcjogJ0AnIH0pLFxuXHRcdFx0bWVudGlvbkV4dGVuc2lvbih7IHRyaWdnZXJDaGFyOiAnIycgfSksXG5cdFx0XHRtZW50aW9uRXh0ZW5zaW9uKHsgdHJpZ2dlckNoYXI6ICckJyB9KVxuXHRcdF1cblx0fSk7XG48L3NjcmlwdD5cblxuPHNjcmlwdD5cblx0aW1wb3J0IHsgb25EZXN0cm95IH0gZnJvbSAnc3ZlbHRlJztcblx0aW1wb3J0IHsgcmVwbGFjZVRva2VucywgcHJvY2Vzc1Jlc3BvbnNlQ29udGVudCB9IGZyb20gJyRsaWIvdXRpbHMnO1xuXHRpbXBvcnQgeyB1c2VyIH0gZnJvbSAnJGxpYi9zdG9yZXMnO1xuXG5cdGltcG9ydCBNYXJrZG93blRva2VucyBmcm9tICcuL01hcmtkb3duL01hcmtkb3duVG9rZW5zLnN2ZWx0ZSc7XG5cblx0ZXhwb3J0IGxldCBpZCA9ICcnO1xuXHRleHBvcnQgbGV0IGNoYXRJZCA9ICcnO1xuXHRleHBvcnQgbGV0IG1lc3NhZ2VJZCA9ICcnO1xuXHRleHBvcnQgbGV0IGNvbnRlbnQ7XG5cdGV4cG9ydCBsZXQgZG9uZSA9IHRydWU7XG5cdGV4cG9ydCBsZXQgbW9kZWwgPSBudWxsO1xuXHRleHBvcnQgbGV0IHNhdmUgPSBmYWxzZTtcblx0ZXhwb3J0IGxldCBwcmV2aWV3ID0gZmFsc2U7XG5cdGV4cG9ydCBsZXQgY29tcGFjdFByZXZpZXcgPSBmYWxzZTtcblxuXHRleHBvcnQgbGV0IHBhcmFncmFwaFRhZyA9ICdwJztcblx0ZXhwb3J0IGxldCBlZGl0Q29kZUJsb2NrID0gdHJ1ZTtcblx0ZXhwb3J0IGxldCB0b3BQYWRkaW5nID0gZmFsc2U7XG5cdGV4cG9ydCBsZXQgYWxsb3dFbWJlZHMgPSB0cnVlO1xuXG5cdGV4cG9ydCBsZXQgc291cmNlSWRzID0gW107XG5cblx0ZXhwb3J0IGxldCBvblNhdmUgPSAoKSA9PiB7fTtcblx0ZXhwb3J0IGxldCBvblVwZGF0ZSA9ICgpID0+IHt9O1xuXG5cdGV4cG9ydCBsZXQgb25QcmV2aWV3ID0gKCkgPT4ge307XG5cblx0ZXhwb3J0IGxldCBvblNvdXJjZUNsaWNrID0gKCkgPT4ge307XG5cdGV4cG9ydCBsZXQgb25UYXNrQ2xpY2sgPSAoKSA9PiB7fTtcblx0ZXhwb3J0IGxldCBvblRvb2xDYWxsUmVzb2x2ZWQgPSAoKSA9PiB7fTtcblxuXHRsZXQgdG9rZW5zID0gW107XG5cdGxldCBwZW5kaW5nVXBkYXRlID0gbnVsbDtcblx0bGV0IGxhc3RDb250ZW50ID0gJyc7XG5cdGxldCBsYXN0UGFyc2VkQ29udGVudCA9ICcnO1xuXG5cdGNvbnN0IHBhcnNlVG9rZW5zID0gKCkgPT4ge1xuXHRcdGlmIChjb250ZW50ID09PSBsYXN0Q29udGVudCkgcmV0dXJuO1xuXHRcdGxhc3RDb250ZW50ID0gY29udGVudDtcblxuXHRcdGNvbnN0IHByb2Nlc3NlZCA9IHJlcGxhY2VUb2tlbnMocHJvY2Vzc1Jlc3BvbnNlQ29udGVudChjb250ZW50KSwgbW9kZWw/Lm5hbWUsICR1c2VyPy5uYW1lKTtcblx0XHRpZiAocHJvY2Vzc2VkID09PSBsYXN0UGFyc2VkQ29udGVudCkgcmV0dXJuO1xuXHRcdGxhc3RQYXJzZWRDb250ZW50ID0gcHJvY2Vzc2VkO1xuXG5cdFx0dG9rZW5zID0gbWFya2VkLmxleGVyKHByb2Nlc3NlZCk7XG5cdH07XG5cblx0Y29uc3QgdXBkYXRlSGFuZGxlciA9IChjb250ZW50KSA9PiB7XG5cdFx0aWYgKGNvbnRlbnQpIHtcblx0XHRcdGlmIChkb25lKSB7XG5cdFx0XHRcdGNhbmNlbEFuaW1hdGlvbkZyYW1lKHBlbmRpbmdVcGRhdGUpO1xuXHRcdFx0XHRwZW5kaW5nVXBkYXRlID0gbnVsbDtcblx0XHRcdFx0cGFyc2VUb2tlbnMoKTtcblx0XHRcdH0gZWxzZSBpZiAoIXBlbmRpbmdVcGRhdGUpIHtcblx0XHRcdFx0cGVuZGluZ1VwZGF0ZSA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG5cdFx0XHRcdFx0cGVuZGluZ1VwZGF0ZSA9IG51bGw7XG5cdFx0XHRcdFx0cGFyc2VUb2tlbnMoKTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9O1xuXG5cdCQ6IHVwZGF0ZUhhbmRsZXIoY29udGVudCk7XG5cblx0Ly8gVGhyb3R0bGUgcGFyc2luZyB0byBvbmNlIHBlciBhbmltYXRpb24gZnJhbWUgd2hpbGUgc3RyZWFtaW5nXG5cdG9uRGVzdHJveSgoKSA9PiB7XG5cdFx0Y2FuY2VsQW5pbWF0aW9uRnJhbWUocGVuZGluZ1VwZGF0ZSk7XG5cdH0pO1xuPC9zY3JpcHQ+XG5cbnsja2V5IGlkfVxuXHQ8TWFya2Rvd25Ub2tlbnNcblx0XHR7dG9rZW5zfVxuXHRcdHtpZH1cblx0XHR7Y2hhdElkfVxuXHRcdHttZXNzYWdlSWR9XG5cdFx0e2RvbmV9XG5cdFx0e3NhdmV9XG5cdFx0e3ByZXZpZXd9XG5cdFx0e2NvbXBhY3RQcmV2aWV3fVxuXHRcdHtwYXJhZ3JhcGhUYWd9XG5cdFx0e2VkaXRDb2RlQmxvY2t9XG5cdFx0e3NvdXJjZUlkc31cblx0XHR7dG9wUGFkZGluZ31cblx0XHR7YWxsb3dFbWJlZHN9XG5cdFx0e29uVGFza0NsaWNrfVxuXHRcdHtvblNvdXJjZUNsaWNrfVxuXHRcdHtvblRvb2xDYWxsUmVzb2x2ZWR9XG5cdFx0e29uU2F2ZX1cblx0XHR7b25VcGRhdGV9XG5cdFx0e29uUHJldmlld31cblx0Lz5cbnsva2V5fVxuIl0sImZpbGUiOiIvc3JjL2xpYi9jb21wb25lbnRzL2NoYXQvTWVzc2FnZXMvTWFya2Rvd24uc3ZlbHRlIn0=
