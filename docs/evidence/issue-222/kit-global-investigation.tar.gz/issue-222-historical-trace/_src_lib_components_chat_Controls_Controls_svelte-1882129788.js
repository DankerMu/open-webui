// /src/lib/components/chat/Controls/Controls.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_3__ = await __vite_ssr_import__("/node_modules/svelte/src/index-client.js", {"importedNames":["createEventDispatcher","getContext"]});
const __vite_ssr_import_4__ = await __vite_ssr_import__("/src/lib/components/icons/XMark.svelte", {"importedNames":["default"]});
const __vite_ssr_import_5__ = await __vite_ssr_import__("/src/lib/components/chat/Settings/Advanced/AdvancedParams.svelte", {"importedNames":["default"]});
const __vite_ssr_import_6__ = await __vite_ssr_import__("/src/lib/components/chat/Controls/Valves.svelte", {"importedNames":["default"]});
const __vite_ssr_import_7__ = await __vite_ssr_import__("/src/lib/components/common/FileItem.svelte", {"importedNames":["default"]});
const __vite_ssr_import_8__ = await __vite_ssr_import__("/src/lib/components/common/Collapsible.svelte", {"importedNames":["default"]});
const __vite_ssr_import_9__ = await __vite_ssr_import__("/src/lib/stores/index.ts", {"importedNames":["user","settings"]});



Controls[__vite_ssr_import_2__.FILENAME] = 'src/lib/components/chat/Controls/Controls.svelte';










var root = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class=" flex items-center justify-between dark:text-gray-100 mb-2"><div class=" text-md self-center"> </div> <button class="self-center"><!></button></div>`), Controls[__vite_ssr_import_2__.FILENAME], [[42, 2, [[43, 3], [44, 3]]]]);
var root_1 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="flex flex-col gap-1 mt-1.5" slot="content"></div>`), Controls[__vite_ssr_import_2__.FILENAME], [[67, 5]]);
var root_2 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="pt-1 pb-1 text-xs" slot="content"><!></div>`), Controls[__vite_ssr_import_2__.FILENAME], [[103, 5]]);
var root_3 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="pt-1 pb-1" slot="content"><textarea rows="3"></textarea></div>`), Controls[__vite_ssr_import_2__.FILENAME], [[118, 5, [[119, 6]]]]);
var root_4 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="pt-1 pb-1 text-xs" slot="content"><div><!></div></div>`), Controls[__vite_ssr_import_2__.FILENAME], [[140, 5, [[141, 6]]]]);
var root_5 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="space-y-1 dark:text-gray-200 text-sm py-0.5 px-0.5"><!> <!> <!> <!></div>`), Controls[__vite_ssr_import_2__.FILENAME], [[57, 2]]);
var root_6 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class=" dark:text-white"><!> <!></div>`), Controls[__vite_ssr_import_2__.FILENAME], [[40, 0]]);

function Controls($$anchor, $$props) {
	__vite_ssr_import_2__.check_target(new.target);
	__vite_ssr_import_2__.push($$props, false, Controls);

	var $$ownership_validator = __vite_ssr_import_2__.create_ownership_validator($$props);

	const $i18n = () => (
		__vite_ssr_import_2__.validate_store(i18n, 'i18n'),
		__vite_ssr_import_2__.store_get(i18n, '$i18n', $$stores)
	);

	const $user = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_9__.user, 'user'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_9__.user, '$user', $$stores)
	);

	const $settings = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_9__.settings, 'settings'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_9__.settings, '$settings', $$stores)
	);

	const [$$stores, $$cleanup] = __vite_ssr_import_2__.setup_stores();
	const dispatch = __vite_ssr_import_3__.createEventDispatcher();
	const i18n = __vite_ssr_import_3__.getContext('i18n');
	let models = __vite_ssr_import_2__.prop($$props, 'models', 24, () => []);
	let chatFiles = __vite_ssr_import_2__.prop($$props, 'chatFiles', 28, () => []);
	let params = __vite_ssr_import_2__.prop($$props, 'params', 28, () => ({}));
	let embed = __vite_ssr_import_2__.prop($$props, 'embed', 8, false);

	// Persist collapsible section open/close state
	const getOpen = (key, fallback = true) => {
		const v = localStorage.getItem(`chatControls.${key}`);

		return __vite_ssr_import_2__.strict_equals(v, null, false) ? __vite_ssr_import_2__.strict_equals(v, 'true') : fallback;
	};

	const setOpen = (key) => (open) => {
		localStorage.setItem(`chatControls.${key}`, String(open));
	};

	let showFiles = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(getOpen('files')), 'showFiles');
	let showValves = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(getOpen('valves', false)), 'showValves');
	let showSystemPrompt = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(getOpen('systemPrompt')), 'showSystemPrompt');
	let showAdvancedParams = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(getOpen('advancedParams')), 'showAdvancedParams');
	const compactSectionButtonClass = 'w-full py-1 text-xs font-normal text-gray-500 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100 transition cursor-pointer select-none';
	const systemPromptTextareaClass = 'w-full resize-vertical rounded-lg border border-gray-100/50 bg-gray-50/40 px-2 py-1.5 text-xs text-gray-700 outline-hidden transition-colors placeholder:text-gray-300 focus:border-blue-400 dark:border-white/[0.04] dark:bg-white/[0.03] dark:text-gray-300 dark:placeholder:text-gray-700 dark:focus:border-blue-500';
	const compactSystemPromptTextareaClass = 'w-full resize-vertical appearance-none bg-transparent py-1 text-xs outline-hidden focus:bg-transparent disabled:bg-transparent';
	var $$exports = { ...__vite_ssr_import_2__.legacy_api() };

	__vite_ssr_import_2__.init();

	var div = root_6();
	var node = __vite_ssr_import_2__.child(div);

	{
		var consequent = ($$anchor) => {
			var div_1 = root();
			var div_2 = __vite_ssr_import_2__.child(div_1);
			var text = __vite_ssr_import_2__.child(div_2, true);

			__vite_ssr_import_2__.reset(div_2);

			var button = __vite_ssr_import_2__.sibling(div_2, 2);
			var node_1 = __vite_ssr_import_2__.child(button);

			__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_4__.default(node_1, { className: 'size-3.5' }), 'component', Controls, 51, 4, { componentTag: 'XMark' });
			__vite_ssr_import_2__.reset(button);
			__vite_ssr_import_2__.reset(div_1);

			__vite_ssr_import_2__.template_effect(
				($0, $1) => {
					__vite_ssr_import_2__.set_text(text, $0);
					__vite_ssr_import_2__.set_attribute(button, 'aria-label', $1);
				},
				[
					() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Controls'))),
					() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Close chat controls')))
				]
			);

			__vite_ssr_import_2__.event('click', button, function click() {
				dispatch('close');
			});

			__vite_ssr_import_2__.append($$anchor, div_1);
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node, ($$render) => {
				if (!embed()) $$render(consequent);
			}),
			'if',
			Controls,
			41,
			1
		);
	}

	var node_2 = __vite_ssr_import_2__.sibling(node, 2);

	{
		var consequent_5 = ($$anchor) => {
			var div_3 = root_5();
			var node_3 = __vite_ssr_import_2__.child(div_3);

			{
				var consequent_1 = ($$anchor) => {
					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Files'))));
						let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.untrack(() => setOpen('files'))));

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_8__.default($$anchor, {
								get title() {
									return __vite_ssr_import_2__.get($0);
								},

								get onChange() {
									return __vite_ssr_import_2__.get($1);
								},
								buttonClassName: 'w-full',
								chevronClassName: 'size-2.5',
								chevronStrokeWidth: '2',
								get open() {
									return __vite_ssr_import_2__.get(showFiles);
								},

								set open($$value) {
									__vite_ssr_import_2__.set(showFiles, $$value);
								},

								$$slots: {
									content: ($$anchor, $$slotProps) => {
										var div_4 = root_1();

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_2__.each(div_4, 5, chatFiles, __vite_ssr_import_2__.index, ($$anchor, file, fileIdx) => {
												{
													let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
														__vite_ssr_import_2__.get(file),
														__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(file)?.url ? __vite_ssr_import_2__.get(file).url : null)
													));

													let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.get(file), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(file)?.size)));

													__vite_ssr_import_2__.add_svelte_meta(
														() => __vite_ssr_import_7__.default($$anchor, {
															className: 'w-full',
															get item() {
																return __vite_ssr_import_2__.get(file);
															},
															edit: true,
															get url() {
																return __vite_ssr_import_2__.get($0);
															},

															get name() {
																return (__vite_ssr_import_2__.get(file), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(file).name));
															},

															get type() {
																return (__vite_ssr_import_2__.get(file), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(file).type));
															},

															get size() {
																return __vite_ssr_import_2__.get($1);
															},
															dismissible: true,
															small: true,
															$$events: {
																dismiss: () => {
																	// Remove the file from the chatFiles array
																	chatFiles().splice(fileIdx, 1);

																	chatFiles(chatFiles());
																},

																click: () => {
																	console.log(...__vite_ssr_import_2__.log_if_contains_state('log', __vite_ssr_import_2__.get(file)));
																}
															}
														}),
														'component',
														Controls,
														69,
														7,
														{ componentTag: 'FileItem' }
													);
												}
											}),
											'each',
											Controls,
											68,
											6
										);

										__vite_ssr_import_2__.reset(div_4);
										__vite_ssr_import_2__.append($$anchor, div_4);
									}
								},
								$$legacy: true
							}),
							'component',
							Controls,
							59,
							4,
							{ componentTag: 'Collapsible' }
						);
					}
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_3, ($$render) => {
						if ((
							__vite_ssr_import_2__.deep_read_state(chatFiles()),
							__vite_ssr_import_2__.untrack(() => chatFiles().length > 0)
						)) $$render(consequent_1);
					}),
					'if',
					Controls,
					58,
					3
				);
			}

			var node_4 = __vite_ssr_import_2__.sibling(node_3, 2);

			{
				var consequent_2 = ($$anchor) => {
					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.untrack(() => setOpen('valves'))));
						let $1 = __vite_ssr_import_2__.derived_safe_equal(() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Valves'))));

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_8__.default($$anchor, {
								get onChange() {
									return __vite_ssr_import_2__.get($0);
								},

								get title() {
									return __vite_ssr_import_2__.get($1);
								},
								buttonClassName: compactSectionButtonClass,
								chevronClassName: 'size-2.5',
								chevronStrokeWidth: '2',
								get open() {
									return __vite_ssr_import_2__.get(showValves);
								},

								set open($$value) {
									__vite_ssr_import_2__.set(showValves, $$value);
								},

								$$slots: {
									content: ($$anchor, $$slotProps) => {
										var div_5 = root_2();
										var node_5 = __vite_ssr_import_2__.child(div_5);

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_6__.default(node_5, {
												get show() {
													return __vite_ssr_import_2__.get(showValves);
												}
											}),
											'component',
											Controls,
											104,
											6,
											{ componentTag: 'Valves' }
										);

										__vite_ssr_import_2__.reset(div_5);
										__vite_ssr_import_2__.append($$anchor, div_5);
									}
								},
								$$legacy: true
							}),
							'component',
							Controls,
							95,
							4,
							{ componentTag: 'Collapsible' }
						);
					}
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_4, ($$render) => {
						if ((
							$user(),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals($user()?.role, 'admin') || ($user()?.permissions.chat?.valves ?? true))
						)) $$render(consequent_2);
					}),
					'if',
					Controls,
					94,
					3
				);
			}

			var node_6 = __vite_ssr_import_2__.sibling(node_4, 2);

			{
				var consequent_3 = ($$anchor) => {
					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('System Prompt'))));
						let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.untrack(() => setOpen('systemPrompt'))));

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_8__.default($$anchor, {
								get title() {
									return __vite_ssr_import_2__.get($0);
								},

								get onChange() {
									return __vite_ssr_import_2__.get($1);
								},
								buttonClassName: compactSectionButtonClass,
								chevronClassName: 'size-2.5',
								chevronStrokeWidth: '2',
								get open() {
									return __vite_ssr_import_2__.get(showSystemPrompt);
								},

								set open($$value) {
									__vite_ssr_import_2__.set(showSystemPrompt, $$value);
								},

								$$slots: {
									content: ($$anchor, $$slotProps) => {
										var div_6 = root_3();
										var textarea = __vite_ssr_import_2__.child(div_6);

										__vite_ssr_import_2__.remove_textarea_child(textarea);
										__vite_ssr_import_2__.reset(div_6);

										__vite_ssr_import_2__.template_effect(
											($0) => {
												__vite_ssr_import_2__.set_class(textarea, 1, __vite_ssr_import_2__.clsx((
													$settings(),
													__vite_ssr_import_2__.untrack(() => $settings()?.highContrastMode ?? false
														? systemPromptTextareaClass
														: compactSystemPromptTextareaClass)
												)));

												__vite_ssr_import_2__.set_attribute(textarea, 'placeholder', $0);
											},
											[
												() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Enter system prompt')))
											]
										);

										__vite_ssr_import_2__.bind_value(
											textarea,
											function get() {
												return params().system;
											},
											function set($$value) {
												$$ownership_validator.mutation(null, ['params', 'system'], params(params().system = $$value, true), 120, 19);
											}
										);

										__vite_ssr_import_2__.append($$anchor, div_6);
									}
								},
								$$legacy: true
							}),
							'component',
							Controls,
							110,
							4,
							{ componentTag: 'Collapsible' }
						);
					}
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_6, ($$render) => {
						if ((
							$user(),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals($user()?.role, 'admin') || ($user()?.permissions.chat?.system_prompt ?? true))
						)) $$render(consequent_3);
					}),
					'if',
					Controls,
					109,
					3
				);
			}

			var node_7 = __vite_ssr_import_2__.sibling(node_6, 2);

			{
				var consequent_4 = ($$anchor) => {
					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Advanced Params'))));
						let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.untrack(() => setOpen('advancedParams'))));

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_8__.default($$anchor, {
								get title() {
									return __vite_ssr_import_2__.get($0);
								},

								get onChange() {
									return __vite_ssr_import_2__.get($1);
								},
								buttonClassName: compactSectionButtonClass,
								chevronClassName: 'size-2.5',
								chevronStrokeWidth: '2',
								get open() {
									return __vite_ssr_import_2__.get(showAdvancedParams);
								},

								set open($$value) {
									__vite_ssr_import_2__.set(showAdvancedParams, $$value);
								},

								$$slots: {
									content: ($$anchor, $$slotProps) => {
										var div_7 = root_4();
										var div_8 = __vite_ssr_import_2__.child(div_7);
										var node_8 = __vite_ssr_import_2__.child(div_8);

										{
											let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
												$user(),
												__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals($user()?.role, 'admin'))
											));

											$$ownership_validator.binding('params', __vite_ssr_import_5__.default, params);

											__vite_ssr_import_2__.add_svelte_meta(
												() => __vite_ssr_import_5__.default(node_8, {
													get admin() {
														return __vite_ssr_import_2__.get($0);
													},
													custom: true,
													get params() {
														return params();
													},

													set params($$value) {
														params($$value);
													},
													$$legacy: true
												}),
												'component',
												Controls,
												142,
												7,
												{ componentTag: 'AdvancedParams' }
											);
										}

										__vite_ssr_import_2__.reset(div_8);
										__vite_ssr_import_2__.reset(div_7);
										__vite_ssr_import_2__.append($$anchor, div_7);
									}
								},
								$$legacy: true
							}),
							'component',
							Controls,
							132,
							4,
							{ componentTag: 'Collapsible' }
						);
					}
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_7, ($$render) => {
						if ((
							$user(),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals($user()?.role, 'admin') || ($user()?.permissions.chat?.params ?? true))
						)) $$render(consequent_4);
					}),
					'if',
					Controls,
					131,
					3
				);
			}

			__vite_ssr_import_2__.reset(div_3);
			__vite_ssr_import_2__.append($$anchor, div_3);
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node_2, ($$render) => {
				if ((
					$user(),
					__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals($user()?.role, 'admin') || ($user()?.permissions.chat?.controls ?? true))
				)) $$render(consequent_5);
			}),
			'if',
			Controls,
			56,
			1
		);
	}

	__vite_ssr_import_2__.reset(div);
	__vite_ssr_import_2__.append($$anchor, div);

	var $$pop = __vite_ssr_import_2__.pop($$exports);

	$$cleanup();

	return $$pop;
}
Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: Controls });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7OztBQUMyRDtBQUlKO0FBQ2lCO0FBQ1A7QUFDSDtBQUNNO0FBRXZCOzs7Ozs7Ozs7O3FDQVg3QyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBRUEsTUFBTSxRQUFRLEdBQUcsMkNBQXFCO0NBQ3RDLE1BQU0sSUFBSSxHQUFHLGdDQUFVLENBQUMsTUFBTTtDQVN2QixJQUFJLE1BQU07Q0FDVixJQUFJLFNBQVM7Q0FDYixJQUFJLE1BQU07Q0FDVixJQUFJLEtBQUssbURBQUcsS0FBSzs7O0NBR3hCLE1BQU0sT0FBTyxJQUFJLEdBQVcsRUFBRSxRQUFRLEdBQUcsSUFBSSxLQUFjO0VBQzFELE1BQU0sQ0FBQyxHQUFHLFlBQVksQ0FBQyxPQUFPLGlCQUFpQixHQUFHOztFQUNsRCxNQUFNLHFDQUFDLENBQUMsRUFBSyxJQUFJLCtDQUFHLENBQUMsRUFBSyxNQUFNLElBQUcsUUFBUTtDQUM1QyxDQUFDOztDQUNELE1BQU0sT0FBTyxJQUFJLEdBQVcsTUFBTSxJQUFhLEtBQUs7RUFDbkQsWUFBWSxDQUFDLE9BQU8saUJBQWlCLEdBQUcsSUFBSSxNQUFNLENBQUMsSUFBSTtDQUN4RCxDQUFDOztDQUVELElBQUksU0FBUyxrRUFBRyxPQUFPLENBQUMsT0FBTztDQUMvQixJQUFJLFVBQVUsa0VBQUcsT0FBTyxDQUFDLFFBQVEsRUFBRSxLQUFLO0NBQ3hDLElBQUksZ0JBQWdCLGtFQUFHLE9BQU8sQ0FBQyxjQUFjO0NBQzdDLElBQUksa0JBQWtCLGtFQUFHLE9BQU8sQ0FBQyxnQkFBZ0I7Q0FFakQsTUFBTSx5QkFBeUIsR0FDOUIscUpBQXFKO0NBQ3RKLE1BQU0seUJBQXlCLEdBQzlCLHlUQUF5VDtDQUMxVCxNQUFNLGdDQUFnQyxHQUNyQyxnSUFBZ0k7Ozs7O0tBR2pJLEdBQUc7d0NBQUgsR0FBRzs7OztPQUVELEtBQUc7T0FDRixLQUFHLCtCQURKLEtBQUc7MENBQ0YsS0FBRzs7K0JBQUgsS0FBRzs7T0FDSCx1Q0FEQSxLQUFHOzRDQUNIOzsrQ0FPQyw2QkFBSzsrQkFQTjsrQkFGRCxLQUFHOzs7Ozt5Q0FFRjs7O3lEQURrQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLFVBQVU7eURBR3hDLEtBQUssR0FBQyxDQUFDLENBQUMscUJBQXFCOzs7O3dDQUZ6Qyx5QkFHZ0I7SUFDZixRQUFRLENBQUMsT0FBTztHQUNqQixDQUFDOzswQ0FQRixLQUFHOzs7OztTQURDLEtBQUs7Ozs7Ozs7Ozs7Ozs7T0FnQlQsS0FBRzs0Q0FBSCxLQUFHOzs7Ozs0R0FHTSxLQUFLLEdBQUMsQ0FBQyxDQUFDLE9BQU87bUdBRVosT0FBTyxDQUFDLE9BQU87OzthQUh6Qjs7Ozs7Ozs7Ozs7WUFFQSxJQUFTOzBDQUFFLFNBQVM7OztZQUFwQixJQUFTO21DQUFFLFNBQVM7Ozs7O2NBTW5CLEtBQUc7Ozs0Q0FBSCxLQUFHLEtBQ0ksU0FBUywwQ0FBSSxJQUFJOzs7d0NBQUosSUFBSTs0RUFLakIsSUFBSSxHQUFFLEdBQUcsNkJBQUcsSUFBSSxFQUFDLEdBQUcsR0FBRyxJQUFJOzs7Z0dBTGQsSUFBSSxpRUFRaEIsSUFBSSxHQUFFLElBQUk7OztvQkFQaEI7OztpREFFTSxJQUFJOztxQkFDSixJQUFJOzs7Ozs7a0RBSlEsSUFBSSxpRUFNaEIsSUFBSSxFQUFDLElBQUk7Ozs7a0RBTkcsSUFBSSxpRUFPaEIsSUFBSSxFQUFDLElBQUk7Ozs7Ozs0QkFFRixJQUFJO3NCQUNWLElBQUk7OytCQUNPOztpQkFHakIsU0FBUyxHQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQzs7aUJBQzNCLFNBQVMsQ0FBRyxTQUFTO2dCQUN0QixDQUFDOzs2QkFDZTtpQkFDZixPQUFPLENBQUMsR0FBRyxpRkFBQyxJQUFJO2dCQUNqQixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7OztzQ0FwQkgsS0FBRztpREFBSCxLQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs2Q0FyREcsU0FBUzsyQ0E0Q2IsU0FBUyxHQUFDLE1BQU0sR0FBRyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7bUdBdUNiLE9BQU8sQ0FBQyxRQUFROzRHQUNuQixLQUFLLEdBQUMsQ0FBQyxDQUFDLFFBQVE7OzthQUh2Qjs7Ozs7Ozs7eUJBSWlCLHlCQUF5Qjs7O1lBSDFDLElBQVM7MENBQUUsVUFBVTs7O1lBQXJCLElBQVM7bUNBQUUsVUFBVTs7Ozs7Y0FPcEIsS0FBRzttREFBSCxLQUFHOzs7aUJBQ0YsNkJBQU07OzhDQUFPLFVBQVU7Ozs7Ozs7Ozs7c0NBRHhCLEtBQUc7aURBQUgsS0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7OytFQVRELEtBQUssSUFBRSxJQUFJLEVBQUssT0FBTyxNQUFLLEtBQUssSUFBRSxXQUFXLENBQUMsSUFBSSxFQUFFLE1BQU0sSUFBSSxJQUFJOzs7Ozs7Ozs7Ozs7Ozs7NEdBaUIvRCxLQUFLLEdBQUMsQ0FBQyxDQUFDLGVBQWU7bUdBRXBCLE9BQU8sQ0FBQyxjQUFjOzs7YUFIaEM7Ozs7Ozs7O3lCQUlpQix5QkFBeUI7OztZQUYxQyxJQUFTOzBDQUFFLGdCQUFnQjs7O1lBQTNCLElBQVM7bUNBQUUsZ0JBQWdCOzs7OztjQU0xQixLQUFHO2NBQ0YsdUNBREQsS0FBRzs7c0RBQ0Y7c0NBREQsS0FBRzs7Ozs0Q0FDRjs7aURBRVEsU0FBUyxJQUFFLGdCQUFnQixJQUFJLEtBQUs7Z0JBQ3pDO2dCQUNBLGdDQUFnQzs7O2dEQUpuQzs7O2dFQU1hLEtBQUssR0FBQyxDQUFDLENBQUMscUJBQXFCOzs7OztXQU4xQztvQkFDQSxHQUFVO21CQUFFLE1BQU0sR0FBQyxNQUFNOztvQkFBekIsR0FBVTt1RUFBRSxNQUFNLENBQU4sTUFBTSxHQUFDLE1BQU07Ozs7aURBRjFCLEtBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7OzsrRUFURCxLQUFLLElBQUUsSUFBSSxFQUFLLE9BQU8sTUFBSyxLQUFLLElBQUUsV0FBVyxDQUFDLElBQUksRUFBRSxhQUFhLElBQUksSUFBSTs7Ozs7Ozs7Ozs7Ozs7OzRHQXdCdEUsS0FBSyxHQUFDLENBQUMsQ0FBQyxpQkFBaUI7bUdBRXRCLE9BQU8sQ0FBQyxnQkFBZ0I7OzthQUhsQzs7Ozs7Ozs7eUJBSWlCLHlCQUF5Qjs7O1lBRjFDLElBQVM7MENBQUUsa0JBQWtCOzs7WUFBN0IsSUFBUzttQ0FBRSxrQkFBa0I7Ozs7O2NBTTVCLEtBQUc7Y0FDRixLQUFHLCtCQURKLEtBQUc7bURBQ0YsS0FBRzs7Ozs7b0ZBQ29CLEtBQUssSUFBRSxJQUFJLEVBQUssT0FBTzs7Ozs7O2tCQUE3Qyw2QkFBYzs7OztxQkFBeUMsSUFBSTtpQkFBRSxNQUFXOzs7O2lCQUFYLE1BQVc7Ozs7Ozs7Ozs7Ozs7c0NBRHpFLEtBQUc7c0NBREosS0FBRztpREFBSCxLQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7K0VBVEQsS0FBSyxJQUFFLElBQUksRUFBSyxPQUFPLE1BQUssS0FBSyxJQUFFLFdBQVcsQ0FBQyxJQUFJLEVBQUUsTUFBTSxJQUFJLElBQUk7Ozs7Ozs7Ozs7K0JBMUV4RSxLQUFHOzBDQUFILEtBQUc7Ozs7Ozs7NkVBREEsS0FBSyxJQUFFLElBQUksRUFBSyxPQUFPLE1BQUssS0FBSyxJQUFFLFdBQVcsQ0FBQyxJQUFJLEVBQUUsUUFBUSxJQUFJLElBQUk7Ozs7Ozs7Ozs7NkJBaEIxRSxHQUFHO3dDQUFILEdBQUc7Ozs7Ozs7QUFGSSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29udHJvbHMuc3ZlbHRlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgbGFuZz1cInRzXCI+XG5cdGltcG9ydCB7IGNyZWF0ZUV2ZW50RGlzcGF0Y2hlciwgZ2V0Q29udGV4dCB9IGZyb20gJ3N2ZWx0ZSc7XG5cdGNvbnN0IGRpc3BhdGNoID0gY3JlYXRlRXZlbnREaXNwYXRjaGVyKCk7XG5cdGNvbnN0IGkxOG4gPSBnZXRDb250ZXh0KCdpMThuJyk7XG5cblx0aW1wb3J0IFhNYXJrIGZyb20gJyRsaWIvY29tcG9uZW50cy9pY29ucy9YTWFyay5zdmVsdGUnO1xuXHRpbXBvcnQgQWR2YW5jZWRQYXJhbXMgZnJvbSAnLi4vU2V0dGluZ3MvQWR2YW5jZWQvQWR2YW5jZWRQYXJhbXMuc3ZlbHRlJztcblx0aW1wb3J0IFZhbHZlcyBmcm9tICckbGliL2NvbXBvbmVudHMvY2hhdC9Db250cm9scy9WYWx2ZXMuc3ZlbHRlJztcblx0aW1wb3J0IEZpbGVJdGVtIGZyb20gJyRsaWIvY29tcG9uZW50cy9jb21tb24vRmlsZUl0ZW0uc3ZlbHRlJztcblx0aW1wb3J0IENvbGxhcHNpYmxlIGZyb20gJyRsaWIvY29tcG9uZW50cy9jb21tb24vQ29sbGFwc2libGUuc3ZlbHRlJztcblxuXHRpbXBvcnQgeyB1c2VyLCBzZXR0aW5ncyB9IGZyb20gJyRsaWIvc3RvcmVzJztcblx0ZXhwb3J0IGxldCBtb2RlbHMgPSBbXTtcblx0ZXhwb3J0IGxldCBjaGF0RmlsZXMgPSBbXTtcblx0ZXhwb3J0IGxldCBwYXJhbXMgPSB7fTtcblx0ZXhwb3J0IGxldCBlbWJlZCA9IGZhbHNlO1xuXG5cdC8vIFBlcnNpc3QgY29sbGFwc2libGUgc2VjdGlvbiBvcGVuL2Nsb3NlIHN0YXRlXG5cdGNvbnN0IGdldE9wZW4gPSAoa2V5OiBzdHJpbmcsIGZhbGxiYWNrID0gdHJ1ZSk6IGJvb2xlYW4gPT4ge1xuXHRcdGNvbnN0IHYgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShgY2hhdENvbnRyb2xzLiR7a2V5fWApO1xuXHRcdHJldHVybiB2ICE9PSBudWxsID8gdiA9PT0gJ3RydWUnIDogZmFsbGJhY2s7XG5cdH07XG5cdGNvbnN0IHNldE9wZW4gPSAoa2V5OiBzdHJpbmcpID0+IChvcGVuOiBib29sZWFuKSA9PiB7XG5cdFx0bG9jYWxTdG9yYWdlLnNldEl0ZW0oYGNoYXRDb250cm9scy4ke2tleX1gLCBTdHJpbmcob3BlbikpO1xuXHR9O1xuXG5cdGxldCBzaG93RmlsZXMgPSBnZXRPcGVuKCdmaWxlcycpO1xuXHRsZXQgc2hvd1ZhbHZlcyA9IGdldE9wZW4oJ3ZhbHZlcycsIGZhbHNlKTtcblx0bGV0IHNob3dTeXN0ZW1Qcm9tcHQgPSBnZXRPcGVuKCdzeXN0ZW1Qcm9tcHQnKTtcblx0bGV0IHNob3dBZHZhbmNlZFBhcmFtcyA9IGdldE9wZW4oJ2FkdmFuY2VkUGFyYW1zJyk7XG5cblx0Y29uc3QgY29tcGFjdFNlY3Rpb25CdXR0b25DbGFzcyA9XG5cdFx0J3ctZnVsbCBweS0xIHRleHQteHMgZm9udC1ub3JtYWwgdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktOTAwIGRhcms6dGV4dC1ncmF5LTQwMCBkYXJrOmhvdmVyOnRleHQtZ3JheS0xMDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciBzZWxlY3Qtbm9uZSc7XG5cdGNvbnN0IHN5c3RlbVByb21wdFRleHRhcmVhQ2xhc3MgPVxuXHRcdCd3LWZ1bGwgcmVzaXplLXZlcnRpY2FsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMC81MCBiZy1ncmF5LTUwLzQwIHB4LTIgcHktMS41IHRleHQteHMgdGV4dC1ncmF5LTcwMCBvdXRsaW5lLWhpZGRlbiB0cmFuc2l0aW9uLWNvbG9ycyBwbGFjZWhvbGRlcjp0ZXh0LWdyYXktMzAwIGZvY3VzOmJvcmRlci1ibHVlLTQwMCBkYXJrOmJvcmRlci13aGl0ZS9bMC4wNF0gZGFyazpiZy13aGl0ZS9bMC4wM10gZGFyazp0ZXh0LWdyYXktMzAwIGRhcms6cGxhY2Vob2xkZXI6dGV4dC1ncmF5LTcwMCBkYXJrOmZvY3VzOmJvcmRlci1ibHVlLTUwMCc7XG5cdGNvbnN0IGNvbXBhY3RTeXN0ZW1Qcm9tcHRUZXh0YXJlYUNsYXNzID1cblx0XHQndy1mdWxsIHJlc2l6ZS12ZXJ0aWNhbCBhcHBlYXJhbmNlLW5vbmUgYmctdHJhbnNwYXJlbnQgcHktMSB0ZXh0LXhzIG91dGxpbmUtaGlkZGVuIGZvY3VzOmJnLXRyYW5zcGFyZW50IGRpc2FibGVkOmJnLXRyYW5zcGFyZW50Jztcbjwvc2NyaXB0PlxuXG48ZGl2IGNsYXNzPVwiIGRhcms6dGV4dC13aGl0ZVwiPlxuXHR7I2lmICFlbWJlZH1cblx0XHQ8ZGl2IGNsYXNzPVwiIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBkYXJrOnRleHQtZ3JheS0xMDAgbWItMlwiPlxuXHRcdFx0PGRpdiBjbGFzcz1cIiB0ZXh0LW1kIHNlbGYtY2VudGVyXCI+eyRpMThuLnQoJ0NvbnRyb2xzJyl9PC9kaXY+XG5cdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdGNsYXNzPVwic2VsZi1jZW50ZXJcIlxuXHRcdFx0XHRhcmlhLWxhYmVsPXskaTE4bi50KCdDbG9zZSBjaGF0IGNvbnRyb2xzJyl9XG5cdFx0XHRcdG9uOmNsaWNrPXsoKSA9PiB7XG5cdFx0XHRcdFx0ZGlzcGF0Y2goJ2Nsb3NlJyk7XG5cdFx0XHRcdH19XG5cdFx0XHQ+XG5cdFx0XHRcdDxYTWFyayBjbGFzc05hbWU9XCJzaXplLTMuNVwiIC8+XG5cdFx0XHQ8L2J1dHRvbj5cblx0XHQ8L2Rpdj5cblx0ey9pZn1cblxuXHR7I2lmICR1c2VyPy5yb2xlID09PSAnYWRtaW4nIHx8ICgkdXNlcj8ucGVybWlzc2lvbnMuY2hhdD8uY29udHJvbHMgPz8gdHJ1ZSl9XG5cdFx0PGRpdiBjbGFzcz1cInNwYWNlLXktMSBkYXJrOnRleHQtZ3JheS0yMDAgdGV4dC1zbSBweS0wLjUgcHgtMC41XCI+XG5cdFx0XHR7I2lmIGNoYXRGaWxlcy5sZW5ndGggPiAwfVxuXHRcdFx0XHQ8Q29sbGFwc2libGVcblx0XHRcdFx0XHR0aXRsZT17JGkxOG4udCgnRmlsZXMnKX1cblx0XHRcdFx0XHRiaW5kOm9wZW49e3Nob3dGaWxlc31cblx0XHRcdFx0XHRvbkNoYW5nZT17c2V0T3BlbignZmlsZXMnKX1cblx0XHRcdFx0XHRidXR0b25DbGFzc05hbWU9XCJ3LWZ1bGxcIlxuXHRcdFx0XHRcdGNoZXZyb25DbGFzc05hbWU9XCJzaXplLTIuNVwiXG5cdFx0XHRcdFx0Y2hldnJvblN0cm9rZVdpZHRoPVwiMlwiXG5cdFx0XHRcdD5cblx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBnYXAtMSBtdC0xLjVcIiBzbG90PVwiY29udGVudFwiPlxuXHRcdFx0XHRcdFx0eyNlYWNoIGNoYXRGaWxlcyBhcyBmaWxlLCBmaWxlSWR4fVxuXHRcdFx0XHRcdFx0XHQ8RmlsZUl0ZW1cblx0XHRcdFx0XHRcdFx0XHRjbGFzc05hbWU9XCJ3LWZ1bGxcIlxuXHRcdFx0XHRcdFx0XHRcdGl0ZW09e2ZpbGV9XG5cdFx0XHRcdFx0XHRcdFx0ZWRpdD17dHJ1ZX1cblx0XHRcdFx0XHRcdFx0XHR1cmw9e2ZpbGU/LnVybCA/IGZpbGUudXJsIDogbnVsbH1cblx0XHRcdFx0XHRcdFx0XHRuYW1lPXtmaWxlLm5hbWV9XG5cdFx0XHRcdFx0XHRcdFx0dHlwZT17ZmlsZS50eXBlfVxuXHRcdFx0XHRcdFx0XHRcdHNpemU9e2ZpbGU/LnNpemV9XG5cdFx0XHRcdFx0XHRcdFx0ZGlzbWlzc2libGU9e3RydWV9XG5cdFx0XHRcdFx0XHRcdFx0c21hbGw9e3RydWV9XG5cdFx0XHRcdFx0XHRcdFx0b246ZGlzbWlzcz17KCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0Ly8gUmVtb3ZlIHRoZSBmaWxlIGZyb20gdGhlIGNoYXRGaWxlcyBhcnJheVxuXG5cdFx0XHRcdFx0XHRcdFx0XHRjaGF0RmlsZXMuc3BsaWNlKGZpbGVJZHgsIDEpO1xuXHRcdFx0XHRcdFx0XHRcdFx0Y2hhdEZpbGVzID0gY2hhdEZpbGVzO1xuXHRcdFx0XHRcdFx0XHRcdH19XG5cdFx0XHRcdFx0XHRcdFx0b246Y2xpY2s9eygpID0+IHtcblx0XHRcdFx0XHRcdFx0XHRcdGNvbnNvbGUubG9nKGZpbGUpO1xuXHRcdFx0XHRcdFx0XHRcdH19XG5cdFx0XHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0XHR7L2VhY2h9XG5cdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdDwvQ29sbGFwc2libGU+XG5cdFx0XHR7L2lmfVxuXG5cdFx0XHR7I2lmICR1c2VyPy5yb2xlID09PSAnYWRtaW4nIHx8ICgkdXNlcj8ucGVybWlzc2lvbnMuY2hhdD8udmFsdmVzID8/IHRydWUpfVxuXHRcdFx0XHQ8Q29sbGFwc2libGVcblx0XHRcdFx0XHRiaW5kOm9wZW49e3Nob3dWYWx2ZXN9XG5cdFx0XHRcdFx0b25DaGFuZ2U9e3NldE9wZW4oJ3ZhbHZlcycpfVxuXHRcdFx0XHRcdHRpdGxlPXskaTE4bi50KCdWYWx2ZXMnKX1cblx0XHRcdFx0XHRidXR0b25DbGFzc05hbWU9e2NvbXBhY3RTZWN0aW9uQnV0dG9uQ2xhc3N9XG5cdFx0XHRcdFx0Y2hldnJvbkNsYXNzTmFtZT1cInNpemUtMi41XCJcblx0XHRcdFx0XHRjaGV2cm9uU3Ryb2tlV2lkdGg9XCIyXCJcblx0XHRcdFx0PlxuXHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJwdC0xIHBiLTEgdGV4dC14c1wiIHNsb3Q9XCJjb250ZW50XCI+XG5cdFx0XHRcdFx0XHQ8VmFsdmVzIHNob3c9e3Nob3dWYWx2ZXN9IC8+XG5cdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdDwvQ29sbGFwc2libGU+XG5cdFx0XHR7L2lmfVxuXG5cdFx0XHR7I2lmICR1c2VyPy5yb2xlID09PSAnYWRtaW4nIHx8ICgkdXNlcj8ucGVybWlzc2lvbnMuY2hhdD8uc3lzdGVtX3Byb21wdCA/PyB0cnVlKX1cblx0XHRcdFx0PENvbGxhcHNpYmxlXG5cdFx0XHRcdFx0dGl0bGU9eyRpMThuLnQoJ1N5c3RlbSBQcm9tcHQnKX1cblx0XHRcdFx0XHRiaW5kOm9wZW49e3Nob3dTeXN0ZW1Qcm9tcHR9XG5cdFx0XHRcdFx0b25DaGFuZ2U9e3NldE9wZW4oJ3N5c3RlbVByb21wdCcpfVxuXHRcdFx0XHRcdGJ1dHRvbkNsYXNzTmFtZT17Y29tcGFjdFNlY3Rpb25CdXR0b25DbGFzc31cblx0XHRcdFx0XHRjaGV2cm9uQ2xhc3NOYW1lPVwic2l6ZS0yLjVcIlxuXHRcdFx0XHRcdGNoZXZyb25TdHJva2VXaWR0aD1cIjJcIlxuXHRcdFx0XHQ+XG5cdFx0XHRcdFx0PGRpdiBjbGFzcz1cInB0LTEgcGItMVwiIHNsb3Q9XCJjb250ZW50XCI+XG5cdFx0XHRcdFx0XHQ8dGV4dGFyZWFcblx0XHRcdFx0XHRcdFx0YmluZDp2YWx1ZT17cGFyYW1zLnN5c3RlbX1cblx0XHRcdFx0XHRcdFx0Y2xhc3M9eygkc2V0dGluZ3M/LmhpZ2hDb250cmFzdE1vZGUgPz8gZmFsc2UpXG5cdFx0XHRcdFx0XHRcdFx0PyBzeXN0ZW1Qcm9tcHRUZXh0YXJlYUNsYXNzXG5cdFx0XHRcdFx0XHRcdFx0OiBjb21wYWN0U3lzdGVtUHJvbXB0VGV4dGFyZWFDbGFzc31cblx0XHRcdFx0XHRcdFx0cm93cz1cIjNcIlxuXHRcdFx0XHRcdFx0XHRwbGFjZWhvbGRlcj17JGkxOG4udCgnRW50ZXIgc3lzdGVtIHByb21wdCcpfVxuXHRcdFx0XHRcdFx0Lz5cblx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0PC9Db2xsYXBzaWJsZT5cblx0XHRcdHsvaWZ9XG5cblx0XHRcdHsjaWYgJHVzZXI/LnJvbGUgPT09ICdhZG1pbicgfHwgKCR1c2VyPy5wZXJtaXNzaW9ucy5jaGF0Py5wYXJhbXMgPz8gdHJ1ZSl9XG5cdFx0XHRcdDxDb2xsYXBzaWJsZVxuXHRcdFx0XHRcdHRpdGxlPXskaTE4bi50KCdBZHZhbmNlZCBQYXJhbXMnKX1cblx0XHRcdFx0XHRiaW5kOm9wZW49e3Nob3dBZHZhbmNlZFBhcmFtc31cblx0XHRcdFx0XHRvbkNoYW5nZT17c2V0T3BlbignYWR2YW5jZWRQYXJhbXMnKX1cblx0XHRcdFx0XHRidXR0b25DbGFzc05hbWU9e2NvbXBhY3RTZWN0aW9uQnV0dG9uQ2xhc3N9XG5cdFx0XHRcdFx0Y2hldnJvbkNsYXNzTmFtZT1cInNpemUtMi41XCJcblx0XHRcdFx0XHRjaGV2cm9uU3Ryb2tlV2lkdGg9XCIyXCJcblx0XHRcdFx0PlxuXHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJwdC0xIHBiLTEgdGV4dC14c1wiIHNsb3Q9XCJjb250ZW50XCI+XG5cdFx0XHRcdFx0XHQ8ZGl2PlxuXHRcdFx0XHRcdFx0XHQ8QWR2YW5jZWRQYXJhbXMgYWRtaW49eyR1c2VyPy5yb2xlID09PSAnYWRtaW4nfSBjdXN0b209e3RydWV9IGJpbmQ6cGFyYW1zIC8+XG5cdFx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0PC9Db2xsYXBzaWJsZT5cblx0XHRcdHsvaWZ9XG5cdFx0PC9kaXY+XG5cdHsvaWZ9XG48L2Rpdj5cbiJdLCJmaWxlIjoiL3NyYy9saWIvY29tcG9uZW50cy9jaGF0L0NvbnRyb2xzL0NvbnRyb2xzLnN2ZWx0ZSJ9
