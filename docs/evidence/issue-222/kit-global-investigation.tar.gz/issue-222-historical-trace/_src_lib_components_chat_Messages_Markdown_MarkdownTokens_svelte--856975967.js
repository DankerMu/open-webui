// /src/lib/components/chat/Messages/Markdown/MarkdownTokens.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_3__ = await __vite_ssr_import__("/node_modules/html-entities/dist/esm/index.js", {"importedNames":["decode"]});
const __vite_ssr_import_4__ = await __vite_ssr_import__("/node_modules/svelte/src/index-client.js", {"importedNames":["onMount","getContext"]});
const __vite_ssr_import_5__ = await __vite_ssr_import__("/node_modules/file-saver/dist/FileSaver.min.js", {"importedNames":["default"]});
const __vite_ssr_import_6__ = await __vite_ssr_import__("/node_modules/marked/lib/marked.esm.js", {"importedNames":["marked"]});
const __vite_ssr_import_7__ = await __vite_ssr_import__("/src/lib/utils/index.ts", {"importedNames":["copyToClipboard","unescapeHtml"]});
const __vite_ssr_import_8__ = await __vite_ssr_import__("/src/lib/apis/chats/index.ts", {"importedNames":["resolveChatMessageToolCall"]});
const __vite_ssr_import_9__ = await __vite_ssr_import__("/src/lib/constants.ts", {"importedNames":["WEBUI_BASE_URL"]});
const __vite_ssr_import_10__ = await __vite_ssr_import__("/src/lib/stores/index.ts", {"importedNames":["settings"]});
const __vite_ssr_import_11__ = await __vite_ssr_import__("/node_modules/svelte-sonner/dist/index.js", {"importedNames":["toast"]});
const __vite_ssr_import_12__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/CodeBlock.svelte", {"importedNames":["default"]});
const __vite_ssr_import_13__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens.svelte", {"importedNames":["default"]});
const __vite_ssr_import_14__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/KatexRenderer.svelte", {"importedNames":["default"]});
const __vite_ssr_import_15__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/AlertRenderer.svelte", {"importedNames":["default","alertComponent"]});
const __vite_ssr_import_16__ = await __vite_ssr_import__("/src/lib/components/common/Collapsible.svelte", {"importedNames":["default"]});
const __vite_ssr_import_17__ = await __vite_ssr_import__("/src/lib/components/common/ToolCallDisplay.svelte", {"importedNames":["default"]});
const __vite_ssr_import_18__ = await __vite_ssr_import__("/src/lib/components/common/Tooltip.svelte", {"importedNames":["default"]});
const __vite_ssr_import_19__ = await __vite_ssr_import__("/src/lib/components/icons/Download.svelte", {"importedNames":["default"]});
const __vite_ssr_import_20__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/ConsecutiveDetailsGroup.svelte", {"importedNames":["default"]});
const __vite_ssr_import_21__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/HTMLToken.svelte", {"importedNames":["default"]});
const __vite_ssr_import_22__ = await __vite_ssr_import__("/src/lib/components/icons/Clipboard.svelte", {"importedNames":["default"]});
const __vite_ssr_import_23__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/ColonFenceBlock.svelte", {"importedNames":["default"]});



MarkdownTokens[__vite_ssr_import_2__.FILENAME] = 'src/lib/components/chat/Messages/Markdown/MarkdownTokens.svelte';
























var root = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<hr class="border-gray-50 dark:border-gray-850/30"/>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[181, 2]]);
var root_1 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<th scope="col" class="px-2.5! py-2! cursor-pointer border-b border-gray-100! dark:border-gray-800!"><div class="gap-1.5 text-start"><div class="shrink-0 break-normal"><!></div></div></th>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[228, 8, [[233, 9, [[234, 10]]]]]]);
var root_2 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<td><div class="break-normal"><!></div></td>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[252, 9, [[260, 10]]]]);
var root_3 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<tr class="text-xs"></tr>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[250, 7]]);
var root_4 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button class="p-1 rounded-lg bg-transparent transition"><!></button>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[279, 5]]);
var root_5 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button class="p-1 rounded-lg bg-transparent transition"><!></button>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[291, 5]]);

var root_6 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="relative w-full group mb-2"><div class="scrollbar-hidden relative overflow-x-auto max-w-full"><table class=" w-full text-sm text-start text-gray-500 dark:text-gray-400 max-w-full rounded-xl" dir="auto"><thead class="text-xs text-gray-700 uppercase dark:text-gray-400 border-none"><tr></tr></thead><tbody></tbody></table></div> <div class=" absolute top-1 right-1.5 z-20 hover-reveal flex gap-0.5"><!> <!></div></div>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [
	[
		219,
		2,
		[
			[220, 3, [[221, 4, [[225, 5, [[226, 6]]], [248, 5]]]]],
			[277, 3]
		]
	]
]);

var root_7 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<blockquote dir="auto"><!></blockquote>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[308, 3]]);
var root_8 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<input class=" translate-y-[1px] -translate-x-1 flex-shrink-0" type="checkbox"/>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[332, 7]]);
var root_9 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<li class="text-start"><!> <!></li>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[330, 5]]);
var root_10 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<ol dir="auto"></ol>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[328, 3]]);
var root_11 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<input class="flex-shrink-0" type="checkbox"/> <div><!></div>`, 1), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[372, 7], [388, 7]]);
var root_12 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<li><!></li>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[370, 5]]);
var root_13 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<ul dir="auto"></ul>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[368, 3]]);
var root_14 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="mb-1.5" slot="content"><!></div>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[464, 7]]);
var root_15 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div slot="content"></div>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[437, 3]]);
var root_16 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class=" mb-1.5" slot="content"><!></div>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[523, 4]]);
var root_17 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<iframe width="100%" frameborder="0"></iframe>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[556, 2]]);
var root_18 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span dir="auto"><!></span>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[570, 3]]);
var root_19 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<p dir="auto"><!></p>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[580, 3]]);
var root_20 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<p><!></p>`), MarkdownTokens[__vite_ssr_import_2__.FILENAME], [[592, 3]]);

function MarkdownTokens($$anchor, $$props) {
	__vite_ssr_import_2__.check_target(new.target);
	__vite_ssr_import_2__.push($$props, false, MarkdownTokens);

	const $settings = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_10__.settings, 'settings'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_10__.settings, '$settings', $$stores)
	);

	const $i18n = () => (
		__vite_ssr_import_2__.validate_store(i18n, 'i18n'),
		__vite_ssr_import_2__.store_get(i18n, '$i18n', $$stores)
	);

	const [$$stores, $$cleanup] = __vite_ssr_import_2__.setup_stores();
	const detailButtonClassName = __vite_ssr_import_2__.mutable_source();
	const displayTokens = __vite_ssr_import_2__.mutable_source();
	const singlePlainBlock = __vite_ssr_import_2__.mutable_source();
	const i18n = __vite_ssr_import_4__.getContext('i18n');
	const { saveAs } = __vite_ssr_import_5__.default;
	let id = __vite_ssr_import_2__.prop($$props, 'id', 8);
	let chatId = __vite_ssr_import_2__.prop($$props, 'chatId', 8, '');
	let messageId = __vite_ssr_import_2__.prop($$props, 'messageId', 8, '');
	let tokens = __vite_ssr_import_2__.prop($$props, 'tokens', 8);
	let top = __vite_ssr_import_2__.prop($$props, 'top', 8, true);
	let attributes = __vite_ssr_import_2__.prop($$props, 'attributes', 24, () => ({}));
	let sourceIds = __vite_ssr_import_2__.prop($$props, 'sourceIds', 24, () => []);
	let done = __vite_ssr_import_2__.prop($$props, 'done', 8, true);
	let save = __vite_ssr_import_2__.prop($$props, 'save', 8, false);
	let preview = __vite_ssr_import_2__.prop($$props, 'preview', 8, false);
	let compactPreview = __vite_ssr_import_2__.prop($$props, 'compactPreview', 8, false);
	let paragraphTag = __vite_ssr_import_2__.prop($$props, 'paragraphTag', 8, 'p');
	let editCodeBlock = __vite_ssr_import_2__.prop($$props, 'editCodeBlock', 8, true);
	let topPadding = __vite_ssr_import_2__.prop($$props, 'topPadding', 8, false);
	let allowEmbeds = __vite_ssr_import_2__.prop($$props, 'allowEmbeds', 8, true);
	let onSave = __vite_ssr_import_2__.prop($$props, 'onSave', 8, () => {});
	let onUpdate = __vite_ssr_import_2__.prop($$props, 'onUpdate', 8, () => {});
	let onPreview = __vite_ssr_import_2__.prop($$props, 'onPreview', 8, () => {});
	let onTaskClick = __vite_ssr_import_2__.prop($$props, 'onTaskClick', 8, () => {});
	let onSourceClick = __vite_ssr_import_2__.prop($$props, 'onSourceClick', 8, () => {});
	let onToolCallResolved = __vite_ssr_import_2__.prop($$props, 'onToolCallResolved', 8, () => {});

	const headerComponent = (depth) => {
		return 'h' + depth;
	};

	const GROUPABLE_DETAIL_TYPES = new Set(['tool_calls', 'reasoning', 'code_interpreter']);

	const isGroupableDetailToken = (token) => {
		return __vite_ssr_import_2__.strict_equals(token?.type, 'details') && GROUPABLE_DETAIL_TYPES.has(token?.attributes?.type ?? '');
	};

	const getDisplayTokens = (tokenList = []) => {
		const displayTokens = [];
		let detailGroup = [];

		const flushDetailGroup = () => {
			if (detailGroup.length > 1) {
				displayTokens.push({ type: 'detail_group', items: [...detailGroup] });
			} else if (__vite_ssr_import_2__.strict_equals(detailGroup.length, 1)) {
				displayTokens.push(detailGroup[0]);
			}

			detailGroup = [];
		};

		for (const token of tokenList) {
			if (isGroupableDetailToken(token)) {
				detailGroup.push(token);
			} else {
				flushDetailGroup();
				displayTokens.push(token);
			}
		}

		flushDetailGroup();

		return displayTokens;
	};

	const getDetailTextContent = (token) => {
		return __vite_ssr_import_3__.decode(token?.text || '').replace(/<summary>.*?<\/summary>/gi, '').trim();
	};

	let resolvingCallId = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'resolvingCallId');

	const resolveToolCall = async (callId, approved) => {
		if (!chatId() || !messageId() || !callId || __vite_ssr_import_2__.get(resolvingCallId)) {
			return;
		}

		__vite_ssr_import_2__.set(resolvingCallId, callId);

		try {
			const res = (await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_8__.resolveChatMessageToolCall(localStorage.token, chatId(), messageId(), callId, approved ? 'approve' : 'reject')))();

			onToolCallResolved()(res);
		} catch(err) {
			__vite_ssr_import_11__.toast.error(String(err));
		} finally {
			__vite_ssr_import_2__.set(resolvingCallId, '');
		}
	};

	const exportTableToCSVHandler = (token, tokenIdx = 0) => {
		console.log('Exporting table to CSV');

		// Extract header row text, decode HTML entities, and escape for CSV.
		const header = token.header.map((headerCell) => `"${__vite_ssr_import_3__.decode(headerCell.text).replace(/"/g, '""')}"`);

		// Create an array for rows that will hold the mapped cell text.
		const rows = token.rows.map((row) => row.map((cell) => {
			// Map tokens into a single text
			const cellContent = cell.tokens.map((token) => token.text).join('');

			// Decode HTML entities and escape double quotes, wrap in double quotes
			return `"${__vite_ssr_import_3__.decode(cellContent).replace(/"/g, '""')}"`;
		}));

		// Combine header and rows
		const csvData = [header, ...rows];

		// Join the rows using commas (,) as the separator and rows using newline (\n).
		const csvContent = csvData.map((row) => row.join(',')).join('\n');

		// Log rows and CSV content to ensure everything is correct.
		console.log(...__vite_ssr_import_2__.log_if_contains_state('log', csvData));

		console.log(...__vite_ssr_import_2__.log_if_contains_state('log', csvContent));

		// To handle Unicode characters, you need to prefix the data with a BOM:
		const bom = '\uFEFF'; // BOM for UTF-8

		// Create a new Blob prefixed with the BOM to ensure proper Unicode encoding.
		const blob = new Blob([bom + csvContent], { type: 'text/csv;charset=UTF-8' });

		// Use FileSaver.js's saveAs function to save the generated CSV file.
		saveAs(blob, `table-${id()}-${tokenIdx}.csv`);
	};

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(compactPreview())), () => {
		__vite_ssr_import_2__.set(detailButtonClassName, `py-0.5 ${compactPreview() ? 'text-xs' : 'text-[0.9375rem]'} text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition`);
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(tokens())), () => {
		__vite_ssr_import_2__.set(displayTokens, getDisplayTokens(tokens()));
	});

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.get(displayTokens)), () => {
		__vite_ssr_import_2__.set(singlePlainBlock, __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(displayTokens).length, 1) && (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(displayTokens)[0]?.type, 'paragraph') || __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(displayTokens)[0]?.type, 'text')));
	});

	__vite_ssr_import_2__.legacy_pre_effect_reset();

	var $$exports = { ...__vite_ssr_import_2__.legacy_api() };

	__vite_ssr_import_2__.init();

	var fragment = __vite_ssr_import_2__.comment();
	var node = __vite_ssr_import_2__.first_child(fragment);

	__vite_ssr_import_2__.add_svelte_meta(
		() => __vite_ssr_import_2__.each(node, 1, () => __vite_ssr_import_2__.get(displayTokens), __vite_ssr_import_2__.index, ($$anchor, token, tokenIdx) => {
			var fragment_1 = __vite_ssr_import_2__.comment();
			var node_1 = __vite_ssr_import_2__.first_child(fragment_1);

			{
				var consequent = ($$anchor) => {
					var hr = root();

					__vite_ssr_import_2__.append($$anchor, hr);
				};

				var consequent_1 = ($$anchor) => {
					var fragment_2 = __vite_ssr_import_2__.comment();
					var node_2 = __vite_ssr_import_2__.first_child(fragment_2);

					{
						__vite_ssr_import_2__.validate_dynamic_element_tag(() => headerComponent(__vite_ssr_import_2__.get(token).depth));
						__vite_ssr_import_2__.validate_void_dynamic_element(() => headerComponent(__vite_ssr_import_2__.get(token).depth));

						__vite_ssr_import_2__.element(
							node_2,
							() => headerComponent(__vite_ssr_import_2__.get(token).depth),
							false,
							($$element, $$anchor) => {
								__vite_ssr_import_2__.attribute_effect($$element, () => ({ dir: 'auto' }));

								{
									let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-h`);

									__vite_ssr_import_2__.add_svelte_meta(
										() => __vite_ssr_import_13__.default($$anchor, {
											get id() {
												return __vite_ssr_import_2__.get($0);
											},

											get tokens() {
												return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens));
											},

											get done() {
												return done();
											},

											get sourceIds() {
												return sourceIds();
											},

											get onSourceClick() {
												return onSourceClick();
											}
										}),
										'component',
										MarkdownTokens,
										184,
										3,
										{ componentTag: 'MarkdownInlineTokens' }
									);
								}
							},
							void 0,
							[183, 2]
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_2);
				};

				var consequent_3 = ($$anchor) => {
					var fragment_4 = __vite_ssr_import_2__.comment();
					var node_3 = __vite_ssr_import_2__.first_child(fragment_4);

					{
						var consequent_2 = ($$anchor) => {
							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}`);

								let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (
									$settings(),
									__vite_ssr_import_2__.untrack(() => $settings()?.collapseCodeBlocks ?? false)
								));

								let $2 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token)?.lang ?? '')));
								let $3 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token)?.text ?? '')));
								let $4 = __vite_ssr_import_2__.derived_safe_equal(() => topPadding() ? 'top-10' : 'top-0');

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_12__.default($$anchor, {
										get id() {
											return __vite_ssr_import_2__.get($0);
										},

										get collapsed() {
											return __vite_ssr_import_2__.get($1);
										},

										get token() {
											return __vite_ssr_import_2__.get(token);
										},

										get lang() {
											return __vite_ssr_import_2__.get($2);
										},

										get code() {
											return __vite_ssr_import_2__.get($3);
										},

										get attributes() {
											return attributes();
										},

										get save() {
											return save();
										},

										get preview() {
											return preview();
										},

										get edit() {
											return editCodeBlock();
										},

										get stickyButtonsClassName() {
											return __vite_ssr_import_2__.get($4);
										},

										onSave: (value) => {
											onSave()({
												raw: __vite_ssr_import_2__.get(token).raw,
												oldContent: __vite_ssr_import_2__.get(token).text,
												newContent: value
											});
										},

										get onUpdate() {
											return onUpdate();
										},

										get onPreview() {
											return onPreview();
										}
									}),
									'component',
									MarkdownTokens,
									194,
									3,
									{ componentTag: 'CodeBlock' }
								);
							}
						};

						var d = __vite_ssr_import_2__.derived(() => (
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).raw.includes('```'))
						));

						var alternate = ($$anchor) => {
							var text = __vite_ssr_import_2__.text();

							__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text, (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).text))));
							__vite_ssr_import_2__.append($$anchor, text);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_3, ($$render) => {
								if (__vite_ssr_import_2__.get(d)) $$render(consequent_2); else $$render(alternate, -1);
							}),
							'if',
							MarkdownTokens,
							193,
							2
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_4);
				};

				var consequent_4 = ($$anchor) => {
					var div = root_6();
					var div_1 = __vite_ssr_import_2__.child(div);
					var table = __vite_ssr_import_2__.child(div_1);
					var thead = __vite_ssr_import_2__.child(table);
					var tr = __vite_ssr_import_2__.child(thead);

					__vite_ssr_import_2__.add_svelte_meta(
						() => __vite_ssr_import_2__.each(tr, 5, () => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).header)), __vite_ssr_import_2__.index, ($$anchor, header, headerIdx) => {
							var th = root_1();
							var div_2 = __vite_ssr_import_2__.child(th);
							var div_3 = __vite_ssr_import_2__.child(div_2);
							var node_4 = __vite_ssr_import_2__.child(div_3);

							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-header-${headerIdx}`);

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_13__.default(node_4, {
										get id() {
											return __vite_ssr_import_2__.get($0);
										},

										get tokens() {
											return (__vite_ssr_import_2__.get(header), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(header).tokens));
										},

										get done() {
											return done();
										},

										get sourceIds() {
											return sourceIds();
										},

										get onSourceClick() {
											return onSourceClick();
										}
									}),
									'component',
									MarkdownTokens,
									235,
									11,
									{ componentTag: 'MarkdownInlineTokens' }
								);
							}

							__vite_ssr_import_2__.reset(div_3);
							__vite_ssr_import_2__.reset(div_2);
							__vite_ssr_import_2__.reset(th);

							__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_style(th, (
								__vite_ssr_import_2__.get(token),
								headerIdx,
								__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).align[headerIdx] ? `text-align: ${__vite_ssr_import_2__.get(token).align[headerIdx]}` : '')
							)));

							__vite_ssr_import_2__.append($$anchor, th);
						}),
						'each',
						MarkdownTokens,
						227,
						7
					);

					__vite_ssr_import_2__.reset(tr);
					__vite_ssr_import_2__.reset(thead);

					var tbody = __vite_ssr_import_2__.sibling(thead);

					__vite_ssr_import_2__.add_svelte_meta(
						() => __vite_ssr_import_2__.each(tbody, 5, () => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).rows)), __vite_ssr_import_2__.index, ($$anchor, row, rowIdx) => {
							var tr_1 = root_3();

							__vite_ssr_import_2__.add_svelte_meta(
								() => __vite_ssr_import_2__.each(tr_1, 5, () => __vite_ssr_import_2__.get(row) ?? [], __vite_ssr_import_2__.index, ($$anchor, cell, cellIdx) => {
									var td = root_2();
									var div_4 = __vite_ssr_import_2__.child(td);
									var node_5 = __vite_ssr_import_2__.child(div_4);

									{
										let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-row-${rowIdx}-${cellIdx}`);

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_13__.default(node_5, {
												get id() {
													return __vite_ssr_import_2__.get($0);
												},

												get tokens() {
													return (__vite_ssr_import_2__.get(cell), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(cell).tokens));
												},

												get done() {
													return done();
												},

												get sourceIds() {
													return sourceIds();
												},

												get onSourceClick() {
													return onSourceClick();
												}
											}),
											'component',
											MarkdownTokens,
											261,
											11,
											{ componentTag: 'MarkdownInlineTokens' }
										);
									}

									__vite_ssr_import_2__.reset(div_4);
									__vite_ssr_import_2__.reset(td);

									__vite_ssr_import_2__.template_effect(() => {
										__vite_ssr_import_2__.set_class(td, 1, `px-3! py-2! text-gray-900 dark:text-white w-max ${(
											__vite_ssr_import_2__.get(token),
											rowIdx,
											__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).rows.length - 1, rowIdx) ? '' : 'border-b border-gray-50! dark:border-gray-850!')
										) ?? ''}`);

										__vite_ssr_import_2__.set_style(td, (
											__vite_ssr_import_2__.get(token),
											cellIdx,
											__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).align[cellIdx] ? `text-align: ${__vite_ssr_import_2__.get(token).align[cellIdx]}` : '')
										));
									});

									__vite_ssr_import_2__.append($$anchor, td);
								}),
								'each',
								MarkdownTokens,
								251,
								8
							);

							__vite_ssr_import_2__.reset(tr_1);
							__vite_ssr_import_2__.append($$anchor, tr_1);
						}),
						'each',
						MarkdownTokens,
						249,
						6
					);

					__vite_ssr_import_2__.reset(tbody);
					__vite_ssr_import_2__.reset(table);
					__vite_ssr_import_2__.reset(div_1);

					var div_5 = __vite_ssr_import_2__.sibling(div_1, 2);
					var node_6 = __vite_ssr_import_2__.child(div_5);

					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Copy'))));

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_18__.default(node_6, {
								get content() {
									return __vite_ssr_import_2__.get($0);
								},

								children: __vite_ssr_import_2__.wrap_snippet(MarkdownTokens, ($$anchor, $$slotProps) => {
									var button = root_4();
									var node_7 = __vite_ssr_import_2__.child(button);

									__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_22__.default(node_7, { className: ' size-3.5', strokeWidth: '1.5' }), 'component', MarkdownTokens, 286, 6, { componentTag: 'Clipboard' });
									__vite_ssr_import_2__.reset(button);

									__vite_ssr_import_2__.event('click', button, function click(e) {
										e.stopPropagation();
										__vite_ssr_import_7__.copyToClipboard(__vite_ssr_import_2__.get(token).raw.trim(), null, $settings()?.copyFormatted ?? false);
									});

									__vite_ssr_import_2__.append($$anchor, button);
								}),
								$$slots: { default: true }
							}),
							'component',
							MarkdownTokens,
							278,
							4,
							{ componentTag: 'Tooltip' }
						);
					}

					var node_8 = __vite_ssr_import_2__.sibling(node_6, 2);

					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Export to CSV'))));

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_18__.default(node_8, {
								get content() {
									return __vite_ssr_import_2__.get($0);
								},

								children: __vite_ssr_import_2__.wrap_snippet(MarkdownTokens, ($$anchor, $$slotProps) => {
									var button_1 = root_5();
									var node_9 = __vite_ssr_import_2__.child(button_1);

									__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_19__.default(node_9, { className: ' size-3.5', strokeWidth: '1.5' }), 'component', MarkdownTokens, 298, 6, { componentTag: 'Download' });
									__vite_ssr_import_2__.reset(button_1);

									__vite_ssr_import_2__.event('click', button_1, function click_1(e) {
										e.stopPropagation();
										exportTableToCSVHandler(__vite_ssr_import_2__.get(token), tokenIdx);
									});

									__vite_ssr_import_2__.append($$anchor, button_1);
								}),
								$$slots: { default: true }
							}),
							'component',
							MarkdownTokens,
							290,
							4,
							{ componentTag: 'Tooltip' }
						);
					}

					__vite_ssr_import_2__.reset(div_5);
					__vite_ssr_import_2__.reset(div);
					__vite_ssr_import_2__.template_effect(() => table.dir = table.dir);
					__vite_ssr_import_2__.append($$anchor, div);
				};

				var consequent_6 = ($$anchor) => {
					const alert = __vite_ssr_import_2__.tag(
						__vite_ssr_import_2__.derived_safe_equal(() => (
							__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_15__.alertComponent),
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_15__.alertComponent(__vite_ssr_import_2__.get(token)))
						)),
						'alert'
					);

					__vite_ssr_import_2__.get(alert);

					var fragment_7 = __vite_ssr_import_2__.comment();
					var node_10 = __vite_ssr_import_2__.first_child(fragment_7);

					{
						var consequent_5 = ($$anchor) => {
							__vite_ssr_import_2__.add_svelte_meta(
								() => __vite_ssr_import_15__.default($$anchor, {
									get token() {
										return __vite_ssr_import_2__.get(token);
									},

									get alert() {
										return __vite_ssr_import_2__.get(alert);
									}
								}),
								'component',
								MarkdownTokens,
								306,
								3,
								{ componentTag: 'AlertRenderer' }
							);
						};

						var alternate_1 = ($$anchor) => {
							var blockquote = root_7();
							var node_11 = __vite_ssr_import_2__.child(blockquote);

							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}`);

								__vite_ssr_import_2__.add_svelte_meta(
									() => MarkdownTokens(node_11, {
										get id() {
											return __vite_ssr_import_2__.get($0);
										},

										get chatId() {
											return chatId();
										},

										get messageId() {
											return messageId();
										},

										get tokens() {
											return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens));
										},

										get done() {
											return done();
										},

										get save() {
											return save();
										},

										get preview() {
											return preview();
										},

										get compactPreview() {
											return compactPreview();
										},

										get editCodeBlock() {
											return editCodeBlock();
										},

										get onTaskClick() {
											return onTaskClick();
										},

										get sourceIds() {
											return sourceIds();
										},

										get onSourceClick() {
											return onSourceClick();
										},

										get onToolCallResolved() {
											return onToolCallResolved();
										}
									}),
									'component',
									MarkdownTokens,
									309,
									4,
									{ componentTag: 'svelte:self' }
								);
							}

							__vite_ssr_import_2__.reset(blockquote);
							__vite_ssr_import_2__.template_effect(() => blockquote.dir = blockquote.dir);
							__vite_ssr_import_2__.append($$anchor, blockquote);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_10, ($$render) => {
								if (__vite_ssr_import_2__.get(alert)) $$render(consequent_5); else $$render(alternate_1, -1);
							}),
							'if',
							MarkdownTokens,
							305,
							2
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_7);
				};

				var consequent_10 = ($$anchor) => {
					var fragment_9 = __vite_ssr_import_2__.comment();
					var node_12 = __vite_ssr_import_2__.first_child(fragment_9);

					{
						var consequent_8 = ($$anchor) => {
							var ol = root_10();

							__vite_ssr_import_2__.add_svelte_meta(
								() => __vite_ssr_import_2__.each(ol, 5, () => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).items)), __vite_ssr_import_2__.index, ($$anchor, item, itemIdx) => {
									var li = root_9();
									var node_13 = __vite_ssr_import_2__.child(li);

									{
										var consequent_7 = ($$anchor) => {
											var input = root_8();

											__vite_ssr_import_2__.remove_input_defaults(input);
											__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_checked(input, (__vite_ssr_import_2__.get(item), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(item).checked))));

											__vite_ssr_import_2__.event('change', input, function change(e) {
												onTaskClick()({
													id: id(),
													token: __vite_ssr_import_2__.get(token),
													tokenIdx,
													item: __vite_ssr_import_2__.get(item),
													itemIdx,
													checked: e.target.checked
												});
											});

											__vite_ssr_import_2__.append($$anchor, input);
										};

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_2__.if(node_13, ($$render) => {
												if ((__vite_ssr_import_2__.get(item), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(item)?.task))) $$render(consequent_7);
											}),
											'if',
											MarkdownTokens,
											331,
											6
										);
									}

									var node_14 = __vite_ssr_import_2__.sibling(node_13, 2);

									{
										let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-${itemIdx}`);

										__vite_ssr_import_2__.add_svelte_meta(
											() => MarkdownTokens(node_14, {
												get id() {
													return __vite_ssr_import_2__.get($0);
												},

												get chatId() {
													return chatId();
												},

												get messageId() {
													return messageId();
												},

												get tokens() {
													return (__vite_ssr_import_2__.get(item), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(item).tokens));
												},

												get top() {
													return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).loose));
												},

												get done() {
													return done();
												},

												get save() {
													return save();
												},

												get preview() {
													return preview();
												},

												get compactPreview() {
													return compactPreview();
												},

												get editCodeBlock() {
													return editCodeBlock();
												},

												get onTaskClick() {
													return onTaskClick();
												},

												get sourceIds() {
													return sourceIds();
												},

												get onSourceClick() {
													return onSourceClick();
												}
											}),
											'component',
											MarkdownTokens,
											349,
											6,
											{ componentTag: 'svelte:self' }
										);
									}

									__vite_ssr_import_2__.reset(li);
									__vite_ssr_import_2__.append($$anchor, li);
								}),
								'each',
								MarkdownTokens,
								329,
								4
							);

							__vite_ssr_import_2__.reset(ol);

							__vite_ssr_import_2__.template_effect(() => {
								__vite_ssr_import_2__.set_attribute(ol, 'start', (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).start || 1)));
								ol.dir = ol.dir;
							});

							__vite_ssr_import_2__.append($$anchor, ol);
						};

						var alternate_3 = ($$anchor) => {
							var ul = root_13();

							__vite_ssr_import_2__.add_svelte_meta(
								() => __vite_ssr_import_2__.each(ul, 5, () => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).items)), __vite_ssr_import_2__.index, ($$anchor, item, itemIdx) => {
									var li_1 = root_12();
									var node_15 = __vite_ssr_import_2__.child(li_1);

									{
										var consequent_9 = ($$anchor) => {
											var fragment_10 = root_11();
											var input_1 = __vite_ssr_import_2__.first_child(fragment_10);

											__vite_ssr_import_2__.remove_input_defaults(input_1);

											var div_6 = __vite_ssr_import_2__.sibling(input_1, 2);
											var node_16 = __vite_ssr_import_2__.child(div_6);

											{
												let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-${itemIdx}`);

												__vite_ssr_import_2__.add_svelte_meta(
													() => MarkdownTokens(node_16, {
														get id() {
															return __vite_ssr_import_2__.get($0);
														},

														get chatId() {
															return chatId();
														},

														get messageId() {
															return messageId();
														},

														get tokens() {
															return (__vite_ssr_import_2__.get(item), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(item).tokens));
														},

														get top() {
															return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).loose));
														},

														get done() {
															return done();
														},

														get save() {
															return save();
														},

														get preview() {
															return preview();
														},

														get compactPreview() {
															return compactPreview();
														},

														get editCodeBlock() {
															return editCodeBlock();
														},

														get onTaskClick() {
															return onTaskClick();
														},

														get sourceIds() {
															return sourceIds();
														},

														get onSourceClick() {
															return onSourceClick();
														}
													}),
													'component',
													MarkdownTokens,
													389,
													8,
													{ componentTag: 'svelte:self' }
												);
											}

											__vite_ssr_import_2__.reset(div_6);
											__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_checked(input_1, (__vite_ssr_import_2__.get(item), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(item).checked))));

											__vite_ssr_import_2__.event('change', input_1, function change_1(e) {
												onTaskClick()({
													id: id(),
													token: __vite_ssr_import_2__.get(token),
													tokenIdx,
													item: __vite_ssr_import_2__.get(item),
													itemIdx,
													checked: e.target.checked
												});
											});

											__vite_ssr_import_2__.append($$anchor, fragment_10);
										};

										var alternate_2 = ($$anchor) => {
											var fragment_11 = __vite_ssr_import_2__.comment();
											var node_17 = __vite_ssr_import_2__.first_child(fragment_11);

											{
												let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-${itemIdx}`);

												__vite_ssr_import_2__.add_svelte_meta(
													() => MarkdownTokens(node_17, {
														get id() {
															return __vite_ssr_import_2__.get($0);
														},

														get chatId() {
															return chatId();
														},

														get messageId() {
															return messageId();
														},

														get tokens() {
															return (__vite_ssr_import_2__.get(item), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(item).tokens));
														},

														get top() {
															return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).loose));
														},

														get done() {
															return done();
														},

														get save() {
															return save();
														},

														get preview() {
															return preview();
														},

														get compactPreview() {
															return compactPreview();
														},

														get editCodeBlock() {
															return editCodeBlock();
														},

														get onTaskClick() {
															return onTaskClick();
														},

														get sourceIds() {
															return sourceIds();
														},

														get onSourceClick() {
															return onSourceClick();
														}
													}),
													'component',
													MarkdownTokens,
													406,
													7,
													{ componentTag: 'svelte:self' }
												);
											}

											__vite_ssr_import_2__.append($$anchor, fragment_11);
										};

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_2__.if(node_15, ($$render) => {
												if ((__vite_ssr_import_2__.get(item), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(item)?.task))) $$render(consequent_9); else $$render(alternate_2, -1);
											}),
											'if',
											MarkdownTokens,
											371,
											6
										);
									}

									__vite_ssr_import_2__.reset(li_1);

									__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_class(li_1, 1, `text-start ${(
										__vite_ssr_import_2__.get(item),
										__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(item)?.task ? 'flex -translate-x-6.5 gap-3 ' : '')
									) ?? ''}`));

									__vite_ssr_import_2__.append($$anchor, li_1);
								}),
								'each',
								MarkdownTokens,
								369,
								4
							);

							__vite_ssr_import_2__.reset(ul);
							__vite_ssr_import_2__.template_effect(() => ul.dir = ul.dir);
							__vite_ssr_import_2__.append($$anchor, ul);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_12, ($$render) => {
								if ((__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).ordered))) $$render(consequent_8); else $$render(alternate_3, -1);
							}),
							'if',
							MarkdownTokens,
							327,
							2
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_9);
				};

				var consequent_13 = ($$anchor) => {
					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-detail-group`);
						let $1 = __vite_ssr_import_2__.derived_safe_equal(() => !!chatId() && !!messageId() && save());

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_20__.default($$anchor, {
								get id() {
									return __vite_ssr_import_2__.get($0);
								},

								get tokens() {
									return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).items));
								},

								get messageDone() {
									return done();
								},

								get compactPreview() {
									return compactPreview();
								},

								get allowEmbeds() {
									return allowEmbeds();
								},

								get resolvable() {
									return __vite_ssr_import_2__.get($1);
								},

								get resolvingCallId() {
									return __vite_ssr_import_2__.get(resolvingCallId);
								},
								onResolve: resolveToolCall,
								$$slots: {
									content: ($$anchor, $$slotProps) => {
										var div_7 = root_15();

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_2__.each(div_7, 5, () => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).items)), __vite_ssr_import_2__.index, ($$anchor, detailToken, detailIdx) => {
												const textContent = __vite_ssr_import_2__.tag(
													__vite_ssr_import_2__.derived_safe_equal(() => (
														__vite_ssr_import_2__.get(detailToken),
														__vite_ssr_import_2__.untrack(() => getDetailTextContent(__vite_ssr_import_2__.get(detailToken)))
													)),
													'textContent'
												);

												__vite_ssr_import_2__.get(textContent);

												var fragment_13 = __vite_ssr_import_2__.comment();
												var node_18 = __vite_ssr_import_2__.first_child(fragment_13);

												{
													var consequent_11 = ($$anchor) => {
														{
															let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-${detailIdx}-tc`);

															let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (
																__vite_ssr_import_2__.get(detailToken),
																__vite_ssr_import_2__.untrack(() => getDetailTextContent(__vite_ssr_import_2__.get(detailToken)))
															));

															let $2 = __vite_ssr_import_2__.derived_safe_equal(() => !!chatId() && !!messageId() && save());

															let $3 = __vite_ssr_import_2__.derived_safe_equal(() => (
																__vite_ssr_import_2__.get(resolvingCallId),
																__vite_ssr_import_2__.get(detailToken),
																__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(resolvingCallId), __vite_ssr_import_2__.get(detailToken).attributes?.id))
															));

															let $4 = __vite_ssr_import_2__.derived_safe_equal(() => (
																$settings(),
																__vite_ssr_import_2__.untrack(() => $settings()?.expandDetails ?? false)
															));

															__vite_ssr_import_2__.add_svelte_meta(
																() => __vite_ssr_import_17__.default($$anchor, {
																	get id() {
																		return __vite_ssr_import_2__.get($0);
																	},

																	get attributes() {
																		return (
																			__vite_ssr_import_2__.get(detailToken),
																			__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(detailToken).attributes)
																		);
																	},

																	get resultContent() {
																		return __vite_ssr_import_2__.get($1);
																	},
																	grouped: true,
																	get resolvable() {
																		return __vite_ssr_import_2__.get($2);
																	},

																	get resolving() {
																		return __vite_ssr_import_2__.get($3);
																	},
																	onResolve: (approved) => resolveToolCall(__vite_ssr_import_2__.get(detailToken).attributes?.id ?? '', approved),
																	get open() {
																		return __vite_ssr_import_2__.get($4);
																	},
																	className: 'w-full',
																	get buttonClassName() {
																		return __vite_ssr_import_2__.get(detailButtonClassName);
																	}
																}),
																'component',
																MarkdownTokens,
																442,
																6,
																{ componentTag: 'ToolCallDisplay' }
															);
														}
													};

													var consequent_12 = ($$anchor) => {
														{
															let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
																$settings(),
																__vite_ssr_import_2__.untrack(() => $settings()?.expandDetails ?? false)
															));

															let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (
																__vite_ssr_import_2__.get(detailToken),
																__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(detailToken)?.attributes)
															));

															__vite_ssr_import_2__.add_svelte_meta(
																() => __vite_ssr_import_16__.default($$anchor, {
																	get title() {
																		return (
																			__vite_ssr_import_2__.get(detailToken),
																			__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(detailToken).summary)
																		);
																	},

																	get open() {
																		return __vite_ssr_import_2__.get($0);
																	},

																	get attributes() {
																		return __vite_ssr_import_2__.get($1);
																	},

																	get messageDone() {
																		return done();
																	},
																	className: 'w-full',
																	get buttonClassName() {
																		return __vite_ssr_import_2__.get(detailButtonClassName);
																	},
																	dir: 'auto',
																	$$slots: {
																		content: ($$anchor, $$slotProps) => {
																			var div_8 = root_14();
																			var node_19 = __vite_ssr_import_2__.child(div_8);

																			{
																				let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-${detailIdx}-d`);

																				let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (
																					__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_6__.marked),
																					__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_3__.decode),
																					__vite_ssr_import_2__.get(detailToken),
																					__vite_ssr_import_2__.untrack(() => __vite_ssr_import_6__.marked.lexer(__vite_ssr_import_3__.decode(__vite_ssr_import_2__.get(detailToken).text)))
																				));

																				let $2 = __vite_ssr_import_2__.derived_safe_equal(() => (
																					__vite_ssr_import_2__.get(detailToken),
																					__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(detailToken)?.attributes)
																				));

																				__vite_ssr_import_2__.add_svelte_meta(
																					() => MarkdownTokens(node_19, {
																						get id() {
																							return __vite_ssr_import_2__.get($0);
																						},

																						get chatId() {
																							return chatId();
																						},

																						get messageId() {
																							return messageId();
																						},

																						get tokens() {
																							return __vite_ssr_import_2__.get($1);
																						},

																						get attributes() {
																							return __vite_ssr_import_2__.get($2);
																						},

																						get done() {
																							return done();
																						},

																						get save() {
																							return save();
																						},

																						get preview() {
																							return preview();
																						},

																						get compactPreview() {
																							return compactPreview();
																						},

																						get editCodeBlock() {
																							return editCodeBlock();
																						},

																						get onTaskClick() {
																							return onTaskClick();
																						},

																						get sourceIds() {
																							return sourceIds();
																						},

																						get onSourceClick() {
																							return onSourceClick();
																						}
																					}),
																					'component',
																					MarkdownTokens,
																					465,
																					8,
																					{ componentTag: 'svelte:self' }
																				);
																			}

																			__vite_ssr_import_2__.reset(div_8);
																			__vite_ssr_import_2__.append($$anchor, div_8);
																		}
																	}
																}),
																'component',
																MarkdownTokens,
																455,
																6,
																{ componentTag: 'Collapsible' }
															);
														}
													};

													var alternate_4 = ($$anchor) => {
														{
															let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
																__vite_ssr_import_2__.get(detailToken),
																__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(detailToken)?.attributes)
															));

															__vite_ssr_import_2__.add_svelte_meta(
																() => __vite_ssr_import_16__.default($$anchor, {
																	get title() {
																		return (
																			__vite_ssr_import_2__.get(detailToken),
																			__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(detailToken).summary)
																		);
																	},
																	open: false,
																	disabled: true,
																	get attributes() {
																		return __vite_ssr_import_2__.get($0);
																	},

																	get messageDone() {
																		return done();
																	},
																	className: 'w-full',
																	get buttonClassName() {
																		return __vite_ssr_import_2__.get(detailButtonClassName);
																	},
																	dir: 'auto'
																}),
																'component',
																MarkdownTokens,
																483,
																6,
																{ componentTag: 'Collapsible' }
															);
														}
													};

													__vite_ssr_import_2__.add_svelte_meta(
														() => __vite_ssr_import_2__.if(node_18, ($$render) => {
															if ((
																__vite_ssr_import_2__.get(detailToken),
																__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(detailToken)?.attributes?.type, 'tool_calls'))
															)) $$render(consequent_11); else if ((
																__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_2__.get(textContent)),
																__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(textContent).length > 0)
															)) $$render(consequent_12, 1); else $$render(alternate_4, -1);
														}),
														'if',
														MarkdownTokens,
														441,
														5
													);
												}

												__vite_ssr_import_2__.append($$anchor, fragment_13);
											}),
											'each',
											MarkdownTokens,
											438,
											4
										);

										__vite_ssr_import_2__.reset(div_7);
										__vite_ssr_import_2__.append($$anchor, div_7);
									}
								}
							}),
							'component',
							MarkdownTokens,
							427,
							2,
							{ componentTag: 'ConsecutiveDetailsGroup' }
						);
					}
				};

				var consequent_16 = ($$anchor) => {
					const textContent = __vite_ssr_import_2__.tag(
						__vite_ssr_import_2__.derived_safe_equal(() => (
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => getDetailTextContent(__vite_ssr_import_2__.get(token)))
						)),
						'textContent'
					);

					__vite_ssr_import_2__.get(textContent);

					var fragment_17 = __vite_ssr_import_2__.comment();
					var node_20 = __vite_ssr_import_2__.first_child(fragment_17);

					{
						var consequent_14 = ($$anchor) => {
							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-tc`);

								let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (
									__vite_ssr_import_2__.get(token),
									__vite_ssr_import_2__.untrack(() => getDetailTextContent(__vite_ssr_import_2__.get(token)))
								));

								let $2 = __vite_ssr_import_2__.derived_safe_equal(() => !!chatId() && !!messageId() && save());

								let $3 = __vite_ssr_import_2__.derived_safe_equal(() => (
									__vite_ssr_import_2__.get(resolvingCallId),
									__vite_ssr_import_2__.get(token),
									__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(resolvingCallId), __vite_ssr_import_2__.get(token).attributes?.id))
								));

								let $4 = __vite_ssr_import_2__.derived_safe_equal(() => (
									$settings(),
									__vite_ssr_import_2__.untrack(() => $settings()?.expandDetails ?? false)
								));

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_17__.default($$anchor, {
										get id() {
											return __vite_ssr_import_2__.get($0);
										},

										get attributes() {
											return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).attributes));
										},

										get resultContent() {
											return __vite_ssr_import_2__.get($1);
										},

										get resolvable() {
											return __vite_ssr_import_2__.get($2);
										},

										get resolving() {
											return __vite_ssr_import_2__.get($3);
										},
										onResolve: (approved) => resolveToolCall(__vite_ssr_import_2__.get(token).attributes?.id ?? '', approved),
										get open() {
											return __vite_ssr_import_2__.get($4);
										},
										className: 'w-full space-y-2',
										get buttonClassName() {
											return __vite_ssr_import_2__.get(detailButtonClassName);
										}
									}),
									'component',
									MarkdownTokens,
									502,
									3,
									{ componentTag: 'ToolCallDisplay' }
								);
							}
						};

						var consequent_15 = ($$anchor) => {
							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
									$settings(),
									__vite_ssr_import_2__.untrack(() => $settings()?.expandDetails ?? false)
								));

								let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token)?.attributes)));

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_16__.default($$anchor, {
										get title() {
											return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).summary));
										},

										get open() {
											return __vite_ssr_import_2__.get($0);
										},

										get attributes() {
											return __vite_ssr_import_2__.get($1);
										},

										get messageDone() {
											return done();
										},
										className: 'w-full space-y-2',
										get buttonClassName() {
											return __vite_ssr_import_2__.get(detailButtonClassName);
										},
										dir: 'auto',
										$$slots: {
											content: ($$anchor, $$slotProps) => {
												var div_9 = root_16();
												var node_21 = __vite_ssr_import_2__.child(div_9);

												{
													let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-d`);

													let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (
														__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_6__.marked),
														__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_3__.decode),
														__vite_ssr_import_2__.get(token),
														__vite_ssr_import_2__.untrack(() => __vite_ssr_import_6__.marked.lexer(__vite_ssr_import_3__.decode(__vite_ssr_import_2__.get(token).text)))
													));

													let $2 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token)?.attributes)));

													__vite_ssr_import_2__.add_svelte_meta(
														() => MarkdownTokens(node_21, {
															get id() {
																return __vite_ssr_import_2__.get($0);
															},

															get chatId() {
																return chatId();
															},

															get messageId() {
																return messageId();
															},

															get tokens() {
																return __vite_ssr_import_2__.get($1);
															},

															get attributes() {
																return __vite_ssr_import_2__.get($2);
															},

															get done() {
																return done();
															},

															get save() {
																return save();
															},

															get preview() {
																return preview();
															},

															get compactPreview() {
																return compactPreview();
															},

															get editCodeBlock() {
																return editCodeBlock();
															},

															get onTaskClick() {
																return onTaskClick();
															},

															get sourceIds() {
																return sourceIds();
															},

															get onSourceClick() {
																return onSourceClick();
															}
														}),
														'component',
														MarkdownTokens,
														524,
														5,
														{ componentTag: 'svelte:self' }
													);
												}

												__vite_ssr_import_2__.reset(div_9);
												__vite_ssr_import_2__.append($$anchor, div_9);
											}
										}
									}),
									'component',
									MarkdownTokens,
									514,
									3,
									{ componentTag: 'Collapsible' }
								);
							}
						};

						var alternate_5 = ($$anchor) => {
							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token)?.attributes)));

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_16__.default($$anchor, {
										get title() {
											return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).summary));
										},
										open: false,
										disabled: true,
										get attributes() {
											return __vite_ssr_import_2__.get($0);
										},

										get messageDone() {
											return done();
										},
										className: 'w-full space-y-2',
										get buttonClassName() {
											return __vite_ssr_import_2__.get(detailButtonClassName);
										},
										dir: 'auto'
									}),
									'component',
									MarkdownTokens,
									542,
									3,
									{ componentTag: 'Collapsible' }
								);
							}
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_20, ($$render) => {
								if ((
									__vite_ssr_import_2__.get(token),
									__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token)?.attributes?.type, 'tool_calls'))
								)) $$render(consequent_14); else if ((
									__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_2__.get(textContent)),
									__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(textContent).length > 0)
								)) $$render(consequent_15, 1); else $$render(alternate_5, -1);
							}),
							'if',
							MarkdownTokens,
							500,
							2
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_17);
				};

				var consequent_17 = ($$anchor) => {
					__vite_ssr_import_2__.add_svelte_meta(
						() => __vite_ssr_import_21__.default($$anchor, {
							get id() {
								return id();
							},

							get token() {
								return __vite_ssr_import_2__.get(token);
							},

							get onSourceClick() {
								return onSourceClick();
							}
						}),
						'component',
						MarkdownTokens,
						554,
						2,
						{ componentTag: 'HtmlToken' }
					);
				};

				var consequent_18 = ($$anchor) => {
					var iframe = root_17();

					__vite_ssr_import_2__.template_effect(() => {
						__vite_ssr_import_2__.set_attribute(iframe, 'src', `${__vite_ssr_import_9__.WEBUI_BASE_URL ?? ''}/api/v1/files/${(__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).fileId)) ?? ''}/content`);
						__vite_ssr_import_2__.set_attribute(iframe, 'title', (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).fileId)));
					});

					__vite_ssr_import_2__.event('load', iframe, function load(e) {
						try {
							e.currentTarget.style.height = e.currentTarget.contentWindow.document.body.scrollHeight + 20 + 'px';
						} catch {}
					});

					__vite_ssr_import_2__.append($$anchor, iframe);
				};

				var consequent_20 = ($$anchor) => {
					var fragment_22 = __vite_ssr_import_2__.comment();
					var node_22 = __vite_ssr_import_2__.first_child(fragment_22);

					{
						var consequent_19 = ($$anchor) => {
							var span = root_18();
							var node_23 = __vite_ssr_import_2__.child(span);

							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-p`);
								let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens ?? [])));

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_13__.default(node_23, {
										get id() {
											return __vite_ssr_import_2__.get($0);
										},

										get tokens() {
											return __vite_ssr_import_2__.get($1);
										},

										get done() {
											return done();
										},

										get sourceIds() {
											return sourceIds();
										},

										get onSourceClick() {
											return onSourceClick();
										}
									}),
									'component',
									MarkdownTokens,
									571,
									4,
									{ componentTag: 'MarkdownInlineTokens' }
								);
							}

							__vite_ssr_import_2__.reset(span);
							__vite_ssr_import_2__.template_effect(() => span.dir = span.dir);
							__vite_ssr_import_2__.append($$anchor, span);
						};

						var alternate_6 = ($$anchor) => {
							var p = root_19();
							var node_24 = __vite_ssr_import_2__.child(p);

							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-p`);
								let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens ?? [])));

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_13__.default(node_24, {
										get id() {
											return __vite_ssr_import_2__.get($0);
										},

										get tokens() {
											return __vite_ssr_import_2__.get($1);
										},

										get done() {
											return done();
										},

										get sourceIds() {
											return sourceIds();
										},

										get onSourceClick() {
											return onSourceClick();
										}
									}),
									'component',
									MarkdownTokens,
									581,
									4,
									{ componentTag: 'MarkdownInlineTokens' }
								);
							}

							__vite_ssr_import_2__.reset(p);

							__vite_ssr_import_2__.template_effect(() => {
								__vite_ssr_import_2__.set_class(p, 1, __vite_ssr_import_2__.clsx(__vite_ssr_import_2__.get(singlePlainBlock) ? '!my-0' : ''));
								p.dir = p.dir;
							});

							__vite_ssr_import_2__.append($$anchor, p);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_22, ($$render) => {
								if (__vite_ssr_import_2__.equals(paragraphTag(), 'span')) $$render(consequent_19); else $$render(alternate_6, -1);
							}),
							'if',
							MarkdownTokens,
							569,
							2
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_22);
				};

				var consequent_24 = ($$anchor) => {
					var fragment_23 = __vite_ssr_import_2__.comment();
					var node_25 = __vite_ssr_import_2__.first_child(fragment_23);

					{
						var consequent_22 = ($$anchor) => {
							var p_1 = root_20();
							var node_26 = __vite_ssr_import_2__.child(p_1);

							{
								var consequent_21 = ($$anchor) => {
									{
										let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-t`);

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_13__.default($$anchor, {
												get id() {
													return __vite_ssr_import_2__.get($0);
												},

												get tokens() {
													return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens));
												},

												get done() {
													return done();
												},

												get sourceIds() {
													return sourceIds();
												},

												get onSourceClick() {
													return onSourceClick();
												}
											}),
											'component',
											MarkdownTokens,
											594,
											5,
											{ componentTag: 'MarkdownInlineTokens' }
										);
									}
								};

								var alternate_7 = ($$anchor) => {
									var text_1 = __vite_ssr_import_2__.text();

									__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_1, $0), [
										() => (
											__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_7__.unescapeHtml),
											__vite_ssr_import_2__.get(token),
											__vite_ssr_import_2__.untrack(() => __vite_ssr_import_7__.unescapeHtml(__vite_ssr_import_2__.get(token).text))
										)
									]);

									__vite_ssr_import_2__.append($$anchor, text_1);
								};

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_2__.if(node_26, ($$render) => {
										if ((__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens))) $$render(consequent_21); else $$render(alternate_7, -1);
									}),
									'if',
									MarkdownTokens,
									593,
									4
								);
							}

							__vite_ssr_import_2__.reset(p_1);
							__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_class(p_1, 1, __vite_ssr_import_2__.clsx(__vite_ssr_import_2__.get(singlePlainBlock) ? '!my-0' : '')));
							__vite_ssr_import_2__.append($$anchor, p_1);
						};

						var consequent_23 = ($$anchor) => {
							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}-p`);
								let $1 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens ?? [])));

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_13__.default($$anchor, {
										get id() {
											return __vite_ssr_import_2__.get($0);
										},

										get tokens() {
											return __vite_ssr_import_2__.get($1);
										},

										get done() {
											return done();
										},

										get sourceIds() {
											return sourceIds();
										},

										get onSourceClick() {
											return onSourceClick();
										}
									}),
									'component',
									MarkdownTokens,
									606,
									3,
									{ componentTag: 'MarkdownInlineTokens' }
								);
							}
						};

						var alternate_8 = ($$anchor) => {
							var text_2 = __vite_ssr_import_2__.text();

							__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_2, $0), [
								() => (
									__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_7__.unescapeHtml),
									__vite_ssr_import_2__.get(token),
									__vite_ssr_import_2__.untrack(() => __vite_ssr_import_7__.unescapeHtml(__vite_ssr_import_2__.get(token).text))
								)
							]);

							__vite_ssr_import_2__.append($$anchor, text_2);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_25, ($$render) => {
								if (top()) $$render(consequent_22); else if ((__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens))) $$render(consequent_23, 1); else $$render(alternate_8, -1);
							}),
							'if',
							MarkdownTokens,
							591,
							2
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_23);
				};

				var consequent_26 = ($$anchor) => {
					var fragment_28 = __vite_ssr_import_2__.comment();
					var node_27 = __vite_ssr_import_2__.first_child(fragment_28);

					{
						var consequent_25 = ($$anchor) => {
							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
									__vite_ssr_import_2__.get(token),
									__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token)?.displayMode ?? false)
								));

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_14__.default($$anchor, {
										get content() {
											return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).text));
										},

										get displayMode() {
											return __vite_ssr_import_2__.get($0);
										}
									}),
									'component',
									MarkdownTokens,
									618,
									3,
									{ componentTag: 'KatexRenderer' }
								);
							}
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_27, ($$render) => {
								if ((__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).text))) $$render(consequent_25);
							}),
							'if',
							MarkdownTokens,
							617,
							2
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_28);
				};

				var consequent_28 = ($$anchor) => {
					var fragment_30 = __vite_ssr_import_2__.comment();
					var node_28 = __vite_ssr_import_2__.first_child(fragment_30);

					{
						var consequent_27 = ($$anchor) => {
							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
									__vite_ssr_import_2__.get(token),
									__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token)?.displayMode ?? false)
								));

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_14__.default($$anchor, {
										get content() {
											return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).text));
										},

										get displayMode() {
											return __vite_ssr_import_2__.get($0);
										}
									}),
									'component',
									MarkdownTokens,
									622,
									3,
									{ componentTag: 'KatexRenderer' }
								);
							}
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_28, ($$render) => {
								if ((__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).text))) $$render(consequent_27);
							}),
							'if',
							MarkdownTokens,
							621,
							2
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_30);
				};

				var consequent_29 = ($$anchor) => {
					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-${tokenIdx}`);

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_23__.default($$anchor, {
								get id() {
									return __vite_ssr_import_2__.get($0);
								},

								get token() {
									return __vite_ssr_import_2__.get(token);
								},
								tokenIdx,
								get done() {
									return done();
								},

								get editCodeBlock() {
									return editCodeBlock();
								},

								get sourceIds() {
									return sourceIds();
								},

								get onTaskClick() {
									return onTaskClick();
								},

								get onSourceClick() {
									return onSourceClick();
								}
							}),
							'component',
							MarkdownTokens,
							625,
							2,
							{ componentTag: 'ColonFenceBlock' }
						);
					}
				};

				var consequent_30 = ($$anchor) => {};

				var alternate_9 = ($$anchor) => {
					var text_3 = __vite_ssr_import_2__.text();

					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_3, $0), [
						() => (
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => console.log(...__vite_ssr_import_2__.log_if_contains_state('log', 'Unknown token', __vite_ssr_import_2__.get(token))))
						)
					]);

					__vite_ssr_import_2__.append($$anchor, text_3);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_1, ($$render) => {
						if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'hr'))
						)) $$render(consequent); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'heading'))
						)) $$render(consequent_1, 1); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'code'))
						)) $$render(consequent_3, 2); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'table'))
						)) $$render(consequent_4, 3); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'blockquote'))
						)) $$render(consequent_6, 4); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'list'))
						)) $$render(consequent_10, 5); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'detail_group'))
						)) $$render(consequent_13, 6); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'details'))
						)) $$render(consequent_16, 7); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'html'))
						)) $$render(consequent_17, 8); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'iframe'))
						)) $$render(consequent_18, 9); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'paragraph'))
						)) $$render(consequent_20, 10); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'text'))
						)) $$render(consequent_24, 11); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'inlineKatex'))
						)) $$render(consequent_26, 12); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'blockKatex'))
						)) $$render(consequent_28, 13); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'colonFence'))
						)) $$render(consequent_29, 14); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'space'))
						)) $$render(consequent_30, 15); else $$render(alternate_9, -1);
					}),
					'if',
					MarkdownTokens,
					180,
					1
				);
			}

			__vite_ssr_import_2__.append($$anchor, fragment_1);
		}),
		'each',
		MarkdownTokens,
		179,
		0
	);

	__vite_ssr_import_2__.append($$anchor, fragment);

	var $$pop = __vite_ssr_import_2__.pop($$exports);

	$$cleanup();

	return $$pop;
}
Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: MarkdownTokens });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ3VDO0FBQ007QUFHVjtBQUdTO0FBQ2U7QUFDRTtBQUViO0FBQ1Q7QUFDRDtBQUVpQztBQUMrQjtBQUNuRDtBQUNvQjtBQUNIO0FBQ1E7QUFDaEI7QUFDQztBQUNVO0FBRTVCO0FBQ29CO0FBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzJDQTVCdkQsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBR0EsTUFBTSxJQUFJLEdBQUcsZ0NBQVUsQ0FBQyxNQUFNO0NBRzlCLE1BQU0sRUFBRSxNQUFNLEtBQUssNkJBQVM7Q0F3QnJCLElBQUksRUFBVTtDQUNkLElBQUksTUFBTSxvREFBRyxFQUFFO0NBQ2YsSUFBSSxTQUFTLHVEQUFHLEVBQUU7Q0FDbEIsSUFBSSxNQUFlO0NBQ25CLElBQUksR0FBRyxpREFBRyxJQUFJO0NBQ2QsSUFBSSxVQUFVO0NBQ2QsSUFBSSxTQUFTO0NBRWIsSUFBSSxJQUFJLGtEQUFHLElBQUk7Q0FFZixJQUFJLElBQUksa0RBQUcsS0FBSztDQUNoQixJQUFJLE9BQU8scURBQUcsS0FBSztDQUNuQixJQUFJLGNBQWMsNERBQUcsS0FBSztDQUUxQixJQUFJLFlBQVksMERBQUcsR0FBRztDQUV0QixJQUFJLGFBQWEsMkRBQUcsSUFBSTtDQUN4QixJQUFJLFVBQVUsd0RBQUcsS0FBSztDQUN0QixJQUFJLFdBQVcseURBQUcsSUFBSTtDQUV0QixJQUFJLE1BQWdCLDBEQUFTLENBQUMsQ0FBQztDQUMvQixJQUFJLFFBQWtCLDREQUFTLENBQUMsQ0FBQztDQUNqQyxJQUFJLFNBQW1CLDZEQUFTLENBQUMsQ0FBQztDQUVsQyxJQUFJLFdBQXFCLCtEQUFTLENBQUMsQ0FBQztDQUNwQyxJQUFJLGFBQXVCLGlFQUFTLENBQUMsQ0FBQztDQUN0QyxJQUFJLGtCQUE0QixzRUFBUyxDQUFDLENBQUM7O0NBRWxELE1BQU0sZUFBZSxJQUFJLEtBQWEsS0FBSztFQUMxQyxNQUFNLENBQUMsR0FBRyxHQUFHLEtBQUs7Q0FDbkIsQ0FBQzs7Q0FFRCxNQUFNLHNCQUFzQixHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsWUFBWSxFQUFFLFdBQVcsRUFBRSxrQkFBa0I7O0NBRXJGLE1BQU0sc0JBQXNCLElBQUksS0FBaUQsS0FBSztFQUNyRixNQUFNLHFDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUssU0FBUyxLQUFJLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO0NBQzdGLENBQUM7O0NBRUQsTUFBTSxnQkFBZ0IsSUFBSSxTQUFrQixVQUFVO0VBQ3JELE1BQU0sYUFBYTtFQUNuQixJQUFJLFdBQVc7O0VBRWYsTUFBTSxnQkFBZ0IsU0FBUztHQUM5QixFQUFFLEVBQUUsV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7SUFDM0IsYUFBYSxDQUFDLElBQUksR0FDakIsSUFBSSxFQUFFLGNBQWMsRUFDcEIsS0FBSyxNQUFNLFdBQVc7R0FFeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLHNDQUFFLFdBQVcsQ0FBQyxNQUFNLEVBQUssQ0FBQyxHQUFFO0lBQ3BDLGFBQWEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7R0FDakM7O0dBRUEsV0FBVztFQUNaLENBQUM7O0VBRUQsSUFBSSxDQUFDLE1BQU0sS0FBSyxJQUFJLFNBQVMsRUFBRTtHQUM5QixFQUFFLEVBQUUsc0JBQXNCLENBQUMsS0FBSyxHQUFHO0lBQ2xDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSztHQUN2QixDQUFDLENBQUMsSUFBSSxDQUFDO0lBQ04sZ0JBQWdCO0lBQ2hCLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSztHQUN6QjtFQUNEOztFQUVBLGdCQUFnQjs7RUFFaEIsTUFBTSxDQUFDLGFBQWE7Q0FDckIsQ0FBQzs7Q0FFRCxNQUFNLG9CQUFvQixJQUFJLEtBQUssS0FBSztFQUN2QyxNQUFNLENBQUMsNEJBQU0sQ0FBQyxLQUFLLEVBQUUsSUFBSSxJQUFJLEVBQUUsRUFDN0IsT0FBTyxDQUFDLDJCQUEyQixFQUFFLEVBQUUsRUFDdkMsSUFBSTtDQUNQLENBQUM7O0NBRUQsSUFBSSxlQUFlLGtFQUFHLEVBQUU7O0NBRXhCLE1BQU0sZUFBZSxHQUFHLEtBQUssRUFBRSxNQUFjLEVBQUUsUUFBaUIsS0FBSztFQUNwRSxFQUFFLEdBQUcsTUFBTSxPQUFLLFNBQVMsT0FBSyxNQUFNLDhCQUFJLGVBQWUsR0FBRTtHQUN4RCxNQUFNO0VBQ1A7OzRCQUVBLGVBQWUsRUFBRyxNQUFNOztFQUN4QixHQUFHLENBQUM7R0FDSCxNQUFNLEdBQUcsc0RBQVMsZ0RBQTBCLENBQzNDLFlBQVksQ0FBQyxLQUFLLEVBQ2xCLE1BQU0sSUFDTixTQUFTLElBQ1QsTUFBTSxFQUNOLFFBQVEsR0FBRyxTQUFTLEdBQUcsUUFBTzs7R0FFL0Isa0JBQWtCLEdBQUMsR0FBRztFQUN2QixDQUFDLENBQUMsS0FBSyxDQUFFLEdBQUcsRUFBRTtHQUNiLDRCQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHO0VBQ3ZCLENBQUMsQ0FBQyxPQUFPLENBQUM7NkJBQ1QsZUFBZSxFQUFHLEVBQUU7RUFDckI7Q0FDRCxDQUFDOztDQVdELE1BQU0sdUJBQXVCLElBQUksS0FBSyxFQUFFLFFBQVEsR0FBRyxDQUFDLEtBQUs7RUFDeEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0I7OztFQUdwQyxNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFDN0IsVUFBVSxTQUFTLDRCQUFNLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUk7OztFQUkvRCxNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLEtBQy9CLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxLQUFLOztHQUVqQixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLEtBQUssS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRTs7O0dBRWxFLE1BQU0sS0FBSyw0QkFBTSxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLElBQUk7RUFDbEQsQ0FBQzs7O0VBSUYsTUFBTSxPQUFPLElBQUksTUFBTSxLQUFLLElBQUk7OztFQUdoQyxNQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsSUFBSTs7O0VBR2hFLE9BQU8sQ0FBQyxHQUFHLHVEQUFDLE9BQU87O0VBQ25CLE9BQU8sQ0FBQyxHQUFHLHVEQUFDLFVBQVU7OztFQUd0QixNQUFNLEdBQUcsR0FBRyxRQUFROzs7RUFHcEIsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLElBQUksRUFBRSxHQUFHLEdBQUcsVUFBVSxLQUFLLElBQUksRUFBRSx3QkFBd0I7OztFQUcxRSxNQUFNLENBQUMsSUFBSSxXQUFXLEVBQUUsTUFBSSxRQUFRO0NBQ3JDLENBQUM7Ozs0QkE3Q0UscUJBQXFCLFlBQ3ZCLGNBQWMsS0FBRyxTQUFTLEdBQUcsa0JBQWlCOzs7OzRCQUc1QyxhQUFhLEVBQUcsZ0JBQWdCLENBQUMsTUFBTTs7Ozs0QkFDdkMsZ0JBQWdCLGdFQUNsQixhQUFhLEVBQUMsTUFBTSxFQUFLLENBQUMsb0VBQ3pCLGFBQWEsRUFBQyxDQUFDLEdBQUcsSUFBSSxFQUFLLFdBQVcsbUVBQUksYUFBYSxFQUFDLENBQUMsR0FBRyxJQUFJLEVBQUssTUFBTTs7Ozs7Ozs7Ozs7Ozs0RUEwQ3ZFLGFBQWEsMkNBQUksS0FBSzs7Ozs7O1NBRTFCLEVBQUU7OzRDQUFGLEVBQUU7Ozs7Ozs7OytEQUVtQixlQUFlLDJCQUFDLEtBQUssRUFBQyxLQUFLO2dFQUEzQixlQUFlLDJCQUFDLEtBQUssRUFBQyxLQUFLOzs7O2FBQTNCLGVBQWUsMkJBQUMsS0FBSyxFQUFDLEtBQUs7Ozs7OztvRUFFeEMsRUFBRSxNQUFJLFFBQVE7OztnQkFEckI7Ozs7Ozs4Q0FMb0IsS0FBSyxpRUFPakIsS0FBSyxFQUFDLE1BQU07Ozs7bUJBQ25CLElBQUk7Ozs7bUJBQ0osU0FBUzs7OzttQkFDVCxhQUFhOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzttRUFNUCxFQUFFLE1BQUksUUFBUTs7Ozs2Q0FDVixTQUFTLElBQUUsa0JBQWtCLElBQUksS0FBSzs7OzJGQWpCN0IsS0FBSyxpRUFtQm5CLEtBQUssR0FBRSxJQUFJLElBQUksRUFBRTsyRkFuQkgsS0FBSyxpRUFvQm5CLEtBQUssR0FBRSxJQUFJLElBQUksRUFBRTtnRUFLQyxVQUFVLEtBQUcsUUFBUSxHQUFHLE9BQU87OztlQVZ2RDs7Ozs7Ozs7Ozs0Q0FHQyxLQUFLOzs7Ozs7Ozs7Ozs7a0JBR0wsVUFBVTs7OztrQkFDVixJQUFJOzs7O2tCQUNKLE9BQU87Ozs7a0JBQ0YsYUFBYTs7Ozs7OzttQkFFVixLQUFLLEtBQUs7V0FDbEIsTUFBTTtZQUNMLEdBQUcsNEJBQUUsS0FBSyxFQUFDLEdBQUc7WUFDZCxVQUFVLDRCQUFFLEtBQUssRUFBQyxJQUFJO1lBQ3RCLFVBQVUsRUFBRTs7VUFFZCxDQUFDOzs7a0JBQ0EsUUFBUTs7OztrQkFDUixTQUFTOzs7Ozs7Ozs7Ozs7O2lDQWxDVSxLQUFLO3FFQWN0QixLQUFLLEVBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLOzs7Ozs7bUhBZFAsS0FBSyxpRUFxQ3pCLEtBQUssRUFBQyxJQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O1NBR1gsR0FBRztTQUNGLEtBQUcsK0JBREosR0FBRztTQUVELG9DQURELEtBQUc7U0FLRCxLQUFLLCtCQUpOO1NBS0UsRUFBRSwrQkFESCxLQUFLOzs7dUNBQ0osRUFBRSxzQ0EvQ2UsS0FBSyxpRUFnRGYsS0FBSyxFQUFDLE1BQU0sNENBQUksTUFBTTtXQUMzQjtXQUtDLEtBQUcsK0JBTEo7V0FNRSxLQUFHLCtCQURKLEtBQUc7Z0RBQ0YsS0FBRzs7O21FQUVLLEVBQUUsTUFBSSxRQUFRLFdBQVcsU0FBUzs7O2VBRHpDOzs7Ozs7NkNBUmtCLE1BQU0saUVBVWhCLE1BQU0sRUFBQyxNQUFNOzs7O2tCQUNwQixJQUFJOzs7O2tCQUNKLFNBQVM7Ozs7a0JBQ1QsYUFBYTs7Ozs7Ozs7Ozs7bUNBTmYsS0FBRzttQ0FESixLQUFHO21DQUxKOzttRkFBQTtrQ0FqRGUsS0FBSzs7c0VBb0RiLEtBQUssRUFBQyxLQUFLLENBQUMsU0FBUyw2Q0FBbUIsS0FBSyxFQUFDLEtBQUssQ0FBQyxTQUFTLE1BQU0sRUFBRTs7OzhDQUg1RTs7Ozs7Ozs7aUNBRkYsRUFBRTtpQ0FESCxLQUFLOztTQXVCTCxLQUFLLGlDQXZCTCxLQUFLOzs7dUNBdUJMLEtBQUssc0NBckVhLEtBQUssaUVBc0VoQixLQUFLLEVBQUMsSUFBSSw0Q0FBSSxHQUFHO1dBQ3RCLElBQUU7Ozt5Q0FBRixJQUFFLHFDQUNLLEdBQUcsaURBQVUsSUFBSTthQUN0QjthQVFDLEtBQUcsK0JBUko7a0RBUUMsS0FBRzs7O3FFQUVLLEVBQUUsTUFBSSxRQUFRLFFBQVEsTUFBTSxJQUFJLE9BQU87OztpQkFEOUM7Ozs7OzsrQ0FWZ0IsSUFBSSxpRUFZWixJQUFJLEVBQUMsTUFBTTs7OztvQkFDbEIsSUFBSTs7OztvQkFDSixTQUFTOzs7O29CQUNULGFBQWE7Ozs7Ozs7Ozs7O3FDQU5mLEtBQUc7cUNBUko7OzswQ0FBQTtxQ0F6RWMsS0FBSzs7NkdBMEVxQyxLQUFLLEVBQUMsSUFBSSxDQUFDLE1BQU0sR0FDeEUsQ0FBQyxFQUNGLFVBQ0csRUFBQyxHQUNELGdEQUFnRDs7OzBDQUxuRDtxQ0F6RWMsS0FBSzs7eUVBK0VaLEtBQUssRUFBQyxLQUFLLENBQUMsT0FBTyw2Q0FBbUIsS0FBSyxFQUFDLEtBQUssQ0FBQyxPQUFPLE1BQU0sRUFBRTs7OztnREFOeEU7Ozs7Ozs7O21DQUZGLElBQUU7OENBQUYsSUFBRTs7Ozs7Ozs7aUNBRkosS0FBSztpQ0EzQk47aUNBREQsS0FBRzs7U0F5REgsS0FBRyxpQ0F6REgsS0FBRzs4Q0F5REgsS0FBRzs7OzRHQUNlLEtBQUssR0FBQyxDQUFDLENBQUMsTUFBTTs7O2FBQS9CLDhCQUFPOzs7Ozs7YUFDTjtrREFBQTs7cURBT0MsOEJBQVM7cUNBUFY7OzhDQUFBLHVCQUVXLENBQUMsRUFBSztVQUNoQixDQUFDLENBQUMsZUFBZTtVQUNqQixxQ0FBZSwyQkFBQyxLQUFLLEVBQUMsR0FBRyxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUUsU0FBUyxJQUFFLGFBQWEsSUFBSSxLQUFLO1NBQzFFLENBQUM7O2dEQUxEOzs7Ozs7Ozs7Ozs7Ozs7NEdBV2dCLEtBQUssR0FBQyxDQUFDLENBQUMsZUFBZTs7O2FBQXhDLDhCQUFPOzs7Ozs7YUFDTjtrREFBQTs7cURBT0MsOEJBQVE7cUNBUFQ7OzhDQUFBLDJCQUVXLENBQUMsRUFBSztVQUNoQixDQUFDLENBQUMsZUFBZTtVQUNqQix1QkFBdUIsMkJBQUMsS0FBSyxHQUFFLFFBQVE7U0FDeEMsQ0FBQzs7Z0RBTEQ7Ozs7Ozs7Ozs7OztpQ0FkRixLQUFHO2lDQTFESixHQUFHO2lEQUVEOzRDQUZGLEdBQUc7Ozs7V0FxRkksS0FBSzs7NkNBNVJVLHFDQUFjO2lDQStKZixLQUFLOzJDQTZIWCxxQ0FBYywyQkFBQyxLQUFLOzs7OzsrQkFBNUIsS0FBSzs7Ozs7Ozs7Y0FFWCw4QkFBYTs7MkNBQUUsS0FBSzs7OzsyQ0FBRyxLQUFLOzs7Ozs7Ozs7Ozs7V0FFNUIsVUFBVTtpREFBVixVQUFVOzs7bUVBRUYsRUFBRSxNQUFJLFFBQVE7OztlQURyQixjQUFPOzs7Ozs7a0JBRU4sTUFBTTs7OztrQkFDTixTQUFTOzs7OzZDQXJJUyxLQUFLLGlFQXNJaEIsS0FBSyxFQUFDLE1BQU07Ozs7a0JBQ25CLElBQUk7Ozs7a0JBQ0osSUFBSTs7OztrQkFDSixPQUFPOzs7O2tCQUNQLGNBQWM7Ozs7a0JBQ2QsYUFBYTs7OztrQkFDYixXQUFXOzs7O2tCQUNYLFNBQVM7Ozs7a0JBQ1QsYUFBYTs7OztrQkFDYixrQkFBa0I7Ozs7Ozs7Ozs7O21DQWRwQixVQUFVO21EQUFWLFVBQVUsT0FBVixVQUFVOzhDQUFWLFVBQVU7Ozs7O3NDQUhQLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7OztXQXVCUixFQUFFOzs7eUNBQUYsRUFBRSxzQ0FySmtCLEtBQUssaUVBc0psQixLQUFLLEVBQUMsS0FBSyw0Q0FBSSxJQUFJO2FBQ3hCLEVBQUU7bURBQUYsRUFBRTs7OztlQUVBOzt1REFBQTt5RkFBQSxrQ0FIa0IsSUFBSSxpRUFNYixJQUFJLEVBQUMsT0FBTzs7aURBSHJCLHVCQUlZLENBQUMsRUFBSztZQUNqQixXQUFXO2FBQ1YsRUFBRSxFQUFFLEVBQUU7YUFDTixLQUFLLDRCQUFFLEtBQUs7YUFDRixRQUFRO2FBQ2xCLElBQUksNEJBQUUsSUFBSTthQUNELE9BQU87YUFDaEIsT0FBTyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUM7O1dBRXBCLENBQUM7O2tEQWJEOzs7OzsyQ0FIa0IsSUFBSSxpRUFFbkIsSUFBSSxHQUFFLElBQUk7Ozs7Ozs7Ozs7OztxRUFtQlAsRUFBRSxNQUFJLFFBQVEsSUFBSSxPQUFPOzs7aUJBRGhDLGNBQU87Ozs7OztvQkFFTixNQUFNOzs7O29CQUNOLFNBQVM7Ozs7K0NBdkJTLElBQUksaUVBd0JmLElBQUksRUFBQyxNQUFNOzs7OytDQTlLRixLQUFLLGlFQStLakIsS0FBSyxFQUFDLEtBQUs7Ozs7b0JBQ2YsSUFBSTs7OztvQkFDSixJQUFJOzs7O29CQUNKLE9BQU87Ozs7b0JBQ1AsY0FBYzs7OztvQkFDZCxhQUFhOzs7O29CQUNiLFdBQVc7Ozs7b0JBQ1gsU0FBUzs7OztvQkFDVCxhQUFhOzs7Ozs7Ozs7OztxQ0FoQ2YsRUFBRTtnREFBRixFQUFFOzs7Ozs7OzttQ0FGSixFQUFFOzs7NENBQUYsRUFBRSxzQ0FySmtCLEtBQUssaUVBcUpmLEtBQUssRUFBQyxLQUFLLElBQUksQ0FBQztRQUExQixFQUFFLE9BQUYsRUFBRTs7OzhDQUFGLEVBQUU7Ozs7V0F3Q0YsRUFBRTs7O3lDQUFGLEVBQUUsc0NBN0xrQixLQUFLLGlFQThMbEIsS0FBSyxFQUFDLEtBQUssNENBQUksSUFBSTthQUN4QixJQUFFO21EQUFGLElBQUU7Ozs7O2VBRUE7O3VEQUFBOztlQWdCQSxLQUFHLGlDQWhCSDtxREFnQkEsS0FBRzs7O3VFQUVLLEVBQUUsTUFBSSxRQUFRLElBQUksT0FBTzs7O21CQURoQyxjQUFPOzs7Ozs7c0JBRU4sTUFBTTs7OztzQkFDTixTQUFTOzs7O2lEQXZCTyxJQUFJLGlFQXdCYixJQUFJLEVBQUMsTUFBTTs7OztpREF0TkosS0FBSyxpRUF1TmYsS0FBSyxFQUFDLEtBQUs7Ozs7c0JBQ2YsSUFBSTs7OztzQkFDSixJQUFJOzs7O3NCQUNKLE9BQU87Ozs7c0JBQ1AsY0FBYzs7OztzQkFDZCxhQUFhOzs7O3NCQUNiLFdBQVc7Ozs7c0JBQ1gsU0FBUzs7OztzQkFDVCxhQUFhOzs7Ozs7Ozs7Ozt1Q0FkZixLQUFHO3lGQWhCSCxvQ0FIa0IsSUFBSSxpRUFNYixJQUFJLEVBQUMsT0FBTzs7aURBSHJCLDJCQUlZLENBQUMsRUFBSztZQUNqQixXQUFXO2FBQ1YsRUFBRSxFQUFFLEVBQUU7YUFDTixLQUFLLDRCQUFFLEtBQUs7YUFDRixRQUFRO2FBQ2xCLElBQUksNEJBQUUsSUFBSTthQUNELE9BQU87YUFDaEIsT0FBTyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUM7O1dBRXBCLENBQUM7Ozs7Ozs7Ozs7dUVBc0JNLEVBQUUsTUFBSSxRQUFRLElBQUksT0FBTzs7O21CQURoQyxjQUFPOzs7Ozs7c0JBRU4sTUFBTTs7OztzQkFDTixTQUFTOzs7O2lEQXhDUSxJQUFJLGlFQXlDZCxJQUFJLEVBQUMsTUFBTTs7OztpREF2T0gsS0FBSyxpRUF3T2hCLEtBQUssRUFBQyxLQUFLOzs7O3NCQUNmLElBQUk7Ozs7c0JBQ0osSUFBSTs7OztzQkFDSixPQUFPOzs7O3NCQUNQLGNBQWM7Ozs7c0JBQ2QsYUFBYTs7OztzQkFDYixXQUFXOzs7O3NCQUNYLFNBQVM7Ozs7c0JBQ1QsYUFBYTs7Ozs7Ozs7Ozs7Ozs7OzsyQ0FsREksSUFBSSxpRUFFbkIsSUFBSSxHQUFFLElBQUk7Ozs7Ozs7OztxQ0FEZixJQUFFOztxRkFBRixJQUFFO29DQURrQixJQUFJO3dFQUNGLElBQUksR0FBRSxJQUFJLEdBQUcsOEJBQThCLEdBQUcsRUFBRTs7O2dEQUF0RSxJQUFFOzs7Ozs7OzttQ0FGSixFQUFFO21EQUFGLEVBQUUsT0FBRixFQUFFOzhDQUFGLEVBQUU7Ozs7O3VDQTdMa0IsS0FBSyxpRUFvSnRCLEtBQUssRUFBQyxPQUFPOzs7Ozs7Ozs7Ozs7OztpRUFxR1YsRUFBRSxNQUFJLFFBQVE7Z0VBS1AsTUFBTSxRQUFNLFNBQVMsTUFBSSxJQUFJOzs7YUFOM0M7Ozs7OzsyQ0F4UHFCLEtBQUssaUVBMFBsQixLQUFLLEVBQUMsS0FBSzs7OztnQkFDTixJQUFJOzs7O2dCQUNoQixjQUFjOzs7O2dCQUNkLFdBQVc7Ozs7Ozs7OzBDQUVYLGVBQWU7O21CQUNMLGVBQWU7OztjQUV6QixLQUFHOzs7NENBQUgsS0FBRyxzQ0FsUWlCLEtBQUssaUVBbVFsQixLQUFLLEVBQUMsS0FBSyw0Q0FBSSxXQUFXO2tCQUN4QixXQUFXOzt3Q0FERSxXQUFXO2tEQUNWLG9CQUFvQiwyQkFBQyxXQUFXOzs7OztzQ0FBOUMsV0FBVzs7Ozs7Ozs7MEVBSVYsRUFBRSxNQUFJLFFBQVEsSUFBSSxTQUFTOzs7MENBTGYsV0FBVztvREFPZixvQkFBb0IsMkJBQUMsV0FBVzs7O3lFQUVqQyxNQUFNLFFBQU0sU0FBUyxNQUFJLElBQUk7OzswQ0FyVjdDLGVBQWU7MENBNFVNLFdBQVc7a0hBVW5CLGVBQWUsNkJBQUssV0FBVyxFQUFDLFVBQVUsRUFBRSxFQUFFOzs7OztvREFFbkQsU0FBUyxJQUFFLGFBQWEsSUFBSSxLQUFLOzs7O3NCQVJ2Qzs7Ozs7Ozs2Q0FKbUIsV0FBVztpRkFNbEIsV0FBVyxFQUFDLFVBQVU7Ozs7Ozs7MEJBRXpCLElBQUk7Ozs7Ozs7OzZCQUdELFFBQVEsS0FBSyxlQUFlLDJCQUFDLFdBQVcsRUFBQyxVQUFVLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxRQUFROzs7Ozs7bURBR2xFLHFCQUFxQjs7Ozs7Ozs7Ozs7Ozs7OztvREFLaEMsU0FBUyxJQUFFLGFBQWEsSUFBSSxLQUFLOzs7OzBDQW5CcEIsV0FBVzs4RUFvQmxCLFdBQVcsR0FBRSxVQUFVOzs7O3NCQUhuQzs7OzZDQWpCbUIsV0FBVztpRkFrQnZCLFdBQVcsRUFBQyxPQUFPOzs7Ozs7Ozs7Ozs7O3lCQUdiLElBQUk7Ozs7bURBRUEscUJBQXFCOzs7Ozt1QkFHckMsS0FBRzs2REFBSCxLQUFHOzs7K0VBRUssRUFBRSxNQUFJLFFBQVEsSUFBSSxTQUFTOzs7MkRBemNqQyw0QkFBTTsyREFQTiw0QkFBTTsrQ0FvYlUsV0FBVzt5REErQnBCLDRCQUFNLENBQUMsS0FBSyxDQUFDLDRCQUFNLDJCQUFDLFdBQVcsRUFBQyxJQUFJOzs7OytDQS9CM0IsV0FBVzttRkFnQ2hCLFdBQVcsR0FBRSxVQUFVOzs7OzJCQUxuQyxjQUFPOzs7Ozs7OEJBRU4sTUFBTTs7Ozs4QkFDTixTQUFTOzs7Ozs7Ozs7Ozs7OEJBR1QsSUFBSTs7Ozs4QkFDSixJQUFJOzs7OzhCQUNKLE9BQU87Ozs7OEJBQ1AsY0FBYzs7Ozs4QkFDZCxhQUFhOzs7OzhCQUNiLFdBQVc7Ozs7OEJBQ1gsU0FBUzs7Ozs4QkFDVCxhQUFhOzs7Ozs7Ozs7OzsrQ0FkZixLQUFHOzBEQUFILEtBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7MENBMUJlLFdBQVc7OEVBaURsQixXQUFXLEdBQUUsVUFBVTs7OztzQkFKbkM7Ozs2Q0E3Q21CLFdBQVc7aUZBOEN2QixXQUFXLEVBQUMsT0FBTzs7O3VCQUNwQixLQUFLOzJCQUNELElBQUk7Ozs7Ozt5QkFFRCxJQUFJOzs7O21EQUVBLHFCQUFxQjs7Ozs7Ozs7Ozs7Ozs7OzswQ0FwRG5CLFdBQVc7a0hBRzNCLFdBQVcsR0FBRSxVQUFVLEVBQUUsSUFBSSxFQUFLLFlBQVk7O2dGQUYzQyxXQUFXOzhFQWVULFdBQVcsRUFBQyxNQUFNLEdBQUcsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O3NDQWpCakMsS0FBRztpREFBSCxLQUFHOzs7Ozs7Ozs7Ozs7OztXQTZERyxXQUFXOztpQ0EvVEcsS0FBSzsyQ0ErVEwsb0JBQW9CLDJCQUFDLEtBQUs7Ozs7OytCQUF4QyxXQUFXOzs7Ozs7OzttRUFLVixFQUFFLE1BQUksUUFBUTs7O21DQXBVRCxLQUFLOzZDQXNVVixvQkFBb0IsMkJBQUMsS0FBSzs7O2tFQUMzQixNQUFNLFFBQU0sU0FBUyxNQUFJLElBQUk7OzttQ0FoWjFDLGVBQWU7bUNBeUVJLEtBQUs7MkdBd1VkLGVBQWUsNkJBQUssS0FBSyxFQUFDLFVBQVUsRUFBRSxFQUFFOzs7Ozs2Q0FFN0MsU0FBUyxJQUFFLGFBQWEsSUFBSSxLQUFLOzs7O2VBUHZDOzs7Ozs7NkNBblVvQixLQUFLLGlFQXFVYixLQUFLLEVBQUMsVUFBVTs7Ozs7Ozs7Ozs7Ozs7c0JBSWhCLFFBQVEsS0FBSyxlQUFlLDJCQUFDLEtBQUssRUFBQyxVQUFVLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxRQUFROzs7Ozs7NENBRzVELHFCQUFxQjs7Ozs7Ozs7Ozs7Ozs7Ozs2Q0FLaEMsU0FBUyxJQUFFLGFBQWEsSUFBSSxLQUFLOzs7MkZBalZuQixLQUFLLGlFQWtWYixLQUFLLEdBQUUsVUFBVTs7O2VBSDdCOzs2Q0EvVW9CLEtBQUssaUVBZ1ZsQixLQUFLLEVBQUMsT0FBTzs7Ozs7Ozs7Ozs7O2tCQUdQLElBQUk7Ozs7NENBRUEscUJBQXFCOzs7OztnQkFHckMsS0FBRztzREFBSCxLQUFHOzs7d0VBRUssRUFBRSxNQUFJLFFBQVE7OztvREFwZ0JqQiw0QkFBTTtvREFQTiw0QkFBTTt3Q0FpTFEsS0FBSztrREE2VmYsNEJBQU0sQ0FBQyxLQUFLLENBQUMsNEJBQU0sMkJBQUMsS0FBSyxFQUFDLElBQUk7OztnR0E3VnBCLEtBQUssaUVBOFZYLEtBQUssR0FBRSxVQUFVOzs7b0JBTDdCLGNBQU87Ozs7Ozt1QkFFTixNQUFNOzs7O3VCQUNOLFNBQVM7Ozs7Ozs7Ozs7Ozt1QkFHVCxJQUFJOzs7O3VCQUNKLElBQUk7Ozs7dUJBQ0osT0FBTzs7Ozt1QkFDUCxjQUFjOzs7O3VCQUNkLGFBQWE7Ozs7dUJBQ2IsV0FBVzs7Ozt1QkFDWCxTQUFTOzs7O3VCQUNULGFBQWE7Ozs7Ozs7Ozs7O3dDQWRmLEtBQUc7bURBQUgsS0FBRzs7Ozs7Ozs7Ozs7Ozs7OzJGQXhWZ0IsS0FBSyxpRUErV2IsS0FBSyxHQUFFLFVBQVU7OztlQUo3Qjs7NkNBM1dvQixLQUFLLGlFQTRXbEIsS0FBSyxFQUFDLE9BQU87O2dCQUNkLEtBQUs7b0JBQ0QsSUFBSTs7Ozs7O2tCQUVELElBQUk7Ozs7NENBRUEscUJBQXFCOzs7Ozs7Ozs7Ozs7Ozs7O21DQWxYbEIsS0FBSzsyR0FpVXRCLEtBQUssR0FBRSxVQUFVLEVBQUUsSUFBSSxFQUFLLFlBQVk7O3lFQUZyQyxXQUFXO3VFQWVULFdBQVcsRUFBQyxNQUFNLEdBQUcsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O1lBeUMvQiw4QkFBUzs7ZUFBRSxFQUFFOzs7O3lDQUFHLEtBQUs7Ozs7ZUFBRyxhQUFhOzs7Ozs7Ozs7Ozs7U0FFckM7OzswQ0FBQSxrQkFDTSxvQ0FBYyxrREExWEMsS0FBSyxpRUEwWFUsS0FBSyxFQUFDLE1BQU07MENBRGhELDRDQXpYcUIsS0FBSyxpRUEyWG5CLEtBQUssRUFBQyxNQUFNOzs7eUNBRm5CLHNCQUtVLENBQUMsRUFBSztNQUNmLEdBQUcsQ0FBQztPQUNILENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FDM0IsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxHQUFHLElBQUk7TUFDdEUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0tBQ1YsQ0FBQzs7NENBVkQ7Ozs7Ozs7OztXQWNDLElBQUk7aURBQUosSUFBSTs7O21FQUVJLEVBQUUsTUFBSSxRQUFROzJGQXpZRixLQUFLLGlFQTBZaEIsS0FBSyxFQUFDLE1BQU07OztlQUZwQjs7Ozs7Ozs7OztrQkFHQyxJQUFJOzs7O2tCQUNKLFNBQVM7Ozs7a0JBQ1QsYUFBYTs7Ozs7Ozs7Ozs7bUNBTmYsSUFBSTttREFBSixJQUFJLE9BQUosSUFBSTs4Q0FBSixJQUFJOzs7O1dBVUosQ0FBQztpREFBRCxDQUFDOzs7bUVBRU8sRUFBRSxNQUFJLFFBQVE7MkZBblpGLEtBQUssaUVBb1poQixLQUFLLEVBQUMsTUFBTTs7O2VBRnBCOzs7Ozs7Ozs7O2tCQUdDLElBQUk7Ozs7a0JBQ0osU0FBUzs7OztrQkFDVCxhQUFhOzs7Ozs7Ozs7OzttQ0FOZixDQUFDOzs7d0NBQUQsQ0FBQywwREFBbUIsZ0JBQWdCLElBQUcsT0FBTyxHQUFHLEVBQUU7UUFBbkQsQ0FBQyxPQUFELENBQUM7Ozs4Q0FBRCxDQUFDOzs7Ozt5Q0FYRSxZQUFZLElBQUksTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7O1dBdUJ6QixHQUFDO2lEQUFELEdBQUM7Ozs7O3FFQUdRLEVBQUUsTUFBSSxRQUFROzs7aUJBRHJCOzs7Ozs7K0NBL1prQixLQUFLLGlFQWlhZixLQUFLLEVBQUMsTUFBTTs7OztvQkFDbkIsSUFBSTs7OztvQkFDSixTQUFTOzs7O29CQUNULGFBQWE7Ozs7Ozs7Ozs7Ozs7Ozs7O2lEQTdrQk8sa0NBQVk7cUNBeUtmLEtBQUs7K0NBdWF2QixrQ0FBWSwyQkFBQyxLQUFLLEVBQUMsSUFBSTs7Ozs7Ozs7O3lDQXZhTCxLQUFLLGlFQThacEIsS0FBSyxFQUFDLE1BQU07Ozs7Ozs7OzttQ0FEakIsR0FBQzttRkFBRCxHQUFDLDBEQUFRLGdCQUFnQixJQUFHLE9BQU8sR0FBRyxFQUFFOzhDQUF4QyxHQUFDOzs7OzttRUFlTSxFQUFFLE1BQUksUUFBUTsyRkE1YUQsS0FBSyxpRUE2YWpCLEtBQUssRUFBQyxNQUFNOzs7ZUFGcEI7Ozs7Ozs7Ozs7a0JBR0MsSUFBSTs7OztrQkFDSixTQUFTOzs7O2tCQUNULGFBQWE7Ozs7Ozs7Ozs7Ozs7Ozs7OytDQXpsQlMsa0NBQVk7bUNBeUtmLEtBQUs7NkNBbWJ6QixrQ0FBWSwyQkFBQyxLQUFLLEVBQUMsSUFBSTs7Ozs7Ozs7O1lBdkJwQixHQUFHLGlFQTVaYyxLQUFLLGlFQTBhakIsS0FBSyxFQUFDLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O21DQTFhQSxLQUFLO3VFQXVidUIsS0FBSyxHQUFFLFdBQVcsSUFBSSxLQUFLOzs7O2VBQTNFLDhCQUFhOzs2Q0F2Yk8sS0FBSyxpRUF1YkYsS0FBSyxFQUFDLElBQUk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0F2YmIsS0FBSyxpRUFzYnRCLEtBQUssRUFBQyxJQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OzttQ0F0Yk8sS0FBSzt1RUEyYnVCLEtBQUssR0FBRSxXQUFXLElBQUksS0FBSzs7OztlQUEzRSw4QkFBYTs7NkNBM2JPLEtBQUssaUVBMmJGLEtBQUssRUFBQyxJQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7dUNBM2JiLEtBQUssaUVBMGJ0QixLQUFLLEVBQUMsSUFBSTs7Ozs7Ozs7Ozs7Ozs7aUVBS1AsRUFBRSxNQUFJLFFBQVE7OzthQURyQjs7Ozs7OzBDQUVDLEtBQUs7O1FBQ0wsUUFBUTs7Z0JBQ1IsSUFBSTs7OztnQkFDSixhQUFhOzs7O2dCQUNiLFNBQVM7Ozs7Z0JBQ1QsV0FBVzs7OztnQkFDWCxhQUFhOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQXRjTyxLQUFLOzJDQTJjMUIsT0FBTyxDQUFDLEdBQUcsdURBQUMsZUFBZSw0QkFBRSxLQUFLOzs7Ozs7Ozs7O2lDQTNjYixLQUFLO3lHQUN2QixLQUFLLEVBQUMsSUFBSSxFQUFLLElBQUk7O2lDQURELEtBQUs7eUdBR2xCLEtBQUssRUFBQyxJQUFJLEVBQUssU0FBUzs7aUNBSFgsS0FBSzt5R0FhbEIsS0FBSyxFQUFDLElBQUksRUFBSyxNQUFNOztpQ0FiUixLQUFLO3lHQXVDbEIsS0FBSyxFQUFDLElBQUksRUFBSyxPQUFPOztpQ0F2Q1QsS0FBSzt5R0E0SGxCLEtBQUssRUFBQyxJQUFJLEVBQUssWUFBWTs7aUNBNUhkLEtBQUs7eUdBbUpsQixLQUFLLEVBQUMsSUFBSSxFQUFLLE1BQU07O2lDQW5KUixLQUFLO3lHQXVQbEIsS0FBSyxFQUFDLElBQUksRUFBSyxjQUFjOztpQ0F2UGhCLEtBQUs7eUdBOFRsQixLQUFLLEVBQUMsSUFBSSxFQUFLLFNBQVM7O2lDQTlUWCxLQUFLO3lHQXNYbEIsS0FBSyxFQUFDLElBQUksRUFBSyxNQUFNOztpQ0F0WFIsS0FBSzt5R0F3WGxCLEtBQUssRUFBQyxJQUFJLEVBQUssUUFBUTs7aUNBeFhWLEtBQUs7eUdBcVlsQixLQUFLLEVBQUMsSUFBSSxFQUFLLFdBQVc7O2lDQXJZYixLQUFLO3lHQTJabEIsS0FBSyxFQUFDLElBQUksRUFBSyxNQUFNOztpQ0EzWlIsS0FBSzt5R0FxYmxCLEtBQUssRUFBQyxJQUFJLEVBQUssYUFBYTs7aUNBcmJmLEtBQUs7eUdBeWJsQixLQUFLLEVBQUMsSUFBSSxFQUFLLFlBQVk7O2lDQXpiZCxLQUFLO3lHQTZibEIsS0FBSyxFQUFDLElBQUksRUFBSyxZQUFZOztpQ0E3YmQsS0FBSzt5R0F3Y2xCLEtBQUssRUFBQyxJQUFJLEVBQUssT0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQTNjekIiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1hcmtkb3duVG9rZW5zLnN2ZWx0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IGxhbmc9XCJ0c1wiPlxuXHRpbXBvcnQgeyBkZWNvZGUgfSBmcm9tICdodG1sLWVudGl0aWVzJztcblx0aW1wb3J0IHsgb25Nb3VudCwgZ2V0Q29udGV4dCB9IGZyb20gJ3N2ZWx0ZSc7XG5cdGNvbnN0IGkxOG4gPSBnZXRDb250ZXh0KCdpMThuJyk7XG5cblx0aW1wb3J0IGZpbGVTYXZlciBmcm9tICdmaWxlLXNhdmVyJztcblx0Y29uc3QgeyBzYXZlQXMgfSA9IGZpbGVTYXZlcjtcblxuXHRpbXBvcnQgeyBtYXJrZWQsIHR5cGUgVG9rZW4gfSBmcm9tICdtYXJrZWQnO1xuXHRpbXBvcnQgeyBjb3B5VG9DbGlwYm9hcmQsIHVuZXNjYXBlSHRtbCB9IGZyb20gJyRsaWIvdXRpbHMnO1xuXHRpbXBvcnQgeyByZXNvbHZlQ2hhdE1lc3NhZ2VUb29sQ2FsbCB9IGZyb20gJyRsaWIvYXBpcy9jaGF0cyc7XG5cblx0aW1wb3J0IHsgV0VCVUlfQkFTRV9VUkwgfSBmcm9tICckbGliL2NvbnN0YW50cyc7XG5cdGltcG9ydCB7IHNldHRpbmdzIH0gZnJvbSAnJGxpYi9zdG9yZXMnO1xuXHRpbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3N2ZWx0ZS1zb25uZXInO1xuXG5cdGltcG9ydCBDb2RlQmxvY2sgZnJvbSAnJGxpYi9jb21wb25lbnRzL2NoYXQvTWVzc2FnZXMvQ29kZUJsb2NrLnN2ZWx0ZSc7XG5cdGltcG9ydCBNYXJrZG93bklubGluZVRva2VucyBmcm9tICckbGliL2NvbXBvbmVudHMvY2hhdC9NZXNzYWdlcy9NYXJrZG93bi9NYXJrZG93bklubGluZVRva2Vucy5zdmVsdGUnO1xuXHRpbXBvcnQgS2F0ZXhSZW5kZXJlciBmcm9tICcuL0thdGV4UmVuZGVyZXIuc3ZlbHRlJztcblx0aW1wb3J0IEFsZXJ0UmVuZGVyZXIsIHsgYWxlcnRDb21wb25lbnQgfSBmcm9tICcuL0FsZXJ0UmVuZGVyZXIuc3ZlbHRlJztcblx0aW1wb3J0IENvbGxhcHNpYmxlIGZyb20gJyRsaWIvY29tcG9uZW50cy9jb21tb24vQ29sbGFwc2libGUuc3ZlbHRlJztcblx0aW1wb3J0IFRvb2xDYWxsRGlzcGxheSBmcm9tICckbGliL2NvbXBvbmVudHMvY29tbW9uL1Rvb2xDYWxsRGlzcGxheS5zdmVsdGUnO1xuXHRpbXBvcnQgVG9vbHRpcCBmcm9tICckbGliL2NvbXBvbmVudHMvY29tbW9uL1Rvb2x0aXAuc3ZlbHRlJztcblx0aW1wb3J0IERvd25sb2FkIGZyb20gJyRsaWIvY29tcG9uZW50cy9pY29ucy9Eb3dubG9hZC5zdmVsdGUnO1xuXHRpbXBvcnQgQ29uc2VjdXRpdmVEZXRhaWxzR3JvdXAgZnJvbSAnLi9Db25zZWN1dGl2ZURldGFpbHNHcm91cC5zdmVsdGUnO1xuXG5cdGltcG9ydCBIdG1sVG9rZW4gZnJvbSAnLi9IVE1MVG9rZW4uc3ZlbHRlJztcblx0aW1wb3J0IENsaXBib2FyZCBmcm9tICckbGliL2NvbXBvbmVudHMvaWNvbnMvQ2xpcGJvYXJkLnN2ZWx0ZSc7XG5cdGltcG9ydCBDb2xvbkZlbmNlQmxvY2sgZnJvbSAnLi9Db2xvbkZlbmNlQmxvY2suc3ZlbHRlJztcblxuXHRleHBvcnQgbGV0IGlkOiBzdHJpbmc7XG5cdGV4cG9ydCBsZXQgY2hhdElkID0gJyc7XG5cdGV4cG9ydCBsZXQgbWVzc2FnZUlkID0gJyc7XG5cdGV4cG9ydCBsZXQgdG9rZW5zOiBUb2tlbltdO1xuXHRleHBvcnQgbGV0IHRvcCA9IHRydWU7XG5cdGV4cG9ydCBsZXQgYXR0cmlidXRlcyA9IHt9O1xuXHRleHBvcnQgbGV0IHNvdXJjZUlkcyA9IFtdO1xuXG5cdGV4cG9ydCBsZXQgZG9uZSA9IHRydWU7XG5cblx0ZXhwb3J0IGxldCBzYXZlID0gZmFsc2U7XG5cdGV4cG9ydCBsZXQgcHJldmlldyA9IGZhbHNlO1xuXHRleHBvcnQgbGV0IGNvbXBhY3RQcmV2aWV3ID0gZmFsc2U7XG5cblx0ZXhwb3J0IGxldCBwYXJhZ3JhcGhUYWcgPSAncCc7XG5cblx0ZXhwb3J0IGxldCBlZGl0Q29kZUJsb2NrID0gdHJ1ZTtcblx0ZXhwb3J0IGxldCB0b3BQYWRkaW5nID0gZmFsc2U7XG5cdGV4cG9ydCBsZXQgYWxsb3dFbWJlZHMgPSB0cnVlO1xuXG5cdGV4cG9ydCBsZXQgb25TYXZlOiBGdW5jdGlvbiA9ICgpID0+IHt9O1xuXHRleHBvcnQgbGV0IG9uVXBkYXRlOiBGdW5jdGlvbiA9ICgpID0+IHt9O1xuXHRleHBvcnQgbGV0IG9uUHJldmlldzogRnVuY3Rpb24gPSAoKSA9PiB7fTtcblxuXHRleHBvcnQgbGV0IG9uVGFza0NsaWNrOiBGdW5jdGlvbiA9ICgpID0+IHt9O1xuXHRleHBvcnQgbGV0IG9uU291cmNlQ2xpY2s6IEZ1bmN0aW9uID0gKCkgPT4ge307XG5cdGV4cG9ydCBsZXQgb25Ub29sQ2FsbFJlc29sdmVkOiBGdW5jdGlvbiA9ICgpID0+IHt9O1xuXG5cdGNvbnN0IGhlYWRlckNvbXBvbmVudCA9IChkZXB0aDogbnVtYmVyKSA9PiB7XG5cdFx0cmV0dXJuICdoJyArIGRlcHRoO1xuXHR9O1xuXG5cdGNvbnN0IEdST1VQQUJMRV9ERVRBSUxfVFlQRVMgPSBuZXcgU2V0KFsndG9vbF9jYWxscycsICdyZWFzb25pbmcnLCAnY29kZV9pbnRlcnByZXRlciddKTtcblxuXHRjb25zdCBpc0dyb3VwYWJsZURldGFpbFRva2VuID0gKHRva2VuOiBUb2tlbiAmIHsgYXR0cmlidXRlcz86IHsgdHlwZT86IHN0cmluZyB9IH0pID0+IHtcblx0XHRyZXR1cm4gdG9rZW4/LnR5cGUgPT09ICdkZXRhaWxzJyAmJiBHUk9VUEFCTEVfREVUQUlMX1RZUEVTLmhhcyh0b2tlbj8uYXR0cmlidXRlcz8udHlwZSA/PyAnJyk7XG5cdH07XG5cblx0Y29uc3QgZ2V0RGlzcGxheVRva2VucyA9ICh0b2tlbkxpc3Q6IFRva2VuW10gPSBbXSkgPT4ge1xuXHRcdGNvbnN0IGRpc3BsYXlUb2tlbnMgPSBbXTtcblx0XHRsZXQgZGV0YWlsR3JvdXAgPSBbXTtcblxuXHRcdGNvbnN0IGZsdXNoRGV0YWlsR3JvdXAgPSAoKSA9PiB7XG5cdFx0XHRpZiAoZGV0YWlsR3JvdXAubGVuZ3RoID4gMSkge1xuXHRcdFx0XHRkaXNwbGF5VG9rZW5zLnB1c2goe1xuXHRcdFx0XHRcdHR5cGU6ICdkZXRhaWxfZ3JvdXAnLFxuXHRcdFx0XHRcdGl0ZW1zOiBbLi4uZGV0YWlsR3JvdXBdXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSBlbHNlIGlmIChkZXRhaWxHcm91cC5sZW5ndGggPT09IDEpIHtcblx0XHRcdFx0ZGlzcGxheVRva2Vucy5wdXNoKGRldGFpbEdyb3VwWzBdKTtcblx0XHRcdH1cblxuXHRcdFx0ZGV0YWlsR3JvdXAgPSBbXTtcblx0XHR9O1xuXG5cdFx0Zm9yIChjb25zdCB0b2tlbiBvZiB0b2tlbkxpc3QpIHtcblx0XHRcdGlmIChpc0dyb3VwYWJsZURldGFpbFRva2VuKHRva2VuKSkge1xuXHRcdFx0XHRkZXRhaWxHcm91cC5wdXNoKHRva2VuKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGZsdXNoRGV0YWlsR3JvdXAoKTtcblx0XHRcdFx0ZGlzcGxheVRva2Vucy5wdXNoKHRva2VuKTtcblx0XHRcdH1cblx0XHR9XG5cblx0XHRmbHVzaERldGFpbEdyb3VwKCk7XG5cblx0XHRyZXR1cm4gZGlzcGxheVRva2Vucztcblx0fTtcblxuXHRjb25zdCBnZXREZXRhaWxUZXh0Q29udGVudCA9ICh0b2tlbikgPT4ge1xuXHRcdHJldHVybiBkZWNvZGUodG9rZW4/LnRleHQgfHwgJycpXG5cdFx0XHQucmVwbGFjZSgvPHN1bW1hcnk+Lio/PFxcL3N1bW1hcnk+L2dpLCAnJylcblx0XHRcdC50cmltKCk7XG5cdH07XG5cblx0bGV0IHJlc29sdmluZ0NhbGxJZCA9ICcnO1xuXG5cdGNvbnN0IHJlc29sdmVUb29sQ2FsbCA9IGFzeW5jIChjYWxsSWQ6IHN0cmluZywgYXBwcm92ZWQ6IGJvb2xlYW4pID0+IHtcblx0XHRpZiAoIWNoYXRJZCB8fCAhbWVzc2FnZUlkIHx8ICFjYWxsSWQgfHwgcmVzb2x2aW5nQ2FsbElkKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0cmVzb2x2aW5nQ2FsbElkID0gY2FsbElkO1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCByZXMgPSBhd2FpdCByZXNvbHZlQ2hhdE1lc3NhZ2VUb29sQ2FsbChcblx0XHRcdFx0bG9jYWxTdG9yYWdlLnRva2VuLFxuXHRcdFx0XHRjaGF0SWQsXG5cdFx0XHRcdG1lc3NhZ2VJZCxcblx0XHRcdFx0Y2FsbElkLFxuXHRcdFx0XHRhcHByb3ZlZCA/ICdhcHByb3ZlJyA6ICdyZWplY3QnXG5cdFx0XHQpO1xuXHRcdFx0b25Ub29sQ2FsbFJlc29sdmVkKHJlcyk7XG5cdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHR0b2FzdC5lcnJvcihTdHJpbmcoZXJyKSk7XG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdHJlc29sdmluZ0NhbGxJZCA9ICcnO1xuXHRcdH1cblx0fTtcblxuXHQkOiBkZXRhaWxCdXR0b25DbGFzc05hbWUgPSBgcHktMC41ICR7XG5cdFx0Y29tcGFjdFByZXZpZXcgPyAndGV4dC14cycgOiAndGV4dC1bMC45Mzc1cmVtXSdcblx0fSB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDAgZGFyazpob3Zlcjp0ZXh0LWdyYXktMzAwIHRyYW5zaXRpb25gO1xuXG5cdCQ6IGRpc3BsYXlUb2tlbnMgPSBnZXREaXNwbGF5VG9rZW5zKHRva2Vucyk7XG5cdCQ6IHNpbmdsZVBsYWluQmxvY2sgPVxuXHRcdGRpc3BsYXlUb2tlbnMubGVuZ3RoID09PSAxICYmXG5cdFx0KGRpc3BsYXlUb2tlbnNbMF0/LnR5cGUgPT09ICdwYXJhZ3JhcGgnIHx8IGRpc3BsYXlUb2tlbnNbMF0/LnR5cGUgPT09ICd0ZXh0Jyk7XG5cblx0Y29uc3QgZXhwb3J0VGFibGVUb0NTVkhhbmRsZXIgPSAodG9rZW4sIHRva2VuSWR4ID0gMCkgPT4ge1xuXHRcdGNvbnNvbGUubG9nKCdFeHBvcnRpbmcgdGFibGUgdG8gQ1NWJyk7XG5cblx0XHQvLyBFeHRyYWN0IGhlYWRlciByb3cgdGV4dCwgZGVjb2RlIEhUTUwgZW50aXRpZXMsIGFuZCBlc2NhcGUgZm9yIENTVi5cblx0XHRjb25zdCBoZWFkZXIgPSB0b2tlbi5oZWFkZXIubWFwKFxuXHRcdFx0KGhlYWRlckNlbGwpID0+IGBcIiR7ZGVjb2RlKGhlYWRlckNlbGwudGV4dCkucmVwbGFjZSgvXCIvZywgJ1wiXCInKX1cImBcblx0XHQpO1xuXG5cdFx0Ly8gQ3JlYXRlIGFuIGFycmF5IGZvciByb3dzIHRoYXQgd2lsbCBob2xkIHRoZSBtYXBwZWQgY2VsbCB0ZXh0LlxuXHRcdGNvbnN0IHJvd3MgPSB0b2tlbi5yb3dzLm1hcCgocm93KSA9PlxuXHRcdFx0cm93Lm1hcCgoY2VsbCkgPT4ge1xuXHRcdFx0XHQvLyBNYXAgdG9rZW5zIGludG8gYSBzaW5nbGUgdGV4dFxuXHRcdFx0XHRjb25zdCBjZWxsQ29udGVudCA9IGNlbGwudG9rZW5zLm1hcCgodG9rZW4pID0+IHRva2VuLnRleHQpLmpvaW4oJycpO1xuXHRcdFx0XHQvLyBEZWNvZGUgSFRNTCBlbnRpdGllcyBhbmQgZXNjYXBlIGRvdWJsZSBxdW90ZXMsIHdyYXAgaW4gZG91YmxlIHF1b3Rlc1xuXHRcdFx0XHRyZXR1cm4gYFwiJHtkZWNvZGUoY2VsbENvbnRlbnQpLnJlcGxhY2UoL1wiL2csICdcIlwiJyl9XCJgO1xuXHRcdFx0fSlcblx0XHQpO1xuXG5cdFx0Ly8gQ29tYmluZSBoZWFkZXIgYW5kIHJvd3Ncblx0XHRjb25zdCBjc3ZEYXRhID0gW2hlYWRlciwgLi4ucm93c107XG5cblx0XHQvLyBKb2luIHRoZSByb3dzIHVzaW5nIGNvbW1hcyAoLCkgYXMgdGhlIHNlcGFyYXRvciBhbmQgcm93cyB1c2luZyBuZXdsaW5lIChcXG4pLlxuXHRcdGNvbnN0IGNzdkNvbnRlbnQgPSBjc3ZEYXRhLm1hcCgocm93KSA9PiByb3cuam9pbignLCcpKS5qb2luKCdcXG4nKTtcblxuXHRcdC8vIExvZyByb3dzIGFuZCBDU1YgY29udGVudCB0byBlbnN1cmUgZXZlcnl0aGluZyBpcyBjb3JyZWN0LlxuXHRcdGNvbnNvbGUubG9nKGNzdkRhdGEpO1xuXHRcdGNvbnNvbGUubG9nKGNzdkNvbnRlbnQpO1xuXG5cdFx0Ly8gVG8gaGFuZGxlIFVuaWNvZGUgY2hhcmFjdGVycywgeW91IG5lZWQgdG8gcHJlZml4IHRoZSBkYXRhIHdpdGggYSBCT006XG5cdFx0Y29uc3QgYm9tID0gJ1xcdUZFRkYnOyAvLyBCT00gZm9yIFVURi04XG5cblx0XHQvLyBDcmVhdGUgYSBuZXcgQmxvYiBwcmVmaXhlZCB3aXRoIHRoZSBCT00gdG8gZW5zdXJlIHByb3BlciBVbmljb2RlIGVuY29kaW5nLlxuXHRcdGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbYm9tICsgY3N2Q29udGVudF0sIHsgdHlwZTogJ3RleHQvY3N2O2NoYXJzZXQ9VVRGLTgnIH0pO1xuXG5cdFx0Ly8gVXNlIEZpbGVTYXZlci5qcydzIHNhdmVBcyBmdW5jdGlvbiB0byBzYXZlIHRoZSBnZW5lcmF0ZWQgQ1NWIGZpbGUuXG5cdFx0c2F2ZUFzKGJsb2IsIGB0YWJsZS0ke2lkfS0ke3Rva2VuSWR4fS5jc3ZgKTtcblx0fTtcbjwvc2NyaXB0PlxuXG48IS0tIHtKU09OLnN0cmluZ2lmeSh0b2tlbnMpfSAtLT5cbnsjZWFjaCBkaXNwbGF5VG9rZW5zIGFzIHRva2VuLCB0b2tlbklkeCAodG9rZW5JZHgpfVxuXHR7I2lmIHRva2VuLnR5cGUgPT09ICdocid9XG5cdFx0PGhyIGNsYXNzPVwiYm9yZGVyLWdyYXktNTAgZGFyazpib3JkZXItZ3JheS04NTAvMzBcIiAvPlxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ2hlYWRpbmcnfVxuXHRcdDxzdmVsdGU6ZWxlbWVudCB0aGlzPXtoZWFkZXJDb21wb25lbnQodG9rZW4uZGVwdGgpfSBkaXI9XCJhdXRvXCI+XG5cdFx0XHQ8TWFya2Rvd25JbmxpbmVUb2tlbnNcblx0XHRcdFx0aWQ9e2Ake2lkfS0ke3Rva2VuSWR4fS1oYH1cblx0XHRcdFx0dG9rZW5zPXt0b2tlbi50b2tlbnN9XG5cdFx0XHRcdHtkb25lfVxuXHRcdFx0XHR7c291cmNlSWRzfVxuXHRcdFx0XHR7b25Tb3VyY2VDbGlja31cblx0XHRcdC8+XG5cdFx0PC9zdmVsdGU6ZWxlbWVudD5cblx0ezplbHNlIGlmIHRva2VuLnR5cGUgPT09ICdjb2RlJ31cblx0XHR7I2lmIHRva2VuLnJhdy5pbmNsdWRlcygnYGBgJyl9XG5cdFx0XHQ8Q29kZUJsb2NrXG5cdFx0XHRcdGlkPXtgJHtpZH0tJHt0b2tlbklkeH1gfVxuXHRcdFx0XHRjb2xsYXBzZWQ9eyRzZXR0aW5ncz8uY29sbGFwc2VDb2RlQmxvY2tzID8/IGZhbHNlfVxuXHRcdFx0XHR7dG9rZW59XG5cdFx0XHRcdGxhbmc9e3Rva2VuPy5sYW5nID8/ICcnfVxuXHRcdFx0XHRjb2RlPXt0b2tlbj8udGV4dCA/PyAnJ31cblx0XHRcdFx0e2F0dHJpYnV0ZXN9XG5cdFx0XHRcdHtzYXZlfVxuXHRcdFx0XHR7cHJldmlld31cblx0XHRcdFx0ZWRpdD17ZWRpdENvZGVCbG9ja31cblx0XHRcdFx0c3RpY2t5QnV0dG9uc0NsYXNzTmFtZT17dG9wUGFkZGluZyA/ICd0b3AtMTAnIDogJ3RvcC0wJ31cblx0XHRcdFx0b25TYXZlPXsodmFsdWUpID0+IHtcblx0XHRcdFx0XHRvblNhdmUoe1xuXHRcdFx0XHRcdFx0cmF3OiB0b2tlbi5yYXcsXG5cdFx0XHRcdFx0XHRvbGRDb250ZW50OiB0b2tlbi50ZXh0LFxuXHRcdFx0XHRcdFx0bmV3Q29udGVudDogdmFsdWVcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0fX1cblx0XHRcdFx0e29uVXBkYXRlfVxuXHRcdFx0XHR7b25QcmV2aWV3fVxuXHRcdFx0Lz5cblx0XHR7OmVsc2V9XG5cdFx0XHR7dG9rZW4udGV4dH1cblx0XHR7L2lmfVxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ3RhYmxlJ31cblx0XHQ8ZGl2IGNsYXNzPVwicmVsYXRpdmUgdy1mdWxsIGdyb3VwIG1iLTJcIj5cblx0XHRcdDxkaXYgY2xhc3M9XCJzY3JvbGxiYXItaGlkZGVuIHJlbGF0aXZlIG92ZXJmbG93LXgtYXV0byBtYXgtdy1mdWxsXCI+XG5cdFx0XHRcdDx0YWJsZVxuXHRcdFx0XHRcdGNsYXNzPVwiIHctZnVsbCB0ZXh0LXNtIHRleHQtc3RhcnQgdGV4dC1ncmF5LTUwMCBkYXJrOnRleHQtZ3JheS00MDAgbWF4LXctZnVsbCByb3VuZGVkLXhsXCJcblx0XHRcdFx0XHRkaXI9XCJhdXRvXCJcblx0XHRcdFx0PlxuXHRcdFx0XHRcdDx0aGVhZCBjbGFzcz1cInRleHQteHMgdGV4dC1ncmF5LTcwMCB1cHBlcmNhc2UgZGFyazp0ZXh0LWdyYXktNDAwIGJvcmRlci1ub25lXCI+XG5cdFx0XHRcdFx0XHQ8dHIgY2xhc3M9XCJcIj5cblx0XHRcdFx0XHRcdFx0eyNlYWNoIHRva2VuLmhlYWRlciBhcyBoZWFkZXIsIGhlYWRlcklkeH1cblx0XHRcdFx0XHRcdFx0XHQ8dGhcblx0XHRcdFx0XHRcdFx0XHRcdHNjb3BlPVwiY29sXCJcblx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzPVwicHgtMi41ISBweS0yISBjdXJzb3ItcG9pbnRlciBib3JkZXItYiBib3JkZXItZ3JheS0xMDAhIGRhcms6Ym9yZGVyLWdyYXktODAwIVwiXG5cdFx0XHRcdFx0XHRcdFx0XHRzdHlsZT17dG9rZW4uYWxpZ25baGVhZGVySWR4XSA/IGB0ZXh0LWFsaWduOiAke3Rva2VuLmFsaWduW2hlYWRlcklkeF19YCA6ICcnfVxuXHRcdFx0XHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJnYXAtMS41IHRleHQtc3RhcnRcIj5cblx0XHRcdFx0XHRcdFx0XHRcdFx0PGRpdiBjbGFzcz1cInNocmluay0wIGJyZWFrLW5vcm1hbFwiPlxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdDxNYXJrZG93bklubGluZVRva2Vuc1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0aWQ9e2Ake2lkfS0ke3Rva2VuSWR4fS1oZWFkZXItJHtoZWFkZXJJZHh9YH1cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHRva2Vucz17aGVhZGVyLnRva2Vuc31cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHtkb25lfVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0e3NvdXJjZUlkc31cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHtvblNvdXJjZUNsaWNrfVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHRcdFx0PC90aD5cblx0XHRcdFx0XHRcdFx0ey9lYWNofVxuXHRcdFx0XHRcdFx0PC90cj5cblx0XHRcdFx0XHQ8L3RoZWFkPlxuXHRcdFx0XHRcdDx0Ym9keT5cblx0XHRcdFx0XHRcdHsjZWFjaCB0b2tlbi5yb3dzIGFzIHJvdywgcm93SWR4fVxuXHRcdFx0XHRcdFx0XHQ8dHIgY2xhc3M9XCJ0ZXh0LXhzXCI+XG5cdFx0XHRcdFx0XHRcdFx0eyNlYWNoIHJvdyA/PyBbXSBhcyBjZWxsLCBjZWxsSWR4fVxuXHRcdFx0XHRcdFx0XHRcdFx0PHRkXG5cdFx0XHRcdFx0XHRcdFx0XHRcdGNsYXNzPVwicHgtMyEgcHktMiEgdGV4dC1ncmF5LTkwMCBkYXJrOnRleHQtd2hpdGUgdy1tYXgge3Rva2VuLnJvd3MubGVuZ3RoIC1cblx0XHRcdFx0XHRcdFx0XHRcdFx0XHQxID09PVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRyb3dJZHhcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHQ/ICcnXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0OiAnYm9yZGVyLWIgYm9yZGVyLWdyYXktNTAhIGRhcms6Ym9yZGVyLWdyYXktODUwISd9XCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0c3R5bGU9e3Rva2VuLmFsaWduW2NlbGxJZHhdID8gYHRleHQtYWxpZ246ICR7dG9rZW4uYWxpZ25bY2VsbElkeF19YCA6ICcnfVxuXHRcdFx0XHRcdFx0XHRcdFx0PlxuXHRcdFx0XHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwiYnJlYWstbm9ybWFsXCI+XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0PE1hcmtkb3duSW5saW5lVG9rZW5zXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRpZD17YCR7aWR9LSR7dG9rZW5JZHh9LXJvdy0ke3Jvd0lkeH0tJHtjZWxsSWR4fWB9XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR0b2tlbnM9e2NlbGwudG9rZW5zfVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0e2RvbmV9XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHR7c291cmNlSWRzfVxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0e29uU291cmNlQ2xpY2t9XG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0Lz5cblx0XHRcdFx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHRcdFx0XHQ8L3RkPlxuXHRcdFx0XHRcdFx0XHRcdHsvZWFjaH1cblx0XHRcdFx0XHRcdFx0PC90cj5cblx0XHRcdFx0XHRcdHsvZWFjaH1cblx0XHRcdFx0XHQ8L3Rib2R5PlxuXHRcdFx0XHQ8L3RhYmxlPlxuXHRcdFx0PC9kaXY+XG5cblx0XHRcdDxkaXYgY2xhc3M9XCIgYWJzb2x1dGUgdG9wLTEgcmlnaHQtMS41IHotMjAgaG92ZXItcmV2ZWFsIGZsZXggZ2FwLTAuNVwiPlxuXHRcdFx0XHQ8VG9vbHRpcCBjb250ZW50PXskaTE4bi50KCdDb3B5Jyl9PlxuXHRcdFx0XHRcdDxidXR0b25cblx0XHRcdFx0XHRcdGNsYXNzPVwicC0xIHJvdW5kZWQtbGcgYmctdHJhbnNwYXJlbnQgdHJhbnNpdGlvblwiXG5cdFx0XHRcdFx0XHRvbjpjbGljaz17KGUpID0+IHtcblx0XHRcdFx0XHRcdFx0ZS5zdG9wUHJvcGFnYXRpb24oKTtcblx0XHRcdFx0XHRcdFx0Y29weVRvQ2xpcGJvYXJkKHRva2VuLnJhdy50cmltKCksIG51bGwsICRzZXR0aW5ncz8uY29weUZvcm1hdHRlZCA/PyBmYWxzZSk7XG5cdFx0XHRcdFx0XHR9fVxuXHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdDxDbGlwYm9hcmQgY2xhc3NOYW1lPVwiIHNpemUtMy41XCIgc3Ryb2tlV2lkdGg9XCIxLjVcIiAvPlxuXHRcdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHQ8L1Rvb2x0aXA+XG5cblx0XHRcdFx0PFRvb2x0aXAgY29udGVudD17JGkxOG4udCgnRXhwb3J0IHRvIENTVicpfT5cblx0XHRcdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdFx0XHRjbGFzcz1cInAtMSByb3VuZGVkLWxnIGJnLXRyYW5zcGFyZW50IHRyYW5zaXRpb25cIlxuXHRcdFx0XHRcdFx0b246Y2xpY2s9eyhlKSA9PiB7XG5cdFx0XHRcdFx0XHRcdGUuc3RvcFByb3BhZ2F0aW9uKCk7XG5cdFx0XHRcdFx0XHRcdGV4cG9ydFRhYmxlVG9DU1ZIYW5kbGVyKHRva2VuLCB0b2tlbklkeCk7XG5cdFx0XHRcdFx0XHR9fVxuXHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdDxEb3dubG9hZCBjbGFzc05hbWU9XCIgc2l6ZS0zLjVcIiBzdHJva2VXaWR0aD1cIjEuNVwiIC8+XG5cdFx0XHRcdFx0PC9idXR0b24+XG5cdFx0XHRcdDwvVG9vbHRpcD5cblx0XHRcdDwvZGl2PlxuXHRcdDwvZGl2PlxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ2Jsb2NrcXVvdGUnfVxuXHRcdHtAY29uc3QgYWxlcnQgPSBhbGVydENvbXBvbmVudCh0b2tlbil9XG5cdFx0eyNpZiBhbGVydH1cblx0XHRcdDxBbGVydFJlbmRlcmVyIHt0b2tlbn0ge2FsZXJ0fSAvPlxuXHRcdHs6ZWxzZX1cblx0XHRcdDxibG9ja3F1b3RlIGRpcj1cImF1dG9cIj5cblx0XHRcdFx0PHN2ZWx0ZTpzZWxmXG5cdFx0XHRcdFx0aWQ9e2Ake2lkfS0ke3Rva2VuSWR4fWB9XG5cdFx0XHRcdFx0e2NoYXRJZH1cblx0XHRcdFx0XHR7bWVzc2FnZUlkfVxuXHRcdFx0XHRcdHRva2Vucz17dG9rZW4udG9rZW5zfVxuXHRcdFx0XHRcdHtkb25lfVxuXHRcdFx0XHRcdHtzYXZlfVxuXHRcdFx0XHRcdHtwcmV2aWV3fVxuXHRcdFx0XHRcdHtjb21wYWN0UHJldmlld31cblx0XHRcdFx0XHR7ZWRpdENvZGVCbG9ja31cblx0XHRcdFx0XHR7b25UYXNrQ2xpY2t9XG5cdFx0XHRcdFx0e3NvdXJjZUlkc31cblx0XHRcdFx0XHR7b25Tb3VyY2VDbGlja31cblx0XHRcdFx0XHR7b25Ub29sQ2FsbFJlc29sdmVkfVxuXHRcdFx0XHQvPlxuXHRcdFx0PC9ibG9ja3F1b3RlPlxuXHRcdHsvaWZ9XG5cdHs6ZWxzZSBpZiB0b2tlbi50eXBlID09PSAnbGlzdCd9XG5cdFx0eyNpZiB0b2tlbi5vcmRlcmVkfVxuXHRcdFx0PG9sIHN0YXJ0PXt0b2tlbi5zdGFydCB8fCAxfSBkaXI9XCJhdXRvXCI+XG5cdFx0XHRcdHsjZWFjaCB0b2tlbi5pdGVtcyBhcyBpdGVtLCBpdGVtSWR4fVxuXHRcdFx0XHRcdDxsaSBjbGFzcz1cInRleHQtc3RhcnRcIj5cblx0XHRcdFx0XHRcdHsjaWYgaXRlbT8udGFza31cblx0XHRcdFx0XHRcdFx0PGlucHV0XG5cdFx0XHRcdFx0XHRcdFx0Y2xhc3M9XCIgdHJhbnNsYXRlLXktWzFweF0gLXRyYW5zbGF0ZS14LTEgZmxleC1zaHJpbmstMFwiXG5cdFx0XHRcdFx0XHRcdFx0dHlwZT1cImNoZWNrYm94XCJcblx0XHRcdFx0XHRcdFx0XHRjaGVja2VkPXtpdGVtLmNoZWNrZWR9XG5cdFx0XHRcdFx0XHRcdFx0b246Y2hhbmdlPXsoZSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0b25UYXNrQ2xpY2soe1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRpZDogaWQsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdHRva2VuOiB0b2tlbixcblx0XHRcdFx0XHRcdFx0XHRcdFx0dG9rZW5JZHg6IHRva2VuSWR4LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRpdGVtOiBpdGVtLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRpdGVtSWR4OiBpdGVtSWR4LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRjaGVja2VkOiBlLnRhcmdldC5jaGVja2VkXG5cdFx0XHRcdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRcdFx0XHR9fVxuXHRcdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdFx0ey9pZn1cblxuXHRcdFx0XHRcdFx0PHN2ZWx0ZTpzZWxmXG5cdFx0XHRcdFx0XHRcdGlkPXtgJHtpZH0tJHt0b2tlbklkeH0tJHtpdGVtSWR4fWB9XG5cdFx0XHRcdFx0XHRcdHtjaGF0SWR9XG5cdFx0XHRcdFx0XHRcdHttZXNzYWdlSWR9XG5cdFx0XHRcdFx0XHRcdHRva2Vucz17aXRlbS50b2tlbnN9XG5cdFx0XHRcdFx0XHRcdHRvcD17dG9rZW4ubG9vc2V9XG5cdFx0XHRcdFx0XHRcdHtkb25lfVxuXHRcdFx0XHRcdFx0XHR7c2F2ZX1cblx0XHRcdFx0XHRcdFx0e3ByZXZpZXd9XG5cdFx0XHRcdFx0XHRcdHtjb21wYWN0UHJldmlld31cblx0XHRcdFx0XHRcdFx0e2VkaXRDb2RlQmxvY2t9XG5cdFx0XHRcdFx0XHRcdHtvblRhc2tDbGlja31cblx0XHRcdFx0XHRcdFx0e3NvdXJjZUlkc31cblx0XHRcdFx0XHRcdFx0e29uU291cmNlQ2xpY2t9XG5cdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdDwvbGk+XG5cdFx0XHRcdHsvZWFjaH1cblx0XHRcdDwvb2w+XG5cdFx0ezplbHNlfVxuXHRcdFx0PHVsIGRpcj1cImF1dG9cIiBjbGFzcz1cIlwiPlxuXHRcdFx0XHR7I2VhY2ggdG9rZW4uaXRlbXMgYXMgaXRlbSwgaXRlbUlkeH1cblx0XHRcdFx0XHQ8bGkgY2xhc3M9XCJ0ZXh0LXN0YXJ0IHtpdGVtPy50YXNrID8gJ2ZsZXggLXRyYW5zbGF0ZS14LTYuNSBnYXAtMyAnIDogJyd9XCI+XG5cdFx0XHRcdFx0XHR7I2lmIGl0ZW0/LnRhc2t9XG5cdFx0XHRcdFx0XHRcdDxpbnB1dFxuXHRcdFx0XHRcdFx0XHRcdGNsYXNzPVwiZmxleC1zaHJpbmstMFwiXG5cdFx0XHRcdFx0XHRcdFx0dHlwZT1cImNoZWNrYm94XCJcblx0XHRcdFx0XHRcdFx0XHRjaGVja2VkPXtpdGVtLmNoZWNrZWR9XG5cdFx0XHRcdFx0XHRcdFx0b246Y2hhbmdlPXsoZSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0b25UYXNrQ2xpY2soe1xuXHRcdFx0XHRcdFx0XHRcdFx0XHRpZDogaWQsXG5cdFx0XHRcdFx0XHRcdFx0XHRcdHRva2VuOiB0b2tlbixcblx0XHRcdFx0XHRcdFx0XHRcdFx0dG9rZW5JZHg6IHRva2VuSWR4LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRpdGVtOiBpdGVtLFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRpdGVtSWR4OiBpdGVtSWR4LFxuXHRcdFx0XHRcdFx0XHRcdFx0XHRjaGVja2VkOiBlLnRhcmdldC5jaGVja2VkXG5cdFx0XHRcdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRcdFx0XHR9fVxuXHRcdFx0XHRcdFx0XHQvPlxuXG5cdFx0XHRcdFx0XHRcdDxkaXY+XG5cdFx0XHRcdFx0XHRcdFx0PHN2ZWx0ZTpzZWxmXG5cdFx0XHRcdFx0XHRcdFx0XHRpZD17YCR7aWR9LSR7dG9rZW5JZHh9LSR7aXRlbUlkeH1gfVxuXHRcdFx0XHRcdFx0XHRcdFx0e2NoYXRJZH1cblx0XHRcdFx0XHRcdFx0XHRcdHttZXNzYWdlSWR9XG5cdFx0XHRcdFx0XHRcdFx0XHR0b2tlbnM9e2l0ZW0udG9rZW5zfVxuXHRcdFx0XHRcdFx0XHRcdFx0dG9wPXt0b2tlbi5sb29zZX1cblx0XHRcdFx0XHRcdFx0XHRcdHtkb25lfVxuXHRcdFx0XHRcdFx0XHRcdFx0e3NhdmV9XG5cdFx0XHRcdFx0XHRcdFx0XHR7cHJldmlld31cblx0XHRcdFx0XHRcdFx0XHRcdHtjb21wYWN0UHJldmlld31cblx0XHRcdFx0XHRcdFx0XHRcdHtlZGl0Q29kZUJsb2NrfVxuXHRcdFx0XHRcdFx0XHRcdFx0e29uVGFza0NsaWNrfVxuXHRcdFx0XHRcdFx0XHRcdFx0e3NvdXJjZUlkc31cblx0XHRcdFx0XHRcdFx0XHRcdHtvblNvdXJjZUNsaWNrfVxuXHRcdFx0XHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdFx0ezplbHNlfVxuXHRcdFx0XHRcdFx0XHQ8c3ZlbHRlOnNlbGZcblx0XHRcdFx0XHRcdFx0XHRpZD17YCR7aWR9LSR7dG9rZW5JZHh9LSR7aXRlbUlkeH1gfVxuXHRcdFx0XHRcdFx0XHRcdHtjaGF0SWR9XG5cdFx0XHRcdFx0XHRcdFx0e21lc3NhZ2VJZH1cblx0XHRcdFx0XHRcdFx0XHR0b2tlbnM9e2l0ZW0udG9rZW5zfVxuXHRcdFx0XHRcdFx0XHRcdHRvcD17dG9rZW4ubG9vc2V9XG5cdFx0XHRcdFx0XHRcdFx0e2RvbmV9XG5cdFx0XHRcdFx0XHRcdFx0e3NhdmV9XG5cdFx0XHRcdFx0XHRcdFx0e3ByZXZpZXd9XG5cdFx0XHRcdFx0XHRcdFx0e2NvbXBhY3RQcmV2aWV3fVxuXHRcdFx0XHRcdFx0XHRcdHtlZGl0Q29kZUJsb2NrfVxuXHRcdFx0XHRcdFx0XHRcdHtvblRhc2tDbGlja31cblx0XHRcdFx0XHRcdFx0XHR7c291cmNlSWRzfVxuXHRcdFx0XHRcdFx0XHRcdHtvblNvdXJjZUNsaWNrfVxuXHRcdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdFx0ey9pZn1cblx0XHRcdFx0XHQ8L2xpPlxuXHRcdFx0XHR7L2VhY2h9XG5cdFx0XHQ8L3VsPlxuXHRcdHsvaWZ9XG5cdHs6ZWxzZSBpZiB0b2tlbi50eXBlID09PSAnZGV0YWlsX2dyb3VwJ31cblx0XHQ8Q29uc2VjdXRpdmVEZXRhaWxzR3JvdXBcblx0XHRcdGlkPXtgJHtpZH0tJHt0b2tlbklkeH0tZGV0YWlsLWdyb3VwYH1cblx0XHRcdHRva2Vucz17dG9rZW4uaXRlbXN9XG5cdFx0XHRtZXNzYWdlRG9uZT17ZG9uZX1cblx0XHRcdHtjb21wYWN0UHJldmlld31cblx0XHRcdHthbGxvd0VtYmVkc31cblx0XHRcdHJlc29sdmFibGU9eyEhY2hhdElkICYmICEhbWVzc2FnZUlkICYmIHNhdmV9XG5cdFx0XHR7cmVzb2x2aW5nQ2FsbElkfVxuXHRcdFx0b25SZXNvbHZlPXtyZXNvbHZlVG9vbENhbGx9XG5cdFx0PlxuXHRcdFx0PGRpdiBzbG90PVwiY29udGVudFwiPlxuXHRcdFx0XHR7I2VhY2ggdG9rZW4uaXRlbXMgYXMgZGV0YWlsVG9rZW4sIGRldGFpbElkeH1cblx0XHRcdFx0XHR7QGNvbnN0IHRleHRDb250ZW50ID0gZ2V0RGV0YWlsVGV4dENvbnRlbnQoZGV0YWlsVG9rZW4pfVxuXG5cdFx0XHRcdFx0eyNpZiBkZXRhaWxUb2tlbj8uYXR0cmlidXRlcz8udHlwZSA9PT0gJ3Rvb2xfY2FsbHMnfVxuXHRcdFx0XHRcdFx0PFRvb2xDYWxsRGlzcGxheVxuXHRcdFx0XHRcdFx0XHRpZD17YCR7aWR9LSR7dG9rZW5JZHh9LSR7ZGV0YWlsSWR4fS10Y2B9XG5cdFx0XHRcdFx0XHRcdGF0dHJpYnV0ZXM9e2RldGFpbFRva2VuLmF0dHJpYnV0ZXN9XG5cdFx0XHRcdFx0XHRcdHJlc3VsdENvbnRlbnQ9e2dldERldGFpbFRleHRDb250ZW50KGRldGFpbFRva2VuKX1cblx0XHRcdFx0XHRcdFx0Z3JvdXBlZD17dHJ1ZX1cblx0XHRcdFx0XHRcdFx0cmVzb2x2YWJsZT17ISFjaGF0SWQgJiYgISFtZXNzYWdlSWQgJiYgc2F2ZX1cblx0XHRcdFx0XHRcdFx0cmVzb2x2aW5nPXtyZXNvbHZpbmdDYWxsSWQgPT09IGRldGFpbFRva2VuLmF0dHJpYnV0ZXM/LmlkfVxuXHRcdFx0XHRcdFx0XHRvblJlc29sdmU9eyhhcHByb3ZlZCkgPT4gcmVzb2x2ZVRvb2xDYWxsKGRldGFpbFRva2VuLmF0dHJpYnV0ZXM/LmlkID8/ICcnLCBhcHByb3ZlZCl9XG5cdFx0XHRcdFx0XHRcdG9wZW49eyRzZXR0aW5ncz8uZXhwYW5kRGV0YWlscyA/PyBmYWxzZX1cblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lPVwidy1mdWxsXCJcblx0XHRcdFx0XHRcdFx0YnV0dG9uQ2xhc3NOYW1lPXtkZXRhaWxCdXR0b25DbGFzc05hbWV9XG5cdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdHs6ZWxzZSBpZiB0ZXh0Q29udGVudC5sZW5ndGggPiAwfVxuXHRcdFx0XHRcdFx0PENvbGxhcHNpYmxlXG5cdFx0XHRcdFx0XHRcdHRpdGxlPXtkZXRhaWxUb2tlbi5zdW1tYXJ5fVxuXHRcdFx0XHRcdFx0XHRvcGVuPXskc2V0dGluZ3M/LmV4cGFuZERldGFpbHMgPz8gZmFsc2V9XG5cdFx0XHRcdFx0XHRcdGF0dHJpYnV0ZXM9e2RldGFpbFRva2VuPy5hdHRyaWJ1dGVzfVxuXHRcdFx0XHRcdFx0XHRtZXNzYWdlRG9uZT17ZG9uZX1cblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lPVwidy1mdWxsXCJcblx0XHRcdFx0XHRcdFx0YnV0dG9uQ2xhc3NOYW1lPXtkZXRhaWxCdXR0b25DbGFzc05hbWV9XG5cdFx0XHRcdFx0XHRcdGRpcj1cImF1dG9cIlxuXHRcdFx0XHRcdFx0PlxuXHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwibWItMS41XCIgc2xvdD1cImNvbnRlbnRcIj5cblx0XHRcdFx0XHRcdFx0XHQ8c3ZlbHRlOnNlbGZcblx0XHRcdFx0XHRcdFx0XHRcdGlkPXtgJHtpZH0tJHt0b2tlbklkeH0tJHtkZXRhaWxJZHh9LWRgfVxuXHRcdFx0XHRcdFx0XHRcdFx0e2NoYXRJZH1cblx0XHRcdFx0XHRcdFx0XHRcdHttZXNzYWdlSWR9XG5cdFx0XHRcdFx0XHRcdFx0XHR0b2tlbnM9e21hcmtlZC5sZXhlcihkZWNvZGUoZGV0YWlsVG9rZW4udGV4dCkpfVxuXHRcdFx0XHRcdFx0XHRcdFx0YXR0cmlidXRlcz17ZGV0YWlsVG9rZW4/LmF0dHJpYnV0ZXN9XG5cdFx0XHRcdFx0XHRcdFx0XHR7ZG9uZX1cblx0XHRcdFx0XHRcdFx0XHRcdHtzYXZlfVxuXHRcdFx0XHRcdFx0XHRcdFx0e3ByZXZpZXd9XG5cdFx0XHRcdFx0XHRcdFx0XHR7Y29tcGFjdFByZXZpZXd9XG5cdFx0XHRcdFx0XHRcdFx0XHR7ZWRpdENvZGVCbG9ja31cblx0XHRcdFx0XHRcdFx0XHRcdHtvblRhc2tDbGlja31cblx0XHRcdFx0XHRcdFx0XHRcdHtzb3VyY2VJZHN9XG5cdFx0XHRcdFx0XHRcdFx0XHR7b25Tb3VyY2VDbGlja31cblx0XHRcdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHRcdDwvQ29sbGFwc2libGU+XG5cdFx0XHRcdFx0ezplbHNlfVxuXHRcdFx0XHRcdFx0PENvbGxhcHNpYmxlXG5cdFx0XHRcdFx0XHRcdHRpdGxlPXtkZXRhaWxUb2tlbi5zdW1tYXJ5fVxuXHRcdFx0XHRcdFx0XHRvcGVuPXtmYWxzZX1cblx0XHRcdFx0XHRcdFx0ZGlzYWJsZWQ9e3RydWV9XG5cdFx0XHRcdFx0XHRcdGF0dHJpYnV0ZXM9e2RldGFpbFRva2VuPy5hdHRyaWJ1dGVzfVxuXHRcdFx0XHRcdFx0XHRtZXNzYWdlRG9uZT17ZG9uZX1cblx0XHRcdFx0XHRcdFx0Y2xhc3NOYW1lPVwidy1mdWxsXCJcblx0XHRcdFx0XHRcdFx0YnV0dG9uQ2xhc3NOYW1lPXtkZXRhaWxCdXR0b25DbGFzc05hbWV9XG5cdFx0XHRcdFx0XHRcdGRpcj1cImF1dG9cIlxuXHRcdFx0XHRcdFx0Lz5cblx0XHRcdFx0XHR7L2lmfVxuXHRcdFx0XHR7L2VhY2h9XG5cdFx0XHQ8L2Rpdj5cblx0XHQ8L0NvbnNlY3V0aXZlRGV0YWlsc0dyb3VwPlxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ2RldGFpbHMnfVxuXHRcdHtAY29uc3QgdGV4dENvbnRlbnQgPSBnZXREZXRhaWxUZXh0Q29udGVudCh0b2tlbil9XG5cblx0XHR7I2lmIHRva2VuPy5hdHRyaWJ1dGVzPy50eXBlID09PSAndG9vbF9jYWxscyd9XG5cdFx0XHQ8IS0tIFRvb2wgY2FsbHMgaGF2ZSBkZWRpY2F0ZWQgaGFuZGxpbmcgd2l0aCBUb29sQ2FsbERpc3BsYXkgY29tcG9uZW50IC0tPlxuXHRcdFx0PFRvb2xDYWxsRGlzcGxheVxuXHRcdFx0XHRpZD17YCR7aWR9LSR7dG9rZW5JZHh9LXRjYH1cblx0XHRcdFx0YXR0cmlidXRlcz17dG9rZW4uYXR0cmlidXRlc31cblx0XHRcdFx0cmVzdWx0Q29udGVudD17Z2V0RGV0YWlsVGV4dENvbnRlbnQodG9rZW4pfVxuXHRcdFx0XHRyZXNvbHZhYmxlPXshIWNoYXRJZCAmJiAhIW1lc3NhZ2VJZCAmJiBzYXZlfVxuXHRcdFx0XHRyZXNvbHZpbmc9e3Jlc29sdmluZ0NhbGxJZCA9PT0gdG9rZW4uYXR0cmlidXRlcz8uaWR9XG5cdFx0XHRcdG9uUmVzb2x2ZT17KGFwcHJvdmVkKSA9PiByZXNvbHZlVG9vbENhbGwodG9rZW4uYXR0cmlidXRlcz8uaWQgPz8gJycsIGFwcHJvdmVkKX1cblx0XHRcdFx0b3Blbj17JHNldHRpbmdzPy5leHBhbmREZXRhaWxzID8/IGZhbHNlfVxuXHRcdFx0XHRjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS0yXCJcblx0XHRcdFx0YnV0dG9uQ2xhc3NOYW1lPXtkZXRhaWxCdXR0b25DbGFzc05hbWV9XG5cdFx0XHQvPlxuXHRcdHs6ZWxzZSBpZiB0ZXh0Q29udGVudC5sZW5ndGggPiAwfVxuXHRcdFx0PENvbGxhcHNpYmxlXG5cdFx0XHRcdHRpdGxlPXt0b2tlbi5zdW1tYXJ5fVxuXHRcdFx0XHRvcGVuPXskc2V0dGluZ3M/LmV4cGFuZERldGFpbHMgPz8gZmFsc2V9XG5cdFx0XHRcdGF0dHJpYnV0ZXM9e3Rva2VuPy5hdHRyaWJ1dGVzfVxuXHRcdFx0XHRtZXNzYWdlRG9uZT17ZG9uZX1cblx0XHRcdFx0Y2xhc3NOYW1lPVwidy1mdWxsIHNwYWNlLXktMlwiXG5cdFx0XHRcdGJ1dHRvbkNsYXNzTmFtZT17ZGV0YWlsQnV0dG9uQ2xhc3NOYW1lfVxuXHRcdFx0XHRkaXI9XCJhdXRvXCJcblx0XHRcdD5cblx0XHRcdFx0PGRpdiBjbGFzcz1cIiBtYi0xLjVcIiBzbG90PVwiY29udGVudFwiPlxuXHRcdFx0XHRcdDxzdmVsdGU6c2VsZlxuXHRcdFx0XHRcdFx0aWQ9e2Ake2lkfS0ke3Rva2VuSWR4fS1kYH1cblx0XHRcdFx0XHRcdHtjaGF0SWR9XG5cdFx0XHRcdFx0XHR7bWVzc2FnZUlkfVxuXHRcdFx0XHRcdFx0dG9rZW5zPXttYXJrZWQubGV4ZXIoZGVjb2RlKHRva2VuLnRleHQpKX1cblx0XHRcdFx0XHRcdGF0dHJpYnV0ZXM9e3Rva2VuPy5hdHRyaWJ1dGVzfVxuXHRcdFx0XHRcdFx0e2RvbmV9XG5cdFx0XHRcdFx0XHR7c2F2ZX1cblx0XHRcdFx0XHRcdHtwcmV2aWV3fVxuXHRcdFx0XHRcdFx0e2NvbXBhY3RQcmV2aWV3fVxuXHRcdFx0XHRcdFx0e2VkaXRDb2RlQmxvY2t9XG5cdFx0XHRcdFx0XHR7b25UYXNrQ2xpY2t9XG5cdFx0XHRcdFx0XHR7c291cmNlSWRzfVxuXHRcdFx0XHRcdFx0e29uU291cmNlQ2xpY2t9XG5cdFx0XHRcdFx0Lz5cblx0XHRcdFx0PC9kaXY+XG5cdFx0XHQ8L0NvbGxhcHNpYmxlPlxuXHRcdHs6ZWxzZX1cblx0XHRcdDxDb2xsYXBzaWJsZVxuXHRcdFx0XHR0aXRsZT17dG9rZW4uc3VtbWFyeX1cblx0XHRcdFx0b3Blbj17ZmFsc2V9XG5cdFx0XHRcdGRpc2FibGVkPXt0cnVlfVxuXHRcdFx0XHRhdHRyaWJ1dGVzPXt0b2tlbj8uYXR0cmlidXRlc31cblx0XHRcdFx0bWVzc2FnZURvbmU9e2RvbmV9XG5cdFx0XHRcdGNsYXNzTmFtZT1cInctZnVsbCBzcGFjZS15LTJcIlxuXHRcdFx0XHRidXR0b25DbGFzc05hbWU9e2RldGFpbEJ1dHRvbkNsYXNzTmFtZX1cblx0XHRcdFx0ZGlyPVwiYXV0b1wiXG5cdFx0XHQvPlxuXHRcdHsvaWZ9XG5cdHs6ZWxzZSBpZiB0b2tlbi50eXBlID09PSAnaHRtbCd9XG5cdFx0PEh0bWxUb2tlbiB7aWR9IHt0b2tlbn0ge29uU291cmNlQ2xpY2t9IC8+XG5cdHs6ZWxzZSBpZiB0b2tlbi50eXBlID09PSAnaWZyYW1lJ31cblx0XHQ8aWZyYW1lXG5cdFx0XHRzcmM9XCJ7V0VCVUlfQkFTRV9VUkx9L2FwaS92MS9maWxlcy97dG9rZW4uZmlsZUlkfS9jb250ZW50XCJcblx0XHRcdHRpdGxlPXt0b2tlbi5maWxlSWR9XG5cdFx0XHR3aWR0aD1cIjEwMCVcIlxuXHRcdFx0ZnJhbWVib3JkZXI9XCIwXCJcblx0XHRcdG9uOmxvYWQ9eyhlKSA9PiB7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0ZS5jdXJyZW50VGFyZ2V0LnN0eWxlLmhlaWdodCA9XG5cdFx0XHRcdFx0XHRlLmN1cnJlbnRUYXJnZXQuY29udGVudFdpbmRvdy5kb2N1bWVudC5ib2R5LnNjcm9sbEhlaWdodCArIDIwICsgJ3B4Jztcblx0XHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0fX1cblx0XHQ+PC9pZnJhbWU+XG5cdHs6ZWxzZSBpZiB0b2tlbi50eXBlID09PSAncGFyYWdyYXBoJ31cblx0XHR7I2lmIHBhcmFncmFwaFRhZyA9PSAnc3Bhbid9XG5cdFx0XHQ8c3BhbiBkaXI9XCJhdXRvXCI+XG5cdFx0XHRcdDxNYXJrZG93bklubGluZVRva2Vuc1xuXHRcdFx0XHRcdGlkPXtgJHtpZH0tJHt0b2tlbklkeH0tcGB9XG5cdFx0XHRcdFx0dG9rZW5zPXt0b2tlbi50b2tlbnMgPz8gW119XG5cdFx0XHRcdFx0e2RvbmV9XG5cdFx0XHRcdFx0e3NvdXJjZUlkc31cblx0XHRcdFx0XHR7b25Tb3VyY2VDbGlja31cblx0XHRcdFx0Lz5cblx0XHRcdDwvc3Bhbj5cblx0XHR7OmVsc2V9XG5cdFx0XHQ8cCBkaXI9XCJhdXRvXCIgY2xhc3M9e3NpbmdsZVBsYWluQmxvY2sgPyAnIW15LTAnIDogJyd9PlxuXHRcdFx0XHQ8TWFya2Rvd25JbmxpbmVUb2tlbnNcblx0XHRcdFx0XHRpZD17YCR7aWR9LSR7dG9rZW5JZHh9LXBgfVxuXHRcdFx0XHRcdHRva2Vucz17dG9rZW4udG9rZW5zID8/IFtdfVxuXHRcdFx0XHRcdHtkb25lfVxuXHRcdFx0XHRcdHtzb3VyY2VJZHN9XG5cdFx0XHRcdFx0e29uU291cmNlQ2xpY2t9XG5cdFx0XHRcdC8+XG5cdFx0XHQ8L3A+XG5cdFx0ey9pZn1cblx0ezplbHNlIGlmIHRva2VuLnR5cGUgPT09ICd0ZXh0J31cblx0XHR7I2lmIHRvcH1cblx0XHRcdDxwIGNsYXNzPXtzaW5nbGVQbGFpbkJsb2NrID8gJyFteS0wJyA6ICcnfT5cblx0XHRcdFx0eyNpZiB0b2tlbi50b2tlbnN9XG5cdFx0XHRcdFx0PE1hcmtkb3duSW5saW5lVG9rZW5zXG5cdFx0XHRcdFx0XHRpZD17YCR7aWR9LSR7dG9rZW5JZHh9LXRgfVxuXHRcdFx0XHRcdFx0dG9rZW5zPXt0b2tlbi50b2tlbnN9XG5cdFx0XHRcdFx0XHR7ZG9uZX1cblx0XHRcdFx0XHRcdHtzb3VyY2VJZHN9XG5cdFx0XHRcdFx0XHR7b25Tb3VyY2VDbGlja31cblx0XHRcdFx0XHQvPlxuXHRcdFx0XHR7OmVsc2V9XG5cdFx0XHRcdFx0e3VuZXNjYXBlSHRtbCh0b2tlbi50ZXh0KX1cblx0XHRcdFx0ey9pZn1cblx0XHRcdDwvcD5cblx0XHR7OmVsc2UgaWYgdG9rZW4udG9rZW5zfVxuXHRcdFx0PE1hcmtkb3duSW5saW5lVG9rZW5zXG5cdFx0XHRcdGlkPXtgJHtpZH0tJHt0b2tlbklkeH0tcGB9XG5cdFx0XHRcdHRva2Vucz17dG9rZW4udG9rZW5zID8/IFtdfVxuXHRcdFx0XHR7ZG9uZX1cblx0XHRcdFx0e3NvdXJjZUlkc31cblx0XHRcdFx0e29uU291cmNlQ2xpY2t9XG5cdFx0XHQvPlxuXHRcdHs6ZWxzZX1cblx0XHRcdHt1bmVzY2FwZUh0bWwodG9rZW4udGV4dCl9XG5cdFx0ey9pZn1cblx0ezplbHNlIGlmIHRva2VuLnR5cGUgPT09ICdpbmxpbmVLYXRleCd9XG5cdFx0eyNpZiB0b2tlbi50ZXh0fVxuXHRcdFx0PEthdGV4UmVuZGVyZXIgY29udGVudD17dG9rZW4udGV4dH0gZGlzcGxheU1vZGU9e3Rva2VuPy5kaXNwbGF5TW9kZSA/PyBmYWxzZX0gLz5cblx0XHR7L2lmfVxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ2Jsb2NrS2F0ZXgnfVxuXHRcdHsjaWYgdG9rZW4udGV4dH1cblx0XHRcdDxLYXRleFJlbmRlcmVyIGNvbnRlbnQ9e3Rva2VuLnRleHR9IGRpc3BsYXlNb2RlPXt0b2tlbj8uZGlzcGxheU1vZGUgPz8gZmFsc2V9IC8+XG5cdFx0ey9pZn1cblx0ezplbHNlIGlmIHRva2VuLnR5cGUgPT09ICdjb2xvbkZlbmNlJ31cblx0XHQ8Q29sb25GZW5jZUJsb2NrXG5cdFx0XHRpZD17YCR7aWR9LSR7dG9rZW5JZHh9YH1cblx0XHRcdHt0b2tlbn1cblx0XHRcdHt0b2tlbklkeH1cblx0XHRcdHtkb25lfVxuXHRcdFx0e2VkaXRDb2RlQmxvY2t9XG5cdFx0XHR7c291cmNlSWRzfVxuXHRcdFx0e29uVGFza0NsaWNrfVxuXHRcdFx0e29uU291cmNlQ2xpY2t9XG5cdFx0Lz5cblx0ezplbHNlIGlmIHRva2VuLnR5cGUgPT09ICdzcGFjZSd9XG5cdFx0PCEtLSBza2lwIC0tPlxuXHR7OmVsc2V9XG5cdFx0e2NvbnNvbGUubG9nKCdVbmtub3duIHRva2VuJywgdG9rZW4pfVxuXHR7L2lmfVxuey9lYWNofVxuIl0sImZpbGUiOiIvc3JjL2xpYi9jb21wb25lbnRzL2NoYXQvTWVzc2FnZXMvTWFya2Rvd24vTWFya2Rvd25Ub2tlbnMuc3ZlbHRlIn0=
