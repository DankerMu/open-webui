// /src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/TextToken.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_3__ = await __vite_ssr_import__("/src/lib/stores/index.ts", {"importedNames":["settings"]});



TextToken[__vite_ssr_import_2__.FILENAME] = 'src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/TextToken.svelte';




var root = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span class="fade-in-token"> </span>`), TextToken[__vite_ssr_import_2__.FILENAME], [[14, 2]]);

function TextToken($$anchor, $$props) {
	__vite_ssr_import_2__.check_target(new.target);
	__vite_ssr_import_2__.push($$props, false, TextToken);

	const $settings = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_3__.settings, 'settings'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_3__.settings, '$settings', $$stores)
	);

	const [$$stores, $$cleanup] = __vite_ssr_import_2__.setup_stores();
	const raw = __vite_ssr_import_2__.mutable_source();
	let token = __vite_ssr_import_2__.prop($$props, 'token', 8);
	let done = __vite_ssr_import_2__.prop($$props, 'done', 8, true);

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(token())), () => {
		__vite_ssr_import_2__.set(raw, token()?.raw ?? '');
	});

	__vite_ssr_import_2__.legacy_pre_effect_reset();

	var $$exports = { ...__vite_ssr_import_2__.legacy_api() };

	__vite_ssr_import_2__.init();

	var fragment = __vite_ssr_import_2__.comment();
	var node = __vite_ssr_import_2__.first_child(fragment);

	{
		var consequent = ($$anchor) => {
			var text_1 = __vite_ssr_import_2__.text();

			__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_1, __vite_ssr_import_2__.get(raw)));
			__vite_ssr_import_2__.append($$anchor, text_1);
		};

		var alternate = ($$anchor) => {
			var fragment_2 = __vite_ssr_import_2__.comment();
			var node_1 = __vite_ssr_import_2__.first_child(fragment_2);

			__vite_ssr_import_2__.add_svelte_meta(
				() => __vite_ssr_import_2__.each(node_1, 1, () => (__vite_ssr_import_2__.get(raw), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(raw).split(' '))), __vite_ssr_import_2__.index, ($$anchor, text) => {
					var span = root();
					var text_2 = __vite_ssr_import_2__.child(span);

					__vite_ssr_import_2__.reset(span);
					__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_2, `${__vite_ssr_import_2__.get(text) ?? ''} `));
					__vite_ssr_import_2__.append($$anchor, span);
				}),
				'each',
				TextToken,
				13,
				1
			);

			__vite_ssr_import_2__.append($$anchor, fragment_2);
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node, ($$render) => {
				if ((
					__vite_ssr_import_2__.deep_read_state(done()),
					$settings(),
					__vite_ssr_import_2__.untrack(() => done() || !($settings()?.chatFadeStreamingText ?? true))
				)) $$render(consequent); else $$render(alternate, -1);
			}),
			'if',
			TextToken,
			10,
			0
		);
	}

	__vite_ssr_import_2__.append($$anchor, fragment);

	var $$pop = __vite_ssr_import_2__.pop($$exports);

	$$cleanup();

	return $$pop;
}
Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: TextToken });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7OztBQUN1Qzs7OztzQ0FEdkMsQ0FBQzs7Ozs7Ozs7Ozs7Q0FHTyxJQUFJLEtBQUs7Q0FDVCxJQUFJLElBQUksa0RBQUcsSUFBSTs7OzRCQUVuQixHQUFHLEVBQUcsS0FBSyxJQUFFLEdBQUcsSUFBSSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7O2dIQUl4QixHQUFHOzs7Ozs7Ozs7aUZBSkQsR0FBRyxpRUFNQyxHQUFHLEVBQUMsS0FBSyxDQUFDLEdBQUcsNkNBQUssSUFBSTtTQUMzQixJQUFJOzhDQUFKLElBQUk7O2lDQUFKLElBQUk7cUhBQ0gsSUFBSTs0Q0FETCxJQUFJOzs7Ozs7Ozs7Ozs7OzsyQ0FUSyxJQUFJOzt5Q0FLWCxJQUFJLFFBQU0sU0FBUyxJQUFFLHFCQUFxQixJQUFJLElBQUk7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRi9DIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUZXh0VG9rZW4uc3ZlbHRlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgbGFuZz1cInRzXCI+XG5cdGltcG9ydCB7IHNldHRpbmdzIH0gZnJvbSAnJGxpYi9zdG9yZXMnO1xuXG5cdGV4cG9ydCBsZXQgdG9rZW47XG5cdGV4cG9ydCBsZXQgZG9uZSA9IHRydWU7XG5cblx0JDogcmF3ID0gdG9rZW4/LnJhdyA/PyAnJztcbjwvc2NyaXB0PlxuXG57I2lmIGRvbmUgfHwgISgkc2V0dGluZ3M/LmNoYXRGYWRlU3RyZWFtaW5nVGV4dCA/PyB0cnVlKX1cblx0e3Jhd31cbns6ZWxzZX1cblx0eyNlYWNoIHJhdy5zcGxpdCgnICcpIGFzIHRleHR9XG5cdFx0PHNwYW4gY2xhc3M9XCJmYWRlLWluLXRva2VuXCI+XG5cdFx0XHR7dGV4dH17JyAnfVxuXHRcdDwvc3Bhbj5cblx0ey9lYWNofVxuey9pZn1cbiJdLCJmaWxlIjoiL3NyYy9saWIvY29tcG9uZW50cy9jaGF0L01lc3NhZ2VzL01hcmtkb3duL01hcmtkb3duSW5saW5lVG9rZW5zL1RleHRUb2tlbi5zdmVsdGUifQ==
