// /src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/NoteLinkToken.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_3__ = await __vite_ssr_import__("/node_modules/svelte/src/index-client.js", {"importedNames":["onMount","getContext"]});
const __vite_ssr_import_4__ = await __vite_ssr_import__("/node_modules/@sveltejs/kit/src/runtime/app/navigation.js", {"importedNames":["goto"]});
const __vite_ssr_import_5__ = await __vite_ssr_import__("/src/lib/apis/notes/index.ts", {"importedNames":["getNoteById"]});
const __vite_ssr_import_6__ = await __vite_ssr_import__("/src/lib/apis/users/index.ts", {"importedNames":["getUserInfoById"]});
const __vite_ssr_import_7__ = await __vite_ssr_import__("/src/lib/utils/index.ts", {"importedNames":["capitalizeFirstLetter"]});



NoteLinkToken[__vite_ssr_import_2__.FILENAME] = 'src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/NoteLinkToken.svelte';








var root = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span class="text-gray-400">...</span>`), NoteLinkToken[__vite_ssr_import_2__.FILENAME], [[60, 5]]);
var root_1 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="text-gray-500 text-xs line-clamp-1 mt-0.5"> </div>`), NoteLinkToken[__vite_ssr_import_2__.FILENAME], [[68, 3]]);
var root_2 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<button class="relative group py-2 px-3 w-60 flex flex-col bg-white dark:bg-gray-850 border border-gray-50/30 dark:border-gray-800/30 rounded-xl text-left cursor-pointer" type="button"><div class="flex flex-col justify-center w-full min-w-0"><div class="dark:text-gray-100 text-sm flex justify-between items-center gap-2"><div class="font-normal line-clamp-1 flex-1 min-w-0"><!></div> <div class="text-gray-500 text-xs shrink-0"> </div></div> <!></div></button>`), NoteLinkToken[__vite_ssr_import_2__.FILENAME], [[44, 0, [[56, 1, [[57, 2, [[58, 3], [65, 3]]]]]]]]);

function NoteLinkToken($$anchor, $$props) {
	__vite_ssr_import_2__.check_target(new.target);
	__vite_ssr_import_2__.push($$props, false, NoteLinkToken);

	const $i18n = () => (
		__vite_ssr_import_2__.validate_store(i18n, 'i18n'),
		__vite_ssr_import_2__.store_get(i18n, '$i18n', $$stores)
	);

	const [$$stores, $$cleanup] = __vite_ssr_import_2__.setup_stores();
	const i18n = __vite_ssr_import_3__.getContext('i18n');
	let noteId = __vite_ssr_import_2__.prop($$props, 'noteId', 8);
	let href = __vite_ssr_import_2__.prop($$props, 'href', 8);
	let title = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'title');
	let author = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'author');
	let loading = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(true), 'loading');

	__vite_ssr_import_3__.onMount(async () => {
		try {
			const note = (await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_5__.getNoteById(localStorage.token, noteId())))();

			if (note) {
				__vite_ssr_import_2__.set(title, note.title || $i18n().t('Untitled'));

				if (note.user_id) {
					try {
						const userInfo = (await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_6__.getUserInfoById(localStorage.token, note.user_id)))();

						if (userInfo) {
							__vite_ssr_import_2__.set(author, __vite_ssr_import_7__.capitalizeFirstLetter(userInfo.name ?? userInfo.email ?? ''));
						}
					} catch {
						// user lookup failed, skip author
					}
				}
			}
		} catch {
			__vite_ssr_import_2__.set(title, $i18n().t('Note'));
		} finally {
			__vite_ssr_import_2__.set(loading, false);
		}
	});

	var $$exports = { ...__vite_ssr_import_2__.legacy_api() };

	__vite_ssr_import_2__.init();

	var button = root_2();

	var // fallback
	div = __vite_ssr_import_2__.child(button);

	var div_1 = __vite_ssr_import_2__.child(div);
	var div_2 = __vite_ssr_import_2__.child(div_1);
	var node = __vite_ssr_import_2__.child(div_2);

	{
		var consequent = ($$anchor) => {
			var span = root();

			__vite_ssr_import_2__.append($$anchor, span);
		};

		var alternate = ($$anchor) => {
			var text = __vite_ssr_import_2__.text();

			__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text, __vite_ssr_import_2__.get(title)));
			__vite_ssr_import_2__.append($$anchor, text);
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node, ($$render) => {
				if (__vite_ssr_import_2__.get(loading)) $$render(consequent); else $$render(alternate, -1);
			}),
			'if',
			NoteLinkToken,
			59,
			4
		);
	}

	__vite_ssr_import_2__.reset(div_2);

	var div_3 = __vite_ssr_import_2__.sibling(div_2, 2);
	var text_1 = __vite_ssr_import_2__.child(div_3, true);

	__vite_ssr_import_2__.reset(div_3);
	__vite_ssr_import_2__.reset(div_1);

	var node_1 = __vite_ssr_import_2__.sibling(div_1, 2);

	{
		var consequent_1 = ($$anchor) => {
			var div_4 = root_1();
			var text_2 = __vite_ssr_import_2__.child(div_4, true);

			__vite_ssr_import_2__.reset(div_4);

			__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_2, $0), [
				() => (
					$i18n(),
					__vite_ssr_import_2__.get(author),
					__vite_ssr_import_2__.untrack(() => $i18n().t('By {{name}}', { name: __vite_ssr_import_2__.get(author) }))
				)
			]);

			__vite_ssr_import_2__.append($$anchor, div_4);
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node_1, ($$render) => {
				if (__vite_ssr_import_2__.get(author)) $$render(consequent_1);
			}),
			'if',
			NoteLinkToken,
			67,
			2
		);
	}

	__vite_ssr_import_2__.reset(div);
	__vite_ssr_import_2__.reset(button);
	__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_1, $0), [() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Note')))]);

	__vite_ssr_import_2__.event('click', button, __vite_ssr_import_2__.preventDefault(__vite_ssr_import_2__.stopPropagation(() => {
		try {
			const url = new URL(href(), window.location.origin);

			__vite_ssr_import_4__.goto(url.pathname);
		} catch {
			// fallback
		}
	})));

	__vite_ssr_import_2__.append($$anchor, button);

	var $$pop = __vite_ssr_import_2__.pop($$exports);

	$$cleanup();

	return $$pop;
}
Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: NoteLinkToken });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7QUFDNkM7QUFDTjtBQUNPO0FBQ0k7QUFDQzs7Ozs7OzBDQUxuRCxDQUFDOzs7Ozs7Ozs7O0NBT0EsTUFBTSxJQUFJLEdBQUcsZ0NBQVUsQ0FBQyxNQUFNO0NBRXZCLElBQUksTUFBYztDQUNsQixJQUFJLElBQVk7Q0FFdkIsSUFBSSxLQUFLLGtFQUFHLEVBQUU7Q0FDZCxJQUFJLE1BQU0sa0VBQUcsRUFBRTtDQUNmLElBQUksT0FBTyxrRUFBRyxJQUFJOztDQUVsQiw2QkFBTyxDQUFDLEtBQUssT0FBTztFQUNuQixHQUFHLENBQUM7R0FDSCxNQUFNLElBQUksc0RBQVMsaUNBQVcsQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLE1BQU07O0dBQ3pELEVBQUUsRUFBRSxJQUFJLEVBQUU7OEJBQ1QsS0FBSyxFQUFHLElBQUksQ0FBQyxLQUFLLElBQUksS0FBSyxHQUFDLENBQUMsQ0FBQyxVQUFVOztJQUV4QyxFQUFFLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRTtLQUNqQixHQUFHLENBQUM7TUFDSCxNQUFNLFFBQVEsc0RBQVMscUNBQWUsQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxPQUFPOztNQUN2RSxFQUFFLEVBQUUsUUFBUSxFQUFFO2lDQUNiLE1BQU0sRUFBRywyQ0FBcUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxLQUFLLElBQUksRUFBRTtNQUNyRTtLQUNELENBQUMsQ0FBQyxLQUFLLENBQUM7O0tBRVI7SUFDRDtHQUNEO0VBQ0QsQ0FBQyxDQUFDLEtBQUssQ0FBQzs2QkFDUCxLQUFLLEVBQUcsS0FBSyxHQUFDLENBQUMsQ0FBQyxNQUFNO0VBQ3ZCLENBQUMsQ0FBQyxPQUFPLENBQUM7NkJBQ1QsT0FBTyxFQUFHLEtBQUs7RUFDaEI7Q0FDRCxDQUFDOzs7Ozs7S0FLRDs7O0NBWUMsR0FBRywrQkFaSjs7S0FhRSxLQUFHLCtCQURKLEdBQUc7S0FFRCxLQUFHLCtCQURKLEtBQUc7d0NBQ0YsS0FBRzs7OztPQUVELElBQUk7OzBDQUFKLElBQUk7Ozs7Ozs4R0FFSixLQUFLOzs7Ozs7a0NBSEYsT0FBTzs7Ozs7Ozs7OzZCQURaLEtBQUc7O0tBT0gsS0FBRyxpQ0FQSCxLQUFHOzBDQU9ILEtBQUc7OzZCQUFILEtBQUc7NkJBUkosS0FBRzs7NENBQUgsS0FBRzs7OztPQVdGLEtBQUc7NENBQUgsS0FBRzs7K0JBQUgsS0FBRzs7Ozs7K0JBdERGLE1BQU07eUNBdUROLEtBQUssR0FBQyxDQUFDLENBQUMsYUFBYSxJQUFJLElBQUksNEJBQUUsTUFBTTs7OzswQ0FEdEMsS0FBRzs7Ozs7a0NBREEsTUFBTTs7Ozs7Ozs7OzZCQVhYLEdBQUc7NkJBWko7Z0pBcUIrQyxLQUFLLEdBQUMsQ0FBQyxDQUFDLE1BQU07O3NDQXJCN0QseUZBRytDO0VBQzlDLEdBQUcsQ0FBQztHQUNILE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFFLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTTs7R0FDaEQsMEJBQUksQ0FBQyxHQUFHLENBQUMsUUFBUTtFQUNsQixDQUFDLENBQUMsS0FBSyxDQUFDOztFQUVSO0NBQ0QsQ0FBQzs7d0NBVkQ7Ozs7Ozs7QUFKTyIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTm90ZUxpbmtUb2tlbi5zdmVsdGUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBsYW5nPVwidHNcIj5cblx0aW1wb3J0IHsgb25Nb3VudCwgZ2V0Q29udGV4dCB9IGZyb20gJ3N2ZWx0ZSc7XG5cdGltcG9ydCB7IGdvdG8gfSBmcm9tICckYXBwL25hdmlnYXRpb24nO1xuXHRpbXBvcnQgeyBnZXROb3RlQnlJZCB9IGZyb20gJyRsaWIvYXBpcy9ub3Rlcyc7XG5cdGltcG9ydCB7IGdldFVzZXJJbmZvQnlJZCB9IGZyb20gJyRsaWIvYXBpcy91c2Vycyc7XG5cdGltcG9ydCB7IGNhcGl0YWxpemVGaXJzdExldHRlciB9IGZyb20gJyRsaWIvdXRpbHMnO1xuXG5cdGNvbnN0IGkxOG4gPSBnZXRDb250ZXh0KCdpMThuJyk7XG5cblx0ZXhwb3J0IGxldCBub3RlSWQ6IHN0cmluZztcblx0ZXhwb3J0IGxldCBocmVmOiBzdHJpbmc7XG5cblx0bGV0IHRpdGxlID0gJyc7XG5cdGxldCBhdXRob3IgPSAnJztcblx0bGV0IGxvYWRpbmcgPSB0cnVlO1xuXG5cdG9uTW91bnQoYXN5bmMgKCkgPT4ge1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBub3RlID0gYXdhaXQgZ2V0Tm90ZUJ5SWQobG9jYWxTdG9yYWdlLnRva2VuLCBub3RlSWQpO1xuXHRcdFx0aWYgKG5vdGUpIHtcblx0XHRcdFx0dGl0bGUgPSBub3RlLnRpdGxlIHx8ICRpMThuLnQoJ1VudGl0bGVkJyk7XG5cblx0XHRcdFx0aWYgKG5vdGUudXNlcl9pZCkge1xuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRjb25zdCB1c2VySW5mbyA9IGF3YWl0IGdldFVzZXJJbmZvQnlJZChsb2NhbFN0b3JhZ2UudG9rZW4sIG5vdGUudXNlcl9pZCk7XG5cdFx0XHRcdFx0XHRpZiAodXNlckluZm8pIHtcblx0XHRcdFx0XHRcdFx0YXV0aG9yID0gY2FwaXRhbGl6ZUZpcnN0TGV0dGVyKHVzZXJJbmZvLm5hbWUgPz8gdXNlckluZm8uZW1haWwgPz8gJycpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRcdFx0Ly8gdXNlciBsb29rdXAgZmFpbGVkLCBza2lwIGF1dGhvclxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0gY2F0Y2gge1xuXHRcdFx0dGl0bGUgPSAkaTE4bi50KCdOb3RlJyk7XG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdGxvYWRpbmcgPSBmYWxzZTtcblx0XHR9XG5cdH0pO1xuPC9zY3JpcHQ+XG5cbjwhLS0gc3ZlbHRlLWlnbm9yZSBhMTF5LWNsaWNrLWV2ZW50cy1oYXZlLWtleS1ldmVudHMgLS0+XG48IS0tIHN2ZWx0ZS1pZ25vcmUgYTExeS1uby1zdGF0aWMtZWxlbWVudC1pbnRlcmFjdGlvbnMgLS0+XG48YnV0dG9uXG5cdGNsYXNzPVwicmVsYXRpdmUgZ3JvdXAgcHktMiBweC0zIHctNjAgZmxleCBmbGV4LWNvbCBiZy13aGl0ZSBkYXJrOmJnLWdyYXktODUwIGJvcmRlciBib3JkZXItZ3JheS01MC8zMCBkYXJrOmJvcmRlci1ncmF5LTgwMC8zMCByb3VuZGVkLXhsIHRleHQtbGVmdCBjdXJzb3ItcG9pbnRlclwiXG5cdHR5cGU9XCJidXR0b25cIlxuXHRvbjpjbGlja3xwcmV2ZW50RGVmYXVsdHxzdG9wUHJvcGFnYXRpb249eygpID0+IHtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3QgdXJsID0gbmV3IFVSTChocmVmLCB3aW5kb3cubG9jYXRpb24ub3JpZ2luKTtcblx0XHRcdGdvdG8odXJsLnBhdGhuYW1lKTtcblx0XHR9IGNhdGNoIHtcblx0XHRcdC8vIGZhbGxiYWNrXG5cdFx0fVxuXHR9fVxuPlxuXHQ8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciB3LWZ1bGwgbWluLXctMFwiPlxuXHRcdDxkaXYgY2xhc3M9XCJkYXJrOnRleHQtZ3JheS0xMDAgdGV4dC1zbSBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cblx0XHRcdDxkaXYgY2xhc3M9XCJmb250LW5vcm1hbCBsaW5lLWNsYW1wLTEgZmxleC0xIG1pbi13LTBcIj5cblx0XHRcdFx0eyNpZiBsb2FkaW5nfVxuXHRcdFx0XHRcdDxzcGFuIGNsYXNzPVwidGV4dC1ncmF5LTQwMFwiPi4uLjwvc3Bhbj5cblx0XHRcdFx0ezplbHNlfVxuXHRcdFx0XHRcdHt0aXRsZX1cblx0XHRcdFx0ey9pZn1cblx0XHRcdDwvZGl2PlxuXHRcdFx0PGRpdiBjbGFzcz1cInRleHQtZ3JheS01MDAgdGV4dC14cyBzaHJpbmstMFwiPnskaTE4bi50KCdOb3RlJyl9PC9kaXY+XG5cdFx0PC9kaXY+XG5cdFx0eyNpZiBhdXRob3J9XG5cdFx0XHQ8ZGl2IGNsYXNzPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXhzIGxpbmUtY2xhbXAtMSBtdC0wLjVcIj5cblx0XHRcdFx0eyRpMThuLnQoJ0J5IHt7bmFtZX19JywgeyBuYW1lOiBhdXRob3IgfSl9XG5cdFx0XHQ8L2Rpdj5cblx0XHR7L2lmfVxuXHQ8L2Rpdj5cbjwvYnV0dG9uPlxuIl0sImZpbGUiOiIvc3JjL2xpYi9jb21wb25lbnRzL2NoYXQvTWVzc2FnZXMvTWFya2Rvd24vTWFya2Rvd25JbmxpbmVUb2tlbnMvTm90ZUxpbmtUb2tlbi5zdmVsdGUifQ==
