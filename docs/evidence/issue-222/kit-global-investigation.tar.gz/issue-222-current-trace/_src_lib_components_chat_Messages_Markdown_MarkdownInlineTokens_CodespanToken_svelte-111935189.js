// /src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/CodespanToken.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_3__ = await __vite_ssr_import__("/src/lib/utils/index.ts", {"importedNames":["copyToClipboard","unescapeHtml"]});
const __vite_ssr_import_4__ = await __vite_ssr_import__("/node_modules/svelte-sonner/dist/index.js", {"importedNames":["toast"]});
const __vite_ssr_import_5__ = await __vite_ssr_import__("/node_modules/svelte/src/index-client.js", {"importedNames":["getContext"]});
const __vite_ssr_import_6__ = await __vite_ssr_import__("/src/lib/stores/index.ts", {"importedNames":["settings"]});



CodespanToken[__vite_ssr_import_2__.FILENAME] = 'src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/CodespanToken.svelte';







var root = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<code> </code>`), CodespanToken[__vite_ssr_import_2__.FILENAME], [[17, 0]]);

function CodespanToken($$anchor, $$props) {
	__vite_ssr_import_2__.check_target(new.target);
	__vite_ssr_import_2__.push($$props, false, CodespanToken);

	const $settings = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_6__.settings, 'settings'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_6__.settings, '$settings', $$stores)
	);

	const $i18n = () => (
		__vite_ssr_import_2__.validate_store(i18n, 'i18n'),
		__vite_ssr_import_2__.store_get(i18n, '$i18n', $$stores)
	);

	const [$$stores, $$cleanup] = __vite_ssr_import_2__.setup_stores();
	const i18n = __vite_ssr_import_5__.getContext('i18n');
	let token = __vite_ssr_import_2__.prop($$props, 'token', 8);
	let done = __vite_ssr_import_2__.prop($$props, 'done', 8, true);
	var $$exports = { ...__vite_ssr_import_2__.legacy_api() };

	__vite_ssr_import_2__.init();

	var code = root();
	var text = __vite_ssr_import_2__.child(code, true);

	__vite_ssr_import_2__.reset(code);

	__vite_ssr_import_2__.template_effect(
		($0) => {
			__vite_ssr_import_2__.set_class(code, 1, `codespan cursor-pointer ${(
				__vite_ssr_import_2__.deep_read_state(done()),
				$settings(),
				__vite_ssr_import_2__.untrack(() => !done() && ($settings()?.chatFadeStreamingText ?? true) ? 'fade-in-token' : '')
			) ?? ''}`);

			__vite_ssr_import_2__.set_text(text, $0);
		},
		[
			() => (
				__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_3__.unescapeHtml),
				__vite_ssr_import_2__.deep_read_state(token()),
				__vite_ssr_import_2__.untrack(() => __vite_ssr_import_3__.unescapeHtml(token().text))
			)
		]
	);

	__vite_ssr_import_2__.event('click', code, function click() {
		__vite_ssr_import_3__.copyToClipboard(__vite_ssr_import_3__.unescapeHtml(token().text));
		__vite_ssr_import_4__.toast.success($i18n().t('Copied to clipboard'));
	});

	__vite_ssr_import_2__.append($$anchor, code);

	var $$pop = __vite_ssr_import_2__.pop($$exports);

	$$cleanup();

	return $$pop;
}
Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: CodespanToken });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7OztBQUMyRDtBQUNyQjtBQUVGO0FBRUc7Ozs7MENBTnZDLENBQUM7Ozs7Ozs7Ozs7Ozs7OztDQVFBLE1BQU0sSUFBSSxHQUFHLGdDQUFVLENBQUMsTUFBTTtDQUV2QixJQUFJLEtBQUs7Q0FDVCxJQUFJLElBQUksa0RBQUcsSUFBSTs7Ozs7S0FLdEI7d0NBQUE7OzZCQUFBOzs7O21DQUFBOzBDQUxXLElBQUk7O3lDQU1rQixJQUFJLE9BQUssU0FBUyxJQUFFLHFCQUFxQixJQUFJLElBQUksSUFDL0UsZUFBYyxHQUNkLEVBQUU7Ozs7Ozs7MENBbEJxQixrQ0FBWTswQ0FTM0IsS0FBSzt3Q0FhWixrQ0FBWSxDQUFDLEtBQUssR0FBQyxJQUFJOzs7OztzQ0FQM0IsdUJBSWdCO0VBQ2YscUNBQWUsQ0FBQyxrQ0FBWSxDQUFDLEtBQUssR0FBQyxJQUFJO0VBQ3ZDLDJCQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMscUJBQXFCO0NBQzVDLENBQUM7O3dDQVBEOzs7Ozs7O0FBSk8iLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNvZGVzcGFuVG9rZW4uc3ZlbHRlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgbGFuZz1cInRzXCI+XG5cdGltcG9ydCB7IGNvcHlUb0NsaXBib2FyZCwgdW5lc2NhcGVIdG1sIH0gZnJvbSAnJGxpYi91dGlscyc7XG5cdGltcG9ydCB7IHRvYXN0IH0gZnJvbSAnc3ZlbHRlLXNvbm5lcic7XG5cblx0aW1wb3J0IHsgZ2V0Q29udGV4dCB9IGZyb20gJ3N2ZWx0ZSc7XG5cblx0aW1wb3J0IHsgc2V0dGluZ3MgfSBmcm9tICckbGliL3N0b3Jlcyc7XG5cblx0Y29uc3QgaTE4biA9IGdldENvbnRleHQoJ2kxOG4nKTtcblxuXHRleHBvcnQgbGV0IHRva2VuO1xuXHRleHBvcnQgbGV0IGRvbmUgPSB0cnVlO1xuPC9zY3JpcHQ+XG5cbjwhLS0gc3ZlbHRlLWlnbm9yZSBhMTF5LWNsaWNrLWV2ZW50cy1oYXZlLWtleS1ldmVudHMgLS0+XG48IS0tIHN2ZWx0ZS1pZ25vcmUgYTExeS1uby1ub25pbnRlcmFjdGl2ZS1lbGVtZW50LWludGVyYWN0aW9ucyAtLT5cbjxjb2RlXG5cdGNsYXNzPVwiY29kZXNwYW4gY3Vyc29yLXBvaW50ZXIgeyFkb25lICYmICgkc2V0dGluZ3M/LmNoYXRGYWRlU3RyZWFtaW5nVGV4dCA/PyB0cnVlKVxuXHRcdD8gJ2ZhZGUtaW4tdG9rZW4nXG5cdFx0OiAnJ31cIlxuXHRvbjpjbGljaz17KCkgPT4ge1xuXHRcdGNvcHlUb0NsaXBib2FyZCh1bmVzY2FwZUh0bWwodG9rZW4udGV4dCkpO1xuXHRcdHRvYXN0LnN1Y2Nlc3MoJGkxOG4udCgnQ29waWVkIHRvIGNsaXBib2FyZCcpKTtcblx0fX0+e3VuZXNjYXBlSHRtbCh0b2tlbi50ZXh0KX08L2NvZGVcbj5cbiJdLCJmaWxlIjoiL3NyYy9saWIvY29tcG9uZW50cy9jaGF0L01lc3NhZ2VzL01hcmtkb3duL01hcmtkb3duSW5saW5lVG9rZW5zL0NvZGVzcGFuVG9rZW4uc3ZlbHRlIn0=
