// /src/lib/components/channel/Messages/Message/UserStatus.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_3__ = await __vite_ssr_import__("/node_modules/svelte/src/index-client.js", {"importedNames":["getContext","onMount"]});
const __vite_ssr_import_4__ = await __vite_ssr_import__("/src/lib/stores/index.ts", {"importedNames":["user","channels","socket"]});
const __vite_ssr_import_5__ = await __vite_ssr_import__("/src/lib/constants.ts", {"importedNames":["WEBUI_API_BASE_URL","WEBUI_BASE_URL"]});
const __vite_ssr_import_6__ = await __vite_ssr_import__("/src/lib/apis/channels/index.ts", {"importedNames":["getChannels","getDMChannelByUserId"]});
const __vite_ssr_import_7__ = await __vite_ssr_import__("/src/lib/components/icons/ChatBubbles.svelte", {"importedNames":["default"]});
const __vite_ssr_import_8__ = await __vite_ssr_import__("/src/lib/components/icons/ChatBubble.svelte", {"importedNames":["default"]});
const __vite_ssr_import_9__ = await __vite_ssr_import__("/src/lib/components/icons/ChatBubbleOval.svelte", {"importedNames":["default"]});
const __vite_ssr_import_10__ = await __vite_ssr_import__("/node_modules/@sveltejs/kit/src/runtime/app/navigation.js", {"importedNames":["goto"]});
const __vite_ssr_import_11__ = await __vite_ssr_import__("/src/lib/components/common/Emoji.svelte", {"importedNames":["default"]});
const __vite_ssr_import_12__ = await __vite_ssr_import__("/src/lib/components/common/Tooltip.svelte", {"importedNames":["default"]});



UserStatus[__vite_ssr_import_2__.FILENAME] = 'src/lib/components/channel/Messages/Message/UserStatus.svelte';













var root = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div><span class="relative flex size-2"><span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span> <span class="relative inline-flex rounded-full size-2 bg-green-500"></span></span></div> <span class="text-xs"> </span>`, 1), UserStatus[__vite_ssr_import_2__.FILENAME], [[53, 6, [[54, 7, [[55, 8], [58, 8]]]]], [62, 6]]);
var root_1 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div><span class="relative flex size-2"><span class="relative inline-flex rounded-full size-2 bg-gray-500"></span></span></div> <span class="text-xs"> </span>`, 1), UserStatus[__vite_ssr_import_2__.FILENAME], [[64, 6, [[65, 7, [[66, 8]]]]], [70, 6]]);
var root_2 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class=" self-center shrink-0"><!></div>`), UserStatus[__vite_ssr_import_2__.FILENAME], [[83, 7]]);
var root_3 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="w-full gap-2 px-2.5 py-1.5 rounded-xl bg-gray-50 dark:text-white dark:bg-gray-900/50 text-black transition text-xs flex items-center"><!> <div class=" self-center line-clamp-2 flex-1 text-left"> </div></div>`), UserStatus[__vite_ssr_import_2__.FILENAME], [[79, 5, [[87, 6]]]]);
var root_4 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="mx-2 mt-2"><!></div>`), UserStatus[__vite_ssr_import_2__.FILENAME], [[77, 3]]);
var root_5 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class=" self-center line-clamp-3 flex-1 text-left text-xs"> </div>`), UserStatus[__vite_ssr_import_2__.FILENAME], [[98, 5]]);
var root_6 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="mx-3.5 mt-2"><!></div>`), UserStatus[__vite_ssr_import_2__.FILENAME], [[96, 3]]);
var root_7 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="px-1.5 py-0.5 rounded-lg bg-gray-50 dark:text-white dark:bg-gray-900/50 text-black transition text-xs"> </div>`), UserStatus[__vite_ssr_import_2__.FILENAME], [[108, 5]]);
var root_8 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="mx-3.5 mt-2 flex flex-wrap gap-0.5 max-h-20 overflow-y-auto"></div>`), UserStatus[__vite_ssr_import_2__.FILENAME], [[106, 3]]);
var root_9 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<hr class="border-gray-100/50 dark:border-gray-800/50 my-2.5"/> <div class=" flex flex-col w-full px-2.5 items-center"><button class="w-full text-left px-3 py-1.5 rounded-xl border border-gray-100/50 dark:border-gray-800/50 hover:bg-gray-50 dark:hover:bg-gray-850 transition flex items-center gap-2 text-sm" type="button"><div><!></div> <div class="font-normal"> </div></button></div>`, 1), UserStatus[__vite_ssr_import_2__.FILENAME], [[118, 3], [120, 3, [[121, 4, [[128, 5], [132, 5]]]]]]);

var root_10 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<div class="py-3"><div class=" flex gap-3.5 w-full px-3 items-center"><div class=" items-center flex shrink-0"><img class=" size-14 object-cover rounded-xl" alt="profile"/></div> <div class=" flex flex-col w-full flex-1"><div class="mb-0.5 font-normal line-clamp-1 pr-2"> </div> <div class=" flex items-center gap-2"><!></div></div></div> <!> <!> <!> <!></div>`), UserStatus[__vite_ssr_import_2__.FILENAME], [
	[
		36,
		1,
		[[37, 2, [[38, 3, [[39, 4]]], [46, 3, [[47, 4], [51, 4]]]]]]
	]
]);

function UserStatus($$anchor, $$props) {
	__vite_ssr_import_2__.check_target(new.target);
	__vite_ssr_import_2__.push($$props, false, UserStatus);

	const $i18n = () => (
		__vite_ssr_import_2__.validate_store(i18n, 'i18n'),
		__vite_ssr_import_2__.store_get(i18n, '$i18n', $$stores)
	);

	const $_user = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_4__.user, '_user'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_4__.user, '$_user', $$stores)
	);

	const [$$stores, $$cleanup] = __vite_ssr_import_2__.setup_stores();
	const i18n = __vite_ssr_import_3__.getContext('i18n');
	let user = __vite_ssr_import_2__.prop($$props, 'user', 8, null);

	const directMessageHandler = async () => {
		if (!user()) {
			return;
		}

		const res = (await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_6__.getDMChannelByUserId(localStorage.token, user().id).catch((error) => {
			console.error(...__vite_ssr_import_2__.log_if_contains_state('error', 'Error fetching DM channel:', error));

			return null;
		})))();

		if (res) {
			__vite_ssr_import_10__.goto(`/channels/${res.id}`);
		}
	};

	var $$exports = { ...__vite_ssr_import_2__.legacy_api() };

	__vite_ssr_import_2__.init();

	var fragment = __vite_ssr_import_2__.comment();
	var node = __vite_ssr_import_2__.first_child(fragment);

	{
		var consequent_6 = ($$anchor) => {
			var div = root_10();
			var div_1 = __vite_ssr_import_2__.child(div);
			var div_2 = __vite_ssr_import_2__.child(div_1);
			var img = __vite_ssr_import_2__.child(div_2);

			__vite_ssr_import_2__.reset(div_2);

			var div_3 = __vite_ssr_import_2__.sibling(div_2, 2);
			var div_4 = __vite_ssr_import_2__.child(div_3);
			var text = __vite_ssr_import_2__.child(div_4, true);

			__vite_ssr_import_2__.reset(div_4);

			var div_5 = __vite_ssr_import_2__.sibling(div_4, 2);
			var node_1 = __vite_ssr_import_2__.child(div_5);

			{
				var consequent = ($$anchor) => {
					var fragment_1 = root();
					var span = __vite_ssr_import_2__.sibling(__vite_ssr_import_2__.first_child(fragment_1), 2);
					var text_1 = __vite_ssr_import_2__.child(span, true);

					__vite_ssr_import_2__.reset(span);
					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_1, $0), [() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Active')))]);
					__vite_ssr_import_2__.append($$anchor, fragment_1);
				};

				var alternate = ($$anchor) => {
					var fragment_2 = root_1();
					var span_1 = __vite_ssr_import_2__.sibling(__vite_ssr_import_2__.first_child(fragment_2), 2);
					var text_2 = __vite_ssr_import_2__.child(span_1, true);

					__vite_ssr_import_2__.reset(span_1);
					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_2, $0), [() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Away')))]);
					__vite_ssr_import_2__.append($$anchor, fragment_2);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_1, ($$render) => {
						if ((
							__vite_ssr_import_2__.deep_read_state(user()),
							__vite_ssr_import_2__.untrack(() => user()?.is_active)
						)) $$render(consequent); else $$render(alternate, -1);
					}),
					'if',
					UserStatus,
					52,
					5
				);
			}

			__vite_ssr_import_2__.reset(div_5);
			__vite_ssr_import_2__.reset(div_3);
			__vite_ssr_import_2__.reset(div_1);

			var node_2 = __vite_ssr_import_2__.sibling(div_1, 2);

			{
				var consequent_2 = ($$anchor) => {
					var div_6 = root_4();
					var node_3 = __vite_ssr_import_2__.child(div_6);

					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
							__vite_ssr_import_2__.deep_read_state(user()),
							__vite_ssr_import_2__.untrack(() => user()?.status_message)
						));

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_12__.default(node_3, {
								get content() {
									return __vite_ssr_import_2__.get($0);
								},

								children: __vite_ssr_import_2__.wrap_snippet(UserStatus, ($$anchor, $$slotProps) => {
									var div_7 = root_3();
									var node_4 = __vite_ssr_import_2__.child(div_7);

									{
										var consequent_1 = ($$anchor) => {
											var div_8 = root_2();
											var node_5 = __vite_ssr_import_2__.child(div_8);

											{
												let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
													__vite_ssr_import_2__.deep_read_state(user()),
													__vite_ssr_import_2__.untrack(() => user()?.status_emoji)
												));

												__vite_ssr_import_2__.add_svelte_meta(
													() => __vite_ssr_import_11__.default(node_5, {
														className: 'size-4',
														get shortCode() {
															return __vite_ssr_import_2__.get($0);
														}
													}),
													'component',
													UserStatus,
													84,
													8,
													{ componentTag: 'Emoji' }
												);
											}

											__vite_ssr_import_2__.reset(div_8);
											__vite_ssr_import_2__.append($$anchor, div_8);
										};

										__vite_ssr_import_2__.add_svelte_meta(
											() => __vite_ssr_import_2__.if(node_4, ($$render) => {
												if ((
													__vite_ssr_import_2__.deep_read_state(user()),
													__vite_ssr_import_2__.untrack(() => user()?.status_emoji)
												)) $$render(consequent_1);
											}),
											'if',
											UserStatus,
											82,
											6
										);
									}

									var div_9 = __vite_ssr_import_2__.sibling(node_4, 2);
									var text_3 = __vite_ssr_import_2__.child(div_9, true);

									__vite_ssr_import_2__.reset(div_9);
									__vite_ssr_import_2__.reset(div_7);

									__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_3, (
										__vite_ssr_import_2__.deep_read_state(user()),
										__vite_ssr_import_2__.untrack(() => user()?.status_message)
									)));

									__vite_ssr_import_2__.append($$anchor, div_7);
								}),
								$$slots: { default: true }
							}),
							'component',
							UserStatus,
							78,
							4,
							{ componentTag: 'Tooltip' }
						);
					}

					__vite_ssr_import_2__.reset(div_6);
					__vite_ssr_import_2__.append($$anchor, div_6);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_2, ($$render) => {
						if ((
							__vite_ssr_import_2__.deep_read_state(user()),
							__vite_ssr_import_2__.untrack(() => user()?.status_emoji || user()?.status_message)
						)) $$render(consequent_2);
					}),
					'if',
					UserStatus,
					76,
					2
				);
			}

			var node_6 = __vite_ssr_import_2__.sibling(node_2, 2);

			{
				var consequent_3 = ($$anchor) => {
					var div_10 = root_6();
					var node_7 = __vite_ssr_import_2__.child(div_10);

					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (__vite_ssr_import_2__.deep_read_state(user()), __vite_ssr_import_2__.untrack(() => user()?.bio)));

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_12__.default(node_7, {
								get content() {
									return __vite_ssr_import_2__.get($0);
								},

								children: __vite_ssr_import_2__.wrap_snippet(UserStatus, ($$anchor, $$slotProps) => {
									var div_11 = root_5();
									var text_4 = __vite_ssr_import_2__.child(div_11, true);

									__vite_ssr_import_2__.reset(div_11);
									__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_4, (__vite_ssr_import_2__.deep_read_state(user()), __vite_ssr_import_2__.untrack(() => user()?.bio))));
									__vite_ssr_import_2__.append($$anchor, div_11);
								}),
								$$slots: { default: true }
							}),
							'component',
							UserStatus,
							97,
							4,
							{ componentTag: 'Tooltip' }
						);
					}

					__vite_ssr_import_2__.reset(div_10);
					__vite_ssr_import_2__.append($$anchor, div_10);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_6, ($$render) => {
						if ((__vite_ssr_import_2__.deep_read_state(user()), __vite_ssr_import_2__.untrack(() => user()?.bio))) $$render(consequent_3);
					}),
					'if',
					UserStatus,
					95,
					2
				);
			}

			var node_8 = __vite_ssr_import_2__.sibling(node_6, 2);

			{
				var consequent_4 = ($$anchor) => {
					var div_12 = root_8();

					__vite_ssr_import_2__.add_svelte_meta(
						() => __vite_ssr_import_2__.each(div_12, 5, () => (__vite_ssr_import_2__.deep_read_state(user()), __vite_ssr_import_2__.untrack(() => user().groups)), __vite_ssr_import_2__.index, ($$anchor, group) => {
							var div_13 = root_7();
							var text_5 = __vite_ssr_import_2__.child(div_13, true);

							__vite_ssr_import_2__.reset(div_13);
							__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text_5, (__vite_ssr_import_2__.get(group), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(group).name))));
							__vite_ssr_import_2__.append($$anchor, div_13);
						}),
						'each',
						UserStatus,
						107,
						4
					);

					__vite_ssr_import_2__.reset(div_12);
					__vite_ssr_import_2__.append($$anchor, div_12);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_8, ($$render) => {
						if ((
							__vite_ssr_import_2__.deep_read_state(user()),
							__vite_ssr_import_2__.untrack(() => (user()?.groups ?? []).length > 0)
						)) $$render(consequent_4);
					}),
					'if',
					UserStatus,
					105,
					2
				);
			}

			var node_9 = __vite_ssr_import_2__.sibling(node_8, 2);

			{
				var consequent_5 = ($$anchor) => {
					var fragment_3 = root_9();
					var div_14 = __vite_ssr_import_2__.sibling(__vite_ssr_import_2__.first_child(fragment_3), 2);
					var button = __vite_ssr_import_2__.child(div_14);
					var div_15 = __vite_ssr_import_2__.child(button);
					var node_10 = __vite_ssr_import_2__.child(div_15);

					__vite_ssr_import_2__.add_svelte_meta(() => __vite_ssr_import_9__.default(node_10, { className: 'size-4' }), 'component', UserStatus, 129, 6, { componentTag: 'ChatBubbleOval' });
					__vite_ssr_import_2__.reset(div_15);

					var div_16 = __vite_ssr_import_2__.sibling(div_15, 2);
					var text_6 = __vite_ssr_import_2__.child(div_16, true);

					__vite_ssr_import_2__.reset(div_16);
					__vite_ssr_import_2__.reset(button);
					__vite_ssr_import_2__.reset(div_14);
					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text_6, $0), [() => ($i18n(), __vite_ssr_import_2__.untrack(() => $i18n().t('Message')))]);

					__vite_ssr_import_2__.event('click', button, function click() {
						directMessageHandler();
					});

					__vite_ssr_import_2__.append($$anchor, fragment_3);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_9, ($$render) => {
						if ((
							$_user(),
							__vite_ssr_import_2__.deep_read_state(user()),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals($_user()?.id, user().id, false))
						)) $$render(consequent_5);
					}),
					'if',
					UserStatus,
					117,
					2
				);
			}

			__vite_ssr_import_2__.reset(div);

			__vite_ssr_import_2__.template_effect(() => {
				__vite_ssr_import_2__.set_attribute(img, 'src', (
					__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_5__.WEBUI_API_BASE_URL),
					__vite_ssr_import_2__.deep_read_state(user()),
					__vite_ssr_import_2__.untrack(() => `${__vite_ssr_import_5__.WEBUI_API_BASE_URL}/users/${user()?.id}/profile/image`)
				));

				__vite_ssr_import_2__.set_text(text, (__vite_ssr_import_2__.deep_read_state(user()), __vite_ssr_import_2__.untrack(() => user().name)));
			});

			__vite_ssr_import_2__.append($$anchor, div);
		};

		__vite_ssr_import_2__.add_svelte_meta(
			() => __vite_ssr_import_2__.if(node, ($$render) => {
				if (user()) $$render(consequent_6);
			}),
			'if',
			UserStatus,
			35,
			0
		);
	}

	__vite_ssr_import_2__.append($$anchor, fragment);

	var $$pop = __vite_ssr_import_2__.pop($$exports);

	$$cleanup();

	return $$pop;
}
Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: UserStatus });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUM2QztBQUlpQjtBQUNNO0FBQ0c7QUFFSjtBQUNGO0FBQ1E7QUFDbEM7QUFDaUI7QUFDSTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VDQWQ1RCxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Q0FHQSxNQUFNLElBQUksR0FBRyxnQ0FBVSxDQUFDLE1BQU07Q0FhdkIsSUFBSSxJQUFJLGtEQUFHLElBQUk7O0NBRXRCLE1BQU0sb0JBQW9CLEdBQUcsS0FBSyxPQUFPO0VBQ3hDLEVBQUUsR0FBRyxJQUFJLElBQUU7R0FDVixNQUFNO0VBQ1A7O0VBRUEsTUFBTSxHQUFHLHNEQUFTLDBDQUFvQixDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsSUFBSSxHQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxLQUFLO0dBQ3BGLE9BQU8sQ0FBQyxLQUFLLHlEQUFDLDRCQUE0QixFQUFFLEtBQUs7O0dBQ2pELE1BQU0sQ0FBQyxJQUFJO0VBQ1osQ0FBQzs7RUFFRCxFQUFFLEVBQUUsR0FBRyxFQUFFO0dBQ1IsMkJBQUksY0FBYyxHQUFHLENBQUMsRUFBRTtFQUN6QjtDQUNELENBQUM7Ozs7Ozs7Ozs7O09BSUEsR0FBRztPQUNGLEtBQUcsK0JBREosR0FBRztPQUVELEtBQUcsK0JBREosS0FBRztPQUVELGtDQURELEtBQUc7OytCQUFILEtBQUc7O09BUUgsS0FBRyxpQ0FSSCxLQUFHO09BU0YsS0FBRywrQkFESixLQUFHOzBDQUNGLEtBQUc7OytCQUFILEtBQUc7O09BSUgsS0FBRyxpQ0FKSCxLQUFHOzRDQUlILEtBQUc7Ozs7O1NBV0QsSUFBSTs4Q0FBSixJQUFJOztpQ0FBSixJQUFJO29KQUFtQixLQUFLLEdBQUMsQ0FBQyxDQUFDLFFBQVE7Ozs7OztTQVF2QyxNQUFJOzhDQUFKLE1BQUk7O2lDQUFKLE1BQUk7b0pBQW1CLEtBQUssR0FBQyxDQUFDLENBQUMsTUFBTTs7Ozs7Ozs2Q0FyRGhDLElBQUk7MkNBbUNOLElBQUksSUFBRSxTQUFTOzs7Ozs7Ozs7OytCQURwQixLQUFHOytCQUxKLEtBQUc7K0JBVEosS0FBRzs7OENBQUgsS0FBRzs7OztTQXdDRixLQUFHOzhDQUFILEtBQUc7Ozs7NkNBNURLLElBQUk7MkNBNkRNLElBQUksSUFBRSxjQUFjOzs7O2FBQXJDLDhCQUFPOzs7Ozs7YUFDTjtrREFBQTs7OztlQUlFLEtBQUc7b0RBQUgsS0FBRzs7OzttREFsRUMsSUFBSTtpREFtRTZCLElBQUksSUFBRSxZQUFZOzs7O21CQUF0RCw4QkFBSzs7Ozs7Ozs7Ozs7Ozs7dUNBRE4sS0FBRztrREFBSCxLQUFHOzs7Ozs7bURBbEVDLElBQUk7aURBaUVMLElBQUksSUFBRSxZQUFZOzs7Ozs7Ozs7O2FBS3RCLEtBQUc7a0RBQUgsS0FBRzs7cUNBQUgsS0FBRztxQ0FSSjs7O2dEQTlETSxJQUFJOzhDQXVFUixJQUFJLElBQUUsY0FBYzs7O2dEQVR0Qjs7Ozs7Ozs7Ozs7O2lDQUZGLEtBQUc7NENBQUgsS0FBRzs7Ozs7OzZDQTVESyxJQUFJOzJDQTJEVCxJQUFJLElBQUUsWUFBWSxJQUFJLElBQUksSUFBRSxjQUFjOzs7Ozs7Ozs7Ozs7OztTQW9CN0MsTUFBRzs4Q0FBSCxNQUFHOzs7cUdBL0VLLElBQUkseUNBZ0ZNLElBQUksSUFBRSxHQUFHOzs7YUFBMUIsOEJBQU87Ozs7OzthQUNOLE1BQUc7a0RBQUgsTUFBRzs7cUNBQUgsTUFBRzttSUFqRkcsSUFBSSx5Q0FrRlQsSUFBSSxJQUFFLEdBQUc7Z0RBRFYsTUFBRzs7Ozs7Ozs7Ozs7O2lDQUZMLE1BQUc7NENBQUgsTUFBRzs7Ozs7aURBL0VLLElBQUkseUNBOEVULElBQUksSUFBRSxHQUFHOzs7Ozs7Ozs7Ozs7O1NBV1osTUFBRzs7O3VDQUFILE1BQUcsa0RBekZLLElBQUkseUNBMEZMLElBQUksR0FBQyxNQUFNLDRDQUFJLEtBQUs7V0FDekI7Z0RBQUE7O21DQUFBO3FIQURvQixLQUFLLGlFQUl4QixLQUFLLEVBQUMsSUFBSTs4Q0FIWDs7Ozs7Ozs7aUNBRkYsTUFBRzs0Q0FBSCxNQUFHOzs7Ozs7NkNBekZLLElBQUk7NENBd0ZSLElBQUksSUFBRSxNQUFNLFFBQVEsTUFBTSxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7OztTQWVsQyxNQUFHO1NBQ0YscUNBREQsTUFBRztTQVFELE1BQUcsK0JBUEo7K0NBT0MsTUFBRzs7aURBQ0YsNkJBQWM7aUNBRGYsTUFBRzs7U0FJSCxNQUFHLGlDQUpILE1BQUc7OENBSUgsTUFBRzs7aUNBQUgsTUFBRztpQ0FYSjtpQ0FERCxNQUFHO29KQWFBLEtBQUssR0FBQyxDQUFDLENBQUMsU0FBUzs7MENBWm5CLHlCQUdnQjtNQUNmLG9CQUFvQjtLQUNyQixDQUFDOzs7Ozs7Ozs7NkNBN0dNLElBQUk7K0VBb0dULE1BQU0sSUFBRSxFQUFFLEVBQUssSUFBSSxHQUFDLEVBQUU7Ozs7Ozs7Ozs7K0JBakYzQixHQUFHOzs7d0NBR0E7MkNBaENLLHdDQUFrQjsyQ0FVaEIsSUFBSTs0Q0F1Qkgsd0NBQWtCLFVBQVUsSUFBSSxJQUFFLEVBQUU7OztnRkF2QnJDLElBQUkseUNBK0JWLElBQUksR0FBQyxJQUFJOzs7MENBWmIsR0FBRzs7Ozs7UUFEQSxJQUFJOzs7Ozs7Ozs7Ozs7Ozs7O0FBRkQiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlVzZXJTdGF0dXMuc3ZlbHRlIl0sInNvdXJjZXNDb250ZW50IjpbIjxzY3JpcHQgbGFuZz1cInRzXCI+XG5cdGltcG9ydCB7IGdldENvbnRleHQsIG9uTW91bnQgfSBmcm9tICdzdmVsdGUnO1xuXG5cdGNvbnN0IGkxOG4gPSBnZXRDb250ZXh0KCdpMThuJyk7XG5cblx0aW1wb3J0IHsgdXNlciBhcyBfdXNlciwgY2hhbm5lbHMsIHNvY2tldCB9IGZyb20gJyRsaWIvc3RvcmVzJztcblx0aW1wb3J0IHsgV0VCVUlfQVBJX0JBU0VfVVJMLCBXRUJVSV9CQVNFX1VSTCB9IGZyb20gJyRsaWIvY29uc3RhbnRzJztcblx0aW1wb3J0IHsgZ2V0Q2hhbm5lbHMsIGdldERNQ2hhbm5lbEJ5VXNlcklkIH0gZnJvbSAnJGxpYi9hcGlzL2NoYW5uZWxzJztcblxuXHRpbXBvcnQgQ2hhdEJ1YmJsZXMgZnJvbSAnJGxpYi9jb21wb25lbnRzL2ljb25zL0NoYXRCdWJibGVzLnN2ZWx0ZSc7XG5cdGltcG9ydCBDaGF0QnViYmxlIGZyb20gJyRsaWIvY29tcG9uZW50cy9pY29ucy9DaGF0QnViYmxlLnN2ZWx0ZSc7XG5cdGltcG9ydCBDaGF0QnViYmxlT3ZhbCBmcm9tICckbGliL2NvbXBvbmVudHMvaWNvbnMvQ2hhdEJ1YmJsZU92YWwuc3ZlbHRlJztcblx0aW1wb3J0IHsgZ290byB9IGZyb20gJyRhcHAvbmF2aWdhdGlvbic7XG5cdGltcG9ydCBFbW9qaSBmcm9tICckbGliL2NvbXBvbmVudHMvY29tbW9uL0Vtb2ppLnN2ZWx0ZSc7XG5cdGltcG9ydCBUb29sdGlwIGZyb20gJyRsaWIvY29tcG9uZW50cy9jb21tb24vVG9vbHRpcC5zdmVsdGUnO1xuXG5cdGV4cG9ydCBsZXQgdXNlciA9IG51bGw7XG5cblx0Y29uc3QgZGlyZWN0TWVzc2FnZUhhbmRsZXIgPSBhc3luYyAoKSA9PiB7XG5cdFx0aWYgKCF1c2VyKSB7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0Y29uc3QgcmVzID0gYXdhaXQgZ2V0RE1DaGFubmVsQnlVc2VySWQobG9jYWxTdG9yYWdlLnRva2VuLCB1c2VyLmlkKS5jYXRjaCgoZXJyb3IpID0+IHtcblx0XHRcdGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGZldGNoaW5nIERNIGNoYW5uZWw6JywgZXJyb3IpO1xuXHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0fSk7XG5cblx0XHRpZiAocmVzKSB7XG5cdFx0XHRnb3RvKGAvY2hhbm5lbHMvJHtyZXMuaWR9YCk7XG5cdFx0fVxuXHR9O1xuPC9zY3JpcHQ+XG5cbnsjaWYgdXNlcn1cblx0PGRpdiBjbGFzcz1cInB5LTNcIj5cblx0XHQ8ZGl2IGNsYXNzPVwiIGZsZXggZ2FwLTMuNSB3LWZ1bGwgcHgtMyBpdGVtcy1jZW50ZXJcIj5cblx0XHRcdDxkaXYgY2xhc3M9XCIgaXRlbXMtY2VudGVyIGZsZXggc2hyaW5rLTBcIj5cblx0XHRcdFx0PGltZ1xuXHRcdFx0XHRcdHNyYz17YCR7V0VCVUlfQVBJX0JBU0VfVVJMfS91c2Vycy8ke3VzZXI/LmlkfS9wcm9maWxlL2ltYWdlYH1cblx0XHRcdFx0XHRjbGFzcz1cIiBzaXplLTE0IG9iamVjdC1jb3ZlciByb3VuZGVkLXhsXCJcblx0XHRcdFx0XHRhbHQ9XCJwcm9maWxlXCJcblx0XHRcdFx0Lz5cblx0XHRcdDwvZGl2PlxuXG5cdFx0XHQ8ZGl2IGNsYXNzPVwiIGZsZXggZmxleC1jb2wgdy1mdWxsIGZsZXgtMVwiPlxuXHRcdFx0XHQ8ZGl2IGNsYXNzPVwibWItMC41IGZvbnQtbm9ybWFsIGxpbmUtY2xhbXAtMSBwci0yXCI+XG5cdFx0XHRcdFx0e3VzZXIubmFtZX1cblx0XHRcdFx0PC9kaXY+XG5cblx0XHRcdFx0PGRpdiBjbGFzcz1cIiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuXHRcdFx0XHRcdHsjaWYgdXNlcj8uaXNfYWN0aXZlfVxuXHRcdFx0XHRcdFx0PGRpdj5cblx0XHRcdFx0XHRcdFx0PHNwYW4gY2xhc3M9XCJyZWxhdGl2ZSBmbGV4IHNpemUtMlwiPlxuXHRcdFx0XHRcdFx0XHRcdDxzcGFuXG5cdFx0XHRcdFx0XHRcdFx0XHRjbGFzcz1cImFuaW1hdGUtcGluZyBhYnNvbHV0ZSBpbmxpbmUtZmxleCBoLWZ1bGwgdy1mdWxsIHJvdW5kZWQtZnVsbCBiZy1ncmVlbi00MDAgb3BhY2l0eS03NVwiXG5cdFx0XHRcdFx0XHRcdFx0Lz5cblx0XHRcdFx0XHRcdFx0XHQ8c3BhbiBjbGFzcz1cInJlbGF0aXZlIGlubGluZS1mbGV4IHJvdW5kZWQtZnVsbCBzaXplLTIgYmctZ3JlZW4tNTAwXCIgLz5cblx0XHRcdFx0XHRcdFx0PC9zcGFuPlxuXHRcdFx0XHRcdFx0PC9kaXY+XG5cblx0XHRcdFx0XHRcdDxzcGFuIGNsYXNzPVwidGV4dC14c1wiPiB7JGkxOG4udCgnQWN0aXZlJyl9IDwvc3Bhbj5cblx0XHRcdFx0XHR7OmVsc2V9XG5cdFx0XHRcdFx0XHQ8ZGl2PlxuXHRcdFx0XHRcdFx0XHQ8c3BhbiBjbGFzcz1cInJlbGF0aXZlIGZsZXggc2l6ZS0yXCI+XG5cdFx0XHRcdFx0XHRcdFx0PHNwYW4gY2xhc3M9XCJyZWxhdGl2ZSBpbmxpbmUtZmxleCByb3VuZGVkLWZ1bGwgc2l6ZS0yIGJnLWdyYXktNTAwXCIgLz5cblx0XHRcdFx0XHRcdFx0PC9zcGFuPlxuXHRcdFx0XHRcdFx0PC9kaXY+XG5cblx0XHRcdFx0XHRcdDxzcGFuIGNsYXNzPVwidGV4dC14c1wiPiB7JGkxOG4udCgnQXdheScpfSA8L3NwYW4+XG5cdFx0XHRcdFx0ey9pZn1cblx0XHRcdFx0PC9kaXY+XG5cdFx0XHQ8L2Rpdj5cblx0XHQ8L2Rpdj5cblxuXHRcdHsjaWYgdXNlcj8uc3RhdHVzX2Vtb2ppIHx8IHVzZXI/LnN0YXR1c19tZXNzYWdlfVxuXHRcdFx0PGRpdiBjbGFzcz1cIm14LTIgbXQtMlwiPlxuXHRcdFx0XHQ8VG9vbHRpcCBjb250ZW50PXt1c2VyPy5zdGF0dXNfbWVzc2FnZX0+XG5cdFx0XHRcdFx0PGRpdlxuXHRcdFx0XHRcdFx0Y2xhc3M9XCJ3LWZ1bGwgZ2FwLTIgcHgtMi41IHB5LTEuNSByb3VuZGVkLXhsIGJnLWdyYXktNTAgZGFyazp0ZXh0LXdoaXRlIGRhcms6YmctZ3JheS05MDAvNTAgdGV4dC1ibGFjayB0cmFuc2l0aW9uIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXJcIlxuXHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdHsjaWYgdXNlcj8uc3RhdHVzX2Vtb2ppfVxuXHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwiIHNlbGYtY2VudGVyIHNocmluay0wXCI+XG5cdFx0XHRcdFx0XHRcdFx0PEVtb2ppIGNsYXNzTmFtZT1cInNpemUtNFwiIHNob3J0Q29kZT17dXNlcj8uc3RhdHVzX2Vtb2ppfSAvPlxuXHRcdFx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHRcdHsvaWZ9XG5cdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwiIHNlbGYtY2VudGVyIGxpbmUtY2xhbXAtMiBmbGV4LTEgdGV4dC1sZWZ0XCI+XG5cdFx0XHRcdFx0XHRcdHt1c2VyPy5zdGF0dXNfbWVzc2FnZX1cblx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHQ8L1Rvb2x0aXA+XG5cdFx0XHQ8L2Rpdj5cblx0XHR7L2lmfVxuXG5cdFx0eyNpZiB1c2VyPy5iaW99XG5cdFx0XHQ8ZGl2IGNsYXNzPVwibXgtMy41IG10LTJcIj5cblx0XHRcdFx0PFRvb2x0aXAgY29udGVudD17dXNlcj8uYmlvfT5cblx0XHRcdFx0XHQ8ZGl2IGNsYXNzPVwiIHNlbGYtY2VudGVyIGxpbmUtY2xhbXAtMyBmbGV4LTEgdGV4dC1sZWZ0IHRleHQteHNcIj5cblx0XHRcdFx0XHRcdHt1c2VyPy5iaW99XG5cdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdDwvVG9vbHRpcD5cblx0XHRcdDwvZGl2PlxuXHRcdHsvaWZ9XG5cblx0XHR7I2lmICh1c2VyPy5ncm91cHMgPz8gW10pLmxlbmd0aCA+IDB9XG5cdFx0XHQ8ZGl2IGNsYXNzPVwibXgtMy41IG10LTIgZmxleCBmbGV4LXdyYXAgZ2FwLTAuNSBtYXgtaC0yMCBvdmVyZmxvdy15LWF1dG9cIj5cblx0XHRcdFx0eyNlYWNoIHVzZXIuZ3JvdXBzIGFzIGdyb3VwfVxuXHRcdFx0XHRcdDxkaXZcblx0XHRcdFx0XHRcdGNsYXNzPVwicHgtMS41IHB5LTAuNSByb3VuZGVkLWxnIGJnLWdyYXktNTAgZGFyazp0ZXh0LXdoaXRlIGRhcms6YmctZ3JheS05MDAvNTAgdGV4dC1ibGFjayB0cmFuc2l0aW9uIHRleHQteHNcIlxuXHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdHtncm91cC5uYW1lfVxuXHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHR7L2VhY2h9XG5cdFx0XHQ8L2Rpdj5cblx0XHR7L2lmfVxuXG5cdFx0eyNpZiAkX3VzZXI/LmlkICE9PSB1c2VyLmlkfVxuXHRcdFx0PGhyIGNsYXNzPVwiYm9yZGVyLWdyYXktMTAwLzUwIGRhcms6Ym9yZGVyLWdyYXktODAwLzUwIG15LTIuNVwiIC8+XG5cblx0XHRcdDxkaXYgY2xhc3M9XCIgZmxleCBmbGV4LWNvbCB3LWZ1bGwgcHgtMi41IGl0ZW1zLWNlbnRlclwiPlxuXHRcdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdFx0Y2xhc3M9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHB4LTMgcHktMS41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTEwMC81MCBkYXJrOmJvcmRlci1ncmF5LTgwMC81MCBob3ZlcjpiZy1ncmF5LTUwIGRhcms6aG92ZXI6YmctZ3JheS04NTAgdHJhbnNpdGlvbiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtXCJcblx0XHRcdFx0XHR0eXBlPVwiYnV0dG9uXCJcblx0XHRcdFx0XHRvbjpjbGljaz17KCkgPT4ge1xuXHRcdFx0XHRcdFx0ZGlyZWN0TWVzc2FnZUhhbmRsZXIoKTtcblx0XHRcdFx0XHR9fVxuXHRcdFx0XHQ+XG5cdFx0XHRcdFx0PGRpdj5cblx0XHRcdFx0XHRcdDxDaGF0QnViYmxlT3ZhbCBjbGFzc05hbWU9XCJzaXplLTRcIiAvPlxuXHRcdFx0XHRcdDwvZGl2PlxuXG5cdFx0XHRcdFx0PGRpdiBjbGFzcz1cImZvbnQtbm9ybWFsXCI+XG5cdFx0XHRcdFx0XHR7JGkxOG4udCgnTWVzc2FnZScpfVxuXHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHQ8L2J1dHRvbj5cblx0XHRcdDwvZGl2PlxuXHRcdHsvaWZ9XG5cdDwvZGl2Plxuey9pZn1cbiJdLCJmaWxlIjoiL3NyYy9saWIvY29tcG9uZW50cy9jaGFubmVsL01lc3NhZ2VzL01lc3NhZ2UvVXNlclN0YXR1cy5zdmVsdGUifQ==
