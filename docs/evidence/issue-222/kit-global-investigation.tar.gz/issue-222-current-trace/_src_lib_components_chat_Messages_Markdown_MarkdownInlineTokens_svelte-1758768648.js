// /src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_3__ = await __vite_ssr_import__("/node_modules/dompurify/dist/purify.es.mjs", {"importedNames":["default"]});
const __vite_ssr_import_4__ = await __vite_ssr_import__("/node_modules/svelte-sonner/dist/index.js", {"importedNames":["toast"]});
const __vite_ssr_import_5__ = await __vite_ssr_import__("/node_modules/svelte/src/index-client.js", {"importedNames":["getContext"]});
const __vite_ssr_import_6__ = await __vite_ssr_import__("/node_modules/@sveltejs/kit/src/runtime/app/navigation.js", {"importedNames":["goto"]});
const __vite_ssr_import_7__ = await __vite_ssr_import__("/src/lib/constants.ts", {"importedNames":["WEBUI_BASE_URL"]});
const __vite_ssr_import_8__ = await __vite_ssr_import__("/src/lib/utils/index.ts", {"importedNames":["copyToClipboard","unescapeHtml"]});
const __vite_ssr_import_9__ = await __vite_ssr_import__("/src/lib/components/common/Image.svelte", {"importedNames":["default"]});
const __vite_ssr_import_10__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/KatexRenderer.svelte", {"importedNames":["default"]});
const __vite_ssr_import_11__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/Source.svelte", {"importedNames":["default"]});
const __vite_ssr_import_12__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/HTMLToken.svelte", {"importedNames":["default"]});
const __vite_ssr_import_13__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/TextToken.svelte", {"importedNames":["default"]});
const __vite_ssr_import_14__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/CodespanToken.svelte", {"importedNames":["default"]});
const __vite_ssr_import_15__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/MentionToken.svelte", {"importedNames":["default"]});
const __vite_ssr_import_16__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/NoteLinkToken.svelte", {"importedNames":["default"]});
const __vite_ssr_import_17__ = await __vite_ssr_import__("/src/lib/components/chat/Messages/Markdown/SourceToken.svelte", {"importedNames":["default"]});



MarkdownInlineTokens[__vite_ssr_import_2__.FILENAME] = 'src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens.svelte';


















var root = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<a target="_blank" rel="nofollow"><!></a>`), MarkdownInlineTokens[__vite_ssr_import_2__.FILENAME], [[80, 3]]);
var root_1 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<a target="_blank" rel="nofollow"> </a>`), MarkdownInlineTokens[__vite_ssr_import_2__.FILENAME], [[90, 3]]);
var root_2 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<strong><!></strong>`), MarkdownInlineTokens[__vite_ssr_import_2__.FILENAME], [[101, 2]]);
var root_3 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<em><!></em>`), MarkdownInlineTokens[__vite_ssr_import_2__.FILENAME], [[103, 2]]);
var root_4 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<br/>`), MarkdownInlineTokens[__vite_ssr_import_2__.FILENAME], [[107, 2]]);
var root_5 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<del><!></del>`), MarkdownInlineTokens[__vite_ssr_import_2__.FILENAME], [[109, 2]]);
var root_6 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<u><!></u>`), MarkdownInlineTokens[__vite_ssr_import_2__.FILENAME], [[111, 2]]);
var root_7 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<iframe width="100%" frameborder="0"></iframe>`), MarkdownInlineTokens[__vite_ssr_import_2__.FILENAME], [[117, 2]]);

function MarkdownInlineTokens($$anchor, $$props) {
	__vite_ssr_import_2__.check_target(new.target);
	__vite_ssr_import_2__.push($$props, false, MarkdownInlineTokens);

	const i18n = __vite_ssr_import_5__.getContext('i18n');
	let id = __vite_ssr_import_2__.prop($$props, 'id', 8);
	let done = __vite_ssr_import_2__.prop($$props, 'done', 8, true);
	let tokens = __vite_ssr_import_2__.prop($$props, 'tokens', 8);
	let sourceIds = __vite_ssr_import_2__.prop($$props, 'sourceIds', 24, () => []);
	let onSourceClick = __vite_ssr_import_2__.prop($$props, 'onSourceClick', 8, () => {});

	/**
	 * Check if a URL is a same-origin note link and return the note ID if so.
	 */
	const getNoteIdFromHref = (href) => {
		try {
			const url = new URL(href, window.location.origin);

			if (__vite_ssr_import_2__.strict_equals(url.origin, window.location.origin)) {
				const match = url.pathname.match(/^\/notes\/([^/]+)$/);

				if (match) {
					return match[1];
				}
			}
		} catch {
			// Invalid URL
		}

		return null;
	};

	/**
	 * Handle link clicks - intercept same-origin app URLs for in-app navigation
	 */
	const handleLinkClick = (e, href) => {
		try {
			const url = new URL(href, window.location.origin);

			// Check if same origin and an in-app route
			if (__vite_ssr_import_2__.strict_equals(url.origin, window.location.origin) && (url.pathname.startsWith('/notes/') || url.pathname.startsWith('/c/') || url.pathname.startsWith('/channels/'))) {
				e.preventDefault();
				__vite_ssr_import_6__.goto(url.pathname + url.search + url.hash);
			}
		} catch {
			// Invalid URL, let browser handle it
		}
	};

	var $$exports = { ...__vite_ssr_import_2__.legacy_api() };

	__vite_ssr_import_2__.init();

	var fragment = __vite_ssr_import_2__.comment();
	var node = __vite_ssr_import_2__.first_child(fragment);

	__vite_ssr_import_2__.add_svelte_meta(
		() => __vite_ssr_import_2__.each(node, 1, tokens, __vite_ssr_import_2__.index, ($$anchor, token) => {
			var fragment_1 = __vite_ssr_import_2__.comment();
			var node_1 = __vite_ssr_import_2__.first_child(fragment_1);

			{
				var consequent = ($$anchor) => {
					var text = __vite_ssr_import_2__.text();

					__vite_ssr_import_2__.template_effect(($0) => __vite_ssr_import_2__.set_text(text, $0), [
						() => (
							__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_8__.unescapeHtml),
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_8__.unescapeHtml(__vite_ssr_import_2__.get(token).text))
						)
					]);

					__vite_ssr_import_2__.append($$anchor, text);
				};

				var consequent_1 = ($$anchor) => {
					__vite_ssr_import_2__.add_svelte_meta(
						() => __vite_ssr_import_12__.default($$anchor, {
							get id() {
								return id();
							},

							get token() {
								return __vite_ssr_import_2__.get(token);
							},

							get onSourceClick() {
								return onSourceClick();
							}
						}),
						'component',
						MarkdownInlineTokens,
						74,
						2,
						{ componentTag: 'HtmlToken' }
					);
				};

				var consequent_4 = ($$anchor) => {
					const noteId = __vite_ssr_import_2__.tag(
						__vite_ssr_import_2__.derived_safe_equal(() => (
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => getNoteIdFromHref(__vite_ssr_import_2__.get(token).href))
						)),
						'noteId'
					);

					__vite_ssr_import_2__.get(noteId);

					var fragment_4 = __vite_ssr_import_2__.comment();
					var node_2 = __vite_ssr_import_2__.first_child(fragment_4);

					{
						var consequent_2 = ($$anchor) => {
							__vite_ssr_import_2__.add_svelte_meta(
								() => __vite_ssr_import_16__.default($$anchor, {
									get noteId() {
										return __vite_ssr_import_2__.get(noteId);
									},

									get href() {
										return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).href));
									}
								}),
								'component',
								MarkdownInlineTokens,
								78,
								3,
								{ componentTag: 'NoteLinkToken' }
							);
						};

						var consequent_3 = ($$anchor) => {
							var a = root();
							var node_3 = __vite_ssr_import_2__.child(a);

							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-a`);

								__vite_ssr_import_2__.add_svelte_meta(
									() => MarkdownInlineTokens(node_3, {
										get id() {
											return __vite_ssr_import_2__.get($0);
										},

										get tokens() {
											return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens));
										},

										get onSourceClick() {
											return onSourceClick();
										},

										get done() {
											return done();
										}
									}),
									'component',
									MarkdownInlineTokens,
									87,
									4,
									{ componentTag: 'svelte:self' }
								);
							}

							__vite_ssr_import_2__.reset(a);

							__vite_ssr_import_2__.template_effect(() => {
								__vite_ssr_import_2__.set_attribute(a, 'href', (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).href)));
								__vite_ssr_import_2__.set_attribute(a, 'title', (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).title)));
							});

							__vite_ssr_import_2__.event('click', a, function click(e) {
								return handleLinkClick(e, __vite_ssr_import_2__.get(token).href);
							});

							__vite_ssr_import_2__.append($$anchor, a);
						};

						var alternate = ($$anchor) => {
							var a_1 = root_1();
							var text_1 = __vite_ssr_import_2__.child(a_1, true);

							__vite_ssr_import_2__.reset(a_1);

							__vite_ssr_import_2__.template_effect(() => {
								__vite_ssr_import_2__.set_attribute(a_1, 'href', (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).href)));
								__vite_ssr_import_2__.set_attribute(a_1, 'title', (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).title)));
								__vite_ssr_import_2__.set_text(text_1, (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).text)));
							});

							__vite_ssr_import_2__.event('click', a_1, function click_1(e) {
								return handleLinkClick(e, __vite_ssr_import_2__.get(token).href);
							});

							__vite_ssr_import_2__.append($$anchor, a_1);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_2, ($$render) => {
								if (__vite_ssr_import_2__.get(noteId)) $$render(consequent_2); else if ((__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens))) $$render(consequent_3, 1); else $$render(alternate, -1);
							}),
							'if',
							MarkdownInlineTokens,
							77,
							2
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_4);
				};

				var consequent_5 = ($$anchor) => {
					__vite_ssr_import_2__.add_svelte_meta(
						() => __vite_ssr_import_9__.default($$anchor, {
							get src() {
								return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).href));
							},

							get alt() {
								return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).text));
							},
							allowExternal: true
						}),
						'component',
						MarkdownInlineTokens,
						99,
						2,
						{ componentTag: 'Image' }
					);
				};

				var consequent_6 = ($$anchor) => {
					var strong = root_2();
					var node_4 = __vite_ssr_import_2__.child(strong);

					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-strong`);

						__vite_ssr_import_2__.add_svelte_meta(
							() => MarkdownInlineTokens(node_4, {
								get id() {
									return __vite_ssr_import_2__.get($0);
								},

								get tokens() {
									return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens));
								},

								get onSourceClick() {
									return onSourceClick();
								}
							}),
							'component',
							MarkdownInlineTokens,
							101,
							10,
							{ componentTag: 'svelte:self' }
						);
					}

					__vite_ssr_import_2__.reset(strong);
					__vite_ssr_import_2__.append($$anchor, strong);
				};

				var consequent_7 = ($$anchor) => {
					var em = root_3();
					var node_5 = __vite_ssr_import_2__.child(em);

					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-em`);

						__vite_ssr_import_2__.add_svelte_meta(
							() => MarkdownInlineTokens(node_5, {
								get id() {
									return __vite_ssr_import_2__.get($0);
								},

								get tokens() {
									return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens));
								},

								get onSourceClick() {
									return onSourceClick();
								}
							}),
							'component',
							MarkdownInlineTokens,
							103,
							6,
							{ componentTag: 'svelte:self' }
						);
					}

					__vite_ssr_import_2__.reset(em);
					__vite_ssr_import_2__.append($$anchor, em);
				};

				var consequent_8 = ($$anchor) => {
					__vite_ssr_import_2__.add_svelte_meta(
						() => __vite_ssr_import_14__.default($$anchor, {
							get token() {
								return __vite_ssr_import_2__.get(token);
							},

							get done() {
								return done();
							}
						}),
						'component',
						MarkdownInlineTokens,
						105,
						2,
						{ componentTag: 'CodespanToken' }
					);
				};

				var consequent_9 = ($$anchor) => {
					var br = root_4();

					__vite_ssr_import_2__.append($$anchor, br);
				};

				var consequent_10 = ($$anchor) => {
					var del = root_5();
					var node_6 = __vite_ssr_import_2__.child(del);

					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-del`);

						__vite_ssr_import_2__.add_svelte_meta(
							() => MarkdownInlineTokens(node_6, {
								get id() {
									return __vite_ssr_import_2__.get($0);
								},

								get tokens() {
									return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens));
								},

								get onSourceClick() {
									return onSourceClick();
								}
							}),
							'component',
							MarkdownInlineTokens,
							109,
							7,
							{ componentTag: 'svelte:self' }
						);
					}

					__vite_ssr_import_2__.reset(del);
					__vite_ssr_import_2__.append($$anchor, del);
				};

				var consequent_11 = ($$anchor) => {
					var u = root_6();
					var node_7 = __vite_ssr_import_2__.child(u);

					{
						let $0 = __vite_ssr_import_2__.derived_safe_equal(() => `${id()}-underline`);

						__vite_ssr_import_2__.add_svelte_meta(
							() => MarkdownInlineTokens(node_7, {
								get id() {
									return __vite_ssr_import_2__.get($0);
								},

								get tokens() {
									return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).tokens));
								},

								get onSourceClick() {
									return onSourceClick();
								}
							}),
							'component',
							MarkdownInlineTokens,
							111,
							5,
							{ componentTag: 'svelte:self' }
						);
					}

					__vite_ssr_import_2__.reset(u);
					__vite_ssr_import_2__.append($$anchor, u);
				};

				var consequent_13 = ($$anchor) => {
					var fragment_8 = __vite_ssr_import_2__.comment();
					var node_8 = __vite_ssr_import_2__.first_child(fragment_8);

					{
						var consequent_12 = ($$anchor) => {
							{
								let $0 = __vite_ssr_import_2__.derived_safe_equal(() => (
									__vite_ssr_import_2__.get(token),
									__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token)?.displayMode ?? false)
								));

								__vite_ssr_import_2__.add_svelte_meta(
									() => __vite_ssr_import_10__.default($$anchor, {
										get content() {
											return (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).text));
										},

										get displayMode() {
											return __vite_ssr_import_2__.get($0);
										}
									}),
									'component',
									MarkdownInlineTokens,
									114,
									3,
									{ componentTag: 'KatexRenderer' }
								);
							}
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_8, ($$render) => {
								if ((__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).text))) $$render(consequent_12);
							}),
							'if',
							MarkdownInlineTokens,
							113,
							2
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_8);
				};

				var consequent_14 = ($$anchor) => {
					var iframe = root_7();

					__vite_ssr_import_2__.template_effect(() => {
						__vite_ssr_import_2__.set_attribute(iframe, 'src', `${__vite_ssr_import_7__.WEBUI_BASE_URL ?? ''}/api/v1/files/${(__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).fileId)) ?? ''}/content`);
						__vite_ssr_import_2__.set_attribute(iframe, 'title', (__vite_ssr_import_2__.get(token), __vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.get(token).fileId)));
					});

					__vite_ssr_import_2__.event('load', iframe, function load(e) {
						try {
							e.currentTarget.style.height = e.currentTarget.contentWindow.document.body.scrollHeight + 20 + 'px';
						} catch {}
					});

					__vite_ssr_import_2__.append($$anchor, iframe);
				};

				var consequent_15 = ($$anchor) => {
					__vite_ssr_import_2__.add_svelte_meta(
						() => __vite_ssr_import_15__.default($$anchor, {
							get token() {
								return __vite_ssr_import_2__.get(token);
							}
						}),
						'component',
						MarkdownInlineTokens,
						130,
						2,
						{ componentTag: 'MentionToken' }
					);
				};

				var consequent_16 = ($$anchor) => {
					var fragment_11 = __vite_ssr_import_2__.comment();
					var node_9 = __vite_ssr_import_2__.first_child(fragment_11);

					__vite_ssr_import_2__.html(node_9, () => (
						__vite_ssr_import_2__.deep_read_state(__vite_ssr_import_3__.default),
						__vite_ssr_import_2__.get(token),
						__vite_ssr_import_2__.untrack(() => __vite_ssr_import_3__.default.sanitize(`<sup class="footnote-ref footnote-ref-text">${__vite_ssr_import_2__.get(token).escapedText}</sup>`) || '')
					));

					__vite_ssr_import_2__.append($$anchor, fragment_11);
				};

				var consequent_18 = ($$anchor) => {
					var fragment_12 = __vite_ssr_import_2__.comment();
					var node_10 = __vite_ssr_import_2__.first_child(fragment_12);

					{
						var consequent_17 = ($$anchor) => {
							__vite_ssr_import_2__.add_svelte_meta(
								() => __vite_ssr_import_17__.default($$anchor, {
									get id() {
										return id();
									},

									get token() {
										return __vite_ssr_import_2__.get(token);
									},

									get sourceIds() {
										return sourceIds();
									},

									get onClick() {
										return onSourceClick();
									}
								}),
								'component',
								MarkdownInlineTokens,
								137,
								3,
								{ componentTag: 'SourceToken' }
							);
						};

						var alternate_1 = ($$anchor) => {
							__vite_ssr_import_2__.add_svelte_meta(
								() => __vite_ssr_import_13__.default($$anchor, {
									get token() {
										return __vite_ssr_import_2__.get(token);
									},

									get done() {
										return done();
									}
								}),
								'component',
								MarkdownInlineTokens,
								139,
								3,
								{ componentTag: 'TextToken' }
							);
						};

						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_2__.if(node_10, ($$render) => {
								if ((
									__vite_ssr_import_2__.deep_read_state(sourceIds()),
									__vite_ssr_import_2__.untrack(() => (sourceIds() ?? []).length > 0)
								)) $$render(consequent_17); else $$render(alternate_1, -1);
							}),
							'if',
							MarkdownInlineTokens,
							136,
							2
						);
					}

					__vite_ssr_import_2__.append($$anchor, fragment_12);
				};

				var consequent_19 = ($$anchor) => {
					__vite_ssr_import_2__.add_svelte_meta(
						() => __vite_ssr_import_13__.default($$anchor, {
							get token() {
								return __vite_ssr_import_2__.get(token);
							},

							get done() {
								return done();
							}
						}),
						'component',
						MarkdownInlineTokens,
						142,
						2,
						{ componentTag: 'TextToken' }
					);
				};

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_2__.if(node_1, ($$render) => {
						if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'escape'))
						)) $$render(consequent); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'html'))
						)) $$render(consequent_1, 1); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'link'))
						)) $$render(consequent_4, 2); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'image'))
						)) $$render(consequent_5, 3); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'strong'))
						)) $$render(consequent_6, 4); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'em'))
						)) $$render(consequent_7, 5); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'codespan'))
						)) $$render(consequent_8, 6); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'br'))
						)) $$render(consequent_9, 7); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'del'))
						)) $$render(consequent_10, 8); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'underline'))
						)) $$render(consequent_11, 9); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'inlineKatex'))
						)) $$render(consequent_13, 10); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'iframe'))
						)) $$render(consequent_14, 11); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'mention'))
						)) $$render(consequent_15, 12); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'footnote'))
						)) $$render(consequent_16, 13); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'citation'))
						)) $$render(consequent_18, 14); else if ((
							__vite_ssr_import_2__.get(token),
							__vite_ssr_import_2__.untrack(() => __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(token).type, 'text'))
						)) $$render(consequent_19, 15);
					}),
					'if',
					MarkdownInlineTokens,
					71,
					1
				);
			}

			__vite_ssr_import_2__.append($$anchor, fragment_1);
		}),
		'each',
		MarkdownInlineTokens,
		70,
		0
	);

	__vite_ssr_import_2__.append($$anchor, fragment);

	return __vite_ssr_import_2__.pop($$exports);
}
Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: MarkdownInlineTokens });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ2tDO0FBQ0k7QUFHRjtBQUNHO0FBSVM7QUFDVztBQUVIO0FBQ0w7QUFDZDtBQUNNO0FBQ3FCO0FBQ1E7QUFDRjtBQUNFO0FBQ3pCOzs7Ozs7Ozs7OztpREFyQi9DLENBQUM7Ozs7Q0FRQSxNQUFNLElBQUksR0FBRyxnQ0FBVSxDQUFDLE1BQU07Q0FldkIsSUFBSSxFQUFVO0NBQ2QsSUFBSSxJQUFJLGtEQUFHLElBQUk7Q0FDZixJQUFJLE1BQWU7Q0FDbkIsSUFBSSxTQUFTO0NBQ2IsSUFBSSxhQUF1QixpRUFBUyxDQUFDLENBQUM7Ozs7O0NBSzdDLE1BQU0saUJBQWlCLElBQUksSUFBWSxLQUFvQjtFQUMxRCxHQUFHLENBQUM7R0FDSCxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU07O0dBQ2hELEVBQUUsc0NBQUUsR0FBRyxDQUFDLE1BQU0sRUFBSyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRTtJQUMxQyxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxvQkFBb0I7O0lBQ3JELEVBQUUsRUFBRSxLQUFLLEVBQUU7S0FDVixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDZjtHQUNEO0VBQ0QsQ0FBQyxDQUFDLEtBQUssQ0FBQzs7RUFFUjs7RUFDQSxNQUFNLENBQUMsSUFBSTtDQUNaLENBQUM7Ozs7O0NBS0QsTUFBTSxlQUFlLElBQUksQ0FBYSxFQUFFLElBQVksS0FBSztFQUN4RCxHQUFHLENBQUM7R0FDSCxNQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU07OztHQUVoRCxFQUFFLHNDQUNELEdBQUcsQ0FBQyxNQUFNLEVBQUssTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLE1BQ3BDLEdBQUcsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLFNBQVMsS0FDakMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsS0FBSyxLQUM3QixHQUFHLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxZQUFZLElBQ3BDO0lBQ0QsQ0FBQyxDQUFDLGNBQWM7SUFDaEIsMEJBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDLElBQUk7R0FDMUM7RUFDRCxDQUFDLENBQUMsS0FBSyxDQUFDOztFQUVSO0NBQ0QsQ0FBQzs7Ozs7Ozs7Ozs0Q0FHSyxNQUFNLDBDQUFJLEtBQUs7Ozs7Ozs7Ozs7NkNBMURLLGtDQUFZO2lDQTBEdEIsS0FBSzsyQ0FFbkIsa0NBQVksMkJBQUMsS0FBSyxFQUFDLElBQUk7Ozs7Ozs7OztZQUV2Qiw4QkFBUzs7ZUFBRSxFQUFFOzs7O3lDQUFHLEtBQUs7Ozs7ZUFBRyxhQUFhOzs7Ozs7Ozs7Ozs7V0FFOUIsTUFBTTs7aUNBTkMsS0FBSzsyQ0FNSCxpQkFBaUIsMkJBQUMsS0FBSyxFQUFDLElBQUk7Ozs7OytCQUFyQyxNQUFNOzs7Ozs7OztjQUVaLDhCQUFhOzsyQ0FBRSxNQUFNOzs7OzRDQVJSLEtBQUssaUVBUVcsS0FBSyxFQUFDLElBQUk7Ozs7Ozs7Ozs7OztXQUV2QztnREFBQTs7O21FQU9vQixFQUFFOzs7ZUFBckIsb0JBQVc7Ozs7Ozs2Q0FqQkMsS0FBSyxpRUFpQmtCLEtBQUssRUFBQyxNQUFNOzs7O2tCQUFHLGFBQWE7Ozs7a0JBQUcsSUFBSTs7Ozs7Ozs7Ozs7bUNBUHZFOzs7NENBQUEsc0NBVmEsS0FBSyxpRUFXWixLQUFLLEVBQUMsSUFBSTs0Q0FEaEIsdUNBVmEsS0FBSyxpRUFjWCxLQUFLLEVBQUMsS0FBSzs7OzRDQUpsQixrQkFLVyxDQUFDO2VBQUssZUFBZSxDQUFDLENBQUMsNEJBQUUsS0FBSyxFQUFDLElBQUk7Ozs4Q0FMOUM7Ozs7V0FVQTtnREFBQTs7bUNBQUE7Ozs0Q0FBQSx3Q0FwQmEsS0FBSyxpRUFxQlosS0FBSyxFQUFDLElBQUk7NENBRGhCLHlDQXBCYSxLQUFLLGlFQXdCWCxLQUFLLEVBQUMsS0FBSzswRUF4QkwsS0FBSyxpRUF5QmdDLEtBQUssRUFBQyxJQUFJOzs7NENBTDVELHNCQUtXLENBQUM7ZUFBSyxlQUFlLENBQUMsQ0FBQyw0QkFBRSxLQUFLLEVBQUMsSUFBSTs7OzhDQUw5Qzs7Ozs7c0NBYkcsTUFBTSwrREFQSSxLQUFLLGlFQVNWLEtBQUssRUFBQyxNQUFNOzs7Ozs7Ozs7Ozs7OztZQW9CckIsNkJBQUs7OzBDQTdCUyxLQUFLLGlFQTZCUixLQUFLLEVBQUMsSUFBSTs7OzswQ0E3QlAsS0FBSyxpRUE2QlMsS0FBSyxFQUFDLElBQUk7O3NCQUFpQixJQUFJOzs7Ozs7Ozs7OztTQUUzRCxNQUFNOzhDQUFOLE1BQU07OztpRUFBcUIsRUFBRTs7O2FBQXJCLG9CQUFXOzs7Ozs7MkNBL0JMLEtBQUssaUVBK0I2QixLQUFLLEVBQUMsTUFBTTs7OztnQkFBRyxhQUFhOzs7Ozs7Ozs7OztpQ0FBNUUsTUFBTTs0Q0FBTixNQUFNOzs7O1NBRU4sRUFBRTs4Q0FBRixFQUFFOzs7aUVBQXFCLEVBQUU7OzthQUFyQixvQkFBVzs7Ozs7OzJDQWpDRCxLQUFLLGlFQWlDcUIsS0FBSyxFQUFDLE1BQU07Ozs7Z0JBQUcsYUFBYTs7Ozs7Ozs7Ozs7aUNBQXBFLEVBQUU7NENBQUYsRUFBRTs7Ozs7WUFFRiw4QkFBYTs7eUNBQUUsS0FBSzs7OztlQUFHLElBQUk7Ozs7Ozs7Ozs7OztTQUUzQixFQUFFOzs0Q0FBRixFQUFFOzs7O1NBRUYsR0FBRzs4Q0FBSCxHQUFHOzs7aUVBQXFCLEVBQUU7OzthQUFyQixvQkFBVzs7Ozs7OzJDQXZDRixLQUFLLGlFQXVDdUIsS0FBSyxFQUFDLE1BQU07Ozs7Z0JBQUcsYUFBYTs7Ozs7Ozs7Ozs7aUNBQXRFLEdBQUc7NENBQUgsR0FBRzs7OztTQUVILENBQUM7OENBQUQsQ0FBQzs7O2lFQUFxQixFQUFFOzs7YUFBckIsb0JBQVc7Ozs7OzsyQ0F6Q0EsS0FBSyxpRUF5QzJCLEtBQUssRUFBQyxNQUFNOzs7O2dCQUFHLGFBQWE7Ozs7Ozs7Ozs7O2lDQUExRSxDQUFDOzRDQUFELENBQUM7Ozs7Ozs7Ozs7O21DQXpDYSxLQUFLO3VFQTRDOEIsS0FBSyxHQUFFLFdBQVcsSUFBSSxLQUFLOzs7O2VBQTNFLDhCQUFhOzs2Q0E1Q0EsS0FBSyxpRUE0Q0ssS0FBSyxFQUFDLElBQUk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1Q0E1Q3BCLEtBQUssaUVBMkNmLEtBQUssRUFBQyxJQUFJOzs7Ozs7Ozs7Ozs7O1NBSWQ7OzswQ0FBQSxrQkFDTSxvQ0FBYyxrREFoRE4sS0FBSyxpRUFnRGlCLEtBQUssRUFBQyxNQUFNOzBDQURoRCw0Q0EvQ2MsS0FBSyxpRUFpRFosS0FBSyxFQUFDLE1BQU07Ozt5Q0FGbkIsc0JBS1UsQ0FBQyxFQUFLO01BQ2YsR0FBRyxDQUFDO09BQ0gsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUMzQixDQUFDLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLEdBQUcsSUFBSTtNQUN0RSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDVixDQUFDOzs0Q0FWRDs7Ozs7WUFhQSw4QkFBWTs7eUNBQUUsS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FoSWQsNkJBQVM7Z0NBb0VBLEtBQUs7MENBOERiLDZCQUFTLENBQUMsUUFBUSwwRUFDdUIsS0FBSyxFQUFDLFdBQVcsYUFDNUQsRUFBRTs7Ozs7Ozs7Ozs7OztjQUdMLDhCQUFXOztpQkFBRSxFQUFFOzs7OzJDQUFHLEtBQUs7Ozs7aUJBQUcsU0FBUzs7OztpQkFBVyxhQUFhOzs7Ozs7Ozs7Ozs7O2NBRTNELDhCQUFTOzsyQ0FBRSxLQUFLOzs7O2lCQUFHLElBQUk7Ozs7Ozs7Ozs7Ozs7OytDQWhIZixTQUFTOzhDQTZHYixTQUFTLFVBQVEsTUFBTSxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7OztZQU1oQyw4QkFBUzs7eUNBQUUsS0FBSzs7OztlQUFHLElBQUk7Ozs7Ozs7Ozs7Ozs7O2lDQXhFVCxLQUFLO3lHQUNoQixLQUFLLEVBQUMsSUFBSSxFQUFLLFFBQVE7O2lDQURaLEtBQUs7eUdBR1gsS0FBSyxFQUFDLElBQUksRUFBSyxNQUFNOztpQ0FIZixLQUFLO3lHQUtYLEtBQUssRUFBQyxJQUFJLEVBQUssTUFBTTs7aUNBTGYsS0FBSzt5R0E0QlgsS0FBSyxFQUFDLElBQUksRUFBSyxPQUFPOztpQ0E1QmhCLEtBQUs7eUdBOEJYLEtBQUssRUFBQyxJQUFJLEVBQUssUUFBUTs7aUNBOUJqQixLQUFLO3lHQWdDWCxLQUFLLEVBQUMsSUFBSSxFQUFLLElBQUk7O2lDQWhDYixLQUFLO3lHQWtDWCxLQUFLLEVBQUMsSUFBSSxFQUFLLFVBQVU7O2lDQWxDbkIsS0FBSzt5R0FvQ1gsS0FBSyxFQUFDLElBQUksRUFBSyxJQUFJOztpQ0FwQ2IsS0FBSzt5R0FzQ1gsS0FBSyxFQUFDLElBQUksRUFBSyxLQUFLOztpQ0F0Q2QsS0FBSzt5R0F3Q1gsS0FBSyxFQUFDLElBQUksRUFBSyxXQUFXOztpQ0F4Q3BCLEtBQUs7eUdBMENYLEtBQUssRUFBQyxJQUFJLEVBQUssYUFBYTs7aUNBMUN0QixLQUFLO3lHQThDWCxLQUFLLEVBQUMsSUFBSSxFQUFLLFFBQVE7O2lDQTlDakIsS0FBSzt5R0EyRFgsS0FBSyxFQUFDLElBQUksRUFBSyxTQUFTOztpQ0EzRGxCLEtBQUs7eUdBNkRYLEtBQUssRUFBQyxJQUFJLEVBQUssVUFBVTs7aUNBN0RuQixLQUFLO3lHQWlFWCxLQUFLLEVBQUMsSUFBSSxFQUFLLFVBQVU7O2lDQWpFbkIsS0FBSzt5R0F1RVgsS0FBSyxFQUFDLElBQUksRUFBSyxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF6RXhCIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJNYXJrZG93bklubGluZVRva2Vucy5zdmVsdGUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBsYW5nPVwidHNcIj5cblx0aW1wb3J0IERPTVB1cmlmeSBmcm9tICdkb21wdXJpZnknO1xuXHRpbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3N2ZWx0ZS1zb25uZXInO1xuXG5cdGltcG9ydCB0eXBlIHsgVG9rZW4gfSBmcm9tICdtYXJrZWQnO1xuXHRpbXBvcnQgeyBnZXRDb250ZXh0IH0gZnJvbSAnc3ZlbHRlJztcblx0aW1wb3J0IHsgZ290byB9IGZyb20gJyRhcHAvbmF2aWdhdGlvbic7XG5cblx0Y29uc3QgaTE4biA9IGdldENvbnRleHQoJ2kxOG4nKTtcblxuXHRpbXBvcnQgeyBXRUJVSV9CQVNFX1VSTCB9IGZyb20gJyRsaWIvY29uc3RhbnRzJztcblx0aW1wb3J0IHsgY29weVRvQ2xpcGJvYXJkLCB1bmVzY2FwZUh0bWwgfSBmcm9tICckbGliL3V0aWxzJztcblxuXHRpbXBvcnQgSW1hZ2UgZnJvbSAnJGxpYi9jb21wb25lbnRzL2NvbW1vbi9JbWFnZS5zdmVsdGUnO1xuXHRpbXBvcnQgS2F0ZXhSZW5kZXJlciBmcm9tICcuL0thdGV4UmVuZGVyZXIuc3ZlbHRlJztcblx0aW1wb3J0IFNvdXJjZSBmcm9tICcuL1NvdXJjZS5zdmVsdGUnO1xuXHRpbXBvcnQgSHRtbFRva2VuIGZyb20gJy4vSFRNTFRva2VuLnN2ZWx0ZSc7XG5cdGltcG9ydCBUZXh0VG9rZW4gZnJvbSAnLi9NYXJrZG93bklubGluZVRva2Vucy9UZXh0VG9rZW4uc3ZlbHRlJztcblx0aW1wb3J0IENvZGVzcGFuVG9rZW4gZnJvbSAnLi9NYXJrZG93bklubGluZVRva2Vucy9Db2Rlc3BhblRva2VuLnN2ZWx0ZSc7XG5cdGltcG9ydCBNZW50aW9uVG9rZW4gZnJvbSAnLi9NYXJrZG93bklubGluZVRva2Vucy9NZW50aW9uVG9rZW4uc3ZlbHRlJztcblx0aW1wb3J0IE5vdGVMaW5rVG9rZW4gZnJvbSAnLi9NYXJrZG93bklubGluZVRva2Vucy9Ob3RlTGlua1Rva2VuLnN2ZWx0ZSc7XG5cdGltcG9ydCBTb3VyY2VUb2tlbiBmcm9tICcuL1NvdXJjZVRva2VuLnN2ZWx0ZSc7XG5cblx0ZXhwb3J0IGxldCBpZDogc3RyaW5nO1xuXHRleHBvcnQgbGV0IGRvbmUgPSB0cnVlO1xuXHRleHBvcnQgbGV0IHRva2VuczogVG9rZW5bXTtcblx0ZXhwb3J0IGxldCBzb3VyY2VJZHMgPSBbXTtcblx0ZXhwb3J0IGxldCBvblNvdXJjZUNsaWNrOiBGdW5jdGlvbiA9ICgpID0+IHt9O1xuXG5cdC8qKlxuXHQgKiBDaGVjayBpZiBhIFVSTCBpcyBhIHNhbWUtb3JpZ2luIG5vdGUgbGluayBhbmQgcmV0dXJuIHRoZSBub3RlIElEIGlmIHNvLlxuXHQgKi9cblx0Y29uc3QgZ2V0Tm90ZUlkRnJvbUhyZWYgPSAoaHJlZjogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCA9PiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IHVybCA9IG5ldyBVUkwoaHJlZiwgd2luZG93LmxvY2F0aW9uLm9yaWdpbik7XG5cdFx0XHRpZiAodXJsLm9yaWdpbiA9PT0gd2luZG93LmxvY2F0aW9uLm9yaWdpbikge1xuXHRcdFx0XHRjb25zdCBtYXRjaCA9IHVybC5wYXRobmFtZS5tYXRjaCgvXlxcL25vdGVzXFwvKFteL10rKSQvKTtcblx0XHRcdFx0aWYgKG1hdGNoKSB7XG5cdFx0XHRcdFx0cmV0dXJuIG1hdGNoWzFdO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCB7XG5cdFx0XHQvLyBJbnZhbGlkIFVSTFxuXHRcdH1cblx0XHRyZXR1cm4gbnVsbDtcblx0fTtcblxuXHQvKipcblx0ICogSGFuZGxlIGxpbmsgY2xpY2tzIC0gaW50ZXJjZXB0IHNhbWUtb3JpZ2luIGFwcCBVUkxzIGZvciBpbi1hcHAgbmF2aWdhdGlvblxuXHQgKi9cblx0Y29uc3QgaGFuZGxlTGlua0NsaWNrID0gKGU6IE1vdXNlRXZlbnQsIGhyZWY6IHN0cmluZykgPT4ge1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCB1cmwgPSBuZXcgVVJMKGhyZWYsIHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4pO1xuXHRcdFx0Ly8gQ2hlY2sgaWYgc2FtZSBvcmlnaW4gYW5kIGFuIGluLWFwcCByb3V0ZVxuXHRcdFx0aWYgKFxuXHRcdFx0XHR1cmwub3JpZ2luID09PSB3aW5kb3cubG9jYXRpb24ub3JpZ2luICYmXG5cdFx0XHRcdCh1cmwucGF0aG5hbWUuc3RhcnRzV2l0aCgnL25vdGVzLycpIHx8XG5cdFx0XHRcdFx0dXJsLnBhdGhuYW1lLnN0YXJ0c1dpdGgoJy9jLycpIHx8XG5cdFx0XHRcdFx0dXJsLnBhdGhuYW1lLnN0YXJ0c1dpdGgoJy9jaGFubmVscy8nKSlcblx0XHRcdCkge1xuXHRcdFx0XHRlLnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHRcdGdvdG8odXJsLnBhdGhuYW1lICsgdXJsLnNlYXJjaCArIHVybC5oYXNoKTtcblx0XHRcdH1cblx0XHR9IGNhdGNoIHtcblx0XHRcdC8vIEludmFsaWQgVVJMLCBsZXQgYnJvd3NlciBoYW5kbGUgaXRcblx0XHR9XG5cdH07XG48L3NjcmlwdD5cblxueyNlYWNoIHRva2VucyBhcyB0b2tlbiwgdG9rZW5JZHggKHRva2VuSWR4KX1cblx0eyNpZiB0b2tlbi50eXBlID09PSAnZXNjYXBlJ31cblx0XHR7dW5lc2NhcGVIdG1sKHRva2VuLnRleHQpfVxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ2h0bWwnfVxuXHRcdDxIdG1sVG9rZW4ge2lkfSB7dG9rZW59IHtvblNvdXJjZUNsaWNrfSAvPlxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ2xpbmsnfVxuXHRcdHtAY29uc3Qgbm90ZUlkID0gZ2V0Tm90ZUlkRnJvbUhyZWYodG9rZW4uaHJlZil9XG5cdFx0eyNpZiBub3RlSWR9XG5cdFx0XHQ8Tm90ZUxpbmtUb2tlbiB7bm90ZUlkfSBocmVmPXt0b2tlbi5ocmVmfSAvPlxuXHRcdHs6ZWxzZSBpZiB0b2tlbi50b2tlbnN9XG5cdFx0XHQ8YVxuXHRcdFx0XHRocmVmPXt0b2tlbi5ocmVmfVxuXHRcdFx0XHR0YXJnZXQ9XCJfYmxhbmtcIlxuXHRcdFx0XHRyZWw9XCJub2ZvbGxvd1wiXG5cdFx0XHRcdHRpdGxlPXt0b2tlbi50aXRsZX1cblx0XHRcdFx0b246Y2xpY2s9eyhlKSA9PiBoYW5kbGVMaW5rQ2xpY2soZSwgdG9rZW4uaHJlZil9XG5cdFx0XHQ+XG5cdFx0XHRcdDxzdmVsdGU6c2VsZiBpZD17YCR7aWR9LWFgfSB0b2tlbnM9e3Rva2VuLnRva2Vuc30ge29uU291cmNlQ2xpY2t9IHtkb25lfSAvPlxuXHRcdFx0PC9hPlxuXHRcdHs6ZWxzZX1cblx0XHRcdDxhXG5cdFx0XHRcdGhyZWY9e3Rva2VuLmhyZWZ9XG5cdFx0XHRcdHRhcmdldD1cIl9ibGFua1wiXG5cdFx0XHRcdHJlbD1cIm5vZm9sbG93XCJcblx0XHRcdFx0dGl0bGU9e3Rva2VuLnRpdGxlfVxuXHRcdFx0XHRvbjpjbGljaz17KGUpID0+IGhhbmRsZUxpbmtDbGljayhlLCB0b2tlbi5ocmVmKX0+e3Rva2VuLnRleHR9PC9hXG5cdFx0XHQ+XG5cdFx0ey9pZn1cblx0ezplbHNlIGlmIHRva2VuLnR5cGUgPT09ICdpbWFnZSd9XG5cdFx0PEltYWdlIHNyYz17dG9rZW4uaHJlZn0gYWx0PXt0b2tlbi50ZXh0fSBhbGxvd0V4dGVybmFsPXt0cnVlfSAvPlxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ3N0cm9uZyd9XG5cdFx0PHN0cm9uZz48c3ZlbHRlOnNlbGYgaWQ9e2Ake2lkfS1zdHJvbmdgfSB0b2tlbnM9e3Rva2VuLnRva2Vuc30ge29uU291cmNlQ2xpY2t9IC8+PC9zdHJvbmc+XG5cdHs6ZWxzZSBpZiB0b2tlbi50eXBlID09PSAnZW0nfVxuXHRcdDxlbT48c3ZlbHRlOnNlbGYgaWQ9e2Ake2lkfS1lbWB9IHRva2Vucz17dG9rZW4udG9rZW5zfSB7b25Tb3VyY2VDbGlja30gLz48L2VtPlxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ2NvZGVzcGFuJ31cblx0XHQ8Q29kZXNwYW5Ub2tlbiB7dG9rZW59IHtkb25lfSAvPlxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ2JyJ31cblx0XHQ8YnIgLz5cblx0ezplbHNlIGlmIHRva2VuLnR5cGUgPT09ICdkZWwnfVxuXHRcdDxkZWw+PHN2ZWx0ZTpzZWxmIGlkPXtgJHtpZH0tZGVsYH0gdG9rZW5zPXt0b2tlbi50b2tlbnN9IHtvblNvdXJjZUNsaWNrfSAvPjwvZGVsPlxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ3VuZGVybGluZSd9XG5cdFx0PHU+PHN2ZWx0ZTpzZWxmIGlkPXtgJHtpZH0tdW5kZXJsaW5lYH0gdG9rZW5zPXt0b2tlbi50b2tlbnN9IHtvblNvdXJjZUNsaWNrfSAvPjwvdT5cblx0ezplbHNlIGlmIHRva2VuLnR5cGUgPT09ICdpbmxpbmVLYXRleCd9XG5cdFx0eyNpZiB0b2tlbi50ZXh0fVxuXHRcdFx0PEthdGV4UmVuZGVyZXIgY29udGVudD17dG9rZW4udGV4dH0gZGlzcGxheU1vZGU9e3Rva2VuPy5kaXNwbGF5TW9kZSA/PyBmYWxzZX0gLz5cblx0XHR7L2lmfVxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ2lmcmFtZSd9XG5cdFx0PGlmcmFtZVxuXHRcdFx0c3JjPVwie1dFQlVJX0JBU0VfVVJMfS9hcGkvdjEvZmlsZXMve3Rva2VuLmZpbGVJZH0vY29udGVudFwiXG5cdFx0XHR0aXRsZT17dG9rZW4uZmlsZUlkfVxuXHRcdFx0d2lkdGg9XCIxMDAlXCJcblx0XHRcdGZyYW1lYm9yZGVyPVwiMFwiXG5cdFx0XHRvbjpsb2FkPXsoZSkgPT4ge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGUuY3VycmVudFRhcmdldC5zdHlsZS5oZWlnaHQgPVxuXHRcdFx0XHRcdFx0ZS5jdXJyZW50VGFyZ2V0LmNvbnRlbnRXaW5kb3cuZG9jdW1lbnQuYm9keS5zY3JvbGxIZWlnaHQgKyAyMCArICdweCc7XG5cdFx0XHRcdH0gY2F0Y2gge31cblx0XHRcdH19XG5cdFx0PjwvaWZyYW1lPlxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ21lbnRpb24nfVxuXHRcdDxNZW50aW9uVG9rZW4ge3Rva2VufSAvPlxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ2Zvb3Rub3RlJ31cblx0XHR7QGh0bWwgRE9NUHVyaWZ5LnNhbml0aXplKFxuXHRcdFx0YDxzdXAgY2xhc3M9XCJmb290bm90ZS1yZWYgZm9vdG5vdGUtcmVmLXRleHRcIj4ke3Rva2VuLmVzY2FwZWRUZXh0fTwvc3VwPmBcblx0XHQpIHx8ICcnfVxuXHR7OmVsc2UgaWYgdG9rZW4udHlwZSA9PT0gJ2NpdGF0aW9uJ31cblx0XHR7I2lmIChzb3VyY2VJZHMgPz8gW10pLmxlbmd0aCA+IDB9XG5cdFx0XHQ8U291cmNlVG9rZW4ge2lkfSB7dG9rZW59IHtzb3VyY2VJZHN9IG9uQ2xpY2s9e29uU291cmNlQ2xpY2t9IC8+XG5cdFx0ezplbHNlfVxuXHRcdFx0PFRleHRUb2tlbiB7dG9rZW59IHtkb25lfSAvPlxuXHRcdHsvaWZ9XG5cdHs6ZWxzZSBpZiB0b2tlbi50eXBlID09PSAndGV4dCd9XG5cdFx0PFRleHRUb2tlbiB7dG9rZW59IHtkb25lfSAvPlxuXHR7L2lmfVxuey9lYWNofVxuIl0sImZpbGUiOiIvc3JjL2xpYi9jb21wb25lbnRzL2NoYXQvTWVzc2FnZXMvTWFya2Rvd24vTWFya2Rvd25JbmxpbmVUb2tlbnMuc3ZlbHRlIn0=
