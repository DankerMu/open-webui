// /src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/MentionToken.svelte
const __vite_ssr_import_0__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/disclose-version.js");
const __vite_ssr_import_1__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/flags/legacy.js");
const __vite_ssr_import_2__ = await __vite_ssr_import__("/node_modules/svelte/src/internal/client/index.js");
const __vite_ssr_import_3__ = await __vite_ssr_import__("/node_modules/bits-ui/dist/index.js", {"importedNames":["LinkPreview"]});
const __vite_ssr_import_4__ = await __vite_ssr_import__("/node_modules/svelte/src/index-client.js", {"importedNames":["getContext"]});
const __vite_ssr_import_5__ = await __vite_ssr_import__("/node_modules/@sveltejs/kit/src/runtime/app/navigation.js", {"importedNames":["goto"]});
const __vite_ssr_import_6__ = await __vite_ssr_import__("/src/lib/stores/index.ts", {"importedNames":["channels","models"]});
const __vite_ssr_import_7__ = await __vite_ssr_import__("/src/lib/components/channel/Messages/Message/UserStatus.svelte", {"importedNames":["default"]});
const __vite_ssr_import_8__ = await __vite_ssr_import__("/src/lib/components/channel/Messages/Message/UserStatusLinkPreview.svelte", {"importedNames":["default"]});



MentionToken[__vite_ssr_import_2__.FILENAME] = 'src/lib/components/chat/Messages/Markdown/MarkdownInlineTokens/MentionToken.svelte';









var root = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<span class="mention"> </span>`), MentionToken[__vite_ssr_import_2__.FILENAME], [[89, 2]]);
var root_1 = __vite_ssr_import_2__.add_locations(__vite_ssr_import_2__.from_html(`<!> <!>`, 1), MentionToken[__vite_ssr_import_2__.FILENAME], []);

function MentionToken($$anchor, $$props) {
	__vite_ssr_import_2__.check_target(new.target);
	__vite_ssr_import_2__.push($$props, false, MentionToken);

	const $channels = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_6__.channels, 'channels'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_6__.channels, '$channels', $$stores)
	);

	const $i18n = () => (
		__vite_ssr_import_2__.validate_store(i18n, 'i18n'),
		__vite_ssr_import_2__.store_get(i18n, '$i18n', $$stores)
	);

	const $models = () => (
		__vite_ssr_import_2__.validate_store(__vite_ssr_import_6__.models, 'models'),
		__vite_ssr_import_2__.store_get(__vite_ssr_import_6__.models, '$models', $$stores)
	);

	const [$$stores, $$cleanup] = __vite_ssr_import_2__.setup_stores();
	const i18n = __vite_ssr_import_4__.getContext('i18n');
	let token = __vite_ssr_import_2__.prop($$props, 'token', 8);
	let triggerChar = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'triggerChar');
	let label = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'label');
	let idType = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(null), 'idType');
	let id = __vite_ssr_import_2__.tag(__vite_ssr_import_2__.mutable_source(''), 'id');

	const init = () => {
		const _id = token()?.id;

		__vite_ssr_import_2__.set(triggerChar, token()?.triggerChar ?? '@');

		if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(triggerChar), '$')) {
			// Skill mention: id format is "skillId|label"
			const pipeIdx = _id?.indexOf('|') ?? -1;

			if (pipeIdx > 0) {
				__vite_ssr_import_2__.set(id, _id.substring(0, pipeIdx));
				__vite_ssr_import_2__.set(label, _id.substring(pipeIdx + 1));
			} else {
				__vite_ssr_import_2__.set(id, _id);
				__vite_ssr_import_2__.set(label, _id);
			}

			__vite_ssr_import_2__.set(idType, null);

			return;
		}

		// split by : and take first part as idType and second part as id
		const parts = _id?.split(':');

		if (parts) {
			__vite_ssr_import_2__.set(idType, parts[0]);
			__vite_ssr_import_2__.set(id, parts.slice(1).join(':') // in case id contains ':'
			);
		} else {
			__vite_ssr_import_2__.set(idType, null);
			__vite_ssr_import_2__.set(id, _id);
		}

		__vite_ssr_import_2__.set(label, token()?.label ?? __vite_ssr_import_2__.get(id));

		if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(triggerChar), '#')) {
			if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(idType), 'C')) {
				// Channel
				const channel = $channels().find((c) => __vite_ssr_import_2__.strict_equals(c.id, __vite_ssr_import_2__.get(id)));

				if (channel) {
					__vite_ssr_import_2__.set(label, channel.name);
				} else {
					__vite_ssr_import_2__.set(label, $i18n().t('Unknown'));
				}
			} else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(idType), 'T')) {
				// Thread
			}
		} else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(triggerChar), '@')) {
			if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(idType), 'U')) {
				// User
			} else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(idType), 'M')) {
				// Model
				const model = $models().find((m) => __vite_ssr_import_2__.strict_equals(m.id, __vite_ssr_import_2__.get(id)));

				if (model) {
					__vite_ssr_import_2__.set(label, model.name);
				} else {
					__vite_ssr_import_2__.set(label, $i18n().t('Unknown'));
				}
			}
		}
	};

	__vite_ssr_import_2__.legacy_pre_effect(() => (__vite_ssr_import_2__.deep_read_state(token())), () => {
		if (token()) {
			init();
		}
	});

	__vite_ssr_import_2__.legacy_pre_effect_reset();

	var $$exports = { ...__vite_ssr_import_2__.legacy_api() };

	__vite_ssr_import_2__.init();

	__vite_ssr_import_2__.add_svelte_meta(
		() => // Skill mention: id format is "skillId|label"
		// split by : and take first part as idType and second part as id
		// in case id contains ':'
		// Channel
		// Thread
		// User
		// Model
		__vite_ssr_import_3__.LinkPreview.Root($$anchor, {
			openDelay: 0,
			closeDelay: 0,
			children: __vite_ssr_import_2__.wrap_snippet(MentionToken, ($$anchor, $$slotProps) => {
				var fragment_1 = root_1();
				var node = __vite_ssr_import_2__.first_child(fragment_1);

				__vite_ssr_import_2__.add_svelte_meta(
					() => __vite_ssr_import_3__.LinkPreview.Trigger(node, {
						class: ' cursor-pointer no-underline! font-normal! ',
						children: __vite_ssr_import_2__.wrap_snippet(MentionToken, ($$anchor, $$slotProps) => {
							var span = root();
							var text = __vite_ssr_import_2__.child(span);

							__vite_ssr_import_2__.reset(span);
							__vite_ssr_import_2__.template_effect(() => __vite_ssr_import_2__.set_text(text, `${__vite_ssr_import_2__.get(triggerChar) ?? ''}${__vite_ssr_import_2__.get(label) ?? ''}`));

							__vite_ssr_import_2__.event('click', span, async function click() {
								if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(triggerChar), '@')) {
									if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(idType), 'U')) {
										// Open user profile
										console.log(...__vite_ssr_import_2__.log_if_contains_state('log', 'Clicked user mention', __vite_ssr_import_2__.get(id)));
									} else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(idType), 'M')) {
										console.log(...__vite_ssr_import_2__.log_if_contains_state('log', 'Clicked model mention', __vite_ssr_import_2__.get(id)));
										(await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_5__.goto(`/?model=${__vite_ssr_import_2__.get(id)}`)))();
									}
								} else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(triggerChar), '#')) {
									if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(idType), 'C')) {
										// Open channel
										if ($channels().find((c) => __vite_ssr_import_2__.strict_equals(c.id, __vite_ssr_import_2__.get(id)))) {
											(await __vite_ssr_import_2__.track_reactivity_loss(__vite_ssr_import_5__.goto(`/channels/${__vite_ssr_import_2__.get(id)}`)))();
										}
									} else if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(idType), 'T')) {
										// Open thread
									}
								} else {
									// Unknown trigger char, just log
									console.log(...__vite_ssr_import_2__.log_if_contains_state('log', 'Clicked mention', __vite_ssr_import_2__.get(id)));
								}
							});

							__vite_ssr_import_2__.append($$anchor, span);
						}),
						$$slots: { default: true }
					}),
					'component',
					MentionToken,
					85,
					1,
					{ componentTag: 'LinkPreview.Trigger' }
				);

				var node_1 = __vite_ssr_import_2__.sibling(node, 2);

				{
					var consequent = ($$anchor) => {
						__vite_ssr_import_2__.add_svelte_meta(
							() => __vite_ssr_import_8__.default($$anchor, {
								get id() {
									return __vite_ssr_import_2__.get(id);
								}
							}),
							'component',
							MentionToken,
							120,
							2,
							{ componentTag: 'UserStatusLinkPreview' }
						);
					};

					__vite_ssr_import_2__.add_svelte_meta(
						() => __vite_ssr_import_2__.if(node_1, ($$render) => {
							if (__vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(triggerChar), '@') && __vite_ssr_import_2__.strict_equals(__vite_ssr_import_2__.get(idType), 'U')) $$render(consequent);
						}),
						'if',
						MentionToken,
						119,
						1
					);
				}

				__vite_ssr_import_2__.append($$anchor, fragment_1);
			}),
			$$slots: { default: true }
		}),
		'component',
		MentionToken,
		84,
		0,
		{ componentTag: 'LinkPreview.Root' }
	);

	var $$pop = __vite_ssr_import_2__.pop($$exports);

	$$cleanup();

	return $$pop;
}
Object.defineProperty(__vite_ssr_exports__, "default", { enumerable: true, configurable: true, value: MentionToken });

//# sourceMappingSource=vite-node
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7O0FBRXNDO0FBRUY7QUFFRztBQUNRO0FBQ3FDO0FBQ3NCOzs7Ozt5Q0FUMUcsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FXQSxNQUFNLElBQUksR0FBRyxnQ0FBVSxDQUFDLE1BQU07Q0FFdkIsSUFBSSxLQUFZO0NBRXZCLElBQUksV0FBVyxrRUFBRyxFQUFFO0NBQ3BCLElBQUksS0FBSyxrRUFBRyxFQUFFO0NBRWQsSUFBSSxNQUFNLGtFQUFHLElBQUk7Q0FDakIsSUFBSSxFQUFFLGtFQUFHLEVBQUU7O0NBTVgsTUFBTSxJQUFJLFNBQVM7RUFDbEIsTUFBTSxHQUFHLEdBQUcsS0FBSyxJQUFFLEVBQUU7OzRCQUNyQixXQUFXLEVBQUcsS0FBSyxJQUFFLFdBQVcsSUFBSSxHQUFHOztFQUV2QyxFQUFFLGdFQUFFLFdBQVcsR0FBSyxHQUFHLEdBQUU7O0dBRXhCLE1BQU0sT0FBTyxHQUFHLEdBQUcsRUFBRSxPQUFPLENBQUMsR0FBRyxNQUFNLENBQUM7O0dBQ3ZDLEVBQUUsRUFBRSxPQUFPLEdBQUcsQ0FBQyxFQUFFOzhCQUNoQixFQUFFLEVBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsT0FBTzs4QkFDN0IsS0FBSyxFQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxHQUFHLENBQUM7R0FDbEMsQ0FBQyxDQUFDLElBQUksQ0FBQzs4QkFDTixFQUFFLEVBQUcsR0FBRzs4QkFDUixLQUFLLEVBQUcsR0FBRztHQUNaOzs2QkFDQSxNQUFNLEVBQUcsSUFBSTs7R0FDYixNQUFNO0VBQ1A7OztFQUdBLE1BQU0sS0FBSyxHQUFHLEdBQUcsRUFBRSxLQUFLLENBQUMsR0FBRzs7RUFDNUIsRUFBRSxFQUFFLEtBQUssRUFBRTs2QkFDVixNQUFNLEVBQUcsS0FBSyxDQUFDLENBQUM7NkJBQ2hCLEVBQUUsRUFBRyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRzs7RUFDN0IsQ0FBQyxDQUFDLElBQUksQ0FBQzs2QkFDTixNQUFNLEVBQUcsSUFBSTs2QkFDYixFQUFFLEVBQUcsR0FBRztFQUNUOzs0QkFFQSxLQUFLLEVBQUcsS0FBSyxJQUFFLEtBQUssOEJBQUksRUFBRTs7RUFFMUIsRUFBRSxnRUFBRSxXQUFXLEdBQUssR0FBRyxHQUFFO0dBQ3hCLEVBQUUsZ0VBQUUsTUFBTSxHQUFLLEdBQUcsR0FBRTs7SUFFbkIsTUFBTSxPQUFPLEdBQUcsU0FBUyxHQUFDLElBQUksRUFBRSxDQUFDLHlDQUFLLENBQUMsQ0FBQyxFQUFFLDRCQUFLLEVBQUU7O0lBQ2pELEVBQUUsRUFBRSxPQUFPLEVBQUU7K0JBQ1osS0FBSyxFQUFHLE9BQU8sQ0FBQyxJQUFJO0lBQ3JCLENBQUMsQ0FBQyxJQUFJLENBQUM7K0JBQ04sS0FBSyxFQUFHLEtBQUssR0FBQyxDQUFDLENBQUMsU0FBUztJQUMxQjtHQUNELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxnRUFBRSxNQUFNLEdBQUssR0FBRyxHQUFFOztHQUUzQjtFQUNELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxnRUFBRSxXQUFXLEdBQUssR0FBRyxHQUFFO0dBQy9CLEVBQUUsZ0VBQUUsTUFBTSxHQUFLLEdBQUcsR0FBRTs7R0FFcEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLGdFQUFFLE1BQU0sR0FBSyxHQUFHLEdBQUU7O0lBRTFCLE1BQU0sS0FBSyxHQUFHLE9BQU8sR0FBQyxJQUFJLEVBQUUsQ0FBQyx5Q0FBSyxDQUFDLENBQUMsRUFBRSw0QkFBSyxFQUFFOztJQUM3QyxFQUFFLEVBQUUsS0FBSyxFQUFFOytCQUNWLEtBQUssRUFBRyxLQUFLLENBQUMsSUFBSTtJQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDOytCQUNOLEtBQUssRUFBRyxLQUFLLEdBQUMsQ0FBQyxDQUFDLFNBQVM7SUFDMUI7R0FDRDtFQUNEO0NBQ0QsQ0FBQzs7O0VBM0RFLEVBQUUsRUFBRSxLQUFLLElBQUU7R0FDYixJQUFJO0VBQ0w7Ozs7Ozs7Ozs7Ozs7Ozs7OztjQTRENEIsQ0FBQztlQUFjLENBQUM7Ozs7Ozs7OztXQUsxQzs4Q0FBQTs7bUNBQUE7cUhBMEJDLFdBQVcsb0NBQUUsS0FBSzs7NENBMUJuQiw2QkFFc0I7UUFDckIsRUFBRSxnRUFBRSxXQUFXLEdBQUssR0FBRyxHQUFFO1NBQ3hCLEVBQUUsZ0VBQUUsTUFBTSxHQUFLLEdBQUcsR0FBRTs7VUFFbkIsT0FBTyxDQUFDLEdBQUcsdURBQUMsc0JBQXNCLDRCQUFFLEVBQUU7U0FDdkMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLGdFQUFFLE1BQU0sR0FBSyxHQUFHLEdBQUU7VUFDMUIsT0FBTyxDQUFDLEdBQUcsdURBQUMsdUJBQXVCLDRCQUFFLEVBQUU7NkRBQ2pDLDBCQUFJLHNDQUFZLEVBQUU7U0FDekI7UUFDRCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsZ0VBQUUsV0FBVyxHQUFLLEdBQUcsR0FBRTtTQUMvQixFQUFFLGdFQUFFLE1BQU0sR0FBSyxHQUFHLEdBQUU7O1VBRW5CLEVBQUUsRUFBRSxTQUFTLEdBQUMsSUFBSSxFQUFFLENBQUMseUNBQUssQ0FBQyxDQUFDLEVBQUUsNEJBQUssRUFBRSxLQUFHOzhEQUNqQywwQkFBSSx3Q0FBYyxFQUFFO1VBQzNCO1NBQ0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLGdFQUFFLE1BQU0sR0FBSyxHQUFHLEdBQUU7O1NBRTNCO1FBQ0QsQ0FBQyxDQUFDLElBQUksQ0FBQzs7U0FFTixPQUFPLENBQUMsR0FBRyx1REFBQyxpQkFBaUIsNEJBQUUsRUFBRTtRQUNsQztPQUNELENBQUM7OzhDQXhCRDs7Ozs7Ozs7Ozs7Ozs7OzthQStCQSw2QkFBcUI7OzBDQUFFLEVBQUU7Ozs7Ozs7Ozs7Ozs7eUVBRHRCLFdBQVcsR0FBSyxHQUFHLG1FQUFJLE1BQU0sR0FBSyxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBckNuQyIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTWVudGlvblRva2VuLnN2ZWx0ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8c2NyaXB0IGxhbmc9XCJ0c1wiPlxuXHRpbXBvcnQgdHlwZSB7IFRva2VuIH0gZnJvbSAnbWFya2VkJztcblx0aW1wb3J0IHsgTGlua1ByZXZpZXcgfSBmcm9tICdiaXRzLXVpJztcblxuXHRpbXBvcnQgeyBnZXRDb250ZXh0IH0gZnJvbSAnc3ZlbHRlJztcblxuXHRpbXBvcnQgeyBnb3RvIH0gZnJvbSAnJGFwcC9uYXZpZ2F0aW9uJztcblx0aW1wb3J0IHsgY2hhbm5lbHMsIG1vZGVscyB9IGZyb20gJyRsaWIvc3RvcmVzJztcblx0aW1wb3J0IFVzZXJTdGF0dXMgZnJvbSAnJGxpYi9jb21wb25lbnRzL2NoYW5uZWwvTWVzc2FnZXMvTWVzc2FnZS9Vc2VyU3RhdHVzLnN2ZWx0ZSc7XG5cdGltcG9ydCBVc2VyU3RhdHVzTGlua1ByZXZpZXcgZnJvbSAnJGxpYi9jb21wb25lbnRzL2NoYW5uZWwvTWVzc2FnZXMvTWVzc2FnZS9Vc2VyU3RhdHVzTGlua1ByZXZpZXcuc3ZlbHRlJztcblxuXHRjb25zdCBpMThuID0gZ2V0Q29udGV4dCgnaTE4bicpO1xuXG5cdGV4cG9ydCBsZXQgdG9rZW46IFRva2VuO1xuXG5cdGxldCB0cmlnZ2VyQ2hhciA9ICcnO1xuXHRsZXQgbGFiZWwgPSAnJztcblxuXHRsZXQgaWRUeXBlID0gbnVsbDtcblx0bGV0IGlkID0gJyc7XG5cblx0JDogaWYgKHRva2VuKSB7XG5cdFx0aW5pdCgpO1xuXHR9XG5cblx0Y29uc3QgaW5pdCA9ICgpID0+IHtcblx0XHRjb25zdCBfaWQgPSB0b2tlbj8uaWQ7XG5cdFx0dHJpZ2dlckNoYXIgPSB0b2tlbj8udHJpZ2dlckNoYXIgPz8gJ0AnO1xuXG5cdFx0aWYgKHRyaWdnZXJDaGFyID09PSAnJCcpIHtcblx0XHRcdC8vIFNraWxsIG1lbnRpb246IGlkIGZvcm1hdCBpcyBcInNraWxsSWR8bGFiZWxcIlxuXHRcdFx0Y29uc3QgcGlwZUlkeCA9IF9pZD8uaW5kZXhPZignfCcpID8/IC0xO1xuXHRcdFx0aWYgKHBpcGVJZHggPiAwKSB7XG5cdFx0XHRcdGlkID0gX2lkLnN1YnN0cmluZygwLCBwaXBlSWR4KTtcblx0XHRcdFx0bGFiZWwgPSBfaWQuc3Vic3RyaW5nKHBpcGVJZHggKyAxKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGlkID0gX2lkO1xuXHRcdFx0XHRsYWJlbCA9IF9pZDtcblx0XHRcdH1cblx0XHRcdGlkVHlwZSA9IG51bGw7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXG5cdFx0Ly8gc3BsaXQgYnkgOiBhbmQgdGFrZSBmaXJzdCBwYXJ0IGFzIGlkVHlwZSBhbmQgc2Vjb25kIHBhcnQgYXMgaWRcblx0XHRjb25zdCBwYXJ0cyA9IF9pZD8uc3BsaXQoJzonKTtcblx0XHRpZiAocGFydHMpIHtcblx0XHRcdGlkVHlwZSA9IHBhcnRzWzBdO1xuXHRcdFx0aWQgPSBwYXJ0cy5zbGljZSgxKS5qb2luKCc6Jyk7IC8vIGluIGNhc2UgaWQgY29udGFpbnMgJzonXG5cdFx0fSBlbHNlIHtcblx0XHRcdGlkVHlwZSA9IG51bGw7XG5cdFx0XHRpZCA9IF9pZDtcblx0XHR9XG5cblx0XHRsYWJlbCA9IHRva2VuPy5sYWJlbCA/PyBpZDtcblxuXHRcdGlmICh0cmlnZ2VyQ2hhciA9PT0gJyMnKSB7XG5cdFx0XHRpZiAoaWRUeXBlID09PSAnQycpIHtcblx0XHRcdFx0Ly8gQ2hhbm5lbFxuXHRcdFx0XHRjb25zdCBjaGFubmVsID0gJGNoYW5uZWxzLmZpbmQoKGMpID0+IGMuaWQgPT09IGlkKTtcblx0XHRcdFx0aWYgKGNoYW5uZWwpIHtcblx0XHRcdFx0XHRsYWJlbCA9IGNoYW5uZWwubmFtZTtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRsYWJlbCA9ICRpMThuLnQoJ1Vua25vd24nKTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIGlmIChpZFR5cGUgPT09ICdUJykge1xuXHRcdFx0XHQvLyBUaHJlYWRcblx0XHRcdH1cblx0XHR9IGVsc2UgaWYgKHRyaWdnZXJDaGFyID09PSAnQCcpIHtcblx0XHRcdGlmIChpZFR5cGUgPT09ICdVJykge1xuXHRcdFx0XHQvLyBVc2VyXG5cdFx0XHR9IGVsc2UgaWYgKGlkVHlwZSA9PT0gJ00nKSB7XG5cdFx0XHRcdC8vIE1vZGVsXG5cdFx0XHRcdGNvbnN0IG1vZGVsID0gJG1vZGVscy5maW5kKChtKSA9PiBtLmlkID09PSBpZCk7XG5cdFx0XHRcdGlmIChtb2RlbCkge1xuXHRcdFx0XHRcdGxhYmVsID0gbW9kZWwubmFtZTtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRsYWJlbCA9ICRpMThuLnQoJ1Vua25vd24nKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fTtcbjwvc2NyaXB0PlxuXG48TGlua1ByZXZpZXcuUm9vdCBvcGVuRGVsYXk9ezB9IGNsb3NlRGVsYXk9ezB9PlxuXHQ8TGlua1ByZXZpZXcuVHJpZ2dlciBjbGFzcz1cIiBjdXJzb3ItcG9pbnRlciBuby11bmRlcmxpbmUhIGZvbnQtbm9ybWFsISBcIj5cblx0XHQ8IS0tIHN2ZWx0ZS1pZ25vcmUgYTExeS1jbGljay1ldmVudHMtaGF2ZS1rZXktZXZlbnRzIC0tPlxuXHRcdDwhLS0gc3ZlbHRlLWlnbm9yZSBhMTF5LW5vLXN0YXRpYy1lbGVtZW50LWludGVyYWN0aW9ucyAtLT5cblxuXHRcdDxzcGFuXG5cdFx0XHRjbGFzcz1cIm1lbnRpb25cIlxuXHRcdFx0b246Y2xpY2s9e2FzeW5jICgpID0+IHtcblx0XHRcdFx0aWYgKHRyaWdnZXJDaGFyID09PSAnQCcpIHtcblx0XHRcdFx0XHRpZiAoaWRUeXBlID09PSAnVScpIHtcblx0XHRcdFx0XHRcdC8vIE9wZW4gdXNlciBwcm9maWxlXG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZygnQ2xpY2tlZCB1c2VyIG1lbnRpb24nLCBpZCk7XG5cdFx0XHRcdFx0fSBlbHNlIGlmIChpZFR5cGUgPT09ICdNJykge1xuXHRcdFx0XHRcdFx0Y29uc29sZS5sb2coJ0NsaWNrZWQgbW9kZWwgbWVudGlvbicsIGlkKTtcblx0XHRcdFx0XHRcdGF3YWl0IGdvdG8oYC8/bW9kZWw9JHtpZH1gKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0gZWxzZSBpZiAodHJpZ2dlckNoYXIgPT09ICcjJykge1xuXHRcdFx0XHRcdGlmIChpZFR5cGUgPT09ICdDJykge1xuXHRcdFx0XHRcdFx0Ly8gT3BlbiBjaGFubmVsXG5cdFx0XHRcdFx0XHRpZiAoJGNoYW5uZWxzLmZpbmQoKGMpID0+IGMuaWQgPT09IGlkKSkge1xuXHRcdFx0XHRcdFx0XHRhd2FpdCBnb3RvKGAvY2hhbm5lbHMvJHtpZH1gKTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9IGVsc2UgaWYgKGlkVHlwZSA9PT0gJ1QnKSB7XG5cdFx0XHRcdFx0XHQvLyBPcGVuIHRocmVhZFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHQvLyBVbmtub3duIHRyaWdnZXIgY2hhciwganVzdCBsb2dcblx0XHRcdFx0XHRjb25zb2xlLmxvZygnQ2xpY2tlZCBtZW50aW9uJywgaWQpO1xuXHRcdFx0XHR9XG5cdFx0XHR9fVxuXHRcdD5cblx0XHRcdHt0cmlnZ2VyQ2hhcn17bGFiZWx9XG5cdFx0PC9zcGFuPlxuXHQ8L0xpbmtQcmV2aWV3LlRyaWdnZXI+XG5cblx0eyNpZiB0cmlnZ2VyQ2hhciA9PT0gJ0AnICYmIGlkVHlwZSA9PT0gJ1UnfVxuXHRcdDxVc2VyU3RhdHVzTGlua1ByZXZpZXcge2lkfSAvPlxuXHR7L2lmfVxuPC9MaW5rUHJldmlldy5Sb290PlxuIl0sImZpbGUiOiIvc3JjL2xpYi9jb21wb25lbnRzL2NoYXQvTWVzc2FnZXMvTWFya2Rvd24vTWFya2Rvd25JbmxpbmVUb2tlbnMvTWVudGlvblRva2VuLnN2ZWx0ZSJ9
