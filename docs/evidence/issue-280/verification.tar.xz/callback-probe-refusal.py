"""Parent-owned HTTP callback admission across a native replacement/index outage."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time

root, output = map(Path, sys.argv[1:])
assert not output.exists()
for name in ('ALL_PROXY','HTTP_PROXY','HTTPS_PROXY','all_proxy','http_proxy','https_proxy'):
    os.environ.pop(name,None)
os.environ['NO_PROXY'] = os.environ['no_proxy'] = '*'
sys.path[:0] = [str(root),str(root/'computer-use-server')]
import pytest
from tests.orchestrator.test_office_sessions import office_world, _outputs, _snapshot, _state, _versions
from tests.orchestrator.test_office_callback_publish import _opened, _allocate, _surviving, _post
from tests.orchestrator.test_office_callback_processing import CHANGED, _content_origin, _bind_internal
from tests.orchestrator._office_store import _child_env, CHAT

WORKER = r'''
import json,os,time
from pathlib import Path
from types import SimpleNamespace
from docker.errors import NotFound
import docker_manager
from office.publish import publish

def absent(identity):
    raise NotFound(identity)
docker_manager._docker_client=SimpleNamespace(containers=SimpleNamespace(get=absent))
replace=os.replace
def replaced(source,destination,*args,**kwargs):
    result=replace(source,destination,*args,**kwargs)
    if destination=='report.docx':
        Path(os.environ['PROBE_MARKER']).write_text('replaced')
        while True:time.sleep(.02)
    return result
os.replace=replaced
publish(os.environ['OCU_CHAT'],os.environ['PROBE_JOURNAL'])
'''

rows=[]
identities={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ('computer-use-server/office/publish.py','computer-use-server/office/callback.py','computer-use-server/office/sessions.py')}
for final in (False,True):
    for old_epoch in (False,True):
        with tempfile.TemporaryDirectory(prefix='issue-280-callback-') as temporary,pytest.MonkeyPatch.context() as patch:
            fixture=office_world.__wrapped__(Path(temporary),patch)
            world=next(fixture)
            try:
                http,data,_origin,_manager,_broker,_baseline,session=_opened(world)
                if not final:_allocate(http,session,patch)
                with _content_origin({'/save.docx':CHANGED,'/rejected.docx':CHANGED+b'rejected'}) as server,_bind_internal(patch,server.url):
                    payload=_surviving(http,data,session,patch,server,final=final)
                    accepted=json.loads(_state(data).read_bytes())
                    journal,=accepted['journal']
                    index=data/CHAT/'.ocu/index.json'
                    good_index=index.read_bytes();initial_revision=json.loads(good_index)['counter']
                    marker=Path(temporary)/'replace-marker'
                    child=subprocess.Popen([sys.executable,'-c',WORKER],cwd=root/'computer-use-server',env=_child_env(data,PROBE_MARKER=str(marker),PROBE_JOURNAL=journal),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
                    try:
                        deadline=time.monotonic()+15
                        while not marker.exists():
                            if child.poll() is not None or time.monotonic()>=deadline:
                                if child.poll() is None:child.kill()
                                stdout,stderr=child.communicate(timeout=5)
                                raise AssertionError((stdout,stderr))
                            time.sleep(.01)
                        assert marker.read_text()=='replaced'
                        child.kill();child.communicate(timeout=5);assert child.returncode==-9
                    finally:
                        if child.poll() is None:child.kill();child.communicate(timeout=5)
                    target=_outputs(data)/'report.docx';inode=target.stat().st_ino
                    assert target.read_bytes()==CHANGED
                    before=json.loads(_state(data).read_bytes());blobs=_snapshot(_versions(data))
                    if old_epoch:
                        (data/'.office-restore-epoch').write_text('restored-epoch\n')
                        payload['url']=server.url+'/rejected.docx'
                        payload['userdata']='invalid-rejected-envelope'
                    index.write_bytes(b'{unavailable-index')
                    hits=server.hits
                    from office.publish import RecoveryRequiredError
                    outage_exception=None
                    try:
                        outage=_post(http,session,payload)
                    except RecoveryRequiredError as error:
                        if not old_epoch:
                            raise
                        outage=None
                        outage_exception=str(error)
                    pending=json.loads(_state(data).read_bytes())
                    record=pending['sessions'][session['session_id']]
                    row={'requester':'final' if final else 'save','old_epoch':old_epoch,'outage_http':outage.status_code if outage is not None else None,'outage_body':outage.json() if outage is not None else None,'outage_exception':outage_exception,
                        'outage_hits':server.hits-hits,'outage_pending':journal in pending['journal'],'outage_session_state':record['state'],
                        'outage_documents_preserved':pending['documents']==before['documents'],'outage_receipts_preserved':pending['receipts']==before['receipts'],
                        'outage_blobs_preserved':_snapshot(_versions(data))==blobs,'outage_workspace_preserved':target.read_bytes()==CHANGED and target.stat().st_ino==inode}
                    row['outage_accepted']=(row['outage_pending'] and pending['sessions']==before['sessions'] and all(row[k] for k in ('outage_documents_preserved','outage_receipts_preserved','outage_blobs_preserved','outage_workspace_preserved')) and row['outage_hits']==(0 if old_epoch or final else 1))
                    index.write_bytes(good_index);hits=server.hits
                    healthy=_post(http,session,payload)
                    completed=json.loads(_state(data).read_bytes());record=completed['sessions'][session['session_id']]
                    current_index=json.loads(index.read_bytes())
                    row.update(healthy_http=healthy.status_code,healthy_body=healthy.json(),healthy_hits=server.hits-hits,
                        healthy_pending=len(completed['journal']),healthy_session_state=record['state'],healthy_revision=current_index['counter'],initial_revision=initial_revision,
                        healthy_published=completed['documents'][session['file_id']]['versions'][-1]['published'],
                        healthy_receipts_preserved=completed['receipts']==before['receipts'],healthy_blobs_preserved=_snapshot(_versions(data))==blobs,
                        healthy_workspace_preserved=target.read_bytes()==CHANGED and target.stat().st_ino==inode)
                    expected_state='closed' if final else 'orphaned' if old_epoch else 'editing'
                    row['healthy_accepted']=(healthy.status_code==(409 if old_epoch else 200) and not completed['journal'] and record['state']==expected_state and row['healthy_published'] and current_index['counter']==initial_revision+1 and row['healthy_hits']==(0 if old_epoch or final else 1) and all(row[k] for k in ('healthy_receipts_preserved','healthy_blobs_preserved','healthy_workspace_preserved')) and len(completed['documents'][session['file_id']]['versions'])==2 and record['last_published_seq']==1)
                    frozen=_snapshot(data)
                    replay=_post(http,session,payload)
                    row['replay_http']=replay.status_code
                    row['replay_noop']=_snapshot(data)==frozen and target.stat().st_ino==inode
                    row['accepted']=row['outage_accepted'] and row['healthy_accepted'] and row['replay_noop']
                    rows.append(row)
            finally:fixture.close()
        assert not Path(temporary).exists()
assert identities=={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in identities}
result={'accepted':all(row['accepted'] for row in rows),'rows':rows,'source_identities':identities,'oracle_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'limits':'Actual authenticated fixtureHTTP/contentorigin, nativeSIGKILL andfreshpublisher; callback recovery usesrunningfixtureprocess; controlledabsentDocker,notdeploymentcertification.'}
output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
raise SystemExit(0 if result['accepted'] else 1)
