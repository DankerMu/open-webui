"""Add a second real recovery crash without changing the protected state oracle."""
from pathlib import Path
import hashlib
import json
import runpy
import sys

root, output = map(Path,sys.argv[1:])
sys.path[:0]=[str(root),str(root/'computer-use-server')]
from tests.orchestrator import test_office_publish_recovery as recovery
original_crash=recovery._crash
observations=[]
def crash(fixture,cut,**kwargs):
    original_crash(fixture,cut,**kwargs)
    if cut=='replace-after':
        original_crash(fixture,'registration-durability-after',mode='recover')
        entry=fixture.store.read(recovery.CHAT)['journal'][recovery.OBLIGATION]
        observations.append({'first_cut':cut,'second_cut':'registration-durability-after',
            'second_marker':(fixture.data.parent/'crash-marker').read_text(),
            'staging_present': 'staging' in entry,'initial_revision':entry.get('initial_revision')})
recovery._crash=crash
try:
    runpy.run_path('/tmp/issue-280-index-probe.py',run_name='__main__')
except SystemExit:
    assert output.exists()
    report=json.loads(output.read_bytes())
    report['input_control']={'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'observations':observations}
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report['input_control'],indent=2),flush=True)
    raise
