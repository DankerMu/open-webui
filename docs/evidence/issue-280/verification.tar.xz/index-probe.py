"""Parent-owned native replacement/index-outage responsibility oracle."""
from pathlib import Path
import hashlib
import importlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import tempfile

root, output = map(Path, sys.argv[1:])
assert not output.exists()
for name in ('ALL_PROXY','HTTP_PROXY','HTTPS_PROXY','all_proxy','http_proxy','https_proxy'):
    os.environ.pop(name, None)
os.environ['NO_PROXY'] = os.environ['no_proxy'] = '*'
sys.path[:0] = [str(root), str(root/'computer-use-server')]
import pytest
from tests.orchestrator._office_store import world, CHAT, _child_env
from tests.orchestrator.test_office_publish import _prepared, OBLIGATION, SAVED, BASELINE
from tests.orchestrator.test_office_publish_recovery import _crash
from tests.orchestrator.test_office_sessions import _snapshot

RECOVER = r'''
import json, os
from types import SimpleNamespace
from docker.errors import NotFound
import docker_manager
from office.publish import publish, recover_publications
from office.store import OfficeStore
chat = os.environ['OCU_CHAT']
def missing(identity):
    raise NotFound(identity)
docker_manager._docker_client = SimpleNamespace(containers=SimpleNamespace(get=missing))
try:
    if os.environ['PROBE_MODE'] == 'publish':
        result = publish(chat, 'publish-save-3')
        record = {'outcome':result.outcome,'reason':result.reason}
    else:
        recover_publications(chat)
        record = {'outcome':'recovered','reason':None}
except Exception as error:
    record = {'exception':type(error).__name__,'message':str(error)}
record['state'] = OfficeStore().read(chat)
print(json.dumps(record), flush=True)
'''

def fresh(fixture, mode='publish'):
    p = subprocess.run([sys.executable,'-c',RECOVER],cwd=root/'computer-use-server',
        env=_child_env(fixture.data,PROBE_MODE=mode),capture_output=True,text=True,timeout=20)
    assert p.returncode == 0, (p.stdout,p.stderr)
    result = json.loads(p.stdout.strip().splitlines()[-1])
    result['stderr'] = p.stderr
    return result

identities = {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in (
    'computer-use-server/office/publish.py','tests/orchestrator/test_office_publish_recovery.py')}
rows = []
for cut in ('unstarted','preparation-after','replace-after','registration-durability-after'):
    with tempfile.TemporaryDirectory(prefix='issue-280-index-') as temporary, pytest.MonkeyPatch.context() as patch:
        generator = world.__wrapped__(patch,Path(temporary))
        instance = next(generator)
        try:
            for module in ('outputs_broker','office.save_as','office.publish','office.resolution','office.history','office.restore'):
                if module in sys.modules:
                    importlib.reload(sys.modules[module])
            fixture = _prepared(instance,'absent')
            if cut != 'unstarted':
                _crash(fixture,cut)
            before = fixture.store.read(CHAT)
            index = fixture.data/CHAT/'.ocu/index.json'
            valid_index = index.read_bytes()
            inode = fixture.target.stat().st_ino
            selected_before = fixture.target.read_bytes()
            replaced = cut in ('replace-after','registration-durability-after')
            assert selected_before == (SAVED if replaced else BASELINE)
            index.write_bytes(b'{unavailable-index')
            outage = fresh(fixture)
            after_outage = outage['state']
            row = {'cut':cut,'outage_outcome':outage.get('outcome'),'outage_reason':outage.get('reason'),
                'outage_exception':outage.get('exception'),'outage_stderr':outage['stderr'],
                'outage_pending':OBLIGATION in after_outage['journal'],
                'outage_bytes_preserved':fixture.target.read_bytes()==selected_before,
                'outage_inode_preserved':fixture.target.stat().st_ino==inode,
                'outage_documents_preserved':after_outage['documents']==before['documents'],
                'outage_receipts_preserved':after_outage['receipts']==before['receipts']}
            row['outage_accepted'] = (row['outage_outcome']==('interrupted' if replaced else 'failed')
                and row['outage_reason']=='index_unavailable' and row['outage_pending']==replaced
                and all(row[k] for k in ('outage_bytes_preserved','outage_inode_preserved','outage_documents_preserved','outage_receipts_preserved')))
            index.write_bytes(valid_index)
            healthy = fresh(fixture,'recover')
            completed = healthy['state']
            current_index = json.loads(index.read_bytes())
            row.update(healthy_outcome=healthy.get('outcome'),healthy_exception=healthy.get('exception'),
                healthy_pending=len(completed['journal']),healthy_revision=current_index['counter'],
                initial_revision=fixture.indexed['revision'],healthy_inode_preserved=fixture.target.stat().st_ino==inode,
                healthy_published=completed['documents'][fixture.file_id]['versions'][1]['published'],
                healthy_receipts_preserved=completed['receipts']==before['receipts'],
                healthy_bytes=fixture.target.read_bytes().hex())
            row['healthy_accepted'] = (healthy.get('outcome')=='recovered' and not completed['journal']
                and row['healthy_inode_preserved'] and row['healthy_receipts_preserved']
                and row['healthy_published']==replaced
                and current_index['counter']==fixture.indexed['revision']+(1 if replaced else 0)
                and fixture.target.read_bytes()==selected_before)
            snapshot = _snapshot(fixture.data)
            replay = fresh(fixture,'recover')
            row['completed_replay_noop'] = replay.get('outcome')=='recovered' and _snapshot(fixture.data)==snapshot and fixture.target.stat().st_ino==inode
            row['accepted'] = row['outage_accepted'] and row['healthy_accepted'] and row['completed_replay_noop']
            rows.append(row)
        finally:
            generator.close()
    assert not Path(temporary).exists()
assert identities == {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in identities}
result = {'rows':rows,'accepted':all(row['accepted'] for row in rows),'source_identities':identities,
    'oracle_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'environment':{'python':sys.version,'platform':platform.platform(),'packages':{name:importlib.metadata.version(name) for name in ('pytest','pytest-asyncio','fastapi','starlette','httpx','docker','mcp','PyYAML')}},
    'limits':'Real native SIGKILL/filesystem/fresh public publication recovery. Absent controlled Docker engine; no HTTP callback, deployment or power-loss claim from this tracer.'}
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
raise SystemExit(0 if result['accepted'] else 1)
