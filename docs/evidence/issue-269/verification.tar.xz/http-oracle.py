"""Parent-owned real HTTP version/content oracle and unconfigured comparison capture."""
from pathlib import Path
import base64
import copy
import hashlib
import io
import json
import sys
import zipfile
import xml.etree.ElementTree as ET

root, input_name, output = sys.argv[1:]
root, output = Path(root), Path(output)
assert not output.exists()
configured = None if input_name == '-' else Path(input_name)
sys.path.insert(0, str(root/'scripts'))
from smoke_stub_office import _create, _outputs, _request, _restore, _status, _versions, _write_fixtures, start_stub, stop_stub


def doc(payload):
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        assert archive.testzip() is None
        parts = {name:archive.read(name) for name in archive.namelist()}
        for name in ('[Content_Types].xml','_rels/.rels','word/document.xml'):
            ET.fromstring(parts[name])
        text = ''.join(ET.fromstring(parts['word/document.xml']).itertext())
        return parts, text


def matches(payload, version):
    assert version['sha256'] == hashlib.sha256(payload).hexdigest(), 'version hash differs from actual bytes'
    assert version['size'] == len(payload), 'version size differs from actual bytes'


def valid_pair(workspace, autosave, versions):
    matches(workspace, versions[0])
    matches(autosave, versions[1])
    assert autosave != workspace, 'autosave duplicates workspace bytes'
    before_parts, before_text = doc(workspace)
    after_parts, after_text = doc(autosave)
    assert after_parts.keys() == before_parts.keys(), 'package member set changed'
    assert {k:v for k,v in after_parts.items() if k!='word/document.xml'} == {k:v for k,v in before_parts.items() if k!='word/document.xml'}, 'unrelated package parts changed'
    assert 'Verified Office document' in before_text and 'Verified Office document' in after_text
    assert before_text != after_text, 'autosave has no visible content change'
    return {'workspace_text':before_text,'autosave_text':after_text,'members':list(before_parts)}


def snapshot(base, chat):
    listing, etag = _outputs(base, chat)
    entry = next(item for item in listing['files'] if item['path']=='report.docx')
    status, _, body = _request(base, '/files/'+chat+'/report.docx')
    assert status == 200
    history = _versions(base, chat, entry['file_id'])
    assert history[0] == 200
    assert entry['hash'] == hashlib.sha256(body).hexdigest() and entry['size'] == len(body)
    published = next(v for v in history[2]['versions'] if v['number']==history[2]['published_version'])
    matches(body, published)
    return {'listing':listing,'etag':etag,'history':history[2],'content_b64':base64.b64encode(body).decode()}, body, entry


mapping = {'ordinary':'office','unpublished':'office_unpublished','unpublished-repeat':'office_unpublished','stale':'office_stale','stale-restore':'office_stale','stale-repeat':'office_stale'}
fixtures = _write_fixtures(mapping)
proc = record = None
rows = {}
controls = []
try:
    environment = {'OCU_STUB_FIXTURES':str(fixtures),'OCU_STUB_ASSETS':'/nonexistent-issue-269-assets','OCU_STUB_DOCX':str(configured) if configured else '/nonexistent-issue-269-docx'}
    proc, base, record = start_stub(root/'scripts/ocu-stub.py', environment)
    ordinary, ordinary_bytes, _ = snapshot(base,'ordinary')
    if configured:
        assert ordinary_bytes == configured.read_bytes()
        doc(ordinary_bytes)
    rows['ordinary'] = ordinary
    variants = {}
    for chat in ('unpublished','unpublished-repeat','stale-restore','stale-repeat'):
        before, workspace, entry = snapshot(base,chat)
        initial = before['history']
        assert initial['published_version']==1
        assert [(v['number'],v['source'],v['parent'],v['published']) for v in initial['versions']] == [(1,'workspace',None,True),(2,'autosave',1,False)]
        if configured:
            assert workspace == configured.read_bytes()
        else:
            assert workspace == b'PK\x03\x04office-default-document'
        refused = None
        if chat.startswith('stale'):
            refused = _create(base,chat,entry['file_id'])
            assert refused[0]==409 and refused[2]=={'reason':'unpublished_version'}
            after_refusal, retained, _ = snapshot(base,chat)
            assert after_refusal['history']['open_session'] is None
            assert after_refusal['history']['versions']==initial['versions'] and retained==workspace
        restored = _restore(base,chat,entry['file_id'],2)
        assert restored[0]==200 and restored[2]=={'file_id':entry['file_id'],'number':3,'published':True}
        after, autosave, updated = snapshot(base,chat)
        assert after['history']['versions'][:2]==initial['versions']
        restore_version = after['history']['versions'][-1]
        assert (restore_version['number'],restore_version['source'],restore_version['parent'],restore_version['published'])==(3,'restore',2,True)
        matches(autosave,initial['versions'][1])
        assert after['history']['published_version']==3 and updated['file_id']==entry['file_id']
        assert after['listing']['revision']>before['listing']['revision'] and updated['revision']>entry['revision']
        if configured:
            rendered = valid_pair(workspace,autosave,initial['versions'])
        else:
            suffix = b'-stale' if chat.startswith('stale') else b'-autosave'
            assert autosave == workspace+suffix
            rendered = None
        created = _create(base,chat,entry['file_id'])
        assert created[0]==201 and created[2]['file_id']==entry['file_id']
        rows[chat]={'before':before,'refused':None if refused is None else {'status':refused[0],'body':refused[2]},'restore':restored[2],'after':after,'created':created[2],'renderable':rendered}
        kind = 'stale' if chat.startswith('stale') else 'unpublished'
        if kind in variants:
            assert variants[kind]==autosave, 'identical inputs yielded nondeterministic variant'
        variants[kind]=autosave
        if configured and chat=='unpublished':
            for name, altered_bytes, altered_versions in [('same-bytes',workspace,[initial['versions'][0],{**initial['versions'][1],'sha256':hashlib.sha256(workspace).hexdigest(),'size':len(workspace)}]),('wrong-metadata',autosave,[initial['versions'][0],{**initial['versions'][1],'sha256':'0'*64}])]:
                try:
                    valid_pair(workspace,altered_bytes,altered_versions)
                except AssertionError as error:
                    controls.append({'name':name,'rejected':True,'reason':str(error)})
                else:
                    raise AssertionError('oracle accepted negative control '+name)
            valid_pair(workspace,autosave,initial['versions'])
    before, workspace, entry = snapshot(base,'stale')
    old_session = before['history']['open_session']
    assert old_session['state']=='editing' and old_session['editor_ended'] is False
    refused = _create(base,'stale',entry['file_id'])
    assert refused[0]==409 and refused[2]=={'reason':'unpublished_version'}
    after, retained, _ = snapshot(base,'stale')
    assert after['history']['versions']==before['history']['versions'] and after['history']['open_session'] is None and retained==workspace
    retried = _create(base,'stale',entry['file_id'])
    assert retried[0]==201 and retried[2]['session_id']!=old_session['session_id'] and retried[2]['file_id']==entry['file_id']
    final, retained, _ = snapshot(base,'stale')
    assert final['history']['versions']==before['history']['versions'] and retained==workspace
    rows['stale']={'before':before,'refused':refused[2],'after_refusal':after,'retry':retried[2],'final':final}
finally:
    if proc is not None:
        stop_stub(proc,record)
    fixtures.unlink(missing_ok=True)
result={'root':str(root),'configured':bool(configured),'oracle_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'input_sha256':hashlib.sha256(configured.read_bytes()).hexdigest() if configured else None,'rows':rows,'controls':controls,
        'accepted':True,'cleanup':{'process_exit':proc.returncode,'record_removed':not record.exists(),'fixtures_removed':not fixtures.exists()},
        'limits':'Real stub HTTP, ZIP/XML content and metadata checks. Negative controls target the independent content judge with altered captured observations; not production mutation or browser proof.'}
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'configured':result['configured'],'rows':list(rows),'controls':controls,'cleanup':result['cleanup'],'accepted':True},indent=2))
