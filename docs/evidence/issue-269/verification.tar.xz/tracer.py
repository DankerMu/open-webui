"""Parent-owned HTTP fidelity tracer; no renderer or lifecycle implementation mocks."""
from pathlib import Path
import hashlib
import io
import json
import sys
import zipfile
import xml.etree.ElementTree as ET

root, configured, output = map(Path, sys.argv[1:])
assert not output.exists()
sys.path.insert(0, str(root/'scripts'))
from smoke_stub_office import _outputs, _request, _versions, _write_fixtures, start_stub, stop_stub


def document(payload):
    try:
        with zipfile.ZipFile(io.BytesIO(payload)) as package:
            assert package.testzip() is None
            for name in ('[Content_Types].xml', '_rels/.rels', 'word/document.xml'):
                ET.fromstring(package.read(name))
            body = ET.fromstring(package.read('word/document.xml'))
            text = ''.join(body.itertext())
            return {'valid': True, 'text': text, 'members': package.namelist()}
    except (zipfile.BadZipFile, KeyError, ET.ParseError, AssertionError) as error:
        return {'valid': False, 'error_type': type(error).__name__, 'message': str(error)}


identities = {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in
              ('scripts/ocu_stub_office.py','scripts/ocu-stub.py','scripts/smoke_stub_office.py')}
input_bytes = configured.read_bytes()
assert document(input_bytes)['valid']
fixtures = _write_fixtures({'ordinary':'office','unpublished':'office_unpublished','stale':'office_stale'})
proc = record = None
rows = []
try:
    proc, base, record = start_stub(root/'scripts/ocu-stub.py', {
        'OCU_STUB_FIXTURES':str(fixtures), 'OCU_STUB_DOCX':str(configured),
        'OCU_STUB_ASSETS':'/nonexistent-issue-269-assets'})
    for chat in ('ordinary','unpublished','stale'):
        listing, _ = _outputs(base, chat)
        entry = next(item for item in listing['files'] if item['path']=='report.docx')
        status, _, payload = _request(base, '/files/'+chat+'/report.docx')
        assert status == 200
        history = _versions(base, chat, entry['file_id'])
        assert history[0] == 200
        digest = hashlib.sha256(payload).hexdigest()
        metadata_matches = entry['hash']==digest and entry['size']==len(payload) and history[2]['versions'][0]['sha256']==digest and history[2]['versions'][0]['size']==len(payload)
        rows.append({'chat':chat,'status':status,'listing':entry,'history':history[2],
                     'sha256':digest,'size':len(payload),'document':document(payload),
                     'matches_configured':payload==input_bytes,'metadata_matches':metadata_matches})
finally:
    if proc is not None:
        stop_stub(proc, record)
    fixtures.unlink(missing_ok=True)
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in identities.items())
assert rows[0]['document']['valid'] and rows[0]['matches_configured'] and rows[0]['metadata_matches'], 'ordinary configured positive control failed'
failures=[row['chat'] for row in rows[1:] if not (row['document']['valid'] and row['matches_configured'] and row['metadata_matches'])]
result={'source_root':str(root),'source_identities':identities,'oracle_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'configured_sha256':hashlib.sha256(input_bytes).hexdigest(),'rows':rows,'failures':failures,'accepted':not failures,
        'cleanup':{'process_exit':proc.returncode,'record_removed':not record.exists(),'fixtures_removed':not fixtures.exists()},
        'limits':'Real stub HTTP and independent package/XML checks, not browser rendering or DocumentServer.'}
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'accepted':result['accepted'],'failures':failures,'documents':{row['chat']:row['document'] for row in rows},'cleanup':result['cleanup']},indent=2))
raise SystemExit(1 if failures else 0)
