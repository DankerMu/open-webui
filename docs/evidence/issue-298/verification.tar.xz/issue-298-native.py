"""Parent-owned native proxy lifecycle; all credential-bearing material stays private."""
from pathlib import Path
from contextlib import nullcontext
import argparse
import hashlib
import importlib.util
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from unittest.mock import patch


def port():
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', 0))
        return listener.getsockname()[1]


def listening(number):
    try:
        with socket.create_connection(('127.0.0.1', number), timeout=0.2):
            return True
    except OSError:
        return False


def ready(process, ports):
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError('Owned native service exited before readiness')
        if all(listening(number) for number in ports):
            return
        time.sleep(0.05)
    raise RuntimeError('Owned native service readiness deadline exceeded')


def stop(process):
    if process is None:
        return None
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
            return {'exit': process.returncode, 'escalated': True}
    return {'exit': process.returncode, 'escalated': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--private-root', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--fault')
    parser.add_argument('--visible-token', action='store_true')
    parser.add_argument('--test-filter')
    parser.add_argument('--fixture-entry', type=Path)
    args = parser.parse_args()
    os.umask(0o077)
    args.private_root.mkdir(mode=0o700, parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix='native-', dir=args.private_root)).resolve()
    nginx = shutil.which('nginx')
    if not nginx:
        raise RuntimeError('Native nginx prerequisite missing')
    ports = []
    while len(ports) < 5:
        chosen = port()
        if chosen not in ports:
            ports.append(chosen)
    auth, ocu, office, proxy, office_proxy = ports
    token = ("".join(chr(n) for n in range(0x21, 0x7F)) + "$http_host${x}@@LOCATIONS@@"
             if args.visible_token else 'synthetic-native-token')
    env = {
        'PATH': os.environ['PATH'], 'HOME': os.environ['HOME'], 'LANG': 'C.UTF-8',
        'NO_PROXY': '*', 'PYTHONDONTWRITEBYTECODE': '1',
        'OCU_INTERNAL_TOKEN': token,
        'OCU_WEBUI_ORIGIN': 'http://127.0.0.1:18780',
        'OCU_WEBUI_UPSTREAM': f'http://127.0.0.1:{auth}',
        'OCU_PROXY_UPSTREAM': f'http://127.0.0.1:{ocu}',
        'OCU_OFFICE_PROXY_UPSTREAM': f'http://127.0.0.1:{office}',
        'OCU_PROXY_LISTEN': f'127.0.0.1:{proxy}',
        'OCU_OFFICE_PROXY_LISTEN': f'127.0.0.1:{office_proxy}',
        'OCU_TEST_PROXY_PORT': str(proxy), 'OCU_TEST_OFFICE_PROXY_PORT': str(office_proxy),
        'OCU_TEST_RECORD': str(work / 'requests.jsonl'),
    }
    if args.visible_token:
        env['OCU_TEST_TOKEN_DOMAIN'] = 'visible-ascii'
    fixture = master = None
    result = {'python': sys.version, 'root': str(args.root), 'private_work': str(work),
              'ports': ports, 'render_source_sha256': hashlib.sha256(
                  (args.root / 'deploy/proxy/render.py').read_bytes()).hexdigest()}
    result.update(fault=args.fault, token_domain='visible-ascii' if args.visible_token else 'standard')
    try:
        with (work / 'fixture.log').open('wb') as fixture_log:
            fixture = subprocess.Popen([sys.executable, str(args.fixture_entry or args.root / 'deploy/proxy/tests/fixture.py'),
                '--auth-port', str(auth), '--ocu-port', str(ocu),
                '--documentserver-port', str(office), '--record', env['OCU_TEST_RECORD']],
                cwd=args.root, env=env, stdout=fixture_log, stderr=subprocess.STDOUT)
        ready(fixture, [auth, ocu, office])
        spec = importlib.util.spec_from_file_location('gateway_render', args.root / 'deploy/proxy/render.py')
        render = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(render)
        mutation = nullcontext()
        if args.fault:
            fault_spec = importlib.util.spec_from_file_location('gateway_faults', '/tmp/issue298_faults.py')
            faults = importlib.util.module_from_spec(fault_spec)
            fault_spec.loader.exec_module(faults)
            mutation = faults.patch(render, args.root, args.fault)
        native_run = subprocess.run
        def retain_validation(*command, **options):
            checked = native_run(*command, **options)
            if checked.returncode:
                (work / 'render-validation.stderr').write_bytes(checked.stderr or b'')
            return checked
        with mutation, patch.object(render.subprocess, 'run', retain_validation):
            config = render.render(output=work / 'nginx.conf', env=env, nginx=nginx)
        with (work / 'nginx-launch.log').open('wb') as nginx_log:
            master = subprocess.Popen([nginx, '-c', str(config), '-g', 'daemon off;'],
                cwd=args.root, env=env, stdout=nginx_log, stderr=subprocess.STDOUT)
        ready(master, [proxy, office_proxy])
        assert int((work / 'runtime/nginx.pid').read_text()) == master.pid
        command = [sys.executable, '-m', 'unittest', 'discover', '-s', 'deploy/proxy/tests', '-p', 'test_*.py', '-v']
        if args.test_filter:
            command += ['-k', args.test_filter]
        test = subprocess.run(command, cwd=args.root, env=env, capture_output=True, text=True, timeout=240)
        (work / 'tests.stdout').write_text(test.stdout)
        (work / 'tests.stderr').write_text(test.stderr)
        canaries = {token}
        record = Path(env['OCU_TEST_RECORD'])
        observed_lines = record.read_text().splitlines() if record.exists() else []
        for line in observed_lines:
            observed = json.loads(line)
            for header in ('authorization', 'cookie', 'x-ocu-grant', 'x-ocu-internal-token'):
                value = observed.get('headers', {}).get(header)
                if value and len(value) >= 8:
                    canaries.add(value)
            found = re.search(r'/ocu/f/([^/?]+)', observed.get('target', ''))
            if found and len(found.group(1)) >= 8:
                canaries.add(found.group(1))
        public = test.stdout + test.stderr
        for canary in sorted(canaries, key=len, reverse=True):
            public = public.replace(canary, '<redacted-private-canary>')
        public = re.sub(r'/ocu/f/[^/\s\"\']+', '/ocu/f/<redacted-grant>', public)
        public = re.sub(r'session=[A-Za-z0-9_-]+', 'session=<redacted>', public)
        result.update(command=command, exit=test.returncode, output=public,
                      config_mode=oct(config.stat().st_mode & 0o777),
                      runtime_mode=oct((work / 'runtime').stat().st_mode & 0o777),
                      record_mode=oct(record.stat().st_mode & 0o777) if record.exists() else None,
                      recorded_requests=len(observed_lines))
    except Exception as error:
        result.update(exit=2, error_type=type(error).__name__, error='Native lifecycle failed; inspect owned private diagnostics')
    finally:
        result['nginx_stop'] = stop(master)
        result['fixture_stop'] = stop(fixture)
        result['all_owned_ports_closed'] = all(not listening(number) for number in ports)
        args.report.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'exit': result['exit'], 'report': str(args.report),
                      'all_owned_ports_closed': result['all_owned_ports_closed']}))
    return result['exit']


if __name__ == '__main__':
    raise SystemExit(main())
