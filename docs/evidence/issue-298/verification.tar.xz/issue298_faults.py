"""Parent-only rendered-config faults; repository bytes and test oracles stay untouched."""
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch as mock_patch


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise AssertionError('Fault anchor is not unique in candidate configuration')
    return text.replace(old, new, 1)


@contextmanager
def patch(renderer, root, fault):
    original_location = renderer._file_location
    original_read = Path.read_text
    template = root / 'deploy/proxy/nginx.conf.in'
    applied = []

    def location(row, ocu, bearer):
        text = original_location(row, ocu, bearer)
        grant = row['auth'] == 'grant'
        if fault == 'redirect-before-authorization' and not grant:
            text = replace_once(text, '            set $ocu_issuer_target /api/v1/ocu/resource-grants/issue;',
                '            return 302 /ocu/f/c3ludGhldGlj.c2lnbmF0dXJl/chat-ABC-123/report.html;\n'
                '            set $ocu_issuer_target /api/v1/ocu/resource-grants/issue;')
            applied.append(fault)
        elif grant:
            edits = {
                'grant-auth-bypass': ('            auth_request /_ocu_grant_auth;', '            auth_request off;'),
                'grant-cookie-forwarding': ('            proxy_pass_request_headers off;', '            proxy_pass_request_headers off;\n            proxy_set_header Cookie $http_cookie;'),
                'grant-download-admission': ('            if ($ocu_download_exempt) { return 404; }', ''),
                'generated-isolation-loss': ('            add_header Content-Security-Policy $ocu_csp always;', '            add_header Content-Security-Policy $upstream_http_content_security_policy always;'),
                'encoded-query-nosniff-loss': ('            add_header X-Content-Type-Options $ocu_nosniff always;', '            add_header X-Content-Type-Options $ocu_qualified_nosniff always;'),
                'encoded-target-loss': (f'            proxy_pass {ocu}$ocu_file_target;', f'            proxy_pass {ocu}/files/$ocu_chat_id/$ocu_normalized_path$is_args$args;'),
            }
            if fault in edits:
                text = replace_once(text, *edits[fault])
                applied.append(fault)
            elif fault == 'grant-error-log-leak':
                text = replace_once(text, '            error_log /dev/null crit;', '')
                applied.append('grant-content-log')
        return text

    def read_text(path, *args, **kwargs):
        text = original_read(path, *args, **kwargs)
        if path != template:
            return text
        if fault == 'cors-origin-widening':
            text = replace_once(text, '        ~^200:null$ null;', '        ~^200:.*$ null;')
            applied.append(fault)
        elif fault == 'encoded-query-nosniff-loss':
            text = replace_once(text, '    map $ocu_force_isolation $ocu_nosniff {',
                '    map $args $ocu_qualified_nosniff {\n'
                '        default $ocu_nosniff;\n'
                '        "~^download=1&%64ownload=0$" $upstream_http_x_content_type_options;\n'
                '    }\n'
                '    map $ocu_force_isolation $ocu_nosniff {')
            applied.append('encoded-query-policy-map')
        elif fault == 'head-method-confusion':
            text = replace_once(text, '            proxy_set_header X-Ocu-Resource-Method $ocu_resource_method;',
                                '            proxy_set_header X-Ocu-Resource-Method GET;')
            applied.append(fault)
        elif fault == 'grant-error-log-leak':
            if '            error_log /dev/null crit;' not in text:
                raise AssertionError('Grant log suppression fault anchor absent')
            text = text.replace('            error_log /dev/null crit;', '')
            applied.append('grant-auth-denial-logs')
        elif fault == 'diagnose-retry-off':
            text = replace_once(text, '    access_log off;', '    access_log off;\n    proxy_next_upstream off;')
            applied.append(fault)
        elif fault == 'diagnose-request-line':
            text = replace_once(text, '    map $request_uri $ocu_early_cache {', '    map $request $ocu_early_cache {')
            text = replace_once(text, r'        ~^/ocu/f(?:/|\?|$) no-store;', r'        "~^[^ ]+ /ocu/f(?:/|\?| )" no-store;')
            applied.append(fault)
        return text

    with mock_patch.object(renderer, '_file_location', location), mock_patch.object(Path, 'read_text', read_text):
        yield
    if not applied:
        raise AssertionError('Requested rendered-config fault was not applied')
