"""Change only the fixture wire-failure stimulus; leave production and assertions intact."""
import importlib.util
from pathlib import Path

path = Path('/Users/danker/Documents/31308/open-computer-use/deploy/proxy/tests/fixture.py')
spec = importlib.util.spec_from_file_location('native_fixture_diagnostic', path)
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)

def invalid_header(self, malformed=False):
    if malformed:
        self.wfile.write(b'HTTP/1.1 200 OK\r\nContent-Length: invalid\r\n\r\n')
        self.wfile.flush()
    self.close_connection = True

fixture.Handler._fail_transport = invalid_header
fixture.main()
