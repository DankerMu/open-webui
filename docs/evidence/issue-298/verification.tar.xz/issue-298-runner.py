from pathlib import Path
import subprocess
import json
import os
import hashlib
import time

web = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
ocu = Path('/Users/danker/Documents/31308/open-computer-use')
stage298 = Path('/tmp/issue-298-evidence')
delivery298 = Path('/tmp/issue-298-delivery')
delivery298.mkdir(exist_ok=True)
nodebin = '/Users/danker/.nvm/versions/node/v22.23.2/bin'
env298 = {'PATH': f'/Users/danker/.local/bin:{web}/.venv/bin:{nodebin}:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin', 'HOME':str(Path.home()), 'LANG':'C.UTF-8', 'NO_PROXY':'*', 'PYTHONDONTWRITEBYTECODE':'1'}
def capture298(name, args, cwd=web, expected=0, timeout=360, extra_env=None):
    target=stage298/f'{name}.json'
    assert not target.exists(), target
    start=time.monotonic()
    result=subprocess.run(args,cwd=cwd,env=env298|(extra_env or {}),capture_output=True,text=True,timeout=timeout)
    target.write_text(json.dumps({'command':args,'cwd':str(cwd),'exit':result.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':result.stdout,'stderr':result.stderr},indent=2)+'\n')
    print(name,'exit',result.returncode,(result.stdout+result.stderr)[-4000:])
    assert result.returncode==expected
    return result
