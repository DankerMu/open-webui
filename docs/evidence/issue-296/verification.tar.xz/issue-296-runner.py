from pathlib import Path
import subprocess
import json
import os
import hashlib
import shutil

web = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
ocu = Path('/Users/danker/Documents/31308/open-computer-use')
stage296 = Path('/tmp/issue-296-evidence')
delivery296 = Path('/tmp/issue-296-delivery')
nodebin = '/Users/danker/.nvm/versions/node/v22.23.2/bin'
env296 = {
    'PATH': f'/Users/danker/.local/bin:{web}/.venv/bin:{nodebin}:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
    'HOME': str(Path.home()), 'LANG': 'C.UTF-8',
    'NO_PROXY': '127.0.0.1,localhost', 'PYTHONDONTWRITEBYTECODE': '1',
}
uv296 = ['uv', 'run', '--offline', '--no-project', '--python', '3.12', '--no-python-downloads', '--with', 'pytest', '--with', 'pytest-asyncio', '--with', 'PyYAML==6.0.2', '--with-requirements', str(ocu / 'computer-use-server/requirements.txt'), '--']
pytest296 = uv296 + ['python', '/tmp/issue-235-pytest-env.py', 'tests/', '-q', '--import-mode=importlib', '--ignore=tests/integration', '-p', 'no:cacheprovider']


def capture296(name, args, cwd=ocu, expected=0, timeout=300, extra_env=None):
    target = stage296 / f'{name}.json'
    assert not target.exists(), target
    result = subprocess.run(args, cwd=cwd, env=env296 | (extra_env or {}), capture_output=True, text=True, timeout=timeout)
    target.write_text(json.dumps({'command': args, 'cwd': str(cwd), 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}, indent=2) + '\n')
    print(name, 'exit', result.returncode, (result.stdout + result.stderr)[-2400:])
    assert result.returncode == expected
    return result
