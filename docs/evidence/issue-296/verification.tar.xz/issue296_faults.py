"""Parent-only controlled faults; source bytes stay unchanged and patches end per test."""
import os
from pathlib import Path
import sys
from unittest.mock import patch

import pytest


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    module = sys.modules.get('file_response')
    if module is None:
        raise RuntimeError('Selected response fixture did not load the real response module')
    cls = module.WorkspaceFileResponse
    fault = os.environ['ISSUE296_FAULT']
    if fault == 'head-payload':
        original = cls._run_response

        async def payload_response(self, scope, receive, send):
            altered = dict(scope, method='GET') if scope['method'] == 'HEAD' else scope
            return await original(self, altered, receive, send)

        context = patch.object(cls, '_run_response', payload_response)
    elif fault == 'leak':
        context = patch.object(module, 'close_fd', lambda fd: None)
    elif fault == 'double-close':
        original = module.close_fd

        def double_close(fd):
            original(fd)
            original(fd)

        context = patch.object(module, 'close_fd', double_close)
    elif fault == 'abandon-setup':
        original = module.anyio.to_thread.run_sync

        async def abandon(func, *args, **kwargs):
            return await original(func, *args, **(kwargs | {'abandon_on_cancel': True}))

        context = patch.object(module.anyio.to_thread, 'run_sync', abandon)
    elif fault == 'pathname-metadata':
        import uploads
        original = cls.set_stat_headers

        def pathname_stat(self, stat_result):
            path = Path(uploads.BASE_DATA_DIR) / self.chat_id / 'outputs' / self.rel_path
            return original(self, path.stat())

        context = patch.object(cls, 'set_stat_headers', pathname_stat)
    else:
        raise RuntimeError('Unknown protected response fault')
    with context:
        yield
