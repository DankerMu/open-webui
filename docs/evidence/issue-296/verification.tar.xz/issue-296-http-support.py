#!/usr/bin/env python3
"""Issue-201 real-app loopback oracle; no source writes and no external services.

Run in the server's dependency interpreter. --expected-source is an exact HEAD
or a JSON full relative-path -> SHA256 map (a prior source_before.sha256 works).
HEAD alone does NOT pin dirty changes; use a full manifest for candidate runs.
--output is created exclusively before importing the app. Exit 0: acceptance
passed, or characterization completed (NOT acceptance); 1: semantic rejection;
2: setup/transport/identity/cleanup failure. Characterization records HEAD/Range
without inventing protocol behavior. Acceptance requires that baseline report.
Race instrumentation wraps the actual response's send at response-start, only
inside the child process; no production module is replaced or written.
"""
from __future__ import annotations

import argparse
import hashlib
import http.client
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time
import traceback
from email.utils import formatdate
from urllib.parse import quote

DEFAULT_SOURCE = Path('/Users/danker/Documents/31308/open-computer-use')
TOKEN = 'issue-201-loopback-only-internal-token'
MAX_BODY = 2 * 1024 * 1024
LARGE_SIZE = 64 * 1024 * 1024
PREFIX_SIZE = 1024
FIXTURE_MTIME = 1700000000
CSP = 'sandbox allow-scripts allow-forms'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def content_record(data):
    return {'size': len(data), 'sha256': sha(data), 'prefix_hex': data[:128].hex()}


def file_sha(path):
    result = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(256 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def source_identity(root):
    server = root / 'computer-use-server'
    paths = sorted(p for p in server.rglob('*.py') if '__pycache__' not in p.parts)
    paths.append(server / 'requirements.txt')
    hashes = {}
    for path in paths:
        if path.is_symlink() or not path.is_file():
            raise RuntimeError(f'Nonregular source input: {path}')
        hashes[path.relative_to(root).as_posix()] = file_sha(path)
    head = subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD'],
                          check=True, capture_output=True, text=True, timeout=5).stdout.strip()
    return {'git_head': head, 'sha256': hashes, 'digest': digest(hashes)}


def expected_matches(expected, identity):
    path = Path(expected)
    if path.is_file():
        raw = path.read_bytes()
        value = json.loads(raw)
        if 'source_before' in value:
            value = value['source_before']['sha256']
        elif 'sha256' in value and isinstance(value['sha256'], dict):
            value = value['sha256']
        if not isinstance(value, dict) or not value:
            raise ValueError('Expected source manifest must be a nonempty SHA256 map')
        differences = {name: {'expected': value.get(name), 'actual': identity['sha256'].get(name)}
                       for name in sorted(set(value) | set(identity['sha256']))
                       if value.get(name) != identity['sha256'].get(name)}
        return {'kind': 'complete_sha256_map', 'manifest_sha256': sha(raw),
                'matched': not differences, 'differences': differences}
    return {'kind': 'git_head_only', 'expected': expected, 'actual': identity['git_head'],
            'matched': expected == identity['git_head'],
            'limit': 'HEAD does not identify uncommitted source changes'}


def tree_identity(root):
    entries = []

    def visit(path):
        info = path.lstat()
        row = {'path': path.relative_to(root).as_posix(),
               'mode': stat.S_IMODE(info.st_mode), 'mtime_ns': info.st_mtime_ns}
        if stat.S_ISLNK(info.st_mode):
            row.update(type='symlink', target=os.readlink(path))
        elif stat.S_ISDIR(info.st_mode):
            row['type'] = 'directory'
        elif stat.S_ISREG(info.st_mode):
            row.update(type='file', size=info.st_size, sha256=file_sha(path))
        else:
            raise RuntimeError(f'Unexpected fixture type: {path}')
        entries.append(row)
        if row['type'] == 'directory':
            for child in sorted(path.iterdir()):
                visit(child)

    visit(root)
    return {'entries': entries, 'digest': digest(entries)}


def fixture_metadata(path):
    info = path.stat()
    # Independent pinned Starlette 0.38.6 formula; do not ask FileResponse for it.
    seed = f'{info.st_mtime}-{info.st_size}'.encode()
    etag = '"' + hashlib.md5(seed, usedforsecurity=False).hexdigest() + '"'
    return {'size': info.st_size, 'mtime': info.st_mtime, 'mtime_ns': info.st_mtime_ns,
            'inode': info.st_ino, 'device': info.st_dev, 'etag': etag,
            'last_modified': formatdate(info.st_mtime, usegmt=True)}


def make_inputs(root):
    data = root / 'data'
    data.mkdir()
    cases, races = [], []
    number = 0

    def workspace():
        nonlocal number
        number += 1
        chat = f'a1b2c3d4-e5f6-7890-abcd-ef{number:010d}'
        outputs = data / chat / 'outputs'
        outputs.mkdir(parents=True)
        return chat, outputs

    def store(path, body, mtime=FIXTURE_MTIME):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(body)
        os.utime(path, (mtime, mtime))

    def positive(name, chat, filename, target, body, mime, isolated=False):
        for download in (False, True):
            cases.append({'name': name + ('_download' if download else '_inline'),
                          'chat': chat, 'filename': filename, 'download': download,
                          'body': body, 'mime': mime, 'isolated': isolated,
                          'target_name': target.name, 'metadata': fixture_metadata(target),
                          'kind': 'positive'})

    chat, outputs = workspace()
    specifications = [
        ('nested_binary', 'nested/report.bin', b'Issue 201 binary\x00\xff\x01\x80exact bytes\n',
         'application/octet-stream', False),
        ('zero_byte', 'empty.bin', b'', 'application/octet-stream', False),
        ('multichunk', 'many.bin', bytes(range(256)) * 1537 + b'end-marker',
         'application/octet-stream', False),
        ('html', 'view.html', b'<!doctype html><title>Benign fixture</title><p>exact</p>',
         'text/html; charset=utf-8', True),
        ('unicode_html', 'r\u00e9sum\u00e9-\u96ea.html', b'<p>Unicode fixture</p>',
         'text/html; charset=utf-8', True),
        ('quoted_html', 'say"hello.html', b'<p>Quoted fixture</p>',
         'text/html; charset=utf-8', True),
        ('svg', 'drawing.svg', b'<svg xmlns="http://www.w3.org/2000/svg"></svg>',
         'image/svg+xml', True),
        ('xhtml', 'page.xhtml', b'<html xmlns="http://www.w3.org/1999/xhtml"></html>',
         'application/xhtml+xml', True),
        ('xml', 'record.xml', b'<?xml version="1.0"?><record>fixture</record>',
         ('text/xml; charset=utf-8', 'application/xml'), True),
    ]
    for name, filename, body, mime, isolated in specifications:
        target = outputs / filename
        store(target, body)
        positive(name, chat, filename, target, body, mime, isolated)
    alias_body = b'<p>Safely resolved in-root alias</p>'
    target = outputs / 'alias-target.html'
    store(target, alias_body)
    (outputs / 'alias.bin').symlink_to('alias-target.html')
    positive('safe_leaf_alias', chat, 'alias.bin', target, alias_body,
             'text/html; charset=utf-8', True)
    (outputs / 'nested-alias').symlink_to('nested', target_is_directory=True)
    normal_body = specifications[0][2]
    positive('safe_ancestor_alias', chat, 'nested-alias/report.bin',
             outputs / 'nested/report.bin', normal_body, 'application/octet-stream')
    control = cases[0]
    large = outputs / 'disconnect.bin'
    block = b'issue-201-generated-benign-stream\x00' * 2048
    with large.open('wb') as destination:
        remaining = LARGE_SIZE
        while remaining:
            chunk = block[:min(len(block), remaining)]
            destination.write(chunk)
            remaining -= len(chunk)
    os.utime(large, (FIXTURE_MTIME, FIXTURE_MTIME))
    disconnect = {'chat': chat, 'filename': large.name,
                  'metadata': fixture_metadata(large),
                  'prefix': (block * 2)[:PREFIX_SIZE]}
    external = root / 'outside' / 'canary.bin'
    sibling_chat, sibling_outputs = workspace()
    sibling = sibling_outputs / 'canary.bin'
    external_body = b'benign-external-canary: NEVER serve from selected chat\n'
    sibling_body = b'benign-sibling-canary: NEVER serve from selected chat\n'
    store(external, external_body, FIXTURE_MTIME + 3600)
    store(sibling, sibling_body, FIXTURE_MTIME + 7200)

    def negative(name, chat, filename, statuses, forbidden=()):
        for download in (False, True):
            cases.append({'name': name + ('_download' if download else '_inline'),
                          'chat': chat, 'filename': filename, 'download': download,
                          'kind': 'negative', 'statuses': statuses, 'forbidden': list(forbidden)})

    (outputs / 'external.bin').symlink_to(external)
    (outputs / 'sibling.bin').symlink_to(sibling)
    (outputs / 'outside-directory').symlink_to(external.parent, target_is_directory=True)
    negative('external_link', chat, 'external.bin', [403, 404], [external_body])
    negative('sibling_link', chat, 'sibling.bin', [403, 404], [sibling_body])
    negative('external_ancestor', chat, 'outside-directory/canary.bin', [403, 404], [external_body])
    negative('missing', chat, 'missing.bin', [404])
    negative('directory', chat, 'nested', [400])
    root_chat, root_outputs = workspace()
    root_outputs.rmdir()
    root_outputs.symlink_to(sibling_outputs, target_is_directory=True)
    negative('sibling_outputs_root', root_chat, 'canary.bin', [403, 404], [sibling_body])
    root_chat, root_outputs = workspace()
    root_outputs.rmdir()
    root_outputs.parent.rmdir()
    (data / root_chat).symlink_to(sibling_outputs.parent, target_is_directory=True)
    negative('sibling_chat_root', root_chat, 'canary.bin', [403, 404], [sibling_body])
    for kind in ('leaf', 'ancestor'):
        for download in (False, True):
            race_chat, race_outputs = workspace()
            target = race_outputs / 'nested' / 'race.bin'
            body = f'original-pinned-{kind}-{download}\n'.encode() * 6000
            store(target, body)
            name = f'race_{kind}_' + ('download' if download else 'inline')
            positive(f'race_{kind}', race_chat, 'nested/race.bin', target, body, 'application/octet-stream')
            # Keep only this race's designated mode; each race has its own inode/tree.
            cases.pop(-1 if not download else -2)
            selected = target if kind == 'leaf' else target.parent
            replacement = external if kind == 'leaf' else external.parent
            if kind == 'ancestor':
                store(external.parent / 'race.bin', external_body, FIXTURE_MTIME + 3600)
            races.append({'name': name, 'path': f'/files/{race_chat}/nested/race.bin',
                          'download': download, 'selected': str(selected),
                          'held': str(selected.with_name(selected.name + '.held')),
                          'replacement': str(replacement), 'kind': kind})
            cases[-1]['race'] = name
            cases[-1]['forbidden'] = [external_body]
    return data, cases, control, disconnect, races


def request_path(case):
    path = f"/files/{case['chat']}/{quote(case['filename'], safe='/')}"
    return path + ('?download=1' if case.get('download') else '')


def request(port, path, method='GET', extra=None, timeout=5):
    connection = http.client.HTTPConnection('127.0.0.1', port, timeout=timeout)
    try:
        headers = {'Authorization': f'Bearer {TOKEN}', 'Connection': 'close'}
        headers.update(extra or {})
        connection.request(method, path, headers=headers)
        response = connection.getresponse()
        read_error = None
        try:
            body = response.read(MAX_BODY + 1)
        except http.client.IncompleteRead as exc:
            body = exc.partial
            read_error = f'IncompleteRead: {exc}'
        if len(body) > MAX_BODY:
            raise RuntimeError('Response exceeded bounded smoke body limit')
        row = {'status': response.status, 'reason': response.reason,
               'headers': response.getheaders(), 'body': content_record(body)}
        if read_error:
            row['transport_error_after_headers'] = read_error
        return row, body
    finally:
        connection.close()


def header_values(response, name):
    return [value for key, value in response['headers'] if key.lower() == name]


def expected_disposition(filename, mode):
    quoted = quote(filename)
    return (f"{mode}; filename*=utf-8''{quoted}" if quoted != filename
            else f'{mode}; filename="{filename}"')


def judge(case, response, body):
    failures = []
    if response.get('transport_error_after_headers'):
        failures.append(response['transport_error_after_headers'])

    def header(name, expected):
        values = header_values(response, name)
        if isinstance(expected, tuple):
            if len(values) != 1 or values[0] not in expected:
                failures.append(f'{name}: expected one of {expected!r}, got {values!r}')
            return
        wanted = [] if expected is None else [expected]
        if values != wanted:
            failures.append(f'{name}: expected {wanted!r}, got {values!r}')

    if case['kind'] == 'positive':
        if response['status'] != 200:
            failures.append(f"Expected status 200, got {response['status']}")
        if body != case['body']:
            failures.append('Body differs from independent fixture bytes')
        header('content-length', str(case['metadata']['size']))
        header('etag', case['metadata']['etag'])
        header('last-modified', case['metadata']['last_modified'])
        header('cache-control', 'no-store')
        isolated = case['isolated'] and not case['download']
        header('content-type', 'application/octet-stream' if case['download'] else case['mime'])
        header('content-disposition', expected_disposition(case['target_name'],
               'attachment' if case['download'] else 'inline') if case['download'] or isolated else None)
        header('content-security-policy', CSP if isolated else None)
        header('x-content-type-options', 'nosniff' if isolated else None)
        if len(body) != case['metadata']['size']:
            failures.append('Body length does not match original fixture stat')
    else:
        if response['status'] not in case['statuses']:
            failures.append(f"Expected status in {case['statuses']}, got {response['status']}")
        header('content-security-policy', None)
        header('x-content-type-options', None)
        if case['name'].startswith('missing'):
            expected = {'detail': f"File not found: {case['filename']}"}
            try:
                if json.loads(body) != expected:
                    failures.append('Missing-file error body changed')
            except ValueError:
                failures.append('Missing-file error is not JSON')
        if case['name'].startswith('directory'):
            try:
                if json.loads(body) != {'detail': f"Path is not a file: {case['filename']}"}:
                    failures.append('Directory error body changed')
            except ValueError:
                failures.append('Directory error is not JSON')
    for canary in case.get('forbidden', []):
        if canary in body:
            failures.append('Forbidden target bytes disclosed')
    return {'passed': not failures, 'failures': failures}


def toolchain():
    versions = {}
    for name in ('fastapi', 'starlette', 'uvicorn', 'mcp', 'docker', 'pydantic', 'aiohttp'):
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    return {'python': sys.version, 'executable': sys.executable,
            'platform': platform.platform(), 'machine': platform.machine(), 'dependencies': versions}


def serve(source, fd, metadata_path, config_path):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(source / 'computer-use-server'))
    import uvicorn
    import app
    import docker_manager
    if docker_manager._docker_client is not None:
        raise RuntimeError('App import initialized Docker')
    config = json.loads(Path(config_path).read_text())
    journal = Path(config['journal'])
    events = []
    instrumented = set()
    fired_races = set()

    def record(event):
        events.append(event)
        journal.write_text(json.dumps(events))

    def instrument(response):
        cls = type(response)
        class_name = f'{cls.__module__}.{cls.__qualname__}'
        if cls not in instrumented:
            original_call = cls.__call__

            async def wrapped_call(self, scope, receive, send):
                race = next((item for item in config['races'] if item['path'] == scope.get('path')
                             and item['download'] == (scope.get('query_string') == b'download=1')), None)

                async def wrapped_send(message):
                    if (race and message['type'] == 'http.response.start'
                            and race['name'] not in fired_races):
                        fired_races.add(race['name'])
                        selected, held = Path(race['selected']), Path(race['held'])
                        selected.rename(held)
                        selected.symlink_to(race['replacement'], target_is_directory=race['kind'] == 'ancestor')
                        record({'event': 'response_start_swap', 'race': race['name'],
                                'response_class': f'{type(self).__module__}.{type(self).__qualname__}',
                                'status': message['status'],
                                'selected': str(selected), 'held': str(held),
                                'replacement': race['replacement'], 'hook_fired': True})
                    await send(message)

                return await original_call(self, scope, receive, wrapped_send)

            cls.__call__ = wrapped_call
            instrumented.add(cls)
        return class_name

    matching = [route for route in app.app.routes
                if getattr(route, 'path', None) == '/files/{chat_id}/{filename:path}']
    if len(matching) != 1:
        raise RuntimeError('Expected exactly one real single-file route')
    route = matching[0]
    original_endpoint = route.dependant.call

    async def endpoint(**kwargs):
        response = await original_endpoint(**kwargs)
        class_name = instrument(response)
        record({'event': 'actual_endpoint_response', 'response_class': class_name,
                'chat': kwargs.get('chat_id'), 'filename': kwargs.get('filename'),
                'download': kwargs.get('download')})
        return response

    route.dependant.call = endpoint
    Path(metadata_path).write_text(json.dumps({'toolchain': toolchain(),
        'app_file': app.__file__, 'docker_client_initialized_at_import': False,
        'instrumentation': 'actual endpoint return class __call__, send-only response-start wrapper',
        'production_source_modified': False}))
    bound = socket.socket(fileno=fd)
    server = uvicorn.Config(app.app, host='127.0.0.1', lifespan='on', log_level='info',
                            access_log=False, timeout_graceful_shutdown=3)
    uvicorn.Server(server).run(sockets=[bound])


def protocol_signature(response):
    # Ignore transport timestamp/server only; fixture validators are deterministic.
    selected = {'allow', 'content-type', 'content-length', 'content-disposition',
                'content-range', 'accept-ranges', 'cache-control', 'etag', 'last-modified',
                'content-security-policy', 'x-content-type-options'}
    return {'status': response['status'], 'body': response['body'],
            'headers': sorted([[key.lower(), value] for key, value in response['headers']
                               if key.lower() in selected])}


def disconnect_client(port, case):
    connection = http.client.HTTPConnection('127.0.0.1', port, timeout=5)
    response = None
    try:
        connection.connect()
        connection.sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4096)
        receive_buffer = connection.sock.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)
        connection.request('GET', request_path(case), headers={
            'Authorization': f'Bearer {TOKEN}', 'Connection': 'keep-alive'})
        response = connection.getresponse()
        prefix = response.read(PREFIX_SIZE)
        row = {'status': response.status, 'headers': response.getheaders(),
               'consumed_body': content_record(prefix), 'prefix_read_bound': PREFIX_SIZE,
               'generated_file_size': case['metadata']['size'], 'receive_buffer': receive_buffer,
               'limit': 'Client abandonment and subsequent liveness only; NOT FD closure or bounded server-read proof'}
        failures = []
        if response.status != 200 or prefix != case['prefix']:
            failures.append('Disconnect request did not return the expected original prefix/status')
        if not 0 < len(prefix) < case['metadata']['size']:
            failures.append('Client did not abandon before consuming advertised body')
        for name, value in [('content-length', str(case['metadata']['size'])),
                            ('content-type', 'application/octet-stream'), ('cache-control', 'no-store'),
                            ('etag', case['metadata']['etag']),
                            ('last-modified', case['metadata']['last_modified'])]:
            if header_values(row, name) != [value]:
                failures.append(f'Disconnect {name} differs from original fixture')
        row.update(passed=not failures, failures=failures)
        # Bounded read followed by actual socket shutdown, never drain to EOF.
        if connection.sock is None:
            failures.append('Server closed connection before explicit client shutdown')
            row['passed'] = False
        else:
            connection.sock.shutdown(socket.SHUT_RDWR)
            row['socket_shutdown'] = True
        return row
    finally:
        if response is not None:
            response.close()
        connection.close()


def stop_owned(process):
    escalated = False
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=6)
        except subprocess.TimeoutExpired:
            escalated = True
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=4)
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    return {'stopped': process.poll() is not None, 'exit_code': process.returncode,
            'kill_escalated': escalated}


def restore_inputs(root, before, races):
    restored = []
    for race in races:
        selected, held = Path(race['selected']), Path(race['held'])
        if held.exists():
            if selected.exists() or selected.is_symlink():
                if not selected.is_symlink() or os.readlink(selected) != race['replacement']:
                    raise RuntimeError(f'Unexpected race mutation: {selected}')
                selected.unlink()
            held.rename(selected)
            restored.append(race['name'])
    # Only restore known directory timestamps changed by our documented renames.
    parents = {Path(race['selected']).parent.relative_to(root).as_posix() for race in races}
    for row in before['entries']:
        if row['type'] == 'directory' and row['path'] in parents:
            path = root / row['path']
            os.utime(path, ns=(path.stat().st_atime_ns, row['mtime_ns']))
    return restored


def interrupted(signum, frame):
    raise KeyboardInterrupt(f'Interrupted by signal {signum}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=DEFAULT_SOURCE)
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--mode', choices=('accept', 'characterize-protocol'), default='accept')
    parser.add_argument('--protocol-baseline', type=Path)
    parser.add_argument('--startup-timeout', type=float, default=30)
    args = parser.parse_args()
    if not 0 < args.startup_timeout <= 120:
        parser.error('--startup-timeout must be in (0, 120] seconds')
    if args.mode == 'accept' and not args.protocol_baseline:
        parser.error('Acceptance requires --protocol-baseline from characterize-protocol mode')
    source, output, script = args.source.resolve(), args.output.resolve(), Path(__file__).resolve()
    if source in output.parents or output == script or output == source:
        parser.error('--output must be outside source and cannot replace this script')
    with output.open('x', encoding='utf-8') as destination:
        report = {'oracle': 'issue-201-single-file-http-v1', 'mode': args.mode,
                  'script': str(script), 'script_sha256': sha(script.read_bytes()), 'argv': sys.argv,
                  'boundary': 'actual app + actual Uvicorn lifecycle + loopback HTTP',
                  'cases': [], 'protocol': {}, 'errors': [], 'cleanup': {}, 'toolchain': toolchain(),
                  'limits': ['Not executed by the author; parent owns red/green runs',
                             'Disconnect is not descriptor-cleanup or bounded-server-read proof',
                             'Response-start hook marks send timing; acquisition and closure need separate ASGI proof',
                             'XML permits text/xml;charset=utf-8 or application/xml per existing host-dependent MIME contract',
                             'No same-inode mutation snapshot, hard-link, bind-mount, Docker or LAN certification']}
        process = bound = log = run_root = input_root = None
        races = []
        signal.signal(signal.SIGTERM, interrupted)
        try:
            report['source_before'] = source_identity(source)
            report['expected_source'] = expected_matches(args.expected_source, report['source_before'])
            if not report['expected_source']['matched']:
                raise RuntimeError('Expected source identity mismatch; app not executed')
            if report['toolchain']['dependencies']['starlette'] != '0.38.6':
                raise RuntimeError('Oracle requires pinned Starlette 0.38.6')
            baseline = None
            if args.protocol_baseline:
                raw = args.protocol_baseline.read_bytes()
                baseline = json.loads(raw)
                if (baseline.get('oracle') != report['oracle']
                        or baseline.get('mode') != 'characterize-protocol'
                        or not baseline.get('characterization_complete')
                        or baseline.get('exit_code') != 0
                        or baseline.get('toolchain', {}).get('dependencies', {}).get('starlette') != '0.38.6'):
                    raise ValueError('Protocol baseline is not a complete pinned characterization report')
                report['protocol_baseline'] = {'path': str(args.protocol_baseline), 'sha256': sha(raw)}
            with tempfile.TemporaryDirectory(prefix='issue-201-http-', dir='/tmp') as temporary:
                run_root = Path(temporary)
                input_root = run_root / 'inputs'
                input_root.mkdir()
                data, cases, control, disconnect, races = make_inputs(input_root)
                if args.mode == 'characterize-protocol':
                    report['skipped_cases'] = [{'name': case['name'],
                        'reason': 'Protocol-only baseline skips destructive race cases; acceptance runs them'}
                        for case in cases if case.get('race')]
                    cases = [case for case in cases if not case.get('race')]
                    races = []
                report['expected_case_count'] = len(cases)
                report['input_before'] = tree_identity(input_root)
                home = run_root / 'home'
                home.mkdir()
                env = {'PATH': os.defpath, 'HOME': str(home), 'TMPDIR': str(run_root),
                       'XDG_CACHE_HOME': str(run_root / 'cache'),
                       'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUNBUFFERED': '1',
                       'BASE_DATA_DIR': str(data), 'OCU_INTERNAL_TOKEN': TOKEN,
                       'MCP_API_KEY': 'issue-201-loopback-only-mcp-token',
                       'DOCKER_HOST': 'unix://' + str(run_root / 'no-docker.sock'),
                       'DOCKER_SOCKET': 'unix://' + str(run_root / 'no-docker.sock'),
                       'PUBLIC_BASE_URL': 'http://ocu.example',
                       'OCU_WEBUI_ORIGIN': 'https://webui.example',
                       'OCU_SANDBOX_SUBNET': '10.90.0.0/24', 'SINGLE_USER_MODE': 'true',
                       'OCU_PUBLIC_PREFIX': '', 'SKILLS_CACHE_DIR': str(run_root / 'skills'),
                       'SKILLS_CACHE_HOST_PATH': str(run_root / 'skills')}
                bound = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                bound.bind(('127.0.0.1', 0))
                bound.listen(128)
                port, fd = bound.getsockname()[1], bound.fileno()
                metadata, config, journal = [run_root / name for name in ('runtime.json', 'hooks.json', 'events.json')]
                config.write_text(json.dumps({'races': races, 'journal': str(journal)}))
                argv = [sys.executable, '-B', str(script), '_serve', str(source), str(fd), str(metadata), str(config)]
                report['server'] = {'argv': argv, 'cwd': str(run_root), 'port': port,
                                    'environment': env, 'authentication': 'synthetic loopback-only credential',
                                    'docker': 'nonexistent owned socket; no managed sandbox metadata'}
                log = (run_root / 'server.log').open('w+b')
                try:
                    process = subprocess.Popen(argv, cwd=run_root, env=env, pass_fds=(fd,),
                                               start_new_session=True, stdout=log, stderr=subprocess.STDOUT)
                    bound.close()
                    bound = None
                    deadline = time.monotonic() + args.startup_timeout
                    report['readiness'] = []
                    while time.monotonic() < deadline:
                        if process.poll() is not None:
                            raise RuntimeError(f'Uvicorn exited at startup: {process.returncode}')
                        try:
                            response, body = request(port, '/health', timeout=min(.5, max(.01, deadline - time.monotonic())))
                            report['readiness'].append(response)
                            if response['status'] == 200 and json.loads(body).get('status') == 'healthy':
                                break
                        except (OSError, http.client.HTTPException, ValueError) as exc:
                            report['readiness'].append({'error': f'{type(exc).__name__}: {exc}'})
                        time.sleep(.05)
                    else:
                        raise TimeoutError('Readiness deadline exceeded')
                    report['runtime'] = json.loads(metadata.read_text())
                    # Record actual protocol first, even when security acceptance later rejects.
                    for download in (False, True):
                        selected = dict(control, download=download)
                        for label, method, extra in [('head', 'HEAD', {}),
                                                     ('range', 'GET', {'Range': 'bytes=1-4'}),
                                                     ('unsatisfiable_range', 'GET', {'Range': 'bytes=999999999-'})]:
                            key = ('download_' if download else 'inline_') + label
                            response, body = request(port, request_path(selected), method, extra)
                            signature = protocol_signature(response)
                            report['protocol'][key] = {'method': method, 'request_headers': extra,
                                                       'response': response, 'signature': signature}
                            if baseline:
                                report['protocol'][key]['passed'] = signature == baseline['protocol'][key]['signature']
                    report['characterization_complete'] = len(report['protocol']) == 6
                    for case in cases:
                        row = {key: value for key, value in case.items() if key not in ('body', 'forbidden')}
                        if case['kind'] == 'positive':
                            row['expected_body'] = content_record(case['body'])
                        row['forbidden_bytes'] = [content_record(item) for item in case.get('forbidden', [])]
                        try:
                            response, body = request(port, request_path(case))
                            row.update(response=response, **judge(case, response, body))
                        except (OSError, http.client.HTTPException, ValueError) as exc:
                            row.update(passed=False, failures=[f'Transport/decode: {type(exc).__name__}: {exc}'])
                            report['errors'].append(f"{case['name']}: transport/decode failure")
                        report['cases'].append(row)
                    report['disconnect'] = disconnect_client(port, disconnect)
                    response, body = request(port, request_path(control))
                    report['disconnect']['continuing_service'] = {'response': response, **judge(control, response, body)}
                finally:
                    if process is not None:
                        report['cleanup']['process'] = stop_owned(process)
                    if bound is not None:
                        bound.close()
                        bound = None
                    report['race_events'] = json.loads(journal.read_text()) if journal.exists() else []
                    report['input_after_requests'] = tree_identity(input_root)
                    report['owned_race_restored'] = restore_inputs(input_root, report['input_before'], races)
                    report['input_after'] = tree_identity(input_root)
                    report['input_unchanged_after_restoration'] = report['input_before'] == report['input_after']
                    log.flush()
                    log.seek(0)
                    report['server_log'] = log.read(256 * 1024).decode('utf-8', errors='replace')
                    log.close()
                    log = None
                    probe = socket.socket()
                    probe.settimeout(.5)
                    try:
                        errno = probe.connect_ex(('127.0.0.1', port))
                        report['cleanup'].update(port_connect_errno=errno, port_closed=errno != 0)
                    finally:
                        probe.close()
                report['cleanup']['docker_socket_created'] = (run_root / 'no-docker.sock').exists()
                for row in report['cases']:
                    if row.get('race'):
                        fired = [event for event in report['race_events']
                                 if event.get('event') == 'response_start_swap' and event.get('race') == row['race']]
                        row['hook_events'] = fired
                        if (len(fired) != 1 or not fired[0].get('hook_fired')
                                or fired[0].get('status') != 200
                                or not fired[0].get('response_class')):
                            row['passed'] = False
                            row['failures'].append('Expected one status-200 swap on the concrete response class')
        except BaseException as exc:
            report['errors'].append(f'{type(exc).__name__}: {exc}')
            report['traceback'] = traceback.format_exc()
        finally:
            if process is not None and process.poll() is None:
                try:
                    report['cleanup']['process'] = stop_owned(process)
                except BaseException as exc:
                    report['errors'].append(f'Process cleanup failure: {exc}')
            if bound is not None:
                bound.close()
            if log is not None:
                log.close()
            if run_root is not None:
                report['cleanup']['owned_directory_removed'] = not run_root.exists()
            try:
                report['source_after'] = source_identity(source)
                report['source_unchanged'] = report.get('source_before') == report['source_after']
            except BaseException as exc:
                report['errors'].append(f'Source identity after failure: {exc}')
            complete = (report.get('expected_case_count', 0) > 0
                        and len(report['cases']) == report['expected_case_count']
                        and report.get('characterization_complete') and 'disconnect' in report)
            invariant = (report.get('source_unchanged') and report.get('input_unchanged_after_restoration')
                         and report['cleanup'].get('owned_directory_removed')
                         and report['cleanup'].get('process', {}).get('stopped')
                         and report['cleanup'].get('port_closed')
                         and not report['cleanup'].get('docker_socket_created'))
            disconnect_ok = (complete and report['disconnect'].get('passed')
                             and report['disconnect']['continuing_service'].get('passed'))
            semantic = (complete and all(case.get('passed') for case in report['cases'])
                        and disconnect_ok
                        and all(row.get('passed') for row in report['protocol'].values()))
            report['acceptance_passed'] = args.mode == 'accept' and semantic and invariant and not report['errors']
            report['exit_code'] = (2 if report['errors'] or not complete or not invariant else
                                   0 if (args.mode == 'characterize-protocol' and disconnect_ok) or semantic else 1)
            report['characterization_only_not_acceptance'] = args.mode == 'characterize-protocol'
            report['semantic_failures'] = [case['name'] for case in report['cases'] if not case.get('passed')]
            json.dump(report, destination, indent=2, sort_keys=True)
            destination.write('\n')
            destination.flush()
            os.fsync(destination.fileno())
        print(json.dumps({'output': str(output), 'exit_code': report['exit_code'],
                          'acceptance_passed': report['acceptance_passed'],
                          'characterization_only_not_acceptance': report['characterization_only_not_acceptance'],
                          'semantic_failures': report['semantic_failures'], 'errors': report['errors']}))
        return report['exit_code']


if __name__ == '__main__':
    if len(sys.argv) == 6 and sys.argv[1] == '_serve':
        serve(Path(sys.argv[2]), int(sys.argv[3]), sys.argv[4], sys.argv[5])
    else:
        sys.exit(main())
