"""Parent-owned HEAD wire oracle over the prior descriptor probe's real-app lifecycle."""
from __future__ import annotations

import argparse
import http.client
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import sys
import zipfile

SUPPORT = Path(__file__).with_name('issue-296-http-support.py')
spec = importlib.util.spec_from_file_location('head_http_support', SUPPORT)
support = importlib.util.module_from_spec(spec)
spec.loader.exec_module(support)
HEADER_NAMES = {
    'content-type', 'content-length', 'content-disposition', 'cache-control',
    'etag', 'last-modified', 'content-security-policy', 'x-content-type-options',
    'content-range', 'accept-ranges', 'www-authenticate', 'allow',
}


def selected_headers(response):
    return sorted((key.lower(), value) for key, value in response['headers'] if key.lower() in HEADER_NAMES)


def raw_head(port, path, authenticated=True):
    headers = ['HEAD ' + path + ' HTTP/1.1', 'Host: 127.0.0.1', 'Connection: close']
    if authenticated:
        headers.append('Authorization: Bearer ' + support.TOKEN)
    with socket.create_connection(('127.0.0.1', port), timeout=5) as connection:
        connection.sendall(('\r\n'.join(headers) + '\r\n\r\n').encode('ascii'))
        chunks = []
        size = 0
        while True:
            chunk = connection.recv(65536)
            if not chunk:
                break
            size += len(chunk)
            if size > support.MAX_BODY:
                raise RuntimeError('HEAD wire response exceeded bounded oracle input')
            chunks.append(chunk)
    raw = b''.join(chunks)
    header_block, separator, body = raw.partition(b'\r\n\r\n')
    if not separator:
        raise RuntimeError('HEAD response lacks a complete header block')
    status_line, _, header_bytes = header_block.partition(b'\r\n')
    status = int(status_line.split(b' ', 2)[1])
    parsed = http.client.parse_headers(io.BytesIO(header_bytes + b'\r\n\r\n'))
    return {'status': status, 'headers': list(parsed.items()), 'wire_body_bytes': len(body)}


def serve(source, fd, metadata_path, config_path):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(source / 'computer-use-server'))
    import app
    import docker_manager
    import uvicorn

    if docker_manager._docker_client is not None:
        raise RuntimeError('App import initialized Docker')
    config = json.loads(Path(config_path).read_text())
    if config['races']:
        raise RuntimeError('This HEAD wire probe does not claim response-start race instrumentation')
    Path(metadata_path).write_text(json.dumps({
        'toolchain': support.toolchain(), 'app_file': app.__file__,
        'docker_client_initialized_at_import': False,
        'instrumentation': 'none; actual registered app and Uvicorn lifecycle',
        'production_source_modified': False,
    }))
    bound = socket.socket(fileno=fd)
    server = uvicorn.Config(app.app, host='127.0.0.1', lifespan='on', log_level='info',
                            access_log=False, timeout_graceful_shutdown=3)
    uvicorn.Server(server).run(sockets=[bound])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError('Refusing to replace existing HEAD evidence')
    get_output = args.output.with_suffix('.get-characterization.json')
    cases = {}
    observed = {}
    special = []
    archive_chat = 'a1b2c3d4-e5f6-7890-abcd-ef9999999999'
    archive_marker = b'ordinary archive filename must not shadow the reserved route'
    original_inputs = support.make_inputs
    original_request = support.request

    def inputs(root):
        result = original_inputs(root)
        data, source_cases, _, _, _ = result
        for case in source_cases:
            if not case.get('race'):
                cases[support.request_path(case)] = case
        outputs = data / archive_chat / 'outputs'
        outputs.mkdir(parents=True)
        target = outputs / 'archive'
        target.write_bytes(archive_marker)
        os.utime(target, (1700000100, 1700000100))
        return result

    def request(port, path, method='GET', extra=None, timeout=5):
        response, body = original_request(port, path, method, extra, timeout)
        if method == 'GET' and not extra and path in cases and path not in observed:
            head = raw_head(port, path)
            observed[path] = {
                'case': cases[path]['name'], 'get_status': response['status'], 'head': head,
                'passed': head['status'] == response['status'] and head['wire_body_bytes'] == 0
                          and selected_headers(head) == selected_headers(response),
            }
            if not special:
                unsigned_get, _ = original_request(port, path, extra={'Authorization': ''})
                unsigned_head = raw_head(port, path, authenticated=False)
                special.append({'case': 'anonymous-head', 'head': unsigned_head,
                                'passed': unsigned_get['status'] == unsigned_head['status'] == 401
                                and unsigned_head['wire_body_bytes'] == 0
                                and selected_headers(unsigned_get) == selected_headers(unsigned_head)})
                archive_path = f'/files/{archive_chat}/archive'
                archive_get, archive_body = original_request(port, archive_path)
                with zipfile.ZipFile(io.BytesIO(archive_body)) as archive:
                    archive_ok = archive.namelist() == ['archive'] and archive.read('archive') == archive_marker
                archive_head = raw_head(port, archive_path)
                headers = dict((key.lower(), value) for key, value in archive_head['headers'])
                special.append({'case': 'reserved-archive-head', 'head': archive_head,
                                'archive_get_status': archive_get['status'],
                                'archive_get_exact_contents': archive_ok,
                                'passed': archive_get['status'] == 200 and archive_ok
                                and archive_head['status'] == 405 and archive_head['wire_body_bytes'] == 0
                                and headers.get('allow') == 'GET'
                                and not {'etag', 'last-modified', 'content-disposition'} & headers.keys()})
        return response, body

    support.make_inputs = inputs
    support.request = request
    support.serve = serve
    support.__file__ = str(Path(__file__).resolve())
    sys.argv = [str(Path(__file__).resolve()), '--source', str(args.source),
                '--expected-source', args.expected_source, '--output', str(get_output),
                '--mode', 'characterize-protocol']
    core_exit = support.main()
    core = json.loads(get_output.read_text())
    retained_get = core_exit == 0 and all(case.get('passed') for case in core['cases'])
    complete = len(observed) == len(cases) == 36 and len(special) == 2
    passed = retained_get and complete and all(row['passed'] for row in observed.values()) and all(row['passed'] for row in special)
    report = {
        'oracle': 'confined-head-wire', 'get_characterization': str(get_output),
        'get_characterization_sha256': support.sha(get_output.read_bytes()),
        'retained_get_passed': retained_get, 'complete': complete,
        'head_cases': list(observed.values()), 'special_cases': special,
        'source_before': core.get('source_before'), 'source_after': core.get('source_after'),
        'cleanup': core.get('cleanup'), 'errors': core.get('errors'),
        'passed': passed, 'exit': 0 if passed else 1 if core_exit == 0 else 2,
        'limits': ['Raw TCP proves empty wire body; ASGI/target-read and ownership/race proof belongs to the paired suites.',
                   'No HEAD race, same-inode snapshot, hard-link/bind-mount, image, Linux or LAN claim.'],
    }
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'output': str(args.output), 'passed': passed, 'head_cases': len(observed),
                      'failures': [row['case'] for row in list(observed.values()) + special if not row['passed']]}))
    return report['exit']


if __name__ == '__main__':
    if len(sys.argv) == 6 and sys.argv[1] == '_serve':
        serve(Path(sys.argv[2]), int(sys.argv[3]), sys.argv[4], sys.argv[5])
    else:
        raise SystemExit(main())
