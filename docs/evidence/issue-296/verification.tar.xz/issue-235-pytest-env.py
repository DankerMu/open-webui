import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sys

proxy_names = ('ALL_PROXY', 'HTTP_PROXY', 'HTTPS_PROXY', 'all_proxy', 'http_proxy', 'https_proxy')
removed = [name for name in proxy_names if name in os.environ]
for name in proxy_names:
    os.environ.pop(name, None)
# Local fixture traffic must not inherit workstation or macOS system proxy routing.
os.environ['NO_PROXY'] = '*'
os.environ['no_proxy'] = '*'
metadata = {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(), 'removed_proxy_variable_names': removed, 'no_proxy_all': True, 'packages': {name: importlib.metadata.version(name) for name in ('pytest', 'pytest-asyncio', 'fastapi', 'starlette', 'aiohttp', 'httpx', 'docker', 'mcp', 'PyYAML')}}
print(json.dumps({'test_environment': metadata}), flush=True)
os.execv(sys.executable, [sys.executable, '-m', 'pytest', *sys.argv[1:]])
