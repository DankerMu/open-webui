"""Parent-owned actual HTTP query oracle; reports no credentials or redirect URLs."""
import argparse
import asyncio
from contextlib import ExitStack
from datetime import timedelta
import json
import os
import sqlite3
from pathlib import Path
from urllib.parse import urlsplit

import httpx

from open_webui.test.ocu_harness import _cleanup_owner, _owner_and_chat
from open_webui.utils.auth import create_token


def run(corpus, report_path):
    results = []
    failures = []

    def check(condition, case, property_name):
        if not condition:
            failures.append({'case': case, 'property': property_name})

    with ExitStack() as cleanup:
        owner, chat = asyncio.run(_owner_and_chat(prefix='query-http'))
        cleanup.callback(lambda: asyncio.run(_cleanup_owner(owner.id, chat.id)))
        foreign, other = asyncio.run(_owner_and_chat(prefix='query-foreign'))
        cleanup.callback(lambda: asyncio.run(_cleanup_owner(foreign.id, other.id)))
        owner_token = create_token({'id': owner.id}, timedelta(minutes=5))
        foreign_token = create_token({'id': foreign.id}, timedelta(minutes=5))
        target_path = 'nested/report%20one.html'
        target = {'X-Chat-Id': chat.id, 'X-Ocu-Resource-Path': target_path}
        with httpx.Client(base_url='http://127.0.0.1:8080', follow_redirects=False, trust_env=False) as client:
            for method in ('GET', 'HEAD'):
                for entry in corpus['cases']:
                    case = method + '/' + entry['case']
                    response = client.request(method, '/api/v1/ocu/resource-grants/issue', headers={
                        **target, 'X-Ocu-Resource-Query': entry['query'],
                        'Cookie': 'token=' + owner_token,
                    })
                    results.append({'case': case, 'expected_status': entry['status'], 'status': response.status_code})
                    check(response.status_code == entry['status'], case, 'status')
                    check(response.content == b'', case, 'empty body')
                    check(response.headers.get('cache-control') == 'no-store', case, 'no-store')
                    if response.status_code == 302:
                        location = urlsplit(response.headers.get('location', ''))
                        parts = location.path.split('/')
                        check(not location.scheme and not location.netloc, case, 'relative Location')
                        valid_route = len(parts) >= 6 and parts[:3] == ['', 'ocu', 'f'] and parts[4] == chat.id
                        check(valid_route, case, 'grant route')
                        check('/'.join(parts[5:]) == target_path, case, 'encoded path preserved')
                        check(location.query == entry['query'], case, 'raw query preserved')
                        check(response.headers.get('referrer-policy') == 'no-referrer', case, 'no-referrer')
                        if valid_route:
                            verified = client.get('/api/v1/ocu/resource-grants/auth', headers={
                                'X-Ocu-Grant': parts[3], 'X-Chat-Id': chat.id,
                                'X-Ocu-Resource-Path': target_path, 'X-Ocu-Resource-Method': method,
                            })
                            check(verified.status_code == 200 and verified.content == b'', case, 'issued grant verifies')
                            check(verified.headers.get('x-user-id') == owner.id, case, 'issuing owner identity')
                    else:
                        check('location' not in response.headers, case, 'denial has no Location')
            for name, headers, expected in (
                ('anonymous', {}, 401), ('foreign', {'Cookie': 'token=' + foreign_token}, 403),
            ):
                response = client.get('/api/v1/ocu/resource-grants/issue', headers={
                    **target, 'X-Ocu-Resource-Query': 'download=1&%64ownload=0', **headers,
                })
                results.append({'case': name, 'expected_status': expected, 'status': response.status_code})
                check(response.status_code == expected, name, 'authority refusal')
                check(response.content == b'' and 'location' not in response.headers, name, 'empty denial without Location')
    database = Path(os.environ['DATA_DIR']) / 'webui.db'
    with sqlite3.connect(f'file:{database}?mode=ro', uri=True) as connection:
        remaining_users = connection.execute(
            'SELECT count(*) FROM user WHERE id IN (?, ?)', (owner.id, foreign.id)
        ).fetchone()[0]
        remaining_chats = connection.execute(
            'SELECT count(*) FROM chat WHERE id IN (?, ?)', (chat.id, other.id)
        ).fetchone()[0]
    check(remaining_users == 0 and remaining_chats == 0, 'cleanup', 'owned rows absent')
    report = {'cases': results, 'failures': failures, 'credentials_or_redirect_values_emitted': False,
              'owned_rows_absent': remaining_users == 0 and remaining_chats == 0, 'passed': not failures,
              'boundary': 'Actual issuer/verifier HTTP only; no new gateway or OCU forwarding claim'}
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'cases': len(results), 'failed_properties': len(failures), 'passed': not failures,
                      'credentials_or_redirect_values_emitted': False}))
    return int(bool(failures))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--corpus', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    raise SystemExit(run(json.loads(args.corpus.read_text()), args.report))
