"""Parent-only classifier faults; real routes and permanent assertions remain intact."""
import ast
import os
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from urllib.parse import unquote

import pytest


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    from open_webui.routers import ocu_resource_grants as router

    fault = os.environ['ISSUE414_FAULT']
    if fault == 'historical-raw-key-count':
        baseline = Path(os.environ['ISSUE414_BASELINE_ROUTER'])
        tree = ast.parse(baseline.read_text())
        functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == '_valid_query']
        if len(functions) != 1:
            raise RuntimeError('Historical query predicate is not unique')
        namespace = vars(router).copy()
        exec(compile(ast.Module(body=functions, type_ignores=[]), str(baseline), 'exec'), namespace)
        context = patch.object(router, '_valid_query', namespace['_valid_query'])
    elif fault == 'allow-unambiguous-download':
        context = patch.object(router, '_DOWNLOAD_EXEMPT_QUERY', SimpleNamespace(fullmatch=lambda query: None))
    elif fault == 'decode-before-classify':
        original = router._DOWNLOAD_EXEMPT_QUERY
        context = patch.object(router, '_DOWNLOAD_EXEMPT_QUERY', SimpleNamespace(
            fullmatch=lambda query: original.fullmatch(unquote(query, encoding='utf-8', errors='strict'))
        ))
    else:
        raise RuntimeError('Unknown protected classification fault')
    with context:
        yield
