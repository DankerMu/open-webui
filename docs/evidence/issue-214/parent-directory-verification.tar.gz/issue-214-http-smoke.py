"""Parent-owned actual HTTP durability oracle; temporary storage, no power-loss claim."""
import errno
import http.client
import importlib.util
import json
import os
from pathlib import Path
import socket
import stat
import subprocess
import sys
import tempfile
import time

ROOT = Path('/Users/danker/Documents/31308/open-computer-use')
SUPPORT = Path('/tmp/issue-200-http-smoke.py')
spec = importlib.util.spec_from_file_location('durability_smoke_support', SUPPORT)
support = importlib.util.module_from_spec(spec)
spec.loader.exec_module(support)
TOKEN = 'issue-214-loopback-only-token'
CHAT = 'a1b2c3d4-e5f6-7890-abcd-ef1234567814'
FAIL_BASE = 'a1b2c3d4-e5f6-7890-abcd-ef1234567815'
FAIL_CHAT = 'a1b2c3d4-e5f6-7890-abcd-ef1234567816'

def serve(fd, root):
    data = root/'data'
    original = os.fsync
    def synced(descriptor):
        info = os.fstat(descriptor)
        identity = (info.st_dev, info.st_ino)
        label = 'regular-file' if stat.S_ISREG(info.st_mode) else 'unclassified-directory'
        for path in [data, *[data/chat for chat in (CHAT, FAIL_BASE, FAIL_CHAT)], *[data/chat/'.ocu' for chat in (CHAT, FAIL_BASE, FAIL_CHAT)]]:
            try:
                candidate = path.stat()
            except FileNotFoundError:
                continue
            if identity == (candidate.st_dev, candidate.st_ino):
                label = str(path.relative_to(root))
                break
        fail = False
        fault = root/'fault.json'
        if fault.exists():
            target = root/json.loads(fault.read_text())['target']
            try:
                target_info = target.stat()
                fail = identity == (target_info.st_dev, target_info.st_ino)
            except FileNotFoundError:
                pass
        row = {'path': label, 'dev': info.st_dev, 'ino': info.st_ino, 'failure': fail}
        if not fail:
            original(descriptor)
        with (root/'trace.jsonl').open('a') as stream:
            stream.write(json.dumps(row)+'\n')
        if fail:
            raise OSError(errno.EIO, 'controlled parent synchronization failure')
    os.fsync = synced
    support.serve(ROOT, fd, root/'server-metadata.json')

def run(output):
    if output.exists():
        raise RuntimeError('Refusing to overwrite evidence')
    report = {'exit': None, 'source_before': support.source_identity(ROOT), 'toolchain': support.toolchain(),
              'script_sha256': support.sha(Path(__file__).read_bytes()), 'support_sha256': support.sha(SUPPORT.read_bytes()), 'requests': []}
    process = bound = None
    with tempfile.TemporaryDirectory(prefix='issue-214-http-', dir='/tmp') as directory:
        root = Path(directory)
        data = root/'data'
        env = {'PATH': os.defpath, 'HOME': str(root), 'BASE_DATA_DIR': str(data), 'OCU_INTERNAL_TOKEN': TOKEN,
               'MCP_API_KEY': 'issue-214-loopback-mcp-token', 'PUBLIC_BASE_URL': 'http://ocu.example',
               'OCU_WEBUI_ORIGIN': 'https://webui.example', 'OCU_SANDBOX_SUBNET': '10.90.0.0/24',
               'SINGLE_USER_MODE': 'true', 'DOCKER_HOST': 'unix://'+str(root/'absent.sock'),
               'SKILLS_CACHE_DIR': str(root/'skills'), 'SKILLS_CACHE_HOST_PATH': str(root/'skills'), 'PYTHONDONTWRITEBYTECODE': '1'}
        bound = socket.socket(); bound.bind(('127.0.0.1',0)); bound.listen(128)
        port = bound.getsockname()[1]
        def request(method, path, body=None, extra=None):
            conn = http.client.HTTPConnection('127.0.0.1', port, timeout=5)
            try:
                conn.request(method, path, body, {'Authorization': 'Bearer '+TOKEN, 'Connection':'close', **(extra or {})})
                response = conn.getresponse(); content = response.read(1048577)
                assert len(content) <= 1048576
                row = {'method':method, 'path':path, 'status':response.status, 'body_sha256':support.sha(content)}
                if response.getheader('Content-Type','').startswith('application/json'):
                    row['json'] = json.loads(content)
                report['requests'].append(row)
                return row, content
            finally:
                conn.close()
        def upload(chat, payload=b'durable upload\x00\xff'):
            boundary = 'issue214boundary'
            body = b'--'+boundary.encode()+b'\r\nContent-Disposition: form-data; name="file"; filename="report.bin"\r\nContent-Type: application/octet-stream\r\n\r\n'+payload+b'\r\n--'+boundary.encode()+b'--\r\n'
            return request('POST', f'/api/uploads/{chat}/report.bin', body, {'Content-Type':'multipart/form-data; boundary='+boundary, 'X-OCU-Attachment-Id':'F214'})[0]
        def trace():
            return [json.loads(line) for line in (root/'trace.jsonl').read_text().splitlines()]
        with (root/'server.log').open('w+b') as log:
            try:
                argv = [sys.executable, '-B', str(Path(__file__).resolve()), '_serve', str(bound.fileno()), str(root)]
                report['server_argv'] = argv
                process = subprocess.Popen(argv, env=env, cwd=root, pass_fds=(bound.fileno(),), start_new_session=True, stdout=log, stderr=subprocess.STDOUT)
                bound.close(); bound = None
                deadline = time.monotonic()+30
                while time.monotonic() < deadline:
                    if process.poll() is not None:
                        raise RuntimeError('Server exited before readiness')
                    try:
                        if request('GET','/health')[0]['status'] == 200:
                            break
                    except (OSError,http.client.HTTPException):
                        pass
                    time.sleep(.05)
                else:
                    raise TimeoutError('Server readiness deadline')
                first = upload(CHAT)
                assert first['status'] == 200, first
                assert first['json']['filename'] == 'report.bin'
                paths = [row['path'] for row in trace() if not row['failure']]
                assert {'data', f'data/{CHAT}', f'data/{CHAT}/.ocu', 'regular-file'} <= set(paths), paths
                assert paths.index('data') < paths.index(f'data/{CHAT}') < paths.index('regular-file') < paths.index(f'data/{CHAT}/.ocu'), paths
                stored = data/CHAT/'outputs/report.bin'
                assert stored.read_bytes() == b'durable upload\x00\xff'
                receipts = (data/CHAT/'.ocu/imports.json').read_bytes()
                repeated = upload(CHAT, b'replay must not replace')
                assert repeated['status'] == 200 and repeated['json'] == first['json']
                assert stored.read_bytes() == b'durable upload\x00\xff'
                assert (data/CHAT/'.ocu/imports.json').read_bytes() == receipts
                assert request('GET',f'/api/uploads/{CHAT}/imports')[0]['json'] == {'ids':['F214']}
                for chat,target in ((FAIL_BASE,'data'), (FAIL_CHAT,f'data/{FAIL_CHAT}')):
                    (root/'fault.json').write_text(json.dumps({'target':target}))
                    failed = upload(chat)
                    assert failed['status'] == 500, failed
                    assert not (data/chat/'.ocu/imports.json').exists()
                    assert not (data/chat/'outputs/report.bin').exists()
                    assert any(row['path'] == target and row['failure'] for row in trace())
                    (root/'fault.json').unlink()
                    retry_start = len(trace())
                    restored = upload(chat)
                    assert restored['status'] == 200, restored
                    assert any(row['path'] == target and not row['failure'] for row in trace()[retry_start:])
                    assert (data/chat/'outputs/report.bin').read_bytes() == b'durable upload\x00\xff'
                report['trace'] = trace()
                report['exit'] = 0
            except BaseException as exc:
                report.update(exit=1, failure=repr(exc))
            finally:
                if process is not None:
                    report['process_cleanup'] = support.stop_owned(process)
                if bound is not None:
                    bound.close()
                log.flush(); log.seek(0); report['server_log'] = log.read().decode(errors='replace')
                probe=socket.socket(); probe.settimeout(.5)
                try:
                    report['port_closed'] = probe.connect_ex(('127.0.0.1',port)) != 0
                finally:
                    probe.close()
    report['owned_tree_removed'] = not root.exists()
    report['source_after'] = support.source_identity(ROOT)
    report['source_unchanged'] = report['source_before'] == report['source_after']
    if not all(report[key] for key in ('port_closed','owned_tree_removed','source_unchanged')):
        report['exit'] = 2
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({key:report[key] for key in ('exit','port_closed','owned_tree_removed','source_unchanged')},indent=2))
    if 'failure' in report:
        print(report['failure'])
    return report['exit']

if __name__ == '__main__':
    if sys.argv[1] == '_serve':
        serve(int(sys.argv[2]),Path(sys.argv[3]))
    else:
        raise SystemExit(run(Path(sys.argv[1])))
