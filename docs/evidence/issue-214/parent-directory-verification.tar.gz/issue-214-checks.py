"""Parent-owned bounded execution with frozen fixture and source identities."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path('/Users/danker/Documents/31308/open-computer-use')
FIXTURE = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2/openspec/changes/ocu-parent-directory-durability')
parser = argparse.ArgumentParser()
parser.add_argument('--run-id', required=True)
parser.add_argument('--timeout', type=int, default=300)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
if not args.run_id.isalnum() or not command or not 1 <= args.timeout <= 3600:
    raise SystemExit('Invalid execution contract')
base = Path('/tmp/issue-214-' + args.run_id)
log = Path(str(base) + '.log')
result = Path(str(base) + '.json')
if log.exists() or result.exists():
    raise SystemExit('Evidence identity already exists')

def identity():
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0')
    return {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in paths
            if name and not name.startswith('.run/') and (name.endswith('.py') or name.endswith('requirements.txt'))}

def fixture():
    return {str(p.relative_to(FIXTURE)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in FIXTURE.rglob('*') if p.is_file()}

def head():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()

state = {'argv': command, 'cwd': str(ROOT), 'head': head(), 'inputs_before': identity(),
         'fixture_before': fixture(), 'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'exit': None}
env = {key: value for key, value in os.environ.items() if key.lower() not in {'all_proxy','http_proxy','https_proxy'}}
started = time.monotonic()
process = None
try:
    with log.open('x') as output:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        state['pid'] = process.pid
        state['exit'] = process.wait(timeout=args.timeout)
except (subprocess.TimeoutExpired, KeyboardInterrupt) as exc:
    state['interruption'] = type(exc).__name__
finally:
    if process is not None and process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)
    state.update(elapsed_seconds=time.monotonic()-started, inputs_after=identity(), fixture_after=fixture(), head_after=head(), child_reaped=process is None or process.poll() is not None)
    state['unchanged'] = state['inputs_before'] == state['inputs_after'] and state['fixture_before'] == state['fixture_after'] and state['head'] == state['head_after']
    result.write_text(json.dumps(state, indent=2)+'\n')
    print(json.dumps({k:v for k,v in state.items() if not k.startswith(('inputs_', 'fixture_'))}, indent=2))
raise SystemExit(state['exit'] if state['unchanged'] and state['exit'] is not None else 2)
