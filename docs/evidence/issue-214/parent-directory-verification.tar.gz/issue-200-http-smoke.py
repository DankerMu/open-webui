#!/usr/bin/env python3
"""Independent issue-200 loopback HTTP oracle; never modifies the source tree.

Run with the server requirements installed in the executing interpreter. Exit 0
means all assertions pass, 1 is semantic rejection, and 2 is setup/transport or
cleanup failure. Reports are created exclusively: use distinct RED/GREEN paths.
--expected-source accepts either an exact Git HEAD or a JSON file containing a
relative-path -> SHA256 map (also accepts a report's source_before.sha256 map).
No expected failure mode is normalized into success. This is not a race oracle.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import http.client
import importlib.metadata
import io
import json
import os
from pathlib import Path
import platform
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile
import zlib

DEFAULT_SOURCE = Path('/Users/danker/Documents/31308/open-computer-use')
TOKEN = 'issue-200-loopback-only-internal-token'
MAX_BODY = 4 * 1024 * 1024


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(data):
    return {
        'size': len(data), 'sha256': sha(data),
        'base64': base64.b64encode(data).decode('ascii'),
        'utf8': data.decode('utf-8', errors='replace'),
    }


def canonical_digest(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def source_identity(root):
    server = root / 'computer-use-server'
    paths = sorted(p for p in server.rglob('*.py') if '__pycache__' not in p.parts)
    paths.append(server / 'requirements.txt')
    hashes = {}
    for path in paths:
        if path.is_symlink() or not path.is_file():
            raise RuntimeError(f'Nonregular source input: {path}')
        hashes[path.relative_to(root).as_posix()] = sha(path.read_bytes())
    head = subprocess.run(
        ['git', '-C', str(root), 'rev-parse', 'HEAD'], check=True,
        capture_output=True, text=True, timeout=5,
    ).stdout.strip()
    return {'git_head': head, 'sha256': hashes, 'digest': canonical_digest(hashes)}


def tree_identity(root):
    """Walk without following links; all canary targets are inside this owned tree."""
    entries = []

    def visit(path):
        info = path.lstat()
        row = {'path': path.relative_to(root).as_posix(),
               'mode': stat.S_IMODE(info.st_mode), 'mtime_ns': info.st_mtime_ns}
        if stat.S_ISLNK(info.st_mode):
            row.update(type='symlink', target=os.readlink(path))
        elif stat.S_ISDIR(info.st_mode):
            row['type'] = 'directory'
        elif stat.S_ISREG(info.st_mode):
            row.update(type='file', size=info.st_size, sha256=sha(path.read_bytes()))
        else:
            raise RuntimeError(f'Unexpected input type: {path}')
        entries.append(row)
        if row['type'] == 'directory':
            for child in sorted(path.iterdir()):
                visit(child)

    visit(root)
    return {'entries': entries, 'digest': canonical_digest(entries)}


def make_inputs(root):
    data = root / 'data'
    data.mkdir()
    normal = b'Issue 200 ordinary nested output\n\x00exact bytes\xff'
    retained = b'Issue 200 ordinary retained output\n'
    external = b'benign-archive-canary: outside outputs, never disclose\n'
    sibling = b'benign-archive-canary: sibling chat, never disclose\n'
    in_tree = b'benign-archive-canary: legitimate real file, never duplicate via link\n'
    cases = []

    def workspace(chat):
        outputs = data / chat / 'outputs'
        outputs.mkdir(parents=True)
        return outputs

    def add(name, chat, allowed, forbidden_names=(), forbidden_bytes=(), positive=False):
        cases.append({'name': name, 'chat': chat, 'positive': positive,
                      'allowed': allowed, 'forbidden_names': list(forbidden_names),
                      'forbidden_bytes': list(forbidden_bytes)})

    chat = 'a1b2c3d4-e5f6-7890-abcd-ef1234567801'
    outputs = workspace(chat)
    (outputs / 'nested').mkdir()
    (outputs / 'nested' / 'report.bin').write_bytes(normal)
    add('positive_nested', chat, {'nested/report.bin': normal}, positive=True)

    chat = 'a1b2c3d4-e5f6-7890-abcd-ef1234567802'
    outputs = workspace(chat)
    (outputs / 'retained.txt').write_bytes(retained)
    (outputs.parent / 'benign-archive-canary').write_bytes(external)
    (outputs / 'external-link.txt').symlink_to('../benign-archive-canary')
    add('external_parent_link', chat, {'retained.txt': retained},
        ['external-link.txt'], [external])

    sibling_chat = 'a1b2c3d4-e5f6-7890-abcd-ef1234567899'
    sibling_outputs = workspace(sibling_chat)
    (sibling_outputs / 'benign-archive-canary').write_bytes(sibling)
    chat = 'a1b2c3d4-e5f6-7890-abcd-ef1234567803'
    outputs = workspace(chat)
    (outputs / 'retained.txt').write_bytes(retained)
    (outputs / 'sibling-link.txt').symlink_to(
        f'../../{sibling_chat}/outputs/benign-archive-canary')
    add('sibling_chat_link', chat, {'retained.txt': retained},
        ['sibling-link.txt'], [sibling])

    chat = 'a1b2c3d4-e5f6-7890-abcd-ef1234567804'
    outputs = workspace(chat)
    (outputs / 'retained.txt').write_bytes(retained)
    (outputs / 'real-target.txt').write_bytes(in_tree)
    (outputs / 'in-tree-link.txt').symlink_to('real-target.txt')
    add('in_tree_link', chat,
        {'retained.txt': retained, 'real-target.txt': in_tree}, ['in-tree-link.txt'])

    chat = 'a1b2c3d4-e5f6-7890-abcd-ef1234567805'
    outputs = workspace(chat)
    (outputs / 'retained.txt').write_bytes(retained)
    outside = root / 'outside-outputs'
    outside.mkdir()
    (outside / 'benign-archive-canary').write_bytes(external)
    (outputs / 'linked-directory').symlink_to(outside, target_is_directory=True)
    add('linked_ancestor', chat, {'retained.txt': retained},
        ['linked-directory/benign-archive-canary'], [external])

    chat = 'a1b2c3d4-e5f6-7890-abcd-ef1234567806'
    (data / chat).mkdir()
    (data / chat / 'outputs').symlink_to(f'../{sibling_chat}/outputs', target_is_directory=True)
    add('sibling_outputs_root_link', chat, {}, ['benign-archive-canary'], [sibling])
    return data, cases


def request(port, path, token=TOKEN, timeout=5):
    connection = http.client.HTTPConnection('127.0.0.1', port, timeout=timeout)
    try:
        connection.request('GET', path, headers={'Authorization': f'Bearer {token}',
                                               'Connection': 'close'})
        response = connection.getresponse()
        body = response.read(MAX_BODY + 1)
        if len(body) > MAX_BODY:
            raise RuntimeError(f'HTTP body exceeded {MAX_BODY} bytes')
        return {'status': response.status, 'reason': response.reason,
                'headers': response.getheaders(), 'body': encoded(body)}, body
    finally:
        connection.close()


def judge(case, response, body):
    failures = []
    members = []
    status = response['status']
    for canary in case['forbidden_bytes']:
        if canary in body:
            failures.append('Forbidden target bytes in raw response body')
    if status == 200:
        headers = {key.lower(): value for key, value in response['headers']}
        if headers.get('content-type', '').split(';')[0].strip() != 'application/zip':
            failures.append('Successful archive lacks application/zip Content-Type')
        disposition = f"attachment; filename=chat-{case['chat']}-outputs.zip"
        if headers.get('content-disposition') != disposition:
            failures.append('Successful archive has incorrect attachment filename/header')
        try:
            with zipfile.ZipFile(io.BytesIO(body)) as archive:
                for item in archive.infolist():
                    if item.file_size > MAX_BODY:
                        raise ValueError('Decoded member exceeds smoke byte bound')
                    content = archive.read(item)
                    members.append({'name': item.filename, 'is_directory': item.is_dir(),
                                    'content': encoded(content)})
                    if item.filename in case['forbidden_names']:
                        failures.append(f'Forbidden symlink alias included: {item.filename}')
                    for canary in case['forbidden_bytes']:
                        if canary in content:
                            failures.append(f'Forbidden target bytes in member: {item.filename}')
                    expected = case['allowed'].get(item.filename)
                    if expected is None:
                        failures.append(f'Unexpected ZIP member: {item.filename}')
                    elif content != expected:
                        failures.append(f'Wrong exact bytes: {item.filename}')
                names = [member['name'] for member in members]
                if sorted(names) != sorted(case['allowed']):
                    failures.append('ZIP membership differs from independent expected regular files')
                if len(names) != len(set(names)):
                    failures.append('Duplicate ZIP member names')
        except (zipfile.BadZipFile, ValueError, RuntimeError, NotImplementedError, OSError, EOFError, zlib.error) as exc:
            failures.append(f'Malformed/unreadable ZIP: {type(exc).__name__}: {exc}')
    elif case['positive']:
        failures.append(f'Positive nested file requires HTTP 200, received {status}')
    elif not 400 <= status < 500:
        failures.append(f'Unsafe tree requires omission ZIP or closed 4xx, received {status}')
    # In-tree target bytes are legitimate only at real-target.txt; aliases are forbidden.
    if status != 200 and case['name'] == 'in_tree_link':
        target = case['allowed']['real-target.txt']
        if target in body:
            failures.append('In-tree target bytes disclosed in closed/error response')
    return {'members': members, 'passed': not failures, 'failures': failures}


def toolchain():
    versions = {}
    for name in ('fastapi', 'starlette', 'uvicorn', 'mcp', 'docker', 'pydantic', 'aiohttp'):
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    return {'python': sys.version, 'executable': sys.executable,
            'platform': platform.platform(), 'machine': platform.machine(),
            'dependencies': versions}


def serve(source, fd, metadata_path):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(source / 'computer-use-server'))
    import uvicorn
    import app
    import docker_manager
    if docker_manager._docker_client is not None:
        raise RuntimeError('App import unexpectedly initialized a Docker client')
    Path(metadata_path).write_text(json.dumps({'toolchain': toolchain(),
        'app_file': app.__file__, 'docker_client_initialized_at_import': False}))
    bound = socket.socket(fileno=fd)
    config = uvicorn.Config(app.app, host='127.0.0.1', lifespan='on',
                            log_level='info', access_log=False,
                            timeout_graceful_shutdown=3)
    uvicorn.Server(config).run(sockets=[bound])


def expected_matches(expected, identity):
    path = Path(expected)
    if path.is_file():
        raw = path.read_bytes()
        value = json.loads(raw)
        if 'source_before' in value:
            value = value['source_before']['sha256']
        elif 'sha256' in value and isinstance(value['sha256'], dict):
            value = value['sha256']
        if not isinstance(value, dict) or not value:
            raise ValueError('--expected-source JSON must contain a nonempty SHA256 map')
        differences = {name: {'expected': digest, 'actual': identity['sha256'].get(name)}
                       for name, digest in value.items()
                       if identity['sha256'].get(name) != digest}
        return {'kind': 'sha256_map', 'manifest_sha256': sha(raw),
                'matched': not differences, 'differences': differences}
    return {'kind': 'git_head', 'expected': expected,
            'actual': identity['git_head'], 'matched': expected == identity['git_head']}


def stop_owned(process):
    escalated = False
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=6)
        except subprocess.TimeoutExpired:
            escalated = True
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=4)
    # A descendant cannot remain alive merely because the direct child exited first.
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    return {'stopped': process.poll() is not None,
            'exit_code': process.returncode, 'kill_escalated': escalated}


def interrupted(signum, frame):
    raise KeyboardInterrupt(f'Interrupted by signal {signum}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=DEFAULT_SOURCE)
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--startup-timeout', type=float, default=30)
    args = parser.parse_args()
    if not 0 < args.startup_timeout <= 120:
        parser.error('--startup-timeout must be greater than zero and at most 120 seconds')
    source = args.source.resolve()
    output = args.output.resolve()
    script = Path(__file__).resolve()
    if output == script or source in output.parents:
        parser.error('--output must be outside source and must not replace this script')
    # Reserve the output before starting anything; GREEN cannot erase the RED artifact.
    with output.open('x', encoding='utf-8') as destination:
        report = {'oracle': 'issue-200-archive-http-v1', 'script': str(script),
                  'script_sha256': sha(script.read_bytes()), 'argv': sys.argv,
                  'boundary': 'actual imported app, actual Uvicorn, loopback HTTP',
                  'cases': [], 'errors': [], 'cleanup': {},
                  'toolchain': toolchain(),
                  'limits': ['No deterministic selection/read race injection',
                             'One host/toolchain; no Docker, hard-link or bind-mount coverage']}
        process = None
        bound = None
        log = None
        input_root = None
        run_root = None
        signal.signal(signal.SIGTERM, interrupted)
        try:
            report['source_before'] = source_identity(source)
            report['expected_source'] = expected_matches(args.expected_source, report['source_before'])
            if not report['expected_source']['matched']:
                raise RuntimeError('Expected source identity mismatch; refusing to execute app')
            with tempfile.TemporaryDirectory(prefix='issue-200-http-', dir='/tmp') as temp:
                run_root = Path(temp)
                input_root = run_root / 'inputs'
                input_root.mkdir()
                data, cases = make_inputs(input_root)
                report['input_before'] = tree_identity(input_root)
                home = run_root / 'home'
                home.mkdir()
                env = {
                    'PATH': os.defpath, 'HOME': str(home), 'TMPDIR': str(run_root),
                    'XDG_CACHE_HOME': str(run_root / 'cache'),
                    'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUNBUFFERED': '1',
                    'BASE_DATA_DIR': str(data), 'OCU_INTERNAL_TOKEN': TOKEN,
                    'MCP_API_KEY': 'issue-200-loopback-only-mcp-token',
                    'DOCKER_HOST': 'unix://' + str(run_root / 'no-docker.sock'),
                    'DOCKER_SOCKET': 'unix://' + str(run_root / 'no-docker.sock'),
                    'PUBLIC_BASE_URL': 'http://ocu.example',
                    'OCU_WEBUI_ORIGIN': 'https://webui.example',
                    'OCU_SANDBOX_SUBNET': '10.90.0.0/24',
                    'SINGLE_USER_MODE': 'true', 'OCU_PUBLIC_PREFIX': '',
                    'SKILLS_CACHE_DIR': str(run_root / 'skills'),
                    'SKILLS_CACHE_HOST_PATH': str(run_root / 'skills'),
                }
                bound = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                bound.bind(('127.0.0.1', 0))
                bound.listen(128)
                port = bound.getsockname()[1]
                fd = bound.fileno()
                metadata = run_root / 'runtime.json'
                argv = [sys.executable, '-B', str(script), '_serve', str(source), str(fd), str(metadata)]
                report['server'] = {'argv': argv, 'cwd': str(run_root), 'port': port,
                                    'environment_names': sorted(env),
                                    'authentication': 'synthetic loopback-only Bearer credential',
                                    'docker': 'nonexistent owned socket, no managed sandbox metadata'}
                log = (run_root / 'server.log').open('w+b')
                try:
                    process = subprocess.Popen(argv, cwd=run_root, env=env,
                        pass_fds=(fd,), start_new_session=True, stdout=log, stderr=subprocess.STDOUT)
                    bound.close()
                    bound = None
                    deadline = time.monotonic() + args.startup_timeout
                    readiness = []
                    report['readiness'] = readiness
                    while time.monotonic() < deadline:
                        if process.poll() is not None:
                            raise RuntimeError(f'Uvicorn exited during startup: {process.returncode}')
                        try:
                            response, body = request(port, '/health', timeout=min(0.5, max(0.01, deadline - time.monotonic())))
                            readiness.append(response)
                            if response['status'] == 200 and json.loads(body).get('status') == 'healthy':
                                break
                        except (OSError, http.client.HTTPException, ValueError) as exc:
                            readiness.append({'error': f'{type(exc).__name__}: {exc}'})
                        time.sleep(0.05)
                    else:
                        raise TimeoutError('Uvicorn readiness deadline exceeded')
                    report['runtime'] = json.loads(metadata.read_text())
                    for case in cases:
                        row = {'name': case['name'], 'chat': case['chat'],
                               'expected_regular_members': {name: encoded(content)
                                   for name, content in case['allowed'].items()},
                               'forbidden_names': case['forbidden_names'],
                               'forbidden_target_bytes': [encoded(value) for value in case['forbidden_bytes']]}
                        try:
                            response, body = request(port, f"/files/{case['chat']}/archive")
                            row.update(response=response, **judge(case, response, body))
                        except (OSError, http.client.HTTPException, ValueError) as exc:
                            row.update(passed=False, transport_error=f'{type(exc).__name__}: {exc}')
                            report['errors'].append(f"{case['name']}: transport/decode failure")
                        report['cases'].append(row)
                finally:
                    if process is not None:
                        report['cleanup']['process'] = stop_owned(process)
                    if bound is not None:
                        bound.close()
                        bound = None
                    report['input_after'] = tree_identity(input_root)
                    report['input_unchanged'] = report['input_before'] == report['input_after']
                    log.flush()
                    log.seek(0)
                    report['server_log'] = log.read(256 * 1024).decode('utf-8', errors='replace')
                    log.close()
                    log = None
                    probe = socket.socket()
                    probe.settimeout(0.5)
                    try:
                        errno = probe.connect_ex(('127.0.0.1', port))
                        report['cleanup']['port_connect_errno'] = errno
                        report['cleanup']['port_closed'] = errno != 0
                    finally:
                        probe.close()
                report['cleanup']['docker_socket_created'] = (run_root / 'no-docker.sock').exists()
        except BaseException as exc:
            report['errors'].append(f'{type(exc).__name__}: {exc}')
            report['traceback'] = traceback.format_exc()
        finally:
            if process is not None and process.poll() is None:
                try:
                    report['cleanup']['process'] = stop_owned(process)
                except BaseException as exc:
                    report['errors'].append(f'Process cleanup failure: {exc}')
            if bound is not None:
                bound.close()
            if log is not None:
                log.close()
            if run_root is not None:
                report['cleanup']['owned_directory_removed'] = not run_root.exists()
            try:
                report['source_after'] = source_identity(source)
                report['source_unchanged'] = report.get('source_before') == report['source_after']
            except BaseException as exc:
                report['errors'].append(f'Source after identity failure: {exc}')
            complete = len(report['cases']) == 6
            semantic = complete and all(case.get('passed') for case in report['cases'])
            invariant = (report.get('source_unchanged') and report.get('input_unchanged')
                         and report['cleanup'].get('owned_directory_removed')
                         and report['cleanup'].get('process', {}).get('stopped')
                         and report['cleanup'].get('port_closed')
                         and not report['cleanup'].get('docker_socket_created'))
            report['exit_code'] = 2 if report['errors'] or not complete or not invariant else (0 if semantic else 1)
            report['passed'] = report['exit_code'] == 0
            json.dump(report, destination, indent=2, sort_keys=True)
            destination.write('\n')
            destination.flush()
            os.fsync(destination.fileno())
        print(json.dumps({'output': str(output), 'exit_code': report['exit_code'],
                          'cases': [{'name': case['name'],
                                     'status': case.get('response', {}).get('status'),
                                     'passed': case.get('passed'),
                                     'failures': case.get('failures', [])}
                                    for case in report['cases']], 'errors': report['errors']}))
        return report['exit_code']


if __name__ == '__main__':
    if len(sys.argv) == 5 and sys.argv[1] == '_serve':
        serve(Path(sys.argv[2]), int(sys.argv[3]), sys.argv[4])
    else:
        sys.exit(main())
