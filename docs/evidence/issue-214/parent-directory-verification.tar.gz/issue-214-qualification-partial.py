"""Qualify corrected lock/storage test seams against the pre-change source."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path('/Users/danker/Documents/31308/open-computer-use')
BASE = 'f419297e0990a416816446446713385e70f5d8f1'
OUT = Path(sys.argv[1])
if OUT.exists():
    raise SystemExit('Refusing to overwrite qualification')
TESTS = ['tests/orchestrator/test_lifecycle.py', 'tests/orchestrator/test_office_store.py']
SUPPORT = ['tests/orchestrator/_office_store.py']
record = {'baseline': BASE, 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'test_sha256': {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in TESTS + SUPPORT}}
with tempfile.TemporaryDirectory(prefix='issue-214-baseline-',dir='/tmp') as directory:
    work = Path(directory)
    names = subprocess.check_output(['git','ls-tree','-r','--name-only',BASE,'computer-use-server'],cwd=ROOT,text=True).splitlines()
    record['source_sha256'] = {}
    for name in names:
        if not (name.endswith('.py') or name.endswith('requirements.txt')):
            continue
        content = subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)
        destination = work/name
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(content)
        record['source_sha256'][name] = hashlib.sha256(content).hexdigest()
    for name in TESTS + SUPPORT:
        destination=work/name
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(ROOT/name,destination)
    argv=[sys.executable,'-m','pytest',*TESTS,'-k','lock_chat_creation_syncs or lock_parent_sync_failure or lock_retry_requires_parent_sync or lock_parent_durability or broken_flock_negative_control or eio_on_data_root_open','-vv','--import-mode=importlib','--junitxml='+str(OUT.with_suffix('.xml'))]
    result=subprocess.run(argv,cwd=work,capture_output=True,text=True,timeout=60)
    record.update(argv=argv,exit=result.returncode,stdout=result.stdout,stderr=result.stderr)
record['owned_tree_removed']=not work.exists()
record['tests_unchanged']=record['test_sha256']=={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in TESTS + SUPPORT}
OUT.write_text(json.dumps(record,indent=2)+'\n')
print(result.stdout)
print(json.dumps({key:record[key] for key in ('exit','owned_tree_removed','tests_unchanged')},indent=2))
raise SystemExit(result.returncode if record['tests_unchanged'] and record['owned_tree_removed'] else 2)
