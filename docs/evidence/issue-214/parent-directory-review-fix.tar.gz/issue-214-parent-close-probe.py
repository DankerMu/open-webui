"""Real broker acquisition under a call-through parent-close EIO fault."""
import errno
import json
import os
from pathlib import Path
import sys
import tempfile

sys.path.insert(0, '/Users/danker/Documents/31308/open-computer-use/computer-use-server')
import docker_manager
import outputs_broker

CHAT = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890'
report = {'fault': 'original close succeeds, then parent-close EIO is injected', 'error': None}
with tempfile.TemporaryDirectory(prefix='issue-214-parent-close-',dir='/tmp') as directory:
    base = Path(directory)
    chat = base/CHAT
    outputs = chat/'outputs'
    outputs.mkdir(parents=True)
    (outputs/'report.txt').write_bytes(b'complete input')
    docker_manager.BASE_DATA_DIR = base
    parent = chat.stat()
    original_open, original_close = os.open, os.close
    acquired = []
    def opened(*args, **kwargs):
        fd = original_open(*args, **kwargs)
        info = os.fstat(fd)
        if chat.joinpath('.ocu').exists():
            control = chat.joinpath('.ocu').stat()
            if (info.st_dev,info.st_ino) == (control.st_dev,control.st_ino):
                acquired.append((fd,info.st_dev,info.st_ino))
        return fd
    def closed(fd):
        info = os.fstat(fd)
        original_close(fd)
        if (info.st_dev,info.st_ino) == (parent.st_dev,parent.st_ino):
            raise OSError(errno.EIO,'controlled parent close failure')
    with docker_manager._combined_lock(CHAT):
        os.open, os.close = opened, closed
        try:
            outputs_broker.OutputsBroker().reconcile(CHAT)
        except OSError as error:
            report['error'] = {'errno':error.errno,'message':str(error)}
        finally:
            os.open, os.close = original_open, original_close
            leaked = []
            for fd,dev,ino in acquired:
                try:
                    info = os.fstat(fd)
                except OSError:
                    continue
                if (info.st_dev,info.st_ino) == (dev,ino):
                    leaked.append(fd)
                    original_close(fd)
            report['leaked_child_fds'] = leaked
            report['owned_probe_fds_closed'] = True
report['owned_tree_removed'] = not base.exists()
Path(sys.argv[1]).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(1 if report['leaked_child_fds'] else 0)
