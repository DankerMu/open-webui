"""Diagnose the existing HTTP child fixture's disabled resource lifetime."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile

for name in ('ALL_PROXY','HTTP_PROXY','HTTPS_PROXY','all_proxy','http_proxy','https_proxy'):
    os.environ.pop(name, None)
os.environ['NO_PROXY'] = os.environ['no_proxy'] = '*'
sys.path.insert(0, '/Users/danker/Documents/31308/open-computer-use')
import pytest
from tests.orchestrator.test_office_sessions import office_world
from tests.orchestrator.test_office_save_close import _command_box, _save
import tests.orchestrator.test_office_resolution as resolution

mode, output_name = sys.argv[1:]
assert mode in ('candidate','owned-control')
output = Path(output_name)
assert not output.exists()
record = {'mode': mode}
with tempfile.TemporaryDirectory(prefix='office-child-owner-') as directory, pytest.MonkeyPatch.context() as patch:
    worldgen = office_world.__wrapped__(Path(directory), patch)
    world = next(worldgen)
    try:
        _http, data, _origin, _manager, _broker, _original, session = resolution._timeout_first_save(world, patch)
        if mode == 'owned-control':
            old = '    import uvicorn\n    uvicorn.run(app.app,'
            new = '    import uvicorn\n    from office.save_workers import save_worker_lifespan\n    app.app.router.lifespan_context = save_worker_lifespan\n    uvicorn.run(app.app,'
            assert resolution._RESOLVE_WORKER.count(old) == 1
            script = resolution._RESOLVE_WORKER.replace(old, new).replace('lifespan="off", log_level="warning"', 'lifespan="on", log_level="warning"')
            patch.setattr(resolution, '_RESOLVE_WORKER', script)
        with _command_box(patch, session['document_key']) as (origin, saves, infos):
            with resolution._resolve_http_worker(data, session, 'save_as', origin.url) as (http, child, _marker, _environment):
                response = _save(http, session['session_id'], 'persist')
                record.update(status=response.status_code, commands=len(origin.requests), saves=saves, infos=infos)
            _stdout, stderr = child.communicate()
            record.update(child_collected=child.returncode is not None,
                          missing_owner_exception='RuntimeError: Office save worker ownership is unavailable' in stderr)
            record['accepted'] = response.status_code == 202 and len(origin.requests) == 1 and saves == [{'save_seq': 2, 'intent': 'persist'}]
    finally:
        worldgen.close()
record['temporary_root_removed'] = not Path(directory).exists()
record['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
output.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if record['accepted'] else 1)
