"""Run retained command ownership oracles serially with explicit asyncio DNS ownership."""
import json
from pathlib import Path
import subprocess
import sys

root = Path('/Users/danker/Documents/31308/open-computer-use')
stage = Path('/tmp/issue-259-evidence')
uv = ['uv', 'run', '--no-project', '--python', '3.13', '--no-python-downloads',
      '--with', 'pytest', '--with', 'pytest-asyncio', '--with', 'PyYAML==6.0.2',
      '--with-requirements', 'computer-use-server/requirements.txt', '--', 'python',
      '-u', '/tmp/issue-259-runtime-stack.py']
rows = []
for case in ('join', 'close', 'save', 'sweep'):
    rows.append((f'runtime-{case}-explicit-baseline', '/tmp/issue-259-runtime.py', [case], 1, True))
for case in ('join', 'close', 'save', 'sweep', 'restore'):
    rows.append((f'executor-{case}-explicit-baseline', '/tmp/issue-259-executor-probe.py', [case, 'candidate'], 0, True))
# Join candidate already passed runtime-join-explicit-asyncio; do not rerun it.
for case in ('close', 'save', 'sweep'):
    rows.append((f'runtime-{case}-owned', '/tmp/issue-259-runtime.py', [case], 0, False))
for case in ('join', 'close', 'save', 'sweep', 'restore'):
    rows.append((f'executor-{case}-owned', '/tmp/issue-259-executor-probe.py', [case, 'candidate'], 0, False))
for case in ('join', 'close', 'save', 'sweep', 'restore'):
    rows.append((f'executor-{case}-mutant', '/tmp/issue-259-executor-probe.py', [case, 'wrong-executor'], 1, False))
rows += [
    ('callback-capacity-owned', '/tmp/issue-259-callback-capacity.py', ['candidate'], 0, False),
    ('post-acquisition-startup-owned', '/tmp/issue-259-startup-ownership.py', [], 0, False),
]
summary = []
for label, probe, arguments, expected, baseline in rows:
    observation = stage / (label + '-observations.json')
    environment = ['env', 'ISSUE259_PROBE_SOURCE=/tmp/issue-259-source-baseline', 'PYTHONDONTWRITEBYTECODE=1'] if baseline else []
    command = [sys.executable, '/tmp/issue-259-run.py', label, 'source',
               *environment, *uv, probe, *arguments, str(observation)]
    run = subprocess.run(command, cwd=root, text=True, capture_output=True)
    record = json.loads((stage / (label + '.json')).read_text())
    result = json.loads(observation.read_text()) if observation.exists() else None
    valid = (run.returncode == expected and record['inputs_unchanged']
             and not record['interrupted'] and result is not None
             and result['accepted'] == (expected == 0))
    summary.append({'label': label, 'exit': run.returncode, 'expected_exit': expected,
                    'baseline': baseline, 'inputs_unchanged': record['inputs_unchanged'], 'valid': valid})
    print(json.dumps(summary[-1]), flush=True)
    if not valid:
        print(run.stdout)
        print(run.stderr)
        break
prior = json.loads((stage / 'runtime-join-explicit-asyncio-observations.json').read_text())
prior_record = json.loads((stage / 'runtime-join-explicit-asyncio.json').read_text())
prior_valid = prior['accepted'] and prior_record['exit'] == 0 and prior_record['inputs_unchanged']
accepted = len(summary) == len(rows) and all(row['valid'] for row in summary) and prior_valid
output = stage / 'runtime-owner-matrix.json'
assert not output.exists()
output.write_text(json.dumps({'rows': summary, 'complete': len(summary) == len(rows),
                              'prior_join': 'runtime-join-explicit-asyncio.json',
                              'prior_join_valid': prior_valid, 'accepted': accepted}, indent=2)+'\n')
raise SystemExit(0 if accepted else 1)
