# Induced callback admission counterexample

Before accepting the service-loop cutover, a parent-owned actual ASGI save/callback plus real signed command HTTP probe limits the existing AnyIO admission pool to one available slot. The command responder invokes an authenticated status-1 callback before returning its accepted forcesave response.

Observed candidate RED: save holds one AnyIO token while waiting; save returns502 documentserver_unavailable after10.0168s; callback completes200/error0 only afterward. The origin received one valid command, nonstate bytes were preserved and all owned fixture resources closed. This is not a command DNS stall and not yet an attributed cause.

Ranked hypotheses:

1. Shared AnyIO admission creates a wait cycle: save's blocking worker occupies the slot needed by its induced callback. Prediction: changing only the save worker dispatch to the previous default-executor domain, with DNS capacity otherwise adequate, lets that same callback complete and save return202.
2. The new bridge retained the canonical chat lock during force-save. Prediction: changing worker domain alone cannot help. Inspected sessions.py:693–729 shows command waiting outside the lock, against this hypothesis.
3. Callback authentication or state admission is invalid. Prediction: changing worker domain cannot change its refusal; the already-observed callback200/error0 argues against this hypothesis.

The callback/downloader code is unchanged. The probe tests whether the changed caller's resource ownership blocks its existing callback consumer. No production capacity or timeout change is authorized by this diagnostic.
