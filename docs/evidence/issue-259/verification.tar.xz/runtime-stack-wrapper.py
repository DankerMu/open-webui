import faulthandler
import runpy
import sys
import traceback

script, *arguments = sys.argv[1:]
sys.argv = [script, *arguments]
faulthandler.dump_traceback_later(30, exit=True)
try:
    runpy.run_path(script, run_name='__main__')
except BaseException:
    traceback.print_exc()
    sys.stderr.flush()
    raise
