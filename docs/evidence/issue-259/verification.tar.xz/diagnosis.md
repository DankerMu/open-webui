# Command deadline diagnosis

Source authority: issue259 distinguishes command inference from prior callback evidence. This session first exercised the real command client, without production edits.

## Executed RED

`uv run --no-project --python 3.13 --no-python-downloads --with pytest --with pytest-asyncio --with PyYAML==6.0.2 --with-requirements computer-use-server/requirements.txt -- python /tmp/issue-259-dns-probe.py lookup /tmp/issue-259-evidence/lookup-diagnostic.json`

Exit1: `command caller exceeded deadline while DNS remained blocked`. Diagnostic timeout0.25s (production constant remains10s outside the probe), observation allowance0.15s. Real aiohttp ThreadedResolver entered socket.getaddrinfo; coroutine returned unreachable after0.251842s; synchronous asyncio.run caller had not returned at0.40s and returned after explicit DNS release at0.404643s. Worker/resolver both collected; no emergency escape or probe errors.

The minimal seam needs no HTTP response or session state: real command coroutine plus the existing per-call asyncio.run boundary and a held real threaded resolver. This is command-client evidence, not yet proof for all session/sweep callsites or the unchanged10s production budget.

## Ranked hypotheses and predictions

1. Default-executor shutdown owns the overrun. Prediction: while the coroutine is already complete and DNS remains held, the caller stack is in asyncio runner close/default-executor shutdown; retaining a running service loop allows the same command to return unreachable before DNS release.
2. aiohttp session/connector exit waits for resolver completion. Prediction: the command coroutine itself stays incomplete until DNS release. Initial trace contradicts this: coroutine_completed is true before release.
3. Resolution blocks the event-loop thread rather than an executor worker. Prediction: the coroutine timeout cannot fire while DNS is held. Initial timely coroutine return contradicts this.
4. The timeout is missing or misconfigured for command traffic. Prediction: the command coroutine does not return unreachable around the configured0.25s. Initial coroutine timing/outcome contradicts this.

Next probes: same forcesave path; stack observation while held; unchanged-client comparison on an already-running owned loop. These are diagnostic probes, not a production design commitment. Final acceptance must exercise actual callers, original timeout policy, lookup lock ownership and lock-free forcesave.

## Confirmed cause

Forcesave independently reproduced the same deadline overrun with unreachable already produced before DNS release. The instrumented lookup caller was inside asyncio.runners.Runner.close at runners.py:72; the inspected Python3.13 source at72–73 awaits loop.shutdown_default_executor. With the command client, real ThreadedResolver, held socket call and timeout unchanged, only moving command execution onto an already-running owned loop made both lookup and forcesave return unreachable before DNS release (exit0). Per-call mode remained exit1. All instrumented source/test inputs were unchanged; workers, resolver invocations and the diagnostic loop were collected.

The initial forcesave command-capture inputs_unchanged=false is explained solely by its absolute JSON output path being newly created; every source/test/dependency input matched. The runner now freezes preexisting command-file inputs before execution. Raw evidence and the qualification record are retained.

## Implementation boundary

Reuse the existing callback service-loop submission mechanism, not its domain errors or downloader. Keep async forcesave/lookup_key protocol APIs: existing real HTTP-origin admitted-cancellation tests consume them. Add one bounded synchronous command bridge and explicitly pass the actual running request/reaper loop to worker-owned session/sweep operations. Do not convert those protocol APIs to synchronous calls or create a new global/dedicated production loop. The four per-call asyncio.run command sites are the complete production cutover.

Planning complexity: normal issue planning with an expanded fixture, not a separate deep-plan document. One ownership mechanism spans four callers; staged command/caller regressions, complete callsite migration and rollback by revert are sufficient. No unresolved product policy or prerequisite.
