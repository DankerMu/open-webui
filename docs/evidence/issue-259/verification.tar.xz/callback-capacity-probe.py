"""Probe command-induced callback progress with one available AnyIO worker slot."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time

for name in ('ALL_PROXY', 'HTTP_PROXY', 'HTTPS_PROXY', 'all_proxy', 'http_proxy', 'https_proxy'):
    os.environ.pop(name, None)
os.environ['NO_PROXY'] = '*'
os.environ['no_proxy'] = '*'
sys.path.insert(0, '/Users/danker/Documents/31308/open-computer-use')
import anyio.to_thread
import pytest
from tests.orchestrator.test_office_sessions import office_world, _snapshot, _state
from tests.orchestrator.test_office_session_lifecycle import _created
from tests.orchestrator.test_office_save_close import _save, _command_box
from tests.orchestrator.test_office_callback_processing import _post
from tests.orchestrator._office_recorded_callbacks import recorded_status_1_payload

mode, output_name = sys.argv[1:]
assert mode in ('candidate', 'default-waiter-control')
output = Path(output_name)
assert not output.exists()
record = {'mode': mode, 'seam': 'actual ASGI save/callback plus real signed command HTTP'}
callback_done = threading.Event()
stamps = {}
with tempfile.TemporaryDirectory(prefix='office-callback-capacity-') as directory, pytest.MonkeyPatch.context() as patch:
    worldgen = office_world.__wrapped__(Path(directory), patch)
    world = next(worldgen)
    limiter = None
    prior_tokens = None
    try:
        http, data, recording, _manager, _broker = world
        from office import commands, sessions
        file_id, session = _created(world, 'editing')
        before = _snapshot(data)

        def limit_workers():
            current = anyio.to_thread.current_default_thread_limiter()
            prior = current.total_tokens
            current.total_tokens = 1
            return current, prior

        limiter, prior_tokens = http.portal.call(limit_workers)
        if mode == 'default-waiter-control':
            patch.setattr(sessions, 'run_in_threadpool', asyncio.to_thread)

        def induce_callback(_userdata):
            stamps['command_admitted'] = time.monotonic()
            record['borrowed_worker_tokens_at_command'] = limiter.borrowed_tokens
            response = _post(http, session, recorded_status_1_payload(document_key=session['document_key']))
            record['callback_status'] = response.status_code
            record['callback_body'] = response.json()
            stamps['callback_returned'] = time.monotonic()
            callback_done.set()

        with _command_box(patch, session['document_key'], observe=induce_callback) as (origin, _saves, _infos):
            stamps['save_started'] = time.monotonic()
            response = _save(http, session['session_id'], 'persist')
            stamps['save_returned'] = time.monotonic()
            record['save_status'] = response.status_code
            record['save_body_projection'] = {k:v for k,v in response.json().items() if k in ('reason','save_seq','intent')}
            record['callback_completed_when_save_returned'] = callback_done.is_set()
            assert callback_done.wait(5), 'owned command responder callback did not finish'
            record['command_requests'] = len(origin.requests)
        after = _snapshot(data)
        state_path = str(_state(data).relative_to(data))
        record['nonstate_files_unchanged'] = {k:v for k,v in before.items() if k != state_path} == {k:v for k,v in after.items() if k != state_path}
        record['elapsed'] = stamps['save_returned']-stamps['save_started']
        record['budget'] = commands.HTTP_TIMEOUT_SECONDS
        record['accepted'] = all((response.status_code == 202, record['callback_status'] == 200,
                                  record['callback_body'] == {'error': 0}, record['command_requests'] == 1,
                                  record['callback_completed_when_save_returned'],
                                  record['nonstate_files_unchanged'], recording.hits == 0))
    finally:
        if limiter is not None:
            http.portal.call(setattr, limiter, 'total_tokens', prior_tokens)
        worldgen.close()
record.update(timestamps=stamps, owned_fixture_closed=True, temporary_root_removed=not Path(directory).exists(),
              script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
output.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if record['accepted'] else 1)
