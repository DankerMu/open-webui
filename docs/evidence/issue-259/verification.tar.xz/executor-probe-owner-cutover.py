"""Parent-owned healthy command proof with one DNS executor worker."""
import asyncio
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
from urllib.parse import urlsplit

for name in ('ALL_PROXY', 'HTTP_PROXY', 'HTTPS_PROXY', 'all_proxy', 'http_proxy', 'https_proxy'):
    os.environ.pop(name, None)
os.environ['NO_PROXY'] = '*'
os.environ['no_proxy'] = '*'
sys.path.insert(0, '/Users/danker/Documents/31308/open-computer-use')
import aiohttp.connector
import aiohttp.resolver
import httpx
import pytest
import uvicorn
from tests.orchestrator.test_office_sessions import office_world, _create, _snapshot, _state
from tests.orchestrator.test_office_session_lifecycle import _created, _change
from tests.orchestrator.test_office_save_close import _save, _close, _command_box
from tests.orchestrator.test_office_restore import _restore
from tests.orchestrator.test_outputs_endpoint import CHAT

case, mode, output_name = sys.argv[1:]
assert case in ('join', 'close', 'save', 'sweep', 'restore')
assert mode in ('candidate', 'wrong-executor')
output = Path(output_name)
assert not output.exists()
record = {'case': case, 'mode': mode, 'seam': 'real uvicorn HTTP' if case != 'sweep' else 'real Office poll on uvicorn loop'}
loop_box = {}
sock = server = server_thread = None
calls = []
with tempfile.TemporaryDirectory(prefix='office-executor-runtime-') as directory, pytest.MonkeyPatch.context() as patch:
    worldgen = office_world.__wrapped__(Path(directory), patch)
    world = next(worldgen)
    try:
        http, data, recording, _docker, _broker = world
        import app
        from office import commands, config, sessions, restore
        from office.store import OfficeStore
        budget = commands.HTTP_TIMEOUT_SECONDS
        assert budget == 10
        file_id, session = _created(world, 'editing')
        if case == 'sweep':
            now = time.time()
            _change(session['session_id'], state='saving', save_seq=1, pending_save_seq=1,
                    save_intents={'1': 'persist'},
                    last_activity_at=now-config.SESSION_LIVENESS_INTERVAL_SECONDS-1,
                    saving_started_at=now-config.SAVE_CALLBACK_TIMEOUT_SECONDS-1)
        before_state = OfficeStore().read(CHAT)
        before_files = _snapshot(data)

        async def capture_loop(scope, receive, send):
            loop_box['loop'] = asyncio.get_running_loop()
            await http.app(scope, receive, send)

        sock = socket.socket()
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
        server = uvicorn.Server(uvicorn.Config(capture_loop, host='127.0.0.1', port=port,
                                               log_level='error', access_log=False, lifespan='off'))
        server_thread = threading.Thread(target=server.run, kwargs={'sockets': [sock]})
        server_thread.start()
        ready_until = time.monotonic()+5
        while not server.started:
            assert server_thread.is_alive() and time.monotonic() < ready_until, 'HTTP startup failed'
            time.sleep(0.01)
        with httpx.Client(base_url=f'http://127.0.0.1:{port}', trust_env=False, timeout=budget+5) as client:
            assert client.get('/health').json() == {'status': 'healthy'}
            service_loop = loop_box['loop']

            async def limit_executor():
                service_loop.set_default_executor(ThreadPoolExecutor(max_workers=1))

            asyncio.run_coroutine_threadsafe(limit_executor(), service_loop).result(timeout=5)
            original_dns = socket.getaddrinfo

            def observed_dns(host, port, *args, **kwargs):
                if host == 'localhost':
                    calls.append({'entered': time.monotonic(), 'thread': threading.get_ident()})
                return original_dns(host, port, *args, **kwargs)

            patch.setattr(aiohttp.connector, 'DefaultResolver', aiohttp.resolver.ThreadedResolver)
            patch.setattr(socket, 'getaddrinfo', observed_dns)
            if mode == 'wrong-executor':
                # A disposable wrong waiter owner; normal candidate oracles stay unchanged.
                if case == 'save':
                    patch.setattr(http.app.state, 'office_save_executor', service_loop._default_executor)
                else:
                    owner = app if case == 'sweep' else restore if case == 'restore' else sessions
                    patch.setattr(owner, 'run_in_threadpool', asyncio.to_thread)

            async def one_poll():
                stop = asyncio.Event()
                loop = asyncio.get_running_loop()
                def stop_after_reap():
                    loop.call_soon_threadsafe(stop.set)
                with pytest.MonkeyPatch.context() as tick:
                    tick.setattr(app, 'startup_idle_sweep', lambda: None)
                    tick.setattr(app, 'validate_idle_configuration', lambda: (600, 0.001))
                    tick.setattr(app, 'reap_known_sandboxes', stop_after_reap)
                    await app._idle_reaper(stop)

            with _command_box(patch, session['document_key']) as (origin, _seen, _infos):
                patch.setenv('OCU_OFFICE_DOCSERVER_URL', f'http://localhost:{urlsplit(origin.url).port}')
                began = time.monotonic()
                if case == 'join':
                    response = _create(client, file_id)
                elif case == 'close':
                    response = _close(client, session['session_id'])
                elif case == 'save':
                    response = _save(client, session['session_id'], 'persist')
                elif case == 'restore':
                    response = _restore(client, file_id)
                else:
                    response = None
                    asyncio.run_coroutine_threadsafe(one_poll(), service_loop).result(timeout=budget+5)
                elapsed = time.monotonic()-began
                # Captured before origin teardown and outside any emergency cleanup.
                record.update(elapsed=elapsed, real_dns_calls=len(calls), command_requests=len(origin.requests))
                after_state = OfficeStore().read(CHAT)
                after_files = _snapshot(data)
                active = after_state['sessions'][session['session_id']]
                if response is not None:
                    body = response.json()
                    record['response_projection'] = {'status': response.status_code, **{k:body[k] for k in ('reason','save_seq','state','joined') if k in body}}
                if case == 'join':
                    semantics = response.status_code == 200 and body['joined'] is True and active['state'] == 'editing'
                elif case == 'close':
                    semantics = response.status_code == 202 and active['state'] == 'closing' and active['pending_close_seq'] == 1
                elif case == 'save':
                    semantics = response.status_code == 202 and active['state'] == 'saving' and active['pending_save_seq'] == 1
                elif case == 'restore':
                    semantics = response.status_code == 409 and body == {'reason': 'session_open'} and after_state == before_state and after_files == before_files
                else:
                    semantics = active['state'] == 'editing' and active['reason'] == 'save_timeout' and active['pending_save_seq'] == 1
                state_path = str(_state(data).relative_to(data))
                record['nonstate_files_unchanged'] = {k:v for k,v in before_files.items() if k != state_path} == {k:v for k,v in after_files.items() if k != state_path}
                record['document_and_receipt_state_unchanged'] = all(after_state.get(k) == before_state.get(k) for k in ('documents','receipts','journal'))
                record['state_projection'] = {k:active.get(k) for k in ('state','reason','save_seq','pending_save_seq','pending_close_seq')}
                record['caller_semantics_preserved'] = semantics
                record['accepted'] = all((semantics, len(calls) == 1, len(origin.requests) == 1,
                                          record['nonstate_files_unchanged'], record['document_and_receipt_state_unchanged'],
                                          recording.hits == 0))
    finally:
        if server is not None:
            server.should_exit = True
        if server_thread is not None and server_thread.ident is not None:
            server_thread.join(15)
            assert not server_thread.is_alive(), 'owned HTTP/default-executor owner survived cleanup'
        if sock is not None:
            sock.close()
        worldgen.close()
record.update(owned_service_stopped=True, temporary_root_removed=not Path(directory).exists(),
              script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              limits='Local real HTTP/poll, real threaded DNS and signed command origin; fixture Docker, not deployment certification.')
output.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if record['accepted'] else 1)
