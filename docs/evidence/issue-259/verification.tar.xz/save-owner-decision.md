# Save waiter ownership decision

## Problem and authority

Issue259 requires bounded command completion without changing lock/state or callback behavior. The initial candidate fixes the deadline (owning command/deadline scope40passed) but introduces a resource wait cycle: a blocking save waiter consumes the AnyIO token required by a callback induced by its command.

## Evidence

The actual ASGI save/callback plus real signed-command HTTP probe with one available AnyIO token returns save502 after10.0168s; callback200 follows only after save returns. Changing only save dispatch back to the default executor yields callback200 and save202 in0.0041s. Canonical lock placement is unchanged and outside the command wait. This confirms shared callback admission as the cause; invalid auth and chat-lock retention do not explain the differential. The default executor is not the repair because the real one-worker DNS oracle requires that executor to remain available for resolution.

## Options and decision

- Keep shared AnyIO: rejected by the induced-callback counterexample.
- Reuse the default executor: rejected by the one-worker DNS dependency; only a diagnostic control.
- Split prepare/network/reconcile into async phases: removes waiter threads but changes cancellation/admission semantics. Preserving an admitted transaction requires shield-and-drain or a separate task owner; prompt request cancellation and queued-work cancellation would otherwise change.
- Lifespan-owned standard ThreadPoolExecutor for save only: selected. Preserve the full synchronous transaction, fresh per-submission context propagation and existing queued/running cancellation behavior. It is separate from DNS and callback admission. No new event loop, deadline, dependency, retry, capacity setting or global singleton.

Both independent bounded design reviews prefer the private executor; complete reports are retained beside this decision. Parent retains final integration authority. New resource ownership needs proof, not merely the existing40-test pass.

## Lifecycle constraints

Establish cleanup ownership before admitting save work. Withdraw admission before teardown awaits. Drain actual executor work, including work whose request await was cancelled, while the service loop remains responsive. Cleanup must not consume the DNS/default executor or callback AnyIO capacity. Do not substitute shutdown(wait=False) for completion or synchronously block the service loop while jobs still need it. Preserve cancellation after cleanup, including repeated task and AnyIO cancellation. No new shutdown timeout or forced-thread-termination guarantee.

A pre-started shutdown supervisor waiting on an event is selected and independently reviewed as sound. It starts before publishing save admission; failure to start therefore precedes any accepted work and permits synchronous cleanup of the unused executor. It costs one idle lifecycle-owned thread, but avoids a late thread-start ownership hole without tracking every worker future. On close, it drains the executor and notifies a private future on the live loop; the owner shields and drains completion through cancellation, joins the supervisor, then propagates cancellation.

## Evidence required and reversal

Keep the frozen held-DNS and one-DNS-worker oracles. Add induced-callback progress; running/queued save cancellation; context isolation; startup/body failure; admission closure; draining active work with cancellation and independent event-loop progress. Run targeted lifecycle evidence under the available production Python3.12 interpreter as well as the main Python3.13 verification environment. Update the fixture before repair, then update the owning decision after runtime proof.

Revert the source cutover to roll back; no persisted schema change. Revisit only if save cancellation semantics change, executor capacity requires an explicit product policy, or runtime lifecycle APIs change. This is not a claim of global capacity or process-shutdown timing guarantees.
