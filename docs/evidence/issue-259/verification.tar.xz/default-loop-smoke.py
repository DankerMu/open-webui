"""Healthy command callers on uvicorn's unmodified auto-selected service loop."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
from urllib.parse import urlsplit

for name in ('ALL_PROXY', 'HTTP_PROXY', 'HTTPS_PROXY', 'all_proxy', 'http_proxy', 'https_proxy'):
    os.environ.pop(name, None)
os.environ['NO_PROXY'] = os.environ['no_proxy'] = '*'
sys.path.insert(0, '/Users/danker/Documents/31308/open-computer-use')
import httpx
import pytest
import uvicorn
from tests.orchestrator.test_office_sessions import office_world, _create, _snapshot, _state
from tests.orchestrator.test_office_session_lifecycle import _created, _change
from tests.orchestrator.test_office_save_close import _save, _close, _command_box
from tests.orchestrator.test_office_restore import _restore
from tests.orchestrator.test_outputs_endpoint import CHAT

output = Path(sys.argv[1])
assert not output.exists()
rows = []
for case in ('join', 'close', 'save', 'sweep', 'restore'):
    server = server_thread = sock = None
    loop_box = {}
    with tempfile.TemporaryDirectory(prefix='office-default-loop-') as directory, pytest.MonkeyPatch.context() as patch:
        worldgen = office_world.__wrapped__(Path(directory), patch)
        world = next(worldgen)
        try:
            http, data, recording, _docker, _broker = world
            import app
            from office import config
            from office.store import OfficeStore
            file_id, session = _created(world, 'editing')
            if case == 'sweep':
                now = time.time()
                _change(session['session_id'], state='saving', save_seq=1, pending_save_seq=1,
                        save_intents={'1': 'persist'},
                        last_activity_at=now-config.SESSION_LIVENESS_INTERVAL_SECONDS-1,
                        saving_started_at=now-config.SAVE_CALLBACK_TIMEOUT_SECONDS-1)
            before = OfficeStore().read(CHAT)
            files_before = _snapshot(data)

            async def capture(scope, receive, send):
                loop_box['loop'] = asyncio.get_running_loop()
                await http.app(scope, receive, send)

            sock = socket.socket()
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
            server = uvicorn.Server(uvicorn.Config(capture, host='127.0.0.1', port=port,
                                                   log_level='error', access_log=False, lifespan='off'))
            server_thread = threading.Thread(target=server.run, kwargs={'sockets': [sock]})
            server_thread.start()
            until = time.monotonic()+5
            while not server.started:
                assert server_thread.is_alive() and time.monotonic() < until
                time.sleep(0.01)
            with httpx.Client(base_url=f'http://127.0.0.1:{port}', trust_env=False, timeout=15) as client:
                assert client.get('/health').json() == {'status': 'healthy'}
                loop = loop_box['loop']
                loop_type = type(loop).__module__+'.'+type(loop).__name__
                assert type(loop).__module__ == 'uvloop', loop_type

                async def one_poll():
                    stop = asyncio.Event()
                    current = asyncio.get_running_loop()
                    with pytest.MonkeyPatch.context() as tick:
                        tick.setattr(app, 'startup_idle_sweep', lambda: None)
                        tick.setattr(app, 'validate_idle_configuration', lambda: (600, 0.001))
                        tick.setattr(app, 'reap_known_sandboxes', lambda: current.call_soon_threadsafe(stop.set))
                        await app._idle_reaper(stop)

                with _command_box(patch, session['document_key']) as (origin, saves, infos):
                    patch.setenv('OCU_OFFICE_DOCSERVER_URL', f'http://localhost:{urlsplit(origin.url).port}')
                    if case == 'join':
                        response = _create(client, file_id)
                    elif case == 'close':
                        response = _close(client, session['session_id'])
                    elif case == 'save':
                        response = _save(client, session['session_id'], 'persist')
                    elif case == 'restore':
                        response = _restore(client, file_id)
                    else:
                        response = None
                        asyncio.run_coroutine_threadsafe(one_poll(), loop).result(timeout=15)
                    after = OfficeStore().read(CHAT)
                    files_after = _snapshot(data)
                    active = after['sessions'][session['session_id']]
                    body = response.json() if response is not None else None
                    if case == 'join':
                        semantics = response.status_code == 200 and body['joined'] is True and active['state'] == 'editing'
                    elif case == 'close':
                        semantics = response.status_code == 202 and active['state'] == 'closing' and active['pending_close_seq'] == 1
                    elif case == 'save':
                        semantics = response.status_code == 202 and active['state'] == 'saving' and active['pending_save_seq'] == 1
                    elif case == 'restore':
                        semantics = response.status_code == 409 and body == {'reason': 'session_open'} and after == before and files_after == files_before
                    else:
                        semantics = active['state'] == 'editing' and active['reason'] == 'save_timeout' and active['pending_save_seq'] == 1
                    state_path = str(_state(data).relative_to(data))
                    byte_preserved = {k:v for k,v in files_before.items() if k != state_path} == {k:v for k,v in files_after.items() if k != state_path}
                    other_preserved = all(after.get(k) == before.get(k) for k in ('documents','receipts','journal'))
                    rows.append({'case': case, 'loop_type': loop_type,
                                 'status': response.status_code if response is not None else None,
                                 'command_requests': len(origin.requests), 'semantics': semantics,
                                 'nonstate_bytes_preserved': byte_preserved, 'other_state_preserved': other_preserved,
                                 'accepted': semantics and byte_preserved and other_preserved and len(origin.requests) == 1 and recording.hits == 0})
        finally:
            try:
                if server is not None:
                    server.should_exit = True
                if server_thread is not None and server_thread.ident is not None:
                    server_thread.join(10)
                    assert not server_thread.is_alive(), 'default-loop server survived cleanup'
            finally:
                if sock is not None:
                    sock.close()
                worldgen.close()
        assert not any(not row['accepted'] for row in rows), rows
    assert not Path(directory).exists()
record = {'rows': rows, 'accepted': all(row['accepted'] for row in rows),
          'owned_services_stopped': True, 'temporary_roots_removed': True,
          'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'limits': 'Healthy commands on actual uvicorn auto-selected uvloop only; not native DNS-stall or shutdown deadline certification.'}
output.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if record['accepted'] else 1)
