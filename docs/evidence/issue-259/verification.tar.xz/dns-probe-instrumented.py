import asyncio
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import socket
import sys
import threading
import time
import traceback

import aiohttp.connector
import aiohttp.resolver

SOURCE = Path('/Users/danker/Documents/31308/open-computer-use')
sys.path.insert(0, str(SOURCE / 'computer-use-server'))
from office import commands

case = sys.argv[1]
output = Path(sys.argv[2])
mode = sys.argv[3] if len(sys.argv) > 3 else 'per-call'
assert mode in ('per-call', 'owned-loop')
assert case in ('lookup', 'forcesave')
os.environ['OCU_OFFICE_JWT_SECRET'] = 'issue259-test-only-signing-canary'
os.environ['OCU_OFFICE_DOCSERVER_URL'] = 'http://issue259-held-dns.example:9'
original_timeout = commands.HTTP_TIMEOUT_SECONDS
commands.HTTP_TIMEOUT_SECONDS = 0.25
allowance = 0.15
entered = threading.Event()
release = threading.Event()
returned = threading.Event()
completed = threading.Event()
coroutine_completed = threading.Event()
started = threading.Event()
stamps = {}
errors = []
result = {}
original_dns = socket.getaddrinfo
original_resolver = aiohttp.connector.DefaultResolver
service_loop = asyncio.new_event_loop() if mode == 'owned-loop' else None
service_started = threading.Event()


def serve():
    asyncio.set_event_loop(service_loop)
    service_loop.call_soon(service_started.set)
    try:
        service_loop.run_forever()
    finally:
        service_loop.run_until_complete(service_loop.shutdown_asyncgens())
        service_loop.run_until_complete(service_loop.shutdown_default_executor())
        service_loop.close()


service = threading.Thread(target=serve) if service_loop is not None else None
if service is not None:
    service.start()
    assert service_started.wait(2), 'diagnostic service loop did not start'


def held_dns(host, port, *args, **kwargs):
    if host != 'issue259-held-dns.example':
        return original_dns(host, port, *args, **kwargs)
    stamps['dns_entered'] = time.monotonic()
    entered.set()
    try:
        if not release.wait(5):
            errors.append('resolver emergency escape')
            raise TimeoutError('probe resolver escape')
        return original_dns('127.0.0.1', port, *args, **kwargs)
    finally:
        stamps['dns_returned'] = time.monotonic()
        returned.set()


async def invoke():
    if case == 'lookup':
        outcome = await commands.lookup_key('issue259-document')
    else:
        outcome = await commands.forcesave('issue259-document', 1, 'persist')
    result['outcome'] = outcome.value
    stamps['coroutine_returned'] = time.monotonic()
    coroutine_completed.set()
    return outcome


def call():
    try:
        stamps['call_started'] = time.monotonic()
        started.set()
        if service_loop is None:
            asyncio.run(invoke())
        else:
            asyncio.run_coroutine_threadsafe(invoke(), service_loop).result()
        stamps['caller_returned'] = time.monotonic()
    except BaseException as error:
        errors.append(type(error).__name__ + ': ' + str(error))
    finally:
        completed.set()


socket.getaddrinfo = held_dns
aiohttp.connector.DefaultResolver = aiohttp.resolver.ThreadedResolver
worker = threading.Thread(target=call)
try:
    worker.start()
    assert started.wait(2), 'caller did not start'
    deadline = stamps['call_started'] + commands.HTTP_TIMEOUT_SECONDS + allowance
    assert entered.wait(max(0, deadline-time.monotonic())), 'real threaded resolver did not enter'
    returned_by_deadline = completed.wait(max(0, deadline-time.monotonic()))
    frame = sys._current_frames().get(worker.ident)
    result['caller_stack_at_deadline'] = traceback.format_stack(frame) if frame is not None else []
    result.update(case=case, mode=mode, production_timeout=original_timeout,
                  diagnostic_timeout=commands.HTTP_TIMEOUT_SECONDS, allowance=allowance,
                  resolver_entered=entered.is_set(), caller_returned_by_deadline=returned_by_deadline,
                  coroutine_returned_by_deadline=coroutine_completed.is_set(),
                  resolver_released_at_deadline=release.is_set(), resolver_returned_at_deadline=returned.is_set())
finally:
    stamps['dns_released'] = time.monotonic()
    release.set()
    if worker.ident is not None:
        worker.join(timeout=5)
    resolver_finished = not entered.is_set() or returned.wait(5)
    if service is not None:
        service_loop.call_soon_threadsafe(service_loop.stop)
        service.join(timeout=5)
        assert not service.is_alive(), 'diagnostic service loop did not stop'
    socket.getaddrinfo = original_dns
    aiohttp.connector.DefaultResolver = original_resolver
    commands.HTTP_TIMEOUT_SECONDS = original_timeout
    result.update(timestamps=stamps, errors=errors, worker_stopped=not worker.is_alive(), resolver_finished=resolver_finished,
                  python=platform.python_version(), platform=platform.platform(), aiohttp=importlib.metadata.version('aiohttp'))
    output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
    assert not worker.is_alive() and resolver_finished and not errors, 'probe setup or cleanup failed'
assert result['outcome'] == 'unreachable'
assert result['caller_returned_by_deadline'], 'command caller exceeded deadline while DNS remained blocked'
