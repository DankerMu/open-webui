"""Parent-owned held-DNS smoke through real uvicorn HTTP and the Office poll."""
import asyncio
import copy
import fcntl
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
from urllib.parse import urlsplit

for name in ('ALL_PROXY', 'HTTP_PROXY', 'HTTPS_PROXY', 'all_proxy', 'http_proxy', 'https_proxy'):
    os.environ.pop(name, None)
os.environ['NO_PROXY'] = '*'
os.environ['no_proxy'] = '*'
sys.path.insert(0, '/Users/danker/Documents/31308/open-computer-use')
import aiohttp.connector
import aiohttp.resolver
import httpx
import pytest
import uvicorn
from tests.orchestrator.test_office_sessions import office_world, _create, _snapshot, _state
from tests.orchestrator.test_office_session_lifecycle import _created, _change
from tests.orchestrator.test_office_save_close import _save, _close
from tests.orchestrator.test_outputs_endpoint import CHAT

case, output_name = sys.argv[1:]
assert case in ('join', 'close', 'save', 'sweep')
output = Path(output_name)
assert not output.exists()
record = {'case': case, 'seam': 'real uvicorn HTTP' if case != 'sweep' else 'real Office poll on uvicorn loop'}
entered, release, resolver_returned = threading.Event(), threading.Event(), threading.Event()
started, completed, contender_started, acquired = (threading.Event() for _ in range(4))
stamps, results, errors = {}, {}, []
loop_box = {}
worker = contender = server_thread = server = sock = None

with tempfile.TemporaryDirectory(prefix='office-command-runtime-') as directory, pytest.MonkeyPatch.context() as patch:
    worldgen = office_world.__wrapped__(Path(directory), patch)
    world = next(worldgen)
    try:
        http, data, origin, docker, _broker = world
        import app
        from office import commands, config
        from office.store import OfficeStore
        budget = commands.HTTP_TIMEOUT_SECONDS
        assert budget == 10, 'production timeout policy changed'
        allowance = 0.15
        file_id, session = _created(world, 'editing')
        if case == 'sweep':
            now = time.time()
            _change(session['session_id'], state='saving', save_seq=1, pending_save_seq=1,
                    save_intents={'1': 'persist'},
                    last_activity_at=now-config.SESSION_LIVENESS_INTERVAL_SECONDS-1,
                    saving_started_at=now-config.SAVE_CALLBACK_TIMEOUT_SECONDS-1)
        before_state = OfficeStore().read(CHAT)
        before_files = _snapshot(data)
        before_hits = origin.hits

        async def capture_loop(scope, receive, send):
            loop_box['loop'] = asyncio.get_running_loop()
            await http.app(scope, receive, send)

        sock = socket.socket()
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
        server = uvicorn.Server(uvicorn.Config(capture_loop, host='127.0.0.1', port=port,
                                               log_level='error', access_log=False, lifespan='off'))
        server_thread = threading.Thread(target=server.run, kwargs={'sockets': [sock]})
        server_thread.start()
        ready_until = time.monotonic()+5
        while not server.started:
            assert server_thread.is_alive() and time.monotonic() < ready_until, 'HTTP startup failed'
            time.sleep(0.01)
        with httpx.Client(base_url=f'http://127.0.0.1:{port}', trust_env=False, timeout=budget+5) as client:
            assert client.get('/health').json() == {'status': 'healthy'}
            service_loop = loop_box['loop']
            original_dns = socket.getaddrinfo
            held_host = 'issue259-runtime-'+case+'.example'

            def held_dns(host, port, *args, **kwargs):
                if host != held_host:
                    return original_dns(host, port, *args, **kwargs)
                stamps['resolver_entered'] = time.monotonic()
                entered.set()
                try:
                    if not release.wait(budget+10):
                        errors.append('resolver emergency escape')
                        raise TimeoutError('owned resolver escape invalidates proof')
                    return original_dns('127.0.0.1', port, *args, **kwargs)
                finally:
                    stamps['resolver_returned'] = time.monotonic()
                    resolver_returned.set()

            patch.setattr(aiohttp.connector, 'DefaultResolver', aiohttp.resolver.ThreadedResolver)
            patch.setattr(socket, 'getaddrinfo', held_dns)
            patch.setenv('OCU_OFFICE_DOCSERVER_URL', f'http://{held_host}:{urlsplit(origin.url).port}')

            async def one_poll():
                stop = asyncio.Event()
                loop = asyncio.get_running_loop()
                def stop_after_reap():
                    loop.call_soon_threadsafe(stop.set)
                with pytest.MonkeyPatch.context() as tick:
                    tick.setattr(app, 'startup_idle_sweep', lambda: None)
                    tick.setattr(app, 'validate_idle_configuration', lambda: (600, 0.001))
                    tick.setattr(app, 'reap_known_sandboxes', stop_after_reap)
                    await app._idle_reaper(stop)

            def invoke():
                try:
                    stamps['operation_started'] = time.monotonic()
                    started.set()
                    if case == 'join':
                        results['response'] = _create(client, file_id)
                    elif case == 'close':
                        results['response'] = _close(client, session['session_id'])
                    elif case == 'save':
                        results['response'] = _save(client, session['session_id'], 'persist')
                    else:
                        asyncio.run_coroutine_threadsafe(one_poll(), service_loop).result(timeout=budget+5)
                    stamps['operation_returned'] = time.monotonic()
                except BaseException as error:
                    errors.append(type(error).__name__+': '+str(error))
                finally:
                    completed.set()

            def contend():
                try:
                    contender_started.set()
                    with docker._combined_lock(CHAT):
                        stamps['contender_acquired'] = time.monotonic()
                        acquired.set()
                except BaseException as error:
                    errors.append(type(error).__name__+': '+str(error))

            worker = threading.Thread(target=invoke)
            worker.start()
            assert started.wait(2)
            deadline = stamps['operation_started']+budget+allowance
            assert entered.wait(max(0, deadline-time.monotonic())), 'expected real resolver did not enter'
            # Independent file description checks the kernel lock without waiting.
            fd = os.open(data/CHAT/'.lifecycle.lock', os.O_RDWR)
            try:
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    lock_available_during_dns = True
                    fcntl.flock(fd, fcntl.LOCK_UN)
                except BlockingIOError:
                    lock_available_during_dns = False
            finally:
                os.close(fd)
            contender = threading.Thread(target=contend)
            contender.start()
            assert contender_started.wait(2)
            if case == 'save':
                save_lock_free_before_timeout = acquired.wait(1) and not completed.is_set()
            else:
                save_lock_free_before_timeout = None
            done_on_time = completed.wait(max(0, deadline-time.monotonic()))
            lock_free_on_time = acquired.wait(max(0, deadline-time.monotonic()))
            record.update(budget=budget, allowance=allowance, resolver_entered=True,
                          operation_completed_by_deadline=done_on_time, lock_acquired_by_deadline=lock_free_on_time,
                          lock_available_during_dns=lock_available_during_dns,
                          save_lock_free_while_pending=save_lock_free_before_timeout,
                          resolver_released_at_observation=release.is_set(),
                          resolver_returned_at_observation=resolver_returned.is_set())
            stamps['resolver_released'] = time.monotonic()
            release.set()
            worker.join(5)
            contender.join(5)
            assert not worker.is_alive() and not contender.is_alive() and resolver_returned.wait(5)
            assert not errors, errors
            after_state = OfficeStore().read(CHAT)
            after_files = _snapshot(data)
            state_path = str(_state(data).relative_to(data))
            record['nonstate_files_unchanged'] = {k:v for k,v in before_files.items() if k != state_path} == {k:v for k,v in after_files.items() if k != state_path}
            record['origin_hits_delta'] = origin.hits-before_hits
            sid = session['session_id']
            before_normal = copy.deepcopy(before_state)
            after_normal = copy.deepcopy(after_state)
            changed_fields = {'close': ('state', 'save_seq', 'pending_close_seq', 'last_activity_at'),
                              'save': ('state', 'save_seq', 'pending_save_seq', 'save_intents', 'last_activity_at', 'saving_started_at')}.get(case, ())
            for field in changed_fields:
                before_normal['sessions'][sid].pop(field, None)
                after_normal['sessions'][sid].pop(field, None)
            record['unrelated_state_unchanged'] = before_normal == after_normal
            active = after_state['sessions'][sid]
            record['state_projection'] = {k:active.get(k) for k in ('state', 'save_seq', 'pending_save_seq', 'pending_close_seq', 'save_intents')}
            if case != 'sweep':
                response = results['response']
                body = response.json()
                record['response_projection'] = {'status': response.status_code, **{k:body[k] for k in ('reason','save_seq','state') if k in body}}
            if case == 'join':
                semantics = response.status_code == 502 and body == {'reason': 'documentserver_unavailable'} and after_state == before_state
            elif case == 'close':
                semantics = response.status_code == 202 and body['state'] == 'closing' and body['save_seq'] == 1 and active['pending_close_seq'] == 1 and active['state'] == 'closing'
            elif case == 'save':
                semantics = response.status_code == 502 and body == {'reason': 'documentserver_unavailable', 'save_seq': 1} and active['state'] == 'editing' and active['pending_save_seq'] is None and active['save_seq'] == 1 and active['save_intents'] == {'1': 'persist'}
            else:
                semantics = after_state == before_state and active['state'] == 'saving' and active['pending_save_seq'] == 1
            record['caller_semantics_preserved'] = semantics
            record['accepted'] = all((done_on_time, lock_free_on_time, semantics,
                                      record['nonstate_files_unchanged'], record['unrelated_state_unchanged'],
                                      record['origin_hits_delta'] == 0,
                                      not record['resolver_released_at_observation'], not record['resolver_returned_at_observation'],
                                      lock_available_during_dns == (case == 'save'),
                                      case != 'save' or save_lock_free_before_timeout))
    finally:
        release.set()
        for owned in (worker, contender):
            if owned is not None and owned.ident is not None:
                owned.join(5)
                assert not owned.is_alive(), 'owned request/lock worker survived cleanup'
        assert not entered.is_set() or resolver_returned.wait(5), 'owned resolver survived cleanup'
        if server is not None:
            server.should_exit = True
        if server_thread is not None and server_thread.ident is not None:
            server_thread.join(10)
            assert not server_thread.is_alive(), 'owned uvicorn thread survived cleanup'
        if sock is not None:
            sock.close()
        worldgen.close()
record.update(timestamps=stamps, errors=errors, owned_workers_collected=True,
              temporary_root_removed=not Path(directory).exists(), script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              limits='Local real HTTP/poll with fixture Docker and recording origin; not LAN/DocumentServer deployment certification.')
output.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if record['accepted'] else 1)
