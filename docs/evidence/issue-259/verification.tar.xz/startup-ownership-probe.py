"""Observe supervisor ownership when Thread.start raises after actual acquisition."""
import asyncio
import hashlib
import json
from pathlib import Path
import sys
import threading

sys.path.insert(0, '/Users/danker/Documents/31308/open-computer-use/computer-use-server')
from types import SimpleNamespace
import office.save_workers as workers
from starlette.datastructures import State

output = Path(sys.argv[1])
assert not output.exists()
original = threading.Thread
owned = []
failure = RuntimeError('controlled post-acquisition startup failure')

class AcquiredStartFailure(original):
    def start(self):
        target = self._target
        captured = dict(zip(target.__code__.co_freevars, (cell.cell_contents for cell in target.__closure__)))
        owned.append((self, captured['stop']))
        super().start()
        raise failure

async def probe():
    app = SimpleNamespace(state=State())
    record = {'entered': False, 'error_identity': False}
    workers.threading.Thread = AcquiredStartFailure
    try:
        try:
            async with workers.save_worker_lifespan(app):
                record['entered'] = True
        except RuntimeError as error:
            record['error_identity'] = error is failure
        record['supervisors_acquired'] = len(owned)
        record['supervisors_alive_before_rescue'] = sum(thread.is_alive() for thread, _ in owned)
        record['admission_closed'] = getattr(app.state, 'office_save_executor', None) is None
        record['accepted'] = (not record['entered'] and record['error_identity']
                              and record['supervisors_acquired'] == 1
                              and record['supervisors_alive_before_rescue'] == 0
                              and record['admission_closed'])
    finally:
        workers.threading.Thread = original
        for thread, stop in owned:
            stop.set()
            thread.join(2)
            assert not thread.is_alive(), 'probe rescue failed'
        await asyncio.sleep(0)
    record['rescue_not_credited'] = True
    record['source_sha256'] = hashlib.sha256(Path(workers.__file__).read_bytes()).hexdigest()
    return record

record = asyncio.run(probe())
output.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if record['accepted'] else 1)
