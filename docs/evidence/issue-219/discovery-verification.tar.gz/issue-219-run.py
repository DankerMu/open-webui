import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/Users/danker/Documents/31308/open-webui-ocu-plan2')
name, *argv = sys.argv[1:]
output = Path('/tmp') / f'issue-219-{name}.command.json'
if output.exists():
    raise SystemExit(f'Refusing evidence overwrite: {output}')
env = os.environ.copy()
env['PATH'] = '/Users/danker/.nvm/versions/node/v22.23.2/bin:' + str(root / '.venv/bin') + ':' + env['PATH']
config_before = hashlib.sha256((root / 'vite.config.ts').read_bytes()).hexdigest()
started = time.time()
result = subprocess.run(argv, cwd=root, env=env, text=True, capture_output=True, timeout=1800)
record = {'argv': argv, 'exit': result.returncode, 'elapsed': time.time() - started, 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'config_sha256_before': config_before, 'config_sha256_after': hashlib.sha256((root / 'vite.config.ts').read_bytes()).hexdigest(), 'stdout': result.stdout, 'stderr': result.stderr}
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('stdout','stderr')}))
print(result.stdout[-5000:])
print(result.stderr[-2000:])
raise SystemExit(result.returncode)
