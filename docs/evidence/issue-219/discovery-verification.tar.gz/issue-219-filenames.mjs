import { pathToFileURL } from 'node:url';
import { resolve, join, relative } from 'node:path';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import assert from 'node:assert/strict';
process.env.VITEST = 'true';
const { createVitest } = await import(pathToFileURL(resolve('node_modules/vitest/dist/node.js')));
const ctx = await createVitest('test', { watch: false });
const root = await mkdtemp(join(tmpdir(), 'issue-219-filenames-'));
try {
  const expected = [];
  const excluded = [];
  for (const base of ['src', 'scripts']) {
    for (const kind of ['test', 'spec']) {
      for (const prefix of ['', 'c', 'm']) {
        for (const lang of ['js', 'ts']) {
          for (const jsx of ['', 'x']) expected.push(`${base}/nested/example.${kind}.${prefix}${lang}${jsx}`);
        }
      }
    }
    for (const dir of ['node_modules', 'dist', 'cypress', '.cache']) excluded.push(`${base}/${dir}/excluded.test.ts`);
  }
  for (const base of ['.run/local-test/build/webui/src', '.run/vps-test/build/webui/scripts', 'unrelated/build/src', 'src-copy', 'test']) excluded.push(`${base}/excluded.test.ts`);
  for (const file of [...expected, ...excluded]) {
    await mkdir(join(root, file, '..'), { recursive: true });
    await writeFile(join(root, file), "throw new Error('discovery only');\n");
  }
  const project = ctx.getCoreWorkspaceProject();
  const found = (await project.globAllTestFiles(ctx.config.include, ctx.config.exclude, undefined, root)).map(p => relative(root, p)).sort();
  const result = { expected: expected.sort(), excluded: excluded.sort(), discovered: found };
  await writeFile(process.argv[2], JSON.stringify(result, null, 2) + '\n');
  assert.deepEqual(found, expected.sort());
  console.log(`Filename compatibility: ${expected.length} supported paths included; ${excluded.length} unrelated/default-excluded paths rejected`);
} finally {
  await ctx.close();
  await rm(root, { recursive: true, force: true });
}
