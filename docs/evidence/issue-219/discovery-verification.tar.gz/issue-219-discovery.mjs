import { pathToFileURL } from 'node:url';
import { resolve, relative } from 'node:path';
import { readFile, writeFile } from 'node:fs/promises';
const [inventoryPath, resultPath, mode] = process.argv.slice(2);
const inventory = JSON.parse(await readFile(inventoryPath, 'utf8'));
process.env.VITEST = 'true';
const { createVitest } = await import(pathToFileURL(resolve('node_modules/vitest/dist/node.js')));
const options = { watch: false, ...(mode === 'coverage' ? { exclude: ['e2e/**'] } : {}) };
const ctx = await createVitest('test', options);
try {
  const discovered = (await ctx.globTestFiles()).map(([, file]) => relative(process.cwd(), file)).sort();
  const expected = [...inventory.official].sort();
  const missing = expected.filter((file) => !discovered.includes(file));
  const unexpected = discovered.filter((file) => !expected.includes(file));
  const result = { mode, discovered, expected, missing, unexpected, include: ctx.config.include, exclude: ctx.config.exclude };
  await writeFile(resultPath, JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ mode, suites: discovered.length, missing, unexpected }));
  if (missing.length || unexpected.length) process.exitCode = 1;
} finally {
  await ctx.close();
}
